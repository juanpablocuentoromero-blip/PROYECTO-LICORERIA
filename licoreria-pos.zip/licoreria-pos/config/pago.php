<?php

/*
 * Datos de cobro de la licorería (se muestran al cliente cuando elige pagar
 * por QR / transferencia). Se leen del .env para poder cambiarlos sin tocar
 * código.
 *
 * El QR es el de Yolo Pago (Banco Ganadero) y está en public/brand/qr-pago.png.
 * Es un QR ESTÁTICO: identifica la cuenta pero NO lleva el monto, por eso la
 * pantalla de pago muestra el monto exacto y la referencia del pedido.
 */
return [
    'titular' => env('PAGO_TITULAR', 'Juan Cueto Romero'),

    // Imagen del QR (relativa a /public). Vence el 01/10/2027: renovarla antes.
    'qr_imagen' => env('PAGO_QR_IMAGEN', 'brand/qr-pago.png'),
    'qr_vence' => env('PAGO_QR_VENCE', '2027-10-01'),

    // Cuentas donde puede transferir el cliente.
    'cuentas' => [
        [
            'banco' => 'Banco Ganadero',
            'tipo' => 'Yolo Pago (QR)',
            'numero' => env('PAGO_GANADERO_CUENTA', '62672037'),
            'titular' => env('PAGO_GANADERO_TITULAR', 'Juan Cueto Romero'),
        ],
        [
            'banco' => 'Banco BISA',
            'tipo' => 'Caja de ahorro',
            'numero' => env('PAGO_BISA_CUENTA', '7865374016'),
            'titular' => env('PAGO_BISA_TITULAR', 'Cueto Juan'),
        ],
    ],
];
