<?php

// 2.5 — Respaldos automáticos de la base de datos (php artisan backup:base-datos).
return [
    // Ruta del ejecutable. En Linux basta 'mysqldump'. En Windows/XAMPP suele ser
    // 'C:\\xampp\\mysql\\bin\\mysqldump.exe'.
    'mysqldump' => env('BACKUP_MYSQLDUMP_PATH', 'mysqldump'),

    // Disco (config/filesystems.php) donde queda la copia local, en el mismo servidor.
    'disco_local' => env('BACKUP_DISCO_LOCAL', 'backups'),

    // Disco de la copia FUERA del servidor (ej. 's3' para AWS S3, Backblaze B2 o
    // Cloudflare R2, o 'backups_externo' para una carpeta montada: disco USB, NAS...).
    // Si se deja vacío solo se guarda la copia local — y eso NO protege contra
    // la pérdida del servidor.
    'disco_externo' => env('BACKUP_DISCO_EXTERNO'),

    // Carpeta dentro de cada disco.
    'carpeta' => env('BACKUP_CARPETA', 'licoreria'),

    // Cuántos días se conservan los respaldos (local y externo).
    'retencion_dias' => (int) env('BACKUP_RETENCION_DIAS', 14),

    // Hora diaria (hora de Bolivia) en que corre el respaldo.
    'hora' => env('BACKUP_HORA', '03:00'),

    // Si el respaldo falla se avisa por correo a LICORERIA_ADMIN_EMAIL.
    'avisar_si_falla' => (bool) env('BACKUP_AVISAR_SI_FALLA', true),
];
