<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Cross-Origin Resource Sharing (CORS) Configuration
    |--------------------------------------------------------------------------
    |
    | Aquí configuramos qué orígenes (dominios/puertos) pueden hacer
    | peticiones a nuestra API. En desarrollo, Angular corre en el puerto
    | 4200 y Laravel en el 8000, así que son "orígenes distintos" para
    | el navegador y hay que autorizarlo explícitamente.
    |
    */

    'paths' => ['api/*', 'sanctum/csrf-cookie'],

    'allowed_methods' => ['*'],

    'allowed_origins' => [
        'http://localhost:4200',
        'http://127.0.0.1:4200',
    ],

    'allowed_origins_patterns' => [],

    'allowed_headers' => ['*'],

    'exposed_headers' => [],

    'max_age' => 0,

    // true solo si vas a usar autenticación con cookies (Sanctum SPA).
    // Si usas autenticación con Bearer Token, déjalo en false.
    'supports_credentials' => true,

];
