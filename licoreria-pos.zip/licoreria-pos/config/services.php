<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'twilio' => [
        'sid' => env('TWILIO_SID'),
        'token' => env('TWILIO_AUTH_TOKEN'),
        // Sandbox de Twilio por defecto para desarrollo/demo:
        'whatsapp_from' => env('TWILIO_WHATSAPP_FROM', 'whatsapp:+14155238886'),
    ],

    'licoreria' => [
        // Correo del dueño/administrador que recibe la notificación de cada venta.
        'admin_email' => env('LICORERIA_ADMIN_EMAIL', 'admin@licoreria.com'),
        // ID del usuario (staff) que se asigna a los pedidos hechos por
        // clientes desde la tienda online (checkout público), ya que la
        // tabla pedidos exige un usuario_id. Si se deja vacío, se usa el
        // primer administrador activo que exista.
        'usuario_pedidos_id' => env('LICORERIA_USUARIO_PEDIDOS_ID'),
        // Vigencia de los tokens de sesión (Sanctum), en minutos. Al vencer,
        // el usuario debe iniciar sesión otra vez. Staff: 12 h (un turno);
        // clientes de la tienda: 30 días.
        'token_staff_minutos' => env('TOKEN_STAFF_MINUTOS', 720),
        'token_cliente_minutos' => env('TOKEN_CLIENTE_MINUTOS', 43200),
        // Reloj del negocio: el servidor corre en UTC, pero el happy hour y los
        // vencimientos del fiado se miden en hora de Bolivia.
        'zona_horaria' => env('LICORERIA_ZONA_HORARIA', 'America/La_Paz'),
        // 4.2 Alertas: desde cuántos días antes del vencimiento se avisa, y a qué
        // WhatsApp (con código de país, ej. +59171234567) se mandan las alertas nuevas.
        'dias_alerta_vencimiento' => (int) env('LICORERIA_DIAS_ALERTA_VENCIMIENTO', 30),
        'alerta_whatsapp' => env('LICORERIA_ALERTA_WHATSAPP'),
        // Plazo del fiado cuando el cajero no indica otro (en días).
        'dias_credito_defecto' => (int) env('LICORERIA_DIAS_CREDITO', 30),
    ],

    // 6.4 Fidelización (puntos). Con 'activo' = false no se acumula ni se
    // canjea nada (los saldos ya ganados se conservan).
    'fidelizacion' => [
        'activo' => (bool) env('FIDELIZACION_ACTIVO', true),
        // Cuántos Bs pagados dan 1 punto (se redondea hacia abajo).
        'bs_por_punto' => (float) env('FIDELIZACION_BS_POR_PUNTO', 10),
        // Cuántos Bs de descuento vale 1 punto al canjear.
        'valor_punto' => (float) env('FIDELIZACION_VALOR_PUNTO', 0.50),
        // Máximo de la venta que se puede pagar con puntos (porcentaje).
        'tope_canje_pct' => (float) env('FIDELIZACION_TOPE_CANJE_PCT', 20),
        // Mínimo de puntos por canje (evita canjes de 1 punto).
        'min_puntos_canje' => (int) env('FIDELIZACION_MIN_PUNTOS_CANJE', 10),
    ],

];
