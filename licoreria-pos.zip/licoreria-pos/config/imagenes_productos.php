<?php

/*
|--------------------------------------------------------------------------
| Fotos de productos
|--------------------------------------------------------------------------
|
| Las fotos viven en frontend/public/productos/... y se sirven desde la raíz
| del sitio (por eso las rutas empiezan con /productos/).
|
| Producto::imagen usa esta tabla como RESPALDO: si el producto no tiene una
| imagen guardada en la base, se busca primero por CÓDIGO y luego por NOMBRE
| (sin tildes ni mayúsculas). Así la foto aparece aunque hayas cambiado los
| códigos por los de barras. Una imagen guardada a mano en el producto siempre
| gana sobre esta tabla.
|
| Para agregar una foto nueva: copia el archivo a frontend/public/productos/
| y agrega una línea aquí (por código y/o por nombre).
|
| "~" = referencial: misma línea del producto pero otro tamaño o envase.
|
*/

return [

    'por_codigo' => [
        'SING-0001' => '/productos/singanis/casa-real/casa-real-azul.jpg',
        'SING-0002' => '/productos/singanis/casa-real/casa-real-rojo.jpg',
        'SING-0003' => '/productos/singanis/casa-real/casa-real-negro.jpg',
        'SING-0005' => '/productos/singanis/casa-real/don-lucho.webp',
        'SING-0010' => '/productos/singanis/rujero/rujero.webp',
        'SING-0012' => '/productos/singanis/rujero/rujero.webp', // ~ referencial
        'SING-0013' => '/productos/singanis/san-pedro/san-pedro-tradicional.webp',
        'SING-0014' => '/productos/singanis/san-pedro/san-pedro-oro.webp',
        'SING-0016' => '/productos/singanis/tierra-alta/tierra-alta.webp',
        'CERV-0001' => '/productos/cervezas/pacena/pacena-620ml.png',
        'CERV-0002' => '/productos/cervezas/pacena/pacena-botellin-235ml.webp',
        'CERV-0003' => '/productos/cervezas/pacena/pacena-330ml.webp', // ~ referencial
        'CERV-0004' => '/productos/cervezas/pacena/pacena-440ml.webp', // ~ referencial
        'CERV-0006' => '/productos/cervezas/huari/huari-larger-620ml.jpg',
        'CERV-0007' => '/productos/cervezas/huari/huari-larger-440ml.jpg', // ~ referencial
        'CERV-0008' => '/productos/cervezas/huari/huari-miel-269ml.jpg',
        'CERV-0009' => '/productos/cervezas/taquina/taquina-620ml.jpg',
        'CERV-0011' => '/productos/cervezas/ducal/ducal-620.jpg',
        'CERV-0012' => '/productos/cervezas/ducal/ducal-330ml.jpg', // ~ referencial
        'CERV-0013' => '/productos/cervezas/potosina/potosina-440ml.webp', // ~ referencial
        'CERV-0014' => '/productos/cervezas/skol/skol-lata-350ml.webp',
        'CERV-0015' => '/productos/cervezas/corona/corona-355ml.jpg',
        'SODA-0001' => '/productos/sodas-locales/coka-quina/coka-quina-3l.jpg',
        'SODA-0002' => '/productos/sodas-locales/coka-quina/coka-quina-2l.jpg',
        'SODA-0003' => '/productos/sodas-locales/coka-quina/coka-quina-750.jpg',
        'SODA-0004' => '/productos/sodas-locales/coka-quina/coka-quina-330ml.jpg',
        'SODA-0012' => '/productos/sodas-internacionales/coca-cola/coca-cola-3l.webp',
        'SODA-0013' => '/productos/sodas-internacionales/coca-cola/coca-cola-2-5l-retornable.webp',
        'SODA-0014' => '/productos/sodas-internacionales/coca-cola/coca-cola-2l.webp',
        'SODA-0015' => '/productos/sodas-internacionales/coca-cola/coca-cola-2l.webp', // ~ referencial
        'SODA-0016' => '/productos/sodas-internacionales/coca-cola/coca-cola-500ml.webp',
        'SODA-0020' => '/productos/sodas-internacionales/fanta/fanta-500ml.webp',
        'SODA-0022' => '/productos/sodas-internacionales/sprite/sprite-3l.webp',
        'SODA-0023' => '/productos/sodas-internacionales/sprite/sprite-2l.webp',
        'SODA-0024' => '/productos/sodas-internacionales/sprite/sprite-500ml.webp',
        'SODA-0026' => '/productos/sodas-internacionales/pepsi/pepsi-3l.jpg',
        'SODA-0027' => '/productos/sodas-internacionales/pepsi/pepsi-2l.jpg',
        'SODA-0028' => '/productos/sodas-internacionales/pepsi/pepsi-500ml.jpg',
        'SODA-0030' => '/productos/sodas-internacionales/antartica/guarana-3l.jpg',
        'SODA-0031' => '/productos/sodas-internacionales/antartica/guarana-2l.jpg',
        'AGUA-0001' => '/productos/aguas/agua-vital/vital-2l.webp', // ~ referencial
        'AGUA-0003' => '/productos/aguas/agua-vital/vital-600ml.webp',
        'AGUA-0004' => '/productos/aguas/agua-vital/vital-6l.webp', // ~ referencial
        'AGUA-0005' => '/productos/aguas/villasanta/agua-villasanta-2l.webp',
        'WHIS-0001' => '/productos/whiskies/johnnie-walker/red-label.webp',
        'WHIS-0002' => '/productos/whiskies/johnnie-walker/black-label.webp',
        'WHIS-0003' => '/productos/whiskies/johnnie-walker/double-black.webp',
        'WHIS-0004' => '/productos/whiskies/johnnie-walker/gold-label.webp',
        'WHIS-0005' => '/productos/whiskies/johnnie-walker/blue-label.webp',
        'WHIS-0007' => '/productos/whiskies/jack-daniels/jack-daniels-tennessee-negro.webp',
        'WHIS-0008' => '/productos/whiskies/jack-daniels/jack-daniel-honey-.webp',
        'WHIS-0009' => '/productos/whiskies/jack-daniels/jack-daniels-apple.webp',
        'WHIS-0010' => '/productos/whiskies/jack-daniels/jack-daniels-tennessee-negro.webp', // ~ referencial
        'WHIS-0012' => '/productos/whiskies/chivas-regal/chivas-regal.webp',
        'WHIS-0013' => '/productos/whiskies/ballantines/ballantines-finest.png', // ~ referencial
        'WHIS-0014' => '/productos/whiskies/ballantines/ballantines-finest.png',
        'WHIS-0015' => '/productos/whiskies/grants/grants_triple.webp',
        'WHIS-0016' => '/productos/whiskies/grants/grants_triple.webp', // ~ referencial
    ],

    'por_nombre' => [
        'Casa Real Etiqueta Azul 750ml' => '/productos/singanis/casa-real/casa-real-azul.jpg',
        'Casa Real Etiqueta Roja 750ml' => '/productos/singanis/casa-real/casa-real-rojo.jpg',
        'Casa Real Etiqueta Negra 750ml' => '/productos/singanis/casa-real/casa-real-negro.jpg',
        'Casa Real Gran Singani Don Lucho 750ml' => '/productos/singanis/casa-real/don-lucho.webp',
        'Rujero Tradicional 750ml' => '/productos/singanis/rujero/rujero.webp',
        'Rujero Botella 1 Litro' => '/productos/singanis/rujero/rujero.webp', // ~ referencial
        'San Pedro Clásico/Plata 750ml' => '/productos/singanis/san-pedro/san-pedro-tradicional.webp',
        'San Pedro Oro 750ml' => '/productos/singanis/san-pedro/san-pedro-oro.webp',
        'Tierra Alta Botella 750ml' => '/productos/singanis/tierra-alta/tierra-alta.webp',
        'Paceña Botella Retornable 620cc' => '/productos/cervezas/pacena/pacena-620ml.png',
        'Paceña Paceñita 330ml' => '/productos/cervezas/pacena/pacena-botellin-235ml.webp',
        'Paceña Lata 354ml' => '/productos/cervezas/pacena/pacena-330ml.webp', // ~ referencial
        'Paceña Lata 473ml' => '/productos/cervezas/pacena/pacena-440ml.webp', // ~ referencial
        'Huari Botella Retornable 620cc' => '/productos/cervezas/huari/huari-larger-620ml.jpg',
        'Huari Lata 354ml' => '/productos/cervezas/huari/huari-larger-440ml.jpg', // ~ referencial
        'Huari Sabores (Miel/Chocolate/Quinua)' => '/productos/cervezas/huari/huari-miel-269ml.jpg',
        'Taquiña Botella Retornable 620cc' => '/productos/cervezas/taquina/taquina-620ml.jpg',
        'Ducal Botella Retornable 620cc' => '/productos/cervezas/ducal/ducal-620.jpg',
        'Ducal Lata 354ml' => '/productos/cervezas/ducal/ducal-330ml.jpg', // ~ referencial
        'Potosina Lata 473ml' => '/productos/cervezas/potosina/potosina-440ml.webp', // ~ referencial
        'Cerveza Skol Lata 354ml' => '/productos/cervezas/skol/skol-lata-350ml.webp',
        'Corona Porrón 355ml' => '/productos/cervezas/corona/corona-355ml.jpg',
        'Coka Quina Botella 3 Litros' => '/productos/sodas-locales/coka-quina/coka-quina-3l.jpg',
        'Coka Quina Botella 2 Litros' => '/productos/sodas-locales/coka-quina/coka-quina-2l.jpg',
        'Coka Quina Botella 750ml' => '/productos/sodas-locales/coka-quina/coka-quina-750.jpg',
        'Coka Quina Botella 330ml' => '/productos/sodas-locales/coka-quina/coka-quina-330ml.jpg',
        'Coca-Cola Botella 3L' => '/productos/sodas-internacionales/coca-cola/coca-cola-3l.webp',
        'Coca-Cola Botella 2.5L' => '/productos/sodas-internacionales/coca-cola/coca-cola-2-5l-retornable.webp',
        'Coca-Cola Botella 2L' => '/productos/sodas-internacionales/coca-cola/coca-cola-2l.webp',
        'Coca-Cola Botella 1.5L' => '/productos/sodas-internacionales/coca-cola/coca-cola-2l.webp', // ~ referencial
        'Coca-Cola Botella 500ml' => '/productos/sodas-internacionales/coca-cola/coca-cola-500ml.webp',
        'Fanta Botella 500ml' => '/productos/sodas-internacionales/fanta/fanta-500ml.webp',
        'Sprite Botella 3L' => '/productos/sodas-internacionales/sprite/sprite-3l.webp',
        'Sprite Botella 2L' => '/productos/sodas-internacionales/sprite/sprite-2l.webp',
        'Sprite Botella 500ml' => '/productos/sodas-internacionales/sprite/sprite-500ml.webp',
        'Pepsi Botella 3 Litros' => '/productos/sodas-internacionales/pepsi/pepsi-3l.jpg',
        'Pepsi Botella 2 Litros' => '/productos/sodas-internacionales/pepsi/pepsi-2l.jpg',
        'Pepsi Botella 500ml' => '/productos/sodas-internacionales/pepsi/pepsi-500ml.jpg',
        'Guaraná Antarctica Botella 3 Litros' => '/productos/sodas-internacionales/antartica/guarana-3l.jpg',
        'Guaraná Antarctica Botella 2 Litros' => '/productos/sodas-internacionales/antartica/guarana-2l.jpg',
        'Vital Botella 2.5L' => '/productos/aguas/agua-vital/vital-2l.webp', // ~ referencial
        'Vital Botella 600ml' => '/productos/aguas/agua-vital/vital-600ml.webp',
        'Vital Bidón 5 Litros' => '/productos/aguas/agua-vital/vital-6l.webp', // ~ referencial
        'Villa Santa Botella 2L' => '/productos/aguas/villasanta/agua-villasanta-2l.webp',
        'Johnnie Walker Red Label 750ml' => '/productos/whiskies/johnnie-walker/red-label.webp',
        'Johnnie Walker Black Label 1L' => '/productos/whiskies/johnnie-walker/black-label.webp',
        'Johnnie Walker Double Black 750ml' => '/productos/whiskies/johnnie-walker/double-black.webp',
        'Johnnie Walker Gold Label 750ml' => '/productos/whiskies/johnnie-walker/gold-label.webp',
        'Johnnie Walker Blue Label 750ml' => '/productos/whiskies/johnnie-walker/blue-label.webp',
        'Jack Daniel\'s Old No. 7 750ml' => '/productos/whiskies/jack-daniels/jack-daniels-tennessee-negro.webp',
        'Jack Daniel\'s Honey 750ml' => '/productos/whiskies/jack-daniels/jack-daniel-honey-.webp',
        'Jack Daniel\'s Apple 750ml' => '/productos/whiskies/jack-daniels/jack-daniels-apple.webp',
        'Jack Daniel\'s Botella 1 Litro' => '/productos/whiskies/jack-daniels/jack-daniels-tennessee-negro.webp', // ~ referencial
        'Chivas Regal 18 Años 750ml' => '/productos/whiskies/chivas-regal/chivas-regal.webp',
        'Ballantine\'s Botella 750ml' => '/productos/whiskies/ballantines/ballantines-finest.png', // ~ referencial
        'Ballantine\'s Botella 1 Litro' => '/productos/whiskies/ballantines/ballantines-finest.png',
        'Grant\'s Botella 750ml' => '/productos/whiskies/grants/grants_triple.webp',
        'Grant\'s Botella 1 Litro' => '/productos/whiskies/grants/grants_triple.webp', // ~ referencial
    ],

];
