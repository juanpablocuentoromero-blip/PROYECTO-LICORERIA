# Licorería POS

Sistema de punto de venta e inventario para licorería (con módulos de farmacia), compuesto por:

- **Backend:** Laravel 12 (PHP 8.2+) con API REST y autenticación por tokens.
- **Frontend:** Angular 22 (carpeta `frontend/`).
- **Base de datos:** MySQL (XAMPP en desarrollo).

## Módulos principales

Ventas (POS), cierre de caja, caja chica, inventario por almacén, productos con código de barras y combos, proveedores y compras, clientes con NIT/CI, facturación, delivery, cuentas por cobrar, promociones y verificación de edad.

## Requisitos

- PHP 8.2 o superior y Composer
- Node.js 20+ y npm
- MySQL / XAMPP

## Instalación del backend

```bash
composer install
cp .env.example .env
php artisan key:generate
```

Crea la base de datos `licoreria_al_paso` en MySQL, revisa los datos `DB_*` de tu `.env` y ejecuta:

```bash
php artisan migrate
php artisan db:seed
php artisan db:seed --class=PreciosBoliviaSeeder   # precios referenciales y cajas/paquetes
php artisan serve                                   # http://localhost:8000
```

## Instalación del frontend

```bash
cd frontend
npm install
npm start                                           # http://localhost:4200
```

La URL del API está en `frontend/src/environments/environment.ts` (`apiUrl`). Para producción usa `environment.prod.ts`.

## Configuración (.env)

Copia `.env.example` a `.env` y completa tus valores. **Nunca subas el archivo `.env` a GitHub.**
Variables propias del proyecto: `LICORERIA_ADMIN_EMAIL`, `LICORERIA_DIAS_ALERTA_VENCIMIENTO`, `LICORERIA_ALERTA_WHATSAPP` y las credenciales de Twilio (`TWILIO_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_WHATSAPP_FROM`) para las alertas por WhatsApp.

## Usuarios de prueba

El seeder crea usuarios de ejemplo con contraseñas simples (ver `database/seeders/DatabaseSeeder.php`). **Cámbialas antes de usar el sistema con datos reales.**

## Pruebas

```bash
php artisan test
```

## Notas

Los precios cargados por los seeders son referenciales: ajústalos con tus facturas de proveedor desde el módulo Productos. El historial de cambios previo está en `docs/CAMBIOS.md`.
