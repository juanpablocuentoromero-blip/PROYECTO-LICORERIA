# Cambios (aplicar sobre tu proyecto)

1. Copia estos archivos respetando las rutas.
2. Backend:   php artisan migrate
              php artisan db:seed --class=PreciosBoliviaSeeder   (precios y cajas/paquetes)
3. Frontend:  reinicia `ng serve`.

Precios: son REFERENCIALES. Ajústalos a tus facturas de proveedor desde Productos.
