<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;

class Cliente extends Authenticatable
{
    use HasApiTokens;

    protected $table = 'clientes';

    // 'password' y 'remember_token' son opcionales a propósito: un cliente
    // creado a mano por el personal (venta en mostrador, sin cuenta) no
    // tiene password hasta que se registra por su cuenta en la tienda.
    // 'nit_ci' es el documento con el que el mostrador identifica al
    // cliente; "0" es el cliente genérico "SIN NOMBRE".
    protected $fillable = [
        'nombre', 'nit_ci', 'telefono', 'email', 'direccion', 'activo', 'password',
        'mayor_edad_confirmada_at', 'credito_habilitado', 'limite_credito',
    ];

    // 'puntos_saldo' NO es fillable a propósito: solo cambia a través de
    // FidelizacionService (que deja el movimiento en el libro de puntos).

    protected $casts = [
        'mayor_edad_confirmada_at' => 'datetime',
        'credito_habilitado' => 'boolean',
    ];

    protected $hidden = ['password', 'remember_token'];

    public function pedidos()
    {
        return $this->hasMany(Pedido::class);
    }

    public function abonos()
    {
        return $this->hasMany(Abono::class);
    }

    public function puntosMovimientos()
    {
        return $this->hasMany(PuntosMovimiento::class);
    }

    public function tieneCuenta(): bool
    {
        return ! empty($this->password);
    }
}
