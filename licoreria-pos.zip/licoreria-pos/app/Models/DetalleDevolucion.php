<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetalleDevolucion extends Model
{
    protected $table = 'detalle_devoluciones';

    protected $fillable = ['devolucion_id', 'detalle_pedido_id', 'producto_id', 'cantidad', 'monto'];

    public function devolucion()
    {
        return $this->belongsTo(Devolucion::class);
    }

    public function detallePedido()
    {
        return $this->belongsTo(DetallePedido::class);
    }

    public function producto()
    {
        return $this->belongsTo(Producto::class)->withTrashed();
    }
}
