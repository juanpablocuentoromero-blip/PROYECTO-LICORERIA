<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Alerta extends Model
{
    protected $table = 'alertas';

    protected $fillable = [
        'tipo', 'producto_id', 'severidad', 'titulo', 'mensaje', 'activa', 'leida', 'leida_at',
    ];

    protected $casts = [
        'activa' => 'boolean',
        'leida' => 'boolean',
        'leida_at' => 'datetime',
    ];

    public function producto()
    {
        return $this->belongsTo(Producto::class)->withTrashed();
    }
}
