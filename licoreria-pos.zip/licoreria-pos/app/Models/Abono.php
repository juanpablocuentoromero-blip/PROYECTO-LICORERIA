<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Abono extends Model
{
    protected $table = 'abonos';

    protected $fillable = [
        'pedido_id', 'cliente_id', 'usuario_id', 'caja_id', 'monto', 'metodo_pago', 'observaciones',
        'anulado', 'anulado_at', 'motivo_anulacion', 'usuario_anulacion_id',
    ];

    protected $casts = [
        'monto' => 'decimal:2',
        'anulado' => 'boolean',
        'anulado_at' => 'datetime',
    ];

    public function pedido()
    {
        return $this->belongsTo(Pedido::class);
    }

    public function cliente()
    {
        return $this->belongsTo(Cliente::class);
    }

    public function usuario()
    {
        return $this->belongsTo(Usuario::class);
    }

    public function caja()
    {
        return $this->belongsTo(Caja::class);
    }
}
