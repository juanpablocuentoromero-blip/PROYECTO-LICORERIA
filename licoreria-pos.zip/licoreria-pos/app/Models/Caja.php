<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Caja extends Model
{
    protected $table = 'cajas';

    protected $fillable = [
        'almacen_id', 'usuario_apertura_id', 'usuario_cierre_id', 'cerrada_por_nombre',
        'monto_apertura', 'monto_ventas_efectivo', 'monto_ventas_qr', 'monto_ventas_tarjeta',
        'monto_ventas_total', 'monto_abonos_efectivo', 'monto_abonos_qr', 'monto_abonos_tarjeta',
        'monto_ventas_credito', 'monto_devoluciones_efectivo', 'monto_devoluciones_total',
        'cantidad_devoluciones', 'cantidad_ventas', 'cantidad_anuladas', 'monto_anulado',
        'detalle_vendedores', 'monto_ingresos_caja_chica',
        'monto_egresos_caja_chica', 'monto_cierre_esperado', 'monto_cierre_real',
        'diferencia', 'estado', 'observaciones', 'observaciones_cierre',
        'abierta_at', 'cerrada_at',
    ];

    protected $casts = [
        'abierta_at' => 'datetime',
        'cerrada_at' => 'datetime',
        'detalle_vendedores' => 'array',
    ];

    public function almacen()
    {
        return $this->belongsTo(Almacen::class);
    }

    public function usuarioApertura()
    {
        return $this->belongsTo(Usuario::class, 'usuario_apertura_id');
    }

    public function usuarioCierre()
    {
        return $this->belongsTo(Usuario::class, 'usuario_cierre_id');
    }

    public function movimientosCajaChica()
    {
        return $this->hasMany(MovimientoCajaChica::class);
    }
}
