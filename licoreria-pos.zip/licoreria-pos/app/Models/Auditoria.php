<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Auditoria extends Model
{
    protected $table = 'auditorias';

    public $timestamps = false; // solo created_at (lo pone la base)

    protected $fillable = [
        'usuario_id', 'usuario_nombre', 'accion', 'entidad', 'entidad_id',
        'descripcion', 'campo', 'valor_anterior', 'valor_nuevo',
    ];

    protected $casts = ['created_at' => 'datetime'];
}
