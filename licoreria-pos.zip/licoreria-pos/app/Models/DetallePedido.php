<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetallePedido extends Model
{
    protected $table = 'detalle_pedidos';

    protected $fillable = [
        'pedido_id', 'producto_id', 'cantidad', 'presentacion', 'cantidad_presentacion', 'precio_unitario', 'precio_compra', 'precio_venta', 'descuento',
        'descuento_promocion', 'promocion_aplicada', 'subtotal',
    ];

    public function pedido()
    {
        return $this->belongsTo(Pedido::class);
    }

    public function producto()
    {
        return $this->belongsTo(Producto::class);
    }
}
