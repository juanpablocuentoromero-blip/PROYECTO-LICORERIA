<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ZonaDelivery extends Model
{
    protected $table = 'zonas_delivery';

    protected $fillable = ['nombre', 'costo_envio', 'descripcion', 'activo'];

    protected $casts = [
        'costo_envio' => 'decimal:2',
        'activo' => 'boolean',
    ];
}
