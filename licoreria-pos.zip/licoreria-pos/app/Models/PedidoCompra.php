<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PedidoCompra extends Model
{
    protected $table = 'pedidos_compra';

    protected $fillable = [
        'proveedor_id', 'usuario_id', 'estado', 'subtotal', 'total', 'observaciones', 'recibido_at',
    ];

    protected $casts = [
        'recibido_at' => 'datetime',
    ];

    public function proveedor()
    {
        return $this->belongsTo(Proveedor::class);
    }

    public function usuario()
    {
        return $this->belongsTo(Usuario::class);
    }

    public function detalles()
    {
        return $this->hasMany(DetallePedidoCompra::class);
    }
}
