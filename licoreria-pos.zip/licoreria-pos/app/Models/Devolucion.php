<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Devolucion extends Model
{
    protected $table = 'devoluciones';

    protected $fillable = [
        'pedido_id', 'usuario_id', 'caja_id', 'total', 'aplicado_a_saldo',
        'monto_reembolsado', 'metodo_reembolso', 'motivo',
    ];

    public function pedido()
    {
        return $this->belongsTo(Pedido::class);
    }

    public function usuario()
    {
        return $this->belongsTo(Usuario::class);
    }

    public function detalles()
    {
        return $this->hasMany(DetalleDevolucion::class);
    }

    // Número de la nota de crédito: NC-000012
    public function nroNota(): string
    {
        return 'NC-'.str_pad((string) $this->id, 6, '0', STR_PAD_LEFT);
    }
}
