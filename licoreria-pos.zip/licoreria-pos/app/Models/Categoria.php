<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Categoria extends Model
{
    protected $table = 'categorias';

    protected $fillable = ['nombre', 'descripcion', 'activo'];

    public function productos()
    {
        return $this->hasMany(Producto::class);
    }
}
