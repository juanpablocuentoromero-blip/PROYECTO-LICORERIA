<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Proveedor extends Model
{
    protected $table = 'proveedores';

    protected $fillable = ['nombre', 'contacto', 'telefono', 'email', 'direccion', 'activo'];

    public function pedidosCompra()
    {
        return $this->hasMany(PedidoCompra::class);
    }
}
