<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Combo extends Model
{
    protected $table = 'combos';

    protected $fillable = ['producto_id', 'nombre', 'descripcion', 'precio', 'activo'];

    // El producto "vitrina" que representa este combo en el catálogo/POS.
    public function producto()
    {
        return $this->belongsTo(Producto::class);
    }

    public function items()
    {
        return $this->hasMany(ComboItem::class);
    }

    // Cuánto stock del combo se puede vender ahora mismo, calculado a partir
    // de sus componentes: el cuello de botella es el componente que rinda
    // menos combos completos. Nunca se lee de una columna propia, siempre
    // se recalcula contra el stock real de los productos que lo componen.
    public function stockDisponible(): int
    {
        $disponible = null;

        foreach ($this->items as $item) {
            $unidadesPosibles = intdiv($item->producto->stock, $item->cantidad);
            $disponible = $disponible === null ? $unidadesPosibles : min($disponible, $unidadesPosibles);
        }

        return $disponible ?? 0;
    }
}
