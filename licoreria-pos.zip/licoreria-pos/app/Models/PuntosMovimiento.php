<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PuntosMovimiento extends Model
{
    protected $table = 'puntos_movimientos';

    protected $fillable = [
        'cliente_id', 'pedido_id', 'usuario_id', 'tipo', 'puntos', 'saldo_despues', 'descripcion',
    ];

    protected $casts = [
        'puntos' => 'integer',
        'saldo_despues' => 'integer',
    ];

    public function cliente()
    {
        return $this->belongsTo(Cliente::class);
    }

    public function pedido()
    {
        return $this->belongsTo(Pedido::class);
    }

    public function usuario()
    {
        return $this->belongsTo(Usuario::class);
    }
}
