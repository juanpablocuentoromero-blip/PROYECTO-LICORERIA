<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Producto extends Model
{
    use SoftDeletes;

    protected $table = 'productos';

    protected $fillable = [
        'categoria_id', 'codigo', 'codigo_barras', 'unidades_por_paquete', 'unidades_por_caja',
        'nombre', 'descripcion', 'imagen',
        'precio_compra', 'precio_venta', 'margen_porcentaje', 'stock', 'stock_minimo',
        'fecha_vencimiento', 'activo',
    ];

    // Foto del producto. Si no hay una guardada en la base, se usa la tabla
    // config/imagenes_productos.php (por código y luego por nombre).
    public function getImagenAttribute($value): ?string
    {
        if ($value) {
            return $value;
        }

        return self::imagenPorDefecto($this->attributes['codigo'] ?? null, $this->attributes['nombre'] ?? null);
    }

    private static ?array $mapaImagenesPorNombre = null;

    public static function imagenPorDefecto(?string $codigo, ?string $nombre): ?string
    {
        $config = config('imagenes_productos', []);

        if ($codigo && isset($config['por_codigo'][$codigo])) {
            return $config['por_codigo'][$codigo];
        }

        if ($nombre) {
            self::$mapaImagenesPorNombre ??= collect($config['por_nombre'] ?? [])
                ->mapWithKeys(fn ($ruta, $n) => [self::normalizarNombre($n) => $ruta])
                ->all();

            return self::$mapaImagenesPorNombre[self::normalizarNombre($nombre)] ?? null;
        }

        return null;
    }

    private static function normalizarNombre(string $nombre): string
    {
        return preg_replace('/\s+/', ' ', trim(Str::lower(Str::ascii($nombre))));
    }

    public function categoria()
    {
        return $this->belongsTo(Categoria::class);
    }

    public function movimientos()
    {
        return $this->hasMany(MovimientoInventario::class);
    }

    public function detallePedidos()
    {
        return $this->hasMany(DetallePedido::class);
    }

    public function stockPorAlmacen()
    {
        return $this->hasMany(StockPorAlmacen::class);
    }

    public function lotes()
    {
        return $this->hasMany(LoteProducto::class);
    }

    // Precio de venta sugerido a partir del costo y del margen (%) del
    // producto. Devuelve null si el producto no tiene margen configurado.
    public static function precioDesdeMargen(float $costo, ?float $margenPorcentaje): ?float
    {
        if ($margenPorcentaje === null) {
            return null;
        }

        return round($costo * (1 + $margenPorcentaje / 100), 2);
    }

    // Si este producto es el "vitrina" de un combo/promoción, esto lo
    // devuelve (null si es un producto normal). Se usa en el flujo de venta
    // para descontar stock de los componentes en vez del propio.
    public function combo()
    {
        return $this->hasOne(Combo::class);
    }

    // Único punto del sistema que debe mover stock. Ajusta la cantidad en
    // el almacén indicado (positivo entra, negativo sale) y mantiene
    // productos.stock como caché del total en todos los almacenes, para
    // que el resto del código (listados, exportes, stock_minimo) siga
    // leyendo $producto->stock sin enterarse de que ahora hay almacenes.
    // Devuelve el nuevo stock TOTAL (no el del almacén).
    public function ajustarStock(int $delta, int $almacenId): int
    {
        $registro = StockPorAlmacen::lockForUpdate()
            ->firstOrCreate(
                ['producto_id' => $this->id, 'almacen_id' => $almacenId],
                ['cantidad' => 0]
            );

        $nuevaCantidad = $registro->cantidad + $delta;

        if ($nuevaCantidad < 0) {
            abort(422, "Stock insuficiente en el almacén seleccionado para el producto: {$this->nombre}");
        }

        $registro->update(['cantidad' => $nuevaCantidad]);
        $this->increment('stock', $delta);

        // Si el producto maneja lotes, lo que sale se descuenta primero del
        // lote que vence antes (FEFO). Las devoluciones/anulaciones que
        // reponen stock no vuelven a ningún lote en particular.
        if ($delta < 0) {
            $this->consumirLotes(-$delta, $almacenId);
        }

        return $this->stock;
    }

    // Descuenta $cantidad de los lotes del almacén, primero los que vencen
    // antes (los que no tienen fecha van al final). Si los lotes no cubren
    // todo (stock anterior a los lotes), el resto simplemente no tiene lote.
    protected function consumirLotes(int $cantidad, int $almacenId): void
    {
        $lotes = LoteProducto::where('producto_id', $this->id)
            ->where('almacen_id', $almacenId)
            ->where('cantidad_disponible', '>', 0)
            ->orderByRaw('fecha_vencimiento IS NULL')
            ->orderBy('fecha_vencimiento')
            ->orderBy('id')
            ->lockForUpdate()
            ->get();

        if ($lotes->isEmpty()) {
            return;
        }

        foreach ($lotes as $lote) {
            if ($cantidad <= 0) {
                break;
            }

            $tomar = min($cantidad, (int) $lote->cantidad_disponible);
            $lote->update(['cantidad_disponible' => $lote->cantidad_disponible - $tomar]);
            $cantidad -= $tomar;
        }

        $this->sincronizarVencimiento();
    }

    // Deja productos.fecha_vencimiento en el vencimiento más próximo entre
    // los lotes que todavía tienen unidades. Si el producto no tiene lotes,
    // no toca la fecha que se haya cargado a mano.
    public function sincronizarVencimiento(): void
    {
        if (! LoteProducto::where('producto_id', $this->id)->exists()) {
            return;
        }

        $proximo = LoteProducto::where('producto_id', $this->id)
            ->where('cantidad_disponible', '>', 0)
            ->whereNotNull('fecha_vencimiento')
            ->min('fecha_vencimiento');

        $this->forceFill(['fecha_vencimiento' => $proximo])->saveQuietly();
    }
}
