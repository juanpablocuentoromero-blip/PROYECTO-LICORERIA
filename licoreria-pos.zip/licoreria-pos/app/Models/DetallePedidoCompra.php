<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetallePedidoCompra extends Model
{
    protected $table = 'detalle_pedidos_compra';

    protected $fillable = [
        'pedido_compra_id', 'producto_id', 'cantidad', 'cantidad_paquetes', 'unidades_por_paquete',
        'precio_paquete', 'precio_unitario', 'subtotal', 'numero_lote', 'fecha_vencimiento',
    ];

    public function pedidoCompra()
    {
        return $this->belongsTo(PedidoCompra::class);
    }

    public function producto()
    {
        return $this->belongsTo(Producto::class);
    }
}
