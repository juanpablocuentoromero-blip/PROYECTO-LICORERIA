<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pedido extends Model
{
    protected $table = 'pedidos';

    protected $fillable = [
        'cliente_id', 'usuario_id', 'origen', 'almacen_id', 'caja_id', 'estado',
        'direccion_entrega', 'telefono_contacto', 'metodo_pago', 'tipo_venta', 'nro_factura',
        'subtotal', 'descuento', 'total', 'monto_devuelto', 'observaciones',
        'pagado', 'pagado_at', 'referencia_pago',
        'anulada', 'anulada_at', 'motivo_anulacion', 'usuario_anulacion_id',
        // 5.1 verificación de edad
        'mayor_edad_confirmada',
        // 5.2 delivery
        'tipo_entrega', 'zona_delivery_id', 'costo_envio', 'repartidor_id', 'en_camino_at',
        // 5.3 cuentas por cobrar (fiado)
        'saldo_pendiente', 'fecha_vencimiento_credito',
        // 5.4 promociones
        'cupon_codigo',
        // 6.4 fidelización
        'puntos_ganados', 'puntos_canjeados', 'descuento_puntos',
    ];

    protected $casts = [
        'pagado' => 'boolean',
        'pagado_at' => 'datetime',
        'anulada' => 'boolean',
        'anulada_at' => 'datetime',
        'mayor_edad_confirmada' => 'boolean',
        'en_camino_at' => 'datetime',
        'fecha_vencimiento_credito' => 'date',
    ];

    public function cliente()
    {
        return $this->belongsTo(Cliente::class);
    }

    public function usuario()
    {
        return $this->belongsTo(Usuario::class);
    }

    public function usuarioAnulacion()
    {
        return $this->belongsTo(Usuario::class, 'usuario_anulacion_id');
    }

    public function almacen()
    {
        return $this->belongsTo(Almacen::class);
    }

    public function caja()
    {
        return $this->belongsTo(Caja::class);
    }

    public function detalles()
    {
        return $this->hasMany(DetallePedido::class);
    }

    public function zonaDelivery()
    {
        return $this->belongsTo(ZonaDelivery::class, 'zona_delivery_id');
    }

    public function repartidor()
    {
        return $this->belongsTo(Repartidor::class);
    }

    public function abonos()
    {
        return $this->hasMany(Abono::class);
    }

    // 4.6 — cómo se pagó (una fila por método; vacío en ventas anteriores a pagos mixtos).
    public function pagos()
    {
        return $this->hasMany(PagoVenta::class);
    }

    // 4.5 — notas de crédito emitidas sobre esta venta.
    public function devoluciones()
    {
        return $this->hasMany(Devolucion::class);
    }

    // Reparto del cobro por método: [metodo => monto]. Usa pagos_venta y, en
    // ventas viejas (o pedidos online) que no tienen filas ahí, el método único
    // del pedido por su total.
    public function pagosPorMetodo(): array
    {
        $pagos = $this->relationLoaded('pagos') ? $this->pagos : $this->pagos()->get();

        if ($pagos->isEmpty()) {
            return [$this->metodo_pago => round((float) $this->total, 2)];
        }

        return $pagos->groupBy('metodo_pago')
            ->map(fn ($g) => round((float) $g->sum('monto'), 2))
            ->all();
    }

    // Número que se muestra en pantalla/tickets: el fiscal si hay factura,
    // o el interno S/F-000012 si es nota de venta.
    public function nroDocumento(): string
    {
        return $this->nro_factura ?: 'S/F-'.str_pad((string) $this->id, 6, '0', STR_PAD_LEFT);
    }

    // Venta a crédito (fiado): se cobra después, en uno o varios abonos.
    public function esCredito(): bool
    {
        return $this->metodo_pago === 'credito';
    }
}
