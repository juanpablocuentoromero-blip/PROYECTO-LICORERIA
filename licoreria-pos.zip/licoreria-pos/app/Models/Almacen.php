<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Almacen extends Model
{
    protected $table = 'almacenes';

    protected $fillable = [
        'nombre', 'direccion', 'es_principal', 'activo',
    ];

    protected $casts = [
        'es_principal' => 'boolean',
        'activo' => 'boolean',
    ];

    // Se cachea en memoria por request: casi todas las operaciones de stock
    // (ventas, compras, movimientos manuales) todavía no dejan elegir
    // almacén desde el frontend y caen aquí por defecto.
    protected static ?int $principalIdCache = null;

    public static function principalId(): int
    {
        return static::$principalIdCache ??= static::where('es_principal', true)->value('id')
            ?? throw new \RuntimeException('No hay un almacén marcado como principal. Contacta al administrador.');
    }

    public function stocks()
    {
        return $this->hasMany(StockPorAlmacen::class);
    }

    public function movimientos()
    {
        return $this->hasMany(MovimientoInventario::class);
    }
}
