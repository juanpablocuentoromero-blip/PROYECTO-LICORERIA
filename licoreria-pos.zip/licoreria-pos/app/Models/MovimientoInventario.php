<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MovimientoInventario extends Model
{
    protected $table = 'movimientos_inventario';

    public $timestamps = false; // solo tiene created_at, no updated_at

    protected $fillable = [
        'producto_id', 'almacen_id', 'usuario_id', 'tipo', 'cantidad',
        'stock_resultante', 'motivo', 'es_ajuste',
    ];

    protected $casts = [
        'es_ajuste' => 'boolean',
    ];

    public function producto()
    {
        return $this->belongsTo(Producto::class);
    }

    public function usuario()
    {
        return $this->belongsTo(Usuario::class);
    }

    public function almacen()
    {
        return $this->belongsTo(Almacen::class);
    }
}
