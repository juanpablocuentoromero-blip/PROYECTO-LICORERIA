<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MovimientoCajaChica extends Model
{
    protected $table = 'movimientos_caja_chica';

    protected $fillable = [
        'caja_id', 'almacen_id', 'usuario_id', 'cuenta', 'tipo',
        'metodo_pago', 'nro_documento', 'concepto', 'monto',
    ];

    public function caja()
    {
        return $this->belongsTo(Caja::class);
    }

    public function almacen()
    {
        return $this->belongsTo(Almacen::class);
    }

    public function usuario()
    {
        return $this->belongsTo(Usuario::class);
    }
}
