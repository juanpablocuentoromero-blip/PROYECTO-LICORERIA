<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PagoVenta extends Model
{
    protected $table = 'pagos_venta';

    protected $fillable = ['pedido_id', 'caja_id', 'metodo_pago', 'monto'];

    public function pedido()
    {
        return $this->belongsTo(Pedido::class);
    }
}
