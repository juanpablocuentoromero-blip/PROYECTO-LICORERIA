<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LoteProducto extends Model
{
    protected $table = 'lotes_producto';

    protected $fillable = [
        'producto_id', 'almacen_id', 'pedido_compra_id', 'numero_lote',
        'fecha_vencimiento', 'cantidad_inicial', 'cantidad_disponible', 'costo_unitario',
    ];

    protected $casts = [
        'fecha_vencimiento' => 'date:Y-m-d',
    ];

    public function producto()
    {
        return $this->belongsTo(Producto::class);
    }

    public function almacen()
    {
        return $this->belongsTo(Almacen::class);
    }

    public function pedidoCompra()
    {
        return $this->belongsTo(PedidoCompra::class);
    }
}
