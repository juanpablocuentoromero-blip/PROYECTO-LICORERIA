<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TokenRecuperacionPassword extends Model
{
    public $timestamps = false;

    protected $table = 'tokens_recuperacion_password';

    protected $fillable = ['email', 'tipo', 'token', 'created_at'];

    protected $casts = [
        'created_at' => 'datetime',
    ];
}
