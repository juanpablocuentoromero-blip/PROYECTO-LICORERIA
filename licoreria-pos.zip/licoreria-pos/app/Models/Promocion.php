<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Promocion extends Model
{
    protected $table = 'promociones';

    protected $fillable = [
        'nombre', 'tipo', 'alcance', 'categoria_id', 'producto_id',
        'tipo_descuento', 'valor',
        'cantidad_minima', 'hora_inicio', 'hora_fin', 'dias_semana',
        'codigo', 'usos_maximos', 'usos_actuales',
        'fecha_inicio', 'fecha_fin', 'activo',
    ];

    protected $casts = [
        'valor' => 'decimal:2',
        'activo' => 'boolean',
        'cantidad_minima' => 'integer',
        'usos_maximos' => 'integer',
        'usos_actuales' => 'integer',
        'fecha_inicio' => 'date:Y-m-d',
        'fecha_fin' => 'date:Y-m-d',
    ];

    public function categoria()
    {
        return $this->belongsTo(Categoria::class);
    }

    public function producto()
    {
        return $this->belongsTo(Producto::class);
    }
}
