<?php

namespace App\Services;

use App\Models\Cliente;
use App\Models\Devolucion;
use App\Models\Pedido;
use App\Models\PuntosMovimiento;
use Illuminate\Support\Facades\DB;

/**
 * 6.4 — Programa de puntos.
 *
 * Reglas (configurables en config/services.php → 'fidelizacion'):
 *  - Se gana 1 punto por cada `bs_por_punto` Bs PAGADOS (total de la venta,
 *    ya con descuentos y con el canje descontado), redondeado hacia abajo.
 *  - Solo clientes identificados (NIT/CI distinto de 0) y activos.
 *  - Las ventas a crédito no acumulan (el dinero aún no se cobró).
 *  - 1 punto vale `valor_punto` Bs al canjear, hasta `tope_canje_pct` % del
 *    total y desde `min_puntos_canje` puntos.
 *  - Anular una venta devuelve los puntos canjeados y quita los ganados.
 *  - Una devolución parcial quita los puntos en proporción a lo devuelto.
 *
 * Todo movimiento queda en `puntos_movimientos` (libro firmado con el saldo
 * resultante). Los métodos que escriben bloquean la fila del cliente: dos
 * cajas simultáneas no pueden gastar los mismos puntos dos veces.
 * Llamarlos DENTRO de la transacción de la venta.
 */
class FidelizacionService
{
    public function activo(): bool
    {
        return (bool) config('services.fidelizacion.activo', true);
    }

    public function configuracion(): array
    {
        return [
            'activo' => $this->activo(),
            'bs_por_punto' => (float) config('services.fidelizacion.bs_por_punto', 10),
            'valor_punto' => (float) config('services.fidelizacion.valor_punto', 0.5),
            'tope_canje_pct' => (float) config('services.fidelizacion.tope_canje_pct', 20),
            'min_puntos_canje' => (int) config('services.fidelizacion.min_puntos_canje', 10),
        ];
    }

    // Participan los clientes identificados: con NIT/CI (mostrador) o con
    // cuenta propia en la tienda. El genérico "SIN NOMBRE" (NIT 0) no.
    public function esElegible(Cliente $cliente): bool
    {
        $nit = trim((string) $cliente->nit_ci);
        $identificado = ($nit !== '' && $nit !== '0') || $cliente->tieneCuenta();

        return $cliente->activo && $identificado;
    }

    public function puntosPorMonto(float $monto): int
    {
        $bsPorPunto = (float) config('services.fidelizacion.bs_por_punto', 10);

        return $bsPorPunto > 0 ? (int) floor(round($monto, 2) / $bsPorPunto) : 0;
    }

    public function valorDePuntos(int $puntos): float
    {
        return round($puntos * (float) config('services.fidelizacion.valor_punto', 0.5), 2);
    }

    // Máximo de puntos que este cliente puede canjear en una venta de $total.
    public function maximoCanjeable(Cliente $cliente, float $total): int
    {
        $valor = (float) config('services.fidelizacion.valor_punto', 0.5);
        $tope = (float) config('services.fidelizacion.tope_canje_pct', 20);

        if ($valor <= 0 || ! $this->activo() || ! $this->esElegible($cliente)) {
            return 0;
        }

        $porTope = (int) floor(round($total * $tope / 100, 2) / $valor);
        $max = max(0, min((int) $cliente->puntos_saldo, $porTope));

        return $max >= (int) config('services.fidelizacion.min_puntos_canje', 10) ? $max : 0;
    }

    /**
     * Valida un canje y devuelve [puntos, descuento]. Bloquea al cliente:
     * el saldo que se valida es el real, no uno leído antes.
     */
    public function prepararCanje(Cliente $cliente, int $puntos, float $total): array
    {
        if (! $this->activo()) {
            abort(422, 'El programa de puntos está desactivado.');
        }

        if (! $this->esElegible($cliente)) {
            abort(422, 'Para canjear puntos identifique al cliente con su NIT/CI (no puede ser «SIN NOMBRE»).');
        }

        $cliente = Cliente::lockForUpdate()->findOrFail($cliente->id);
        $min = (int) config('services.fidelizacion.min_puntos_canje', 10);

        if ($puntos < $min) {
            abort(422, "El canje mínimo es de {$min} puntos.");
        }

        if ($puntos > (int) $cliente->puntos_saldo) {
            abort(422, "El cliente solo tiene {$cliente->puntos_saldo} punto(s) disponibles.");
        }

        $descuento = $this->valorDePuntos($puntos);
        $tope = (float) config('services.fidelizacion.tope_canje_pct', 20);
        $maxBs = round($total * $tope / 100, 2);

        if ($descuento > $maxBs + 0.009) {
            $maxPuntos = (int) floor($maxBs / max((float) config('services.fidelizacion.valor_punto', 0.5), 0.01));
            abort(422, sprintf(
                'Con puntos se puede pagar como máximo el %s%% de la venta (Bs %.2f = %d puntos).',
                rtrim(rtrim(number_format($tope, 2, '.', ''), '0'), '.'), $maxBs, $maxPuntos
            ));
        }

        return [$puntos, $descuento];
    }

    /**
     * Reparte $descuento entre líneas en proporción a su importe, al centavo
     * y sin perder ni inventar nada (la última línea con importe absorbe el
     * redondeo). Así subtotal de líneas == total y las devoluciones y el
     * reporte de rentabilidad ven el descuento por puntos como cualquier otro.
     *
     * @param  array<int|string, float>  $netos  importe de cada línea
     * @return array<int|string, float>
     */
    public function repartirDescuento(array $netos, float $descuento): array
    {
        $suma = round(array_sum($netos), 2);
        $reparto = array_fill_keys(array_keys($netos), 0.0);

        if ($suma <= 0 || $descuento <= 0) {
            return $reparto;
        }

        $conImporte = array_keys(array_filter($netos, fn ($n) => $n > 0));
        $ultima = end($conImporte);
        $acumulado = 0.0;

        foreach ($conImporte as $k) {
            if ($k === $ultima) {
                $reparto[$k] = round($descuento - $acumulado, 2);
                break;
            }
            $parte = round($descuento * $netos[$k] / $suma, 2);
            $reparto[$k] = $parte;
            $acumulado = round($acumulado + $parte, 2);
        }

        return $reparto;
    }

    // ------------------------------------------------------------------
    // Movimientos
    // ------------------------------------------------------------------

    public function registrarCanje(Pedido $venta, Cliente $cliente, int $puntos): void
    {
        $this->mover($cliente, 'canje', -$puntos, $venta->id, null,
            "Canje en venta #{$venta->id}");
    }

    // Acumula los puntos de una venta cobrada. Idempotente: no suma dos veces.
    public function acumularVenta(Pedido $venta): int
    {
        if (! $this->activo()) {
            return 0;
        }

        return DB::transaction(function () use ($venta) {
            $venta = Pedido::lockForUpdate()->findOrFail($venta->id);
            $cliente = $venta->cliente;

            if (
                ! $cliente || ! $this->esElegible($cliente)
                || $venta->anulada || ! $venta->pagado || $venta->esCredito()
                || $venta->puntos_ganados > 0
                || PuntosMovimiento::where('pedido_id', $venta->id)->where('tipo', 'acumulo')->exists()
            ) {
                return 0;
            }

            $puntos = $this->puntosPorMonto((float) $venta->total);

            if ($puntos > 0) {
                $this->mover($cliente, 'acumulo', $puntos, $venta->id, null,
                    "Compra #{$venta->id} (Bs ".number_format((float) $venta->total, 2).')');
                $venta->forceFill(['puntos_ganados' => $puntos])->save();
            }

            return $puntos;
        });
    }

    // Anulación completa: devuelve lo canjeado y quita lo ganado. Idempotente.
    public function revertirVenta(Pedido $venta, ?int $usuarioId = null): void
    {
        $cliente = $venta->cliente;

        if (! $cliente) {
            return;
        }

        $yaRevertido = PuntosMovimiento::where('pedido_id', $venta->id)
            ->whereIn('tipo', ['reverso_acumulo', 'reverso_canje'])->exists();

        if ($yaRevertido) {
            return;
        }

        $ganados = (int) PuntosMovimiento::where('pedido_id', $venta->id)->where('tipo', 'acumulo')->sum('puntos');
        $canjeados = (int) PuntosMovimiento::where('pedido_id', $venta->id)->where('tipo', 'canje')->sum('puntos'); // negativo
        $yaPorDevolucion = (int) PuntosMovimiento::where('pedido_id', $venta->id)->where('tipo', 'reverso_devolucion')->sum('puntos'); // negativo

        $descripcion = "Anulación de venta #{$venta->id}";

        if ($canjeados < 0) {
            $this->mover($cliente, 'reverso_canje', -$canjeados, $venta->id, $usuarioId, $descripcion);
        }

        $quitar = $ganados + $yaPorDevolucion; // lo que sigue "vivo" del acumulado
        if ($quitar > 0) {
            $this->mover($cliente, 'reverso_acumulo', -$quitar, $venta->id, $usuarioId, $descripcion);
        }
    }

    // Devolución parcial: quita puntos en proporción a lo devuelto hasta ahora.
    // Llamar DESPUÉS de actualizar pedidos.monto_devuelto.
    public function revertirDevolucion(Pedido $venta, Devolucion $devolucion): void
    {
        $cliente = $venta->cliente;
        $ganados = (int) PuntosMovimiento::where('pedido_id', $venta->id)->where('tipo', 'acumulo')->sum('puntos');

        if (! $cliente || $ganados <= 0 || (float) $venta->total <= 0) {
            return;
        }

        $fraccion = min(1.0, (float) $venta->monto_devuelto / (float) $venta->total);
        $objetivo = (int) round($ganados * $fraccion);
        $yaQuitado = -(int) PuntosMovimiento::where('pedido_id', $venta->id)->where('tipo', 'reverso_devolucion')->sum('puntos');
        $quitar = $objetivo - $yaQuitado;

        if ($quitar > 0) {
            $this->mover($cliente, 'reverso_devolucion', -$quitar, $venta->id, $devolucion->usuario_id,
                "Devolución {$devolucion->nroNota()} de venta #{$venta->id}");
        }
    }

    // Ajuste manual del administrador (corrección, cortesía, etc.).
    public function ajustar(Cliente $cliente, int $puntos, string $motivo, ?int $usuarioId): PuntosMovimiento
    {
        return DB::transaction(function () use ($cliente, $puntos, $motivo, $usuarioId) {
            return $this->mover($cliente, 'ajuste', $puntos, null, $usuarioId, $motivo);
        });
    }

    public function resumen(Cliente $cliente, int $limite = 30): array
    {
        $cliente = $cliente->fresh();

        return [
            'cliente_id' => $cliente->id,
            'saldo' => (int) $cliente->puntos_saldo,
            'equivale_a' => $this->valorDePuntos(max(0, (int) $cliente->puntos_saldo)),
            'configuracion' => $this->configuracion(),
            'movimientos' => $cliente->puntosMovimientos()->latest('id')->limit($limite)->get()
                ->map(fn (PuntosMovimiento $m) => [
                    'id' => $m->id,
                    'tipo' => $m->tipo,
                    'puntos' => $m->puntos,
                    'saldo_despues' => $m->saldo_despues,
                    'pedido_id' => $m->pedido_id,
                    'descripcion' => $m->descripcion,
                    'fecha' => $m->created_at?->format('d/m/Y H:i'),
                ])->values(),
        ];
    }

    private function mover(Cliente $cliente, string $tipo, int $puntos, ?int $pedidoId, ?int $usuarioId, ?string $descripcion): PuntosMovimiento
    {
        $bloqueado = Cliente::lockForUpdate()->findOrFail($cliente->id);
        $nuevoSaldo = (int) $bloqueado->puntos_saldo + $puntos;

        $bloqueado->forceFill(['puntos_saldo' => $nuevoSaldo])->save();
        $cliente->puntos_saldo = $nuevoSaldo;

        return PuntosMovimiento::create([
            'cliente_id' => $bloqueado->id,
            'pedido_id' => $pedidoId,
            'usuario_id' => $usuarioId,
            'tipo' => $tipo,
            'puntos' => $puntos,
            'saldo_despues' => $nuevoSaldo,
            'descripcion' => $descripcion,
        ]);
    }
}
