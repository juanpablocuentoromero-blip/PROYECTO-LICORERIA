<?php

namespace App\Services;

use Illuminate\Http\Request;
use Laravel\Sanctum\PersonalAccessToken;

/**
 * Valida el token Bearer de una petición contra la tabla
 * personal_access_tokens (Laravel Sanctum).
 *
 * Los tokens se guardan HASHEADOS (sha256): en la base solo queda el hash,
 * el token en texto plano existe únicamente en el navegador del usuario. Si
 * alguien copia la base de datos, no puede usar esos tokens.
 *
 * Staff (Usuario) y clientes (Cliente) comparten la tabla, así que aquí se
 * exige que el token pertenezca al TIPO de cuenta que la ruta espera. Sin
 * ese chequeo, un token de cliente podría abrir rutas del panel.
 */
class TokenAcceso
{
    /**
     * @param  class-string  $claseCuenta  Usuario::class o Cliente::class
     */
    public static function resolver(Request $request, string $claseCuenta): ?PersonalAccessToken
    {
        $plano = $request->bearerToken();

        if (! $plano) {
            return null;
        }

        $token = PersonalAccessToken::findToken($plano);

        if (! $token) {
            return null;
        }

        if ($token->expires_at && $token->expires_at->isPast()) {
            $token->delete();

            return null;
        }

        // Si la cuenta fue eliminada (soft delete) tokenable viene null.
        $cuenta = $token->tokenable;

        if (! ($cuenta instanceof $claseCuenta) || ! $cuenta->activo) {
            return null;
        }

        // last_used_at se refresca cada 5 min como máximo: el panel consulta
        // pedidos nuevos cada 20 s y no vale la pena escribir en la base en
        // cada petición.
        if (! $token->last_used_at || $token->last_used_at->lt(now()->subMinutes(5))) {
            $token->forceFill(['last_used_at' => now()])->save();
        }

        return $token;
    }
}
