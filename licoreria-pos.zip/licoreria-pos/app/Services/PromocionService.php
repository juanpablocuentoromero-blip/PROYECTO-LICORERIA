<?php

namespace App\Services;

use App\Models\Combo;
use App\Models\Producto;
use App\Models\Promocion;
use Carbon\Carbon;

/**
 * Motor de descuentos y promociones con reglas (tarea 5.4).
 *
 * Tipos de promoción (tabla `promociones`):
 *  - volumen : "llevando N o más" (cantidad_minima).
 *  - horario : happy hour, por franja horaria y días de la semana.
 *  - cupon   : solo aplica si quien vende/compra escribe el código.
 *
 * Cómo se combinan (reglas deliberadamente simples y predecibles):
 *  1. Las promociones AUTOMÁTICAS (volumen y horario) no se acumulan entre
 *     sí: en cada línea gana la que más descuenta.
 *  2. El CUPÓN sí se suma, pero calculado sobre lo que queda de la línea
 *     después de la promoción automática (así nunca se descuenta dos veces
 *     el mismo importe ni se supera el 100 %).
 *  3. Los combos no reciben promociones: ya tienen su precio especial.
 *  4. El descuento manual que escribe el cajero se respeta y se descuenta
 *     primero; las promociones se calculan sobre el resto.
 *
 * Nada de lo que calcula este servicio viene del navegador: los precios y
 * categorías se leen siempre de la base de datos.
 */
class PromocionService
{
    /**
     * @param  array<int, array{producto_id:int, categoria_id:int, cantidad:int, base:float, es_combo?:bool}>  $lineas
     *         Indexadas por producto_id. `base` = importe de la línea menos el
     *         descuento manual (lo que todavía se puede descontar).
     * @return array{
     *     lineas: array<int, array{descuento: float, etiqueta: ?string}>,
     *     cupon: ?array{id:int, codigo:string, nombre:string, descuento:float},
     *     cupon_error: ?string,
     *     total: float
     * }
     */
    public function calcular(array $lineas, ?string $codigoCupon = null): array
    {
        $ahora = $this->ahora();

        $resultado = [];
        foreach ($lineas as $id => $linea) {
            $resultado[$id] = ['auto' => 0.0, 'cupon' => 0.0, 'etiquetas' => []];
        }

        // ---- 1) Promociones automáticas: gana la mejor por línea. ----
        $automaticas = Promocion::where('activo', true)
            ->whereIn('tipo', ['volumen', 'horario'])
            ->get()
            ->filter(fn (Promocion $p) => $this->vigente($p, $ahora));

        $mejorPorLinea = [];
        foreach ($automaticas as $promo) {
            foreach ($this->descuentosDe($promo, $lineas) as $id => $monto) {
                if ($monto > ($resultado[$id]['auto'] ?? 0.0)) {
                    $resultado[$id]['auto'] = $monto;
                    $mejorPorLinea[$id] = $promo->nombre;
                }
            }
        }

        foreach ($mejorPorLinea as $id => $nombre) {
            $resultado[$id]['etiquetas'][] = $nombre;
        }

        // ---- 2) Cupón: se suma sobre lo que quedó de cada línea. ----
        $cupon = null;
        $cuponError = null;
        $codigoCupon = $this->normalizarCodigo($codigoCupon);

        if ($codigoCupon !== null) {
            $promoCupon = Promocion::where('tipo', 'cupon')->where('codigo', $codigoCupon)->first();

            if (! $promoCupon || ! $promoCupon->activo) {
                $cuponError = 'El cupón «'.$codigoCupon.'» no existe o no está activo.';
            } elseif (! $this->vigenteFechas($promoCupon, $ahora)) {
                $cuponError = 'El cupón «'.$codigoCupon.'» no está vigente.';
            } elseif ($promoCupon->usos_maximos !== null && $promoCupon->usos_actuales >= $promoCupon->usos_maximos) {
                $cuponError = 'El cupón «'.$codigoCupon.'» ya alcanzó su límite de usos.';
            } else {
                $restantes = [];
                foreach ($lineas as $id => $linea) {
                    $restantes[$id] = $linea;
                    $restantes[$id]['base'] = round(max(0.0, $linea['base'] - $resultado[$id]['auto']), 2);
                }

                $descuentosCupon = $this->descuentosDe($promoCupon, $restantes);
                $totalCupon = round(array_sum($descuentosCupon), 2);

                if ($totalCupon <= 0) {
                    $cuponError = 'El cupón «'.$codigoCupon.'» no aplica a los productos de esta compra.';
                } else {
                    foreach ($descuentosCupon as $id => $monto) {
                        if ($monto > 0) {
                            $resultado[$id]['cupon'] = $monto;
                            $resultado[$id]['etiquetas'][] = 'Cupón '.$promoCupon->codigo;
                        }
                    }

                    $cupon = [
                        'id' => $promoCupon->id,
                        'codigo' => $promoCupon->codigo,
                        'nombre' => $promoCupon->nombre,
                        'descuento' => $totalCupon,
                    ];
                }
            }
        }

        // ---- 3) Resultado final por línea. ----
        $salida = [];
        $total = 0.0;

        foreach ($resultado as $id => $r) {
            $descuento = round(min($r['auto'] + $r['cupon'], $lineas[$id]['base']), 2);
            $salida[$id] = [
                'descuento' => $descuento,
                'etiqueta' => $r['etiquetas'] ? implode(' + ', $r['etiquetas']) : null,
            ];
            $total = round($total + $descuento, 2);
        }

        return [
            'lineas' => $salida,
            'cupon' => $cupon,
            'cupon_error' => $cuponError,
            'total' => $total,
        ];
    }

    /**
     * Atajo para las pantallas (vista previa): arma las líneas a partir de
     * producto+cantidad(+descuento manual), leyendo precio y categoría de la
     * base. Devuelve lo mismo que calcular().
     *
     * @param  array<int, array{producto_id:int, cantidad:int, descuento?:float|int|null}>  $items
     */
    public function calcularParaItems(array $items, ?string $codigoCupon = null): array
    {
        $agrupados = [];
        foreach ($items as $item) {
            $id = (int) $item['producto_id'];
            $agrupados[$id] ??= ['cantidad' => 0, 'descuento' => 0.0];
            $agrupados[$id]['cantidad'] += (int) $item['cantidad'];
            $agrupados[$id]['descuento'] += (float) ($item['descuento'] ?? 0);
        }

        $productos = Producto::whereIn('id', array_keys($agrupados))->get()->keyBy('id');
        $combos = $this->idsDeCombos(array_keys($agrupados));

        $lineas = [];
        foreach ($agrupados as $id => $datos) {
            $producto = $productos->get($id);
            if (! $producto) {
                continue;
            }

            $bruto = round((float) $producto->precio_venta * $datos['cantidad'], 2);
            $lineas[$id] = [
                'producto_id' => $id,
                'categoria_id' => (int) $producto->categoria_id,
                'cantidad' => $datos['cantidad'],
                'base' => round(max(0.0, $bruto - $datos['descuento']), 2),
                'es_combo' => in_array($id, $combos, true),
            ];
        }

        return $this->calcular($lineas, $codigoCupon);
    }

    /** IDs (de la lista dada) que son productos "vitrina" de un combo. */
    public function idsDeCombos(array $productoIds): array
    {
        if ($productoIds === []) {
            return [];
        }

        return Combo::whereIn('producto_id', $productoIds)->pluck('producto_id')->map(fn ($v) => (int) $v)->all();
    }

    /**
     * Suma una vez más al contador de usos del cupón. Se llama DENTRO de la
     * transacción de la venta, con bloqueo: dos ventas simultáneas no pueden
     * gastar el último uso disponible a la vez.
     */
    public function consumirCupon(int $promocionId): void
    {
        $promo = Promocion::lockForUpdate()->find($promocionId);

        if (! $promo || ($promo->usos_maximos !== null && $promo->usos_actuales >= $promo->usos_maximos)) {
            abort(422, 'El cupón ya alcanzó su límite de usos.');
        }

        $promo->increment('usos_actuales');
    }

    public function normalizarCodigo(?string $codigo): ?string
    {
        $codigo = strtoupper(trim((string) $codigo));

        return $codigo === '' ? null : $codigo;
    }

    // ------------------------------------------------------------------
    // Internos
    // ------------------------------------------------------------------

    /** "Ahora" en la zona horaria del negocio (el servidor corre en UTC). */
    private function ahora(): Carbon
    {
        return now(config('services.licoreria.zona_horaria', 'America/La_Paz'));
    }

    private function vigente(Promocion $promo, Carbon $ahora): bool
    {
        if (! $this->vigenteFechas($promo, $ahora)) {
            return false;
        }

        if ($promo->tipo === 'horario') {
            return $this->dentroDeHorario($promo, $ahora);
        }

        return true; // volumen: sin restricción horaria
    }

    private function vigenteFechas(Promocion $promo, Carbon $ahora): bool
    {
        $hoy = $ahora->toDateString();

        if ($promo->fecha_inicio && $hoy < $promo->fecha_inicio->toDateString()) {
            return false;
        }

        if ($promo->fecha_fin && $hoy > $promo->fecha_fin->toDateString()) {
            return false;
        }

        return true;
    }

    private function dentroDeHorario(Promocion $promo, Carbon $ahora): bool
    {
        $minutosAhora = $ahora->hour * 60 + $ahora->minute;
        $inicio = $this->aMinutos($promo->hora_inicio);
        $fin = $this->aMinutos($promo->hora_fin);

        if ($inicio === null || $fin === null) {
            return false; // una promo de horario sin franja no debe aplicarse nunca
        }

        // Franja que cruza medianoche (ej. 22:00 a 02:00).
        $cruzaMedianoche = $inicio > $fin;

        $enFranja = $cruzaMedianoche
            ? ($minutosAhora >= $inicio || $minutosAhora < $fin)
            : ($minutosAhora >= $inicio && $minutosAhora < $fin);

        if (! $enFranja) {
            return false;
        }

        // Sin días definidos = todos los días. Después de medianoche, en una
        // franja que cruza, el "día" de la promo es el de ayer (cuando empezó).
        $dias = $this->listaDias($promo->dias_semana);
        if ($dias === []) {
            return true;
        }

        $diaReferencia = ($cruzaMedianoche && $minutosAhora < $fin)
            ? $ahora->copy()->subDay()->dayOfWeek
            : $ahora->dayOfWeek;

        return in_array($diaReferencia, $dias, true);
    }

    private function aMinutos(?string $hora): ?int
    {
        if (! $hora || ! preg_match('/^(\d{1,2}):(\d{2})/', $hora, $m)) {
            return null;
        }

        return (int) $m[1] * 60 + (int) $m[2];
    }

    /** "1,2,3" -> [1,2,3] (0 = domingo … 6 = sábado). */
    private function listaDias(?string $dias): array
    {
        if (! $dias) {
            return [];
        }

        return collect(explode(',', $dias))
            ->map(fn ($d) => trim($d))
            ->filter(fn ($d) => $d !== '' && ctype_digit($d))
            ->map(fn ($d) => (int) $d)
            ->values()
            ->all();
    }

    /**
     * Descuento que esta promoción da a cada línea (por producto_id).
     * Solo aparecen las líneas que reciben algo (> 0).
     *
     * @return array<int, float>
     */
    private function descuentosDe(Promocion $promo, array $lineas): array
    {
        $elegibles = array_filter($lineas, fn (array $l) => $this->aplicaALinea($promo, $l));

        if ($elegibles === []) {
            return [];
        }

        // Volumen: la cantidad mínima se mide sobre el total de unidades
        // elegibles (para alcance "producto" es la cantidad de ese producto;
        // para "categoría" o "todo", la suma de las líneas que entran).
        if ($promo->tipo === 'volumen') {
            $unidades = array_sum(array_column($elegibles, 'cantidad'));

            if ($promo->cantidad_minima === null || $unidades < $promo->cantidad_minima) {
                return [];
            }
        }

        $baseTotal = round(array_sum(array_column($elegibles, 'base')), 2);
        if ($baseTotal <= 0) {
            return [];
        }

        $valor = (float) $promo->valor;
        $resultado = [];

        if ($promo->tipo_descuento === 'porcentaje') {
            $pct = min(max($valor, 0.0), 100.0);

            foreach ($elegibles as $id => $linea) {
                $resultado[$id] = round($linea['base'] * $pct / 100, 2);
            }
        } else {
            // Monto fijo: se descuenta UNA vez el valor (sin pasarse de lo
            // que hay) y se reparte proporcional al importe de cada línea.
            $totalADescontar = round(min(max($valor, 0.0), $baseTotal), 2);
            $repartido = 0.0;
            $ultimoId = array_key_last($elegibles);

            foreach ($elegibles as $id => $linea) {
                if ($id === $ultimoId) {
                    // El último absorbe el redondeo para que la suma sea exacta.
                    $parte = round($totalADescontar - $repartido, 2);
                } else {
                    $parte = round($totalADescontar * $linea['base'] / $baseTotal, 2);
                }

                $parte = min($parte, $linea['base']);
                $resultado[$id] = $parte;
                $repartido = round($repartido + $parte, 2);
            }
        }

        return array_filter($resultado, fn ($monto) => $monto > 0);
    }

    private function aplicaALinea(Promocion $promo, array $linea): bool
    {
        if (! empty($linea['es_combo'])) {
            return false; // los combos no entran en promociones
        }

        return match ($promo->alcance) {
            'producto' => (int) $promo->producto_id === (int) $linea['producto_id'],
            'categoria' => (int) $promo->categoria_id === (int) $linea['categoria_id'],
            default => true, // 'todo'
        };
    }
}
