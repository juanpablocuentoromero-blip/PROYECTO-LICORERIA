<?php

namespace App\Services;

use App\Jobs\EnviarWhatsapp;
use App\Models\Alerta;
use App\Models\Combo;
use App\Models\LoteProducto;
use App\Models\Producto;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

/**
 * 4.2 — Alertas de stock mínimo y de vencimiento.
 *
 * Hay a lo sumo UNA alerta por producto y tipo. Cada revisión:
 *  - crea la alerta de los productos que ahora cumplen la condición,
 *  - actualiza el mensaje de los que ya la tenían (si empeoró, vuelve a "no leída"),
 *  - marca como resueltas (activa = false) las que ya no aplican.
 *
 * Solo las alertas NUEVAS (o que empeoraron / reaparecieron) disparan el aviso
 * por correo y WhatsApp, para no mandar el mismo mensaje todos los días.
 */
class AlertaService
{
    public function __construct(private WhatsappService $whatsapp)
    {
    }

    /** Días antes del vencimiento en que empieza a avisar. */
    public function diasAvisoVencimiento(): int
    {
        return (int) config('services.licoreria.dias_alerta_vencimiento', 30);
    }

    /** Días en que el aviso de vencimiento pasa a "crítica". */
    private const DIAS_CRITICOS = 7;

    /**
     * Revisa productos y deja las alertas al día.
     *
     * @return array{nuevas: Alerta[], resueltas: int, activas: int}
     */
    public function revisar(bool $notificar = false): array
    {
        $hoy = Carbon::now(config('services.licoreria.zona_horaria', 'America/La_Paz'))->startOfDay();
        $nuevas = [];
        $vigentes = []; // ["tipo|producto_id" => true]

        // Las "vitrinas" de combos no llevan stock propio: se miden por sus componentes.
        $idsCombo = Combo::pluck('producto_id')->all();

        $productos = Producto::where('activo', true)->whereNotIn('id', $idsCombo)->get();

        // Si el producto maneja lotes, el vencimiento que importa es el del
        // lote más próximo que todavía tiene unidades; si no, la fecha que
        // tenga cargada el propio producto.
        $vencimientoPorLote = LoteProducto::where('cantidad_disponible', '>', 0)
            ->whereNotNull('fecha_vencimiento')
            ->selectRaw('producto_id, MIN(fecha_vencimiento) as vence')
            ->groupBy('producto_id')
            ->pluck('vence', 'producto_id');

        foreach ($productos as $p) {
            // --- stock mínimo ---
            if ((int) $p->stock <= (int) $p->stock_minimo) {
                $agotado = (int) $p->stock <= 0;
                $alerta = $this->guardar(
                    'stock_minimo', $p,
                    $agotado ? 'critica' : 'aviso',
                    $agotado ? "Agotado: {$p->nombre}" : "Stock bajo: {$p->nombre}",
                    $agotado
                        ? "Sin stock (mínimo configurado: {$p->stock_minimo})."
                        : "Quedan {$p->stock} unidades (mínimo configurado: {$p->stock_minimo}).",
                );
                $vigentes["stock_minimo|{$p->id}"] = true;
                if ($alerta) {
                    $nuevas[] = $alerta;
                }
            }

            // --- vencimiento ---
            $fechaVence = $vencimientoPorLote[$p->id] ?? $p->fecha_vencimiento;

            if ($fechaVence && (int) $p->stock > 0) {
                $vence = Carbon::parse($fechaVence, $hoy->timezone)->startOfDay();
                $dias = (int) $hoy->diffInDays($vence, false); // negativo = ya venció

                if ($dias <= $this->diasAvisoVencimiento()) {
                    $vencido = $dias < 0;
                    $texto = $vencido
                        ? 'Venció hace '.abs($dias).' día'.(abs($dias) === 1 ? '' : 's')
                        : ($dias === 0 ? 'Vence hoy' : "Vence en {$dias} día".($dias === 1 ? '' : 's'));

                    $alerta = $this->guardar(
                        'vencimiento', $p,
                        ($vencido || $dias <= self::DIAS_CRITICOS) ? 'critica' : 'aviso',
                        ($vencido ? 'Vencido: ' : 'Por vencer: ').$p->nombre,
                        "{$texto} ({$vence->format('d/m/Y')}). Stock actual: {$p->stock}.",
                    );
                    $vigentes["vencimiento|{$p->id}"] = true;
                    if ($alerta) {
                        $nuevas[] = $alerta;
                    }
                }
            }
        }

        // Resolver las que ya no aplican (se repuso el stock, se vendió el lote, etc.).
        $resueltas = 0;
        Alerta::where('activa', true)->get()->each(function (Alerta $a) use ($vigentes, &$resueltas) {
            if (! isset($vigentes["{$a->tipo}|{$a->producto_id}"])) {
                $a->update(['activa' => false]);
                $resueltas++;
            }
        });

        if ($notificar && count($nuevas) > 0) {
            $this->notificar($nuevas);
        }

        return [
            'nuevas' => $nuevas,
            'resueltas' => $resueltas,
            'activas' => Alerta::where('activa', true)->count(),
        ];
    }

    /**
     * Crea o actualiza la alerta. Devuelve la alerta solo si es "noticia":
     * nueva, reactivada o que subió de aviso a crítica.
     */
    private function guardar(string $tipo, Producto $producto, string $severidad, string $titulo, string $mensaje): ?Alerta
    {
        $alerta = Alerta::where('tipo', $tipo)->where('producto_id', $producto->id)->first();

        if (! $alerta) {
            return Alerta::create([
                'tipo' => $tipo, 'producto_id' => $producto->id, 'severidad' => $severidad,
                'titulo' => $titulo, 'mensaje' => $mensaje,
            ]);
        }

        $esNoticia = ! $alerta->activa || ($severidad === 'critica' && $alerta->severidad !== 'critica');

        $alerta->fill([
            'severidad' => $severidad, 'titulo' => $titulo, 'mensaje' => $mensaje, 'activa' => true,
        ]);

        if ($esNoticia) {
            $alerta->leida = false;
            $alerta->leida_at = null;
        }

        $alerta->save();

        return $esNoticia ? $alerta : null;
    }

    private function notificar(array $nuevas): void
    {
        $lineas = collect($nuevas)->map(fn (Alerta $a) => ($a->severidad === 'critica' ? '🔴 ' : '🟠 ')."{$a->titulo} — {$a->mensaje}");

        $texto = "Licorería Al Paso — alertas de inventario\n\n".$lineas->implode("\n");

        $correo = config('services.licoreria.admin_email');
        if ($correo) {
            try {
                Mail::raw($texto, fn ($m) => $m->to($correo)->subject('Alertas de inventario: '.count($nuevas).' nueva(s)'));
            } catch (\Throwable $e) {
                Log::error('AlertaService: no se pudo enviar el correo de alertas', ['error' => $e->getMessage()]);
            }
        }

        $telefono = config('services.licoreria.alerta_whatsapp');
        if ($telefono) {
            try {
                // WhatsApp tiene tope de largo: se resumen las primeras 15.
                $resumen = $lineas->take(15)->implode("\n").($lineas->count() > 15 ? "\n… y ".($lineas->count() - 15).' más.' : '');
                // 2.4: sale desde la cola, no dentro del botón "Revisar ahora" ni del cron.
                EnviarWhatsapp::dispatch($telefono, "Licorería Al Paso — alertas de inventario\n\n{$resumen}");
            } catch (\Throwable $e) {
                Log::error('AlertaService: no se pudo enviar el WhatsApp de alertas', ['error' => $e->getMessage()]);
            }
        }
    }
}
