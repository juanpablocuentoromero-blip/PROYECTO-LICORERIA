<?php

namespace App\Services;

use App\Models\Auditoria;
use Illuminate\Database\Eloquent\Model;

/**
 * 4.4 — Registro de auditoría: quién cambió precios, usuarios o inventario,
 * cuándo, y el valor anterior y nuevo de cada campo.
 *
 * El usuario sale de la sesión (request->attributes), nunca del body, para que
 * el rastro refleje quién lo hizo realmente.
 */
class AuditoriaService
{
    public function registrar(
        string $accion,
        string $entidad,
        ?int $entidadId,
        string $descripcion,
        ?string $campo = null,
        mixed $anterior = null,
        mixed $nuevo = null,
    ): void {
        $usuario = request()?->attributes->get('usuario_autenticado');

        Auditoria::create([
            'usuario_id' => $usuario?->id,
            'usuario_nombre' => $usuario?->nombre,
            'accion' => $accion,
            'entidad' => $entidad,
            'entidad_id' => $entidadId,
            'descripcion' => mb_substr($descripcion, 0, 255),
            'campo' => $campo,
            'valor_anterior' => $this->texto($anterior),
            'valor_nuevo' => $this->texto($nuevo),
        ]);
    }

    /**
     * Compara $antes (arreglo con los valores previos) con el modelo ya
     * actualizado y registra una fila por cada campo vigilado que cambió.
     */
    public function registrarCambios(string $entidad, Model $modelo, array $antes, array $campos, string $descripcion): void
    {
        foreach ($campos as $campo) {
            $anterior = $antes[$campo] ?? null;
            $nuevo = $modelo->getAttribute($campo);

            if ($this->texto($anterior) === $this->texto($nuevo)) {
                continue;
            }

            $this->registrar('actualizar', $entidad, $modelo->getKey(), $descripcion, $campo, $anterior, $nuevo);
        }
    }

    private function texto(mixed $valor): ?string
    {
        if ($valor === null) {
            return null;
        }

        if (is_bool($valor)) {
            return $valor ? 'sí' : 'no';
        }

        if ($valor instanceof \DateTimeInterface) {
            return $valor->format('Y-m-d');
        }

        // Los decimales de la base llegan como "12.50" y los del request como
        // 12.5: se normalizan para no registrar un "cambio" que no existe.
        if (is_numeric($valor)) {
            return (string) (float) $valor;
        }

        return (string) $valor;
    }
}
