<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Envío de WhatsApp usando la API de Twilio, llamada directamente por HTTP
 * (sin el SDK de Twilio, para no agregar una dependencia de Composer extra).
 *
 * IMPORTANTE - alcance académico:
 * Twilio ofrece un "sandbox" de WhatsApp gratuito para desarrollo. Cada
 * número que deba recibir mensajes tiene que "unirse" al sandbox una sola
 * vez, enviando la palabra clave que Twilio indique (ej. "join palabra-clave")
 * al número del sandbox por WhatsApp. Fuera de un número unido al sandbox,
 * Twilio no entrega el mensaje.
 *
 * Para producción real (enviar a cualquier cliente sin ese paso previo) se
 * necesita un número de WhatsApp Business verificado por Meta, lo cual
 * implica un proceso de aprobación y costo que está fuera del alcance de
 * este proyecto de grado. Esto se documenta como trabajo futuro.
 */
class WhatsappService
{
    private ?string $accountSid;
    private ?string $authToken;
    private ?string $numeroDesde; // Formato: 'whatsapp:+14155238886' (sandbox) o el número de negocio aprobado

    public function __construct()
    {
        $this->accountSid = config('services.twilio.sid');
        $this->authToken = config('services.twilio.token');
        $this->numeroDesde = config('services.twilio.whatsapp_from');
    }

    public function habilitado(): bool
    {
        return filled($this->accountSid) && filled($this->authToken) && filled($this->numeroDesde);
    }

    /**
     * Envía un mensaje de WhatsApp, opcionalmente con un archivo adjunto
     * (por ejemplo, la factura en PDF) referenciado por una URL pública.
     */
    public function enviar(string $telefonoDestino, string $mensaje, ?string $urlArchivo = null): bool
    {
        if (! $this->habilitado()) {
            Log::warning('WhatsappService: credenciales de Twilio no configuradas, no se envió el mensaje.');

            return false;
        }

        $destino = $this->normalizarNumero($telefonoDestino);

        if (! $destino) {
            Log::warning("WhatsappService: número de teléfono inválido, no se pudo enviar: {$telefonoDestino}");

            return false;
        }

        $payload = [
            'From' => $this->numeroDesde,
            'To' => "whatsapp:{$destino}",
            'Body' => $mensaje,
        ];

        if ($urlArchivo) {
            $payload['MediaUrl'] = [$urlArchivo];
        }

        $respuesta = Http::asForm()
            ->withBasicAuth($this->accountSid, $this->authToken)
            ->post("https://api.twilio.com/2010-04-01/Accounts/{$this->accountSid}/Messages.json", $payload);

        if ($respuesta->failed()) {
            Log::error('WhatsappService: fallo al enviar mensaje', [
                'status' => $respuesta->status(),
                'body' => $respuesta->body(),
            ]);

            return false;
        }

        return true;
    }

    /**
     * Normaliza el teléfono a formato E.164 asumiendo Bolivia (+591) cuando
     * el usuario lo guardó solo con 8 dígitos, que es lo más común en el
     * campo "telefono" de Cliente.
     */
    private function normalizarNumero(string $telefono): ?string
    {
        $digitos = preg_replace('/\D+/', '', $telefono);

        if (! $digitos) {
            return null;
        }

        if (str_starts_with($digitos, '591')) {
            return '+'.$digitos;
        }

        if (strlen($digitos) === 8) {
            return '+591'.$digitos;
        }

        // Ya viene con otro código de país o formato distinto: se envía tal cual, con +.
        return '+'.$digitos;
    }
}
