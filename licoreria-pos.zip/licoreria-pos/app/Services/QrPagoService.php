<?php

namespace App\Services;

use App\Models\Pedido;

/**
 * Arma la pantalla de cobro por QR / transferencia.
 *
 * Usa el QR real de Yolo Pago (Banco Ganadero) de la licorería, que el cliente
 * escanea con la app de SU banco. Es un QR estático (identifica la cuenta pero
 * no lleva el monto), así que junto al QR se muestran el monto exacto, la
 * referencia del pedido y los datos de las cuentas para transferir.
 *
 * El dinero NO se acredita solo: el cajero verifica en el banco que llegó y
 * confirma con el endpoint /pedidos/{id}/confirmar-pago.
 *
 * Devuelve HTML con clases .pago-qr-* (estilos globales en frontend/src/styles.css).
 */
class QrPagoService
{
    public function generarReferencia(Pedido $pedido): string
    {
        return 'PED-'.str_pad((string) $pedido->id, 6, '0', STR_PAD_LEFT);
    }

    public function generarHtml(Pedido $pedido, string $referencia): string
    {
        $e = fn ($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');

        $ruta = public_path(config('pago.qr_imagen'));
        $img = is_file($ruta)
            ? '<img class="pago-qr-img" alt="QR de pago Yolo Pago" src="data:image/png;base64,'.base64_encode(file_get_contents($ruta)).'">'
            : '<p class="pago-qr-aviso">QR no disponible. Usa los datos de transferencia.</p>';

        $cuentas = '';
        foreach (config('pago.cuentas', []) as $c) {
            $cuentas .= '<li><strong>'.$e($c['banco']).'</strong> ('.$e($c['tipo']).')<br>'
                .'Cuenta: <strong>'.$e($c['numero']).'</strong><br>'
                .'Titular: '.$e($c['titular']).'</li>';
        }

        return '<div class="pago-qr">'
            .'<p class="pago-qr-monto">Monto a pagar: <strong>Bs '.number_format((float) $pedido->total, 2).'</strong></p>'
            .'<p class="pago-qr-ref">Referencia: <strong>'.$e($referencia).'</strong></p>'
            .$img
            .'<p class="pago-qr-ayuda">Escanea el QR con la app de tu banco, ingresa el monto exacto y escribe la referencia en el detalle/glosa.</p>'
            .'<p class="pago-qr-sub">¿Prefieres transferir?</p>'
            .'<ul class="pago-qr-cuentas">'.$cuentas.'</ul>'
            .'</div>';
    }
}
