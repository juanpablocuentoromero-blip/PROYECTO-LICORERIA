<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use RuntimeException;
use Symfony\Component\Process\Process;

/**
 * 2.5 — Respaldo diario de la base de datos.
 *
 *  1) mysqldump -> archivo .sql.gz en el disco local (storage/app/backups).
 *  2) Verifica que el volcado terminó bien (mysqldump deja "Dump completed" al final).
 *  3) Copia el archivo al disco externo (BACKUP_DISCO_EXTERNO), si está configurado.
 *  4) Borra los respaldos más viejos que BACKUP_RETENCION_DIAS en ambos discos.
 *
 * Si algo falla se registra en el log y se avisa por correo al administrador.
 * Programado en routes/console.php (requiere el cron de Laravel: schedule:run).
 */
class RespaldarBaseDatos extends Command
{
    protected $signature = 'backup:base-datos {--sin-externo : Solo copia local, no sube al disco externo}';

    protected $description = 'Respalda la base de datos (mysqldump comprimido) y la copia fuera del servidor';

    public function handle(): int
    {
        try {
            $conexion = config('database.connections.'.config('database.default'));

            if (($conexion['driver'] ?? null) !== 'mysql' && ($conexion['driver'] ?? null) !== 'mariadb') {
                throw new RuntimeException('El respaldo con mysqldump solo funciona con MySQL/MariaDB (conexión actual: '.($conexion['driver'] ?? '?').').');
            }

            $nombre = sprintf('%s_%s.sql.gz', $conexion['database'], now(config('services.licoreria.zona_horaria', 'America/La_Paz'))->format('Y-m-d_His'));
            $carpeta = trim(config('backup.carpeta'), '/');
            $rutaRelativa = $carpeta.'/'.$nombre;

            $discoLocal = Storage::disk(config('backup.disco_local'));
            $discoLocal->makeDirectory($carpeta);
            $rutaLocal = $discoLocal->path($rutaRelativa);

            $this->volcar($conexion, $rutaLocal);
            $this->info('Respaldo local creado: '.$rutaRelativa.' ('.number_format(filesize($rutaLocal) / 1024, 1).' KB)');

            $externo = config('backup.disco_externo');
            if ($externo && ! $this->option('sin-externo')) {
                $this->subirExterno($externo, $rutaLocal, $rutaRelativa);
                $this->info("Copia externa subida al disco \"{$externo}\".");
            } elseif (! $externo) {
                $this->warn('BACKUP_DISCO_EXTERNO no está configurado: solo existe la copia local (no protege si se pierde el servidor).');
            }

            $this->limpiarAntiguos(config('backup.disco_local'), $carpeta);
            if ($externo) {
                $this->limpiarAntiguos($externo, $carpeta);
            }

            return self::SUCCESS;
        } catch (\Throwable $e) {
            $this->error('El respaldo falló: '.$e->getMessage());
            Log::critical('RespaldarBaseDatos: el respaldo falló', ['error' => $e->getMessage()]);
            $this->avisarFallo($e->getMessage());

            return self::FAILURE;
        }
    }

    private function volcar(array $conexion, string $rutaGz): void
    {
        $sql = $rutaGz.'.tmp.sql';
        $credenciales = tempnam(sys_get_temp_dir(), 'mycnf');

        try {
            // Las credenciales van en un archivo temporal para que la contraseña
            // no aparezca en la línea de comandos (visible con `ps`).
            $cnf = "[client]\n"
                .'user="'.addcslashes((string) $conexion['username'], '"\\')."\"\n"
                .'password="'.addcslashes((string) ($conexion['password'] ?? ''), '"\\')."\"\n"
                .'host="'.($conexion['host'] ?? '127.0.0.1')."\"\n"
                .'port='.($conexion['port'] ?? 3306)."\n";
            file_put_contents($credenciales, $cnf);
            @chmod($credenciales, 0600);

            $proceso = new Process([
                config('backup.mysqldump'),
                '--defaults-extra-file='.$credenciales, // debe ser el primer argumento
                '--single-transaction',
                '--routines',
                '--triggers',
                '--default-character-set=utf8mb4',
                '--result-file='.$sql,
                $conexion['database'],
            ]);
            $proceso->setTimeout(1800);
            $proceso->run();

            if (! $proceso->isSuccessful()) {
                throw new RuntimeException('mysqldump terminó con error: '.trim($proceso->getErrorOutput() ?: $proceso->getOutput()));
            }

            if (! is_file($sql) || filesize($sql) === 0) {
                throw new RuntimeException('mysqldump no generó ningún contenido.');
            }

            // Verificación: un volcado completo termina con "-- Dump completed".
            $cola = $this->ultimosBytes($sql, 512);
            if (! str_contains($cola, 'Dump completed')) {
                throw new RuntimeException('El volcado parece incompleto (no termina con "Dump completed").');
            }

            $this->comprimir($sql, $rutaGz);
        } finally {
            @unlink($credenciales);
            @unlink($sql);
        }
    }

    private function ultimosBytes(string $archivo, int $n): string
    {
        $fh = fopen($archivo, 'rb');
        fseek($fh, -min($n, filesize($archivo)), SEEK_END);
        $texto = stream_get_contents($fh);
        fclose($fh);

        return (string) $texto;
    }

    private function comprimir(string $origen, string $destinoGz): void
    {
        $in = fopen($origen, 'rb');
        $out = gzopen($destinoGz, 'wb9');

        if (! $in || ! $out) {
            throw new RuntimeException('No se pudo comprimir el respaldo.');
        }

        while (! feof($in)) {
            gzwrite($out, fread($in, 1024 * 512));
        }

        fclose($in);
        gzclose($out);

        if (! is_file($destinoGz) || filesize($destinoGz) === 0) {
            throw new RuntimeException('El archivo comprimido quedó vacío.');
        }
    }

    private function subirExterno(string $disco, string $rutaLocal, string $rutaRelativa): void
    {
        $flujo = fopen($rutaLocal, 'rb');

        try {
            // writeStream no carga el archivo entero en memoria.
            $ok = Storage::disk($disco)->writeStream($rutaRelativa, $flujo);
        } finally {
            if (is_resource($flujo)) {
                fclose($flujo);
            }
        }

        if (! $ok) {
            throw new RuntimeException("No se pudo subir la copia al disco externo \"{$disco}\". Revisa sus credenciales/ruta.");
        }

        // Comprobación: el archivo existe allá con el mismo tamaño.
        $disk = Storage::disk($disco);
        if (! $disk->exists($rutaRelativa) || $disk->size($rutaRelativa) !== filesize($rutaLocal)) {
            throw new RuntimeException("La copia en el disco externo \"{$disco}\" no coincide con la local.");
        }
    }

    private function limpiarAntiguos(string $disco, string $carpeta): void
    {
        $limite = Carbon::now()->subDays(max(1, (int) config('backup.retencion_dias')))->getTimestamp();
        $disk = Storage::disk($disco);

        foreach ($disk->files($carpeta) as $archivo) {
            if (! str_ends_with($archivo, '.sql.gz')) {
                continue; // solo se tocan los respaldos de este comando
            }

            if ($disk->lastModified($archivo) < $limite) {
                $disk->delete($archivo);
                $this->line("Eliminado respaldo antiguo ({$disco}): {$archivo}");
            }
        }
    }

    private function avisarFallo(string $motivo): void
    {
        $correo = config('services.licoreria.admin_email');

        if (! config('backup.avisar_si_falla') || ! $correo) {
            return;
        }

        try {
            Mail::raw(
                "El respaldo automático de la base de datos de Licorería Al Paso FALLÓ.\n\nMotivo: {$motivo}\n\nRevisa storage/logs/laravel.log y corre manualmente: php artisan backup:base-datos",
                fn ($m) => $m->to($correo)->subject('⚠️ Falló el respaldo de la base de datos')
            );
        } catch (\Throwable $e) {
            Log::error('RespaldarBaseDatos: no se pudo enviar el aviso de fallo', ['error' => $e->getMessage()]);
        }
    }
}
