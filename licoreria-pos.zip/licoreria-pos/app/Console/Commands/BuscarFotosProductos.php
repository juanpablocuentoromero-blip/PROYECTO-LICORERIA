<?php

namespace App\Console\Commands;

use App\Console\Commands\Concerns\CoincideProductos;
use App\Models\Producto;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Busca fotos para TODOS los productos que todavía no tienen una, en varias
 * fuentes, y las descarga a frontend/public/productos/importadas/.
 *
 * Fuentes (en este orden; la primera que encuentra el mismo producto gana):
 *   1. Tiendas con catálogo products.json (por defecto https://amarket.com.bo).
 *      Agrega más con --tienda=https://otra-tienda.com (se puede repetir).
 *   2. Open Food Facts (openfoodfacts.org): base abierta de productos con foto.
 *      Sus fotos tienen licencia CC BY-SA: conviene citar la fuente.
 *
 * Solo acepta el MISMO producto (marca, línea y tamaño). Lo que no encuentra
 * queda con la imagen genérica con nombre y categoría que ya genera el sistema,
 * así ningún producto se ve vacío.
 *
 *   php artisan productos:buscar-fotos                     # vista previa
 *   php artisan productos:buscar-fotos --aplicar           # descarga y guarda
 *   php artisan productos:buscar-fotos --aplicar --codigo=CERV
 *   php artisan productos:buscar-fotos --sin-off --aplicar # solo tiendas
 */
class BuscarFotosProductos extends Command
{
    use CoincideProductos;

    protected $signature = 'productos:buscar-fotos
        {--aplicar : Descarga y guarda las fotos (sin esto solo muestra qué encontraría)}
        {--tienda=* : Tienda extra con /products.json (se puede repetir)}
        {--sin-amarket : No usar amarket.com.bo}
        {--sin-off : No usar Open Food Facts}
        {--pisar : También reemplaza productos que ya tienen foto}
        {--minimo=0.75 : Parecido mínimo (0 a 1) para aceptar una coincidencia}
        {--tolerancia=0.05 : Diferencia de tamaño aceptada (0.05 = 5 %)}
        {--paginas=60 : Máximo de páginas de 250 productos por tienda}
        {--codigo= : Solo productos cuyo código empiece así (ej. CERV, SODA)}
        {--csv= : Ruta donde guardar el reporte en CSV}';

    public function handle(): int
    {
        $tiendas = $this->option('tienda');
        if (! $this->option('sin-amarket')) {
            array_unshift($tiendas, 'https://amarket.com.bo');
        }

        $minimo = (float) $this->option('minimo');
        $tolerancia = (float) $this->option('tolerancia');

        // 1) Catálogos de tiendas (se leen una sola vez)
        $fuentes = [];
        foreach (array_unique($tiendas) as $base) {
            $this->info('Leyendo '.$base.' ...');
            $catalogo = $this->leerCatalogoJson($base, (int) $this->option('paginas'));

            if ($catalogo === null) {
                $this->warn("No pude leer {$base}/products.json: se omite esa tienda.");

                continue;
            }

            $conFoto = array_values(array_filter($catalogo, fn ($c) => ! empty($c['imagen'])));
            $this->line('  '.count($conFoto).' productos con foto.');
            $fuentes[] = ['nombre' => parse_url($base, PHP_URL_HOST) ?: $base, 'candidatos' => $this->prepararCandidatos($conFoto)];
        }

        // 2) Productos que necesitan foto
        $query = Producto::query()->orderBy('codigo');
        if ($this->option('codigo')) {
            $query->where('codigo', 'like', $this->option('codigo').'%');
        }

        $pendientes = $query->get()->filter(function (Producto $p) {
            if ($this->option('pisar')) {
                return true;
            }

            return ! ($p->getRawOriginal('imagen') ?: Producto::imagenPorDefecto($p->codigo, $p->nombre));
        })->values();

        $this->info($pendientes->count().' productos sin foto. Buscando...');

        $encontrados = [];
        $faltan = [];
        $usarOff = ! $this->option('sin-off');

        foreach ($pendientes as $producto) {
            $hallado = null;

            foreach ($fuentes as $f) {
                if ($m = $this->mejorCoincidencia($producto->nombre, $f['candidatos'], $minimo, $tolerancia)) {
                    $hallado = ['fuente' => $f['nombre'], 'titulo' => $m['titulo'], 'imagen' => $m['imagen'], 'score' => $m['score']];
                    break;
                }
            }

            if (! $hallado && $usarOff) {
                $hallado = $this->buscarEnOpenFoodFacts($producto->nombre, $minimo, $tolerancia);
            }

            if ($hallado) {
                $encontrados[] = [$producto, $hallado];
            } else {
                $faltan[] = $producto;
            }
        }

        $tabla = [];
        $csv = [['codigo', 'producto', 'fuente', 'encontrado', 'parecido', 'url_foto']];
        foreach ($encontrados as [$p, $h]) {
            $tabla[] = [$p->codigo, Str::limit($p->nombre, 34), $h['fuente'], Str::limit($h['titulo'], 38), number_format($h['score'], 2)];
            $csv[] = [$p->codigo, $p->nombre, $h['fuente'], $h['titulo'], round($h['score'], 2), $h['imagen']];
        }

        $this->table(['Código', 'Tu producto', 'Fuente', 'Encontrado', 'Parecido'], $tabla);
        $this->line(count($encontrados).' con foto encontrada; '.count($faltan).' quedarán con la imagen genérica:');
        foreach ($faltan as $p) {
            $this->line("  - {$p->codigo} {$p->nombre}");
            $csv[] = [$p->codigo, $p->nombre, '', '', '', ''];
        }

        if ($path = $this->option('csv')) {
            $h = fopen($path, 'w');
            foreach ($csv as $linea) {
                fputcsv($h, $linea);
            }
            fclose($h);
            $this->line('Reporte guardado en '.$path);
        }

        if (! $this->option('aplicar')) {
            $this->warn('Vista previa: no se descargó nada. Repite con --aplicar para guardar las fotos.');

            return self::SUCCESS;
        }

        $guardadas = 0;
        foreach ($encontrados as [$producto, $h]) {
            if ($ruta = $this->descargarFoto($h['imagen'], $producto->codigo)) {
                $producto->forceFill(['imagen' => $ruta])->saveQuietly();
                $guardadas++;
            }
        }

        $this->info("Listo: {$guardadas} fotos descargadas y guardadas.");

        return self::SUCCESS;
    }

    /**
     * Busca el producto en Open Food Facts. Su API de búsqueda permite pocas
     * consultas por minuto, por eso se espera entre una y otra.
     */
    private function buscarEnOpenFoodFacts(string $nombre, float $minimo, float $tolerancia): ?array
    {
        sleep(7);

        $resp = Http::withHeaders(['User-Agent' => 'LicoreriaAlPaso/1.0 (fotos de catalogo)'])
            ->timeout(40)
            ->get('https://world.openfoodfacts.org/cgi/search.pl', [
                'search_terms' => $nombre,
                'search_simple' => 1,
                'action' => 'process',
                'json' => 1,
                'page_size' => 12,
                'fields' => 'product_name,brands,quantity,image_front_url',
            ]);

        $items = $resp->ok() ? $resp->json('products') : null;

        if (! is_array($items)) {
            return null;
        }

        $candidatos = [];
        foreach ($items as $i) {
            if (empty($i['image_front_url']) || empty($i['product_name'])) {
                continue;
            }

            $candidatos[] = [
                'titulo' => trim(($i['brands'] ?? '').' '.$i['product_name'].' '.($i['quantity'] ?? '')),
                'imagen' => $i['image_front_url'],
            ];
        }

        $m = $this->mejorCoincidencia($nombre, $this->prepararCandidatos($candidatos), $minimo, $tolerancia);

        return $m ? ['fuente' => 'openfoodfacts', 'titulo' => $m['titulo'], 'imagen' => $m['imagen'], 'score' => $m['score']] : null;
    }

    /** Descarga la foto a frontend/public/productos/importadas y devuelve la ruta pública, o null si falla. */
    private function descargarFoto(string $url, string $codigo): ?string
    {
        $resp = Http::timeout(40)->get($url);

        if (! $resp->ok() || $resp->body() === '') {
            $this->warn("No pude descargar la foto de {$codigo}.");

            return null;
        }

        $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH) ?: '', PATHINFO_EXTENSION));
        $ext = in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true) ? $ext : 'jpg';

        $carpeta = base_path('frontend/public/productos/importadas');
        File::ensureDirectoryExists($carpeta);

        $archivo = Str::slug($codigo).'.'.$ext;
        File::put($carpeta.'/'.$archivo, $resp->body());

        return '/productos/importadas/'.$archivo;
    }
}
