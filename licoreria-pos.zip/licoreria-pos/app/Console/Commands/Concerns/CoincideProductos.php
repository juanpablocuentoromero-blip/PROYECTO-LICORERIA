<?php

namespace App\Console\Commands\Concerns;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Lógica compartida por los importadores de precios y fotos: leer catálogos
 * de tiendas y decidir si un producto de afuera es el MISMO que uno tuyo
 * (misma marca, misma línea y mismo tamaño).
 */
trait CoincideProductos
{
    private const PALABRAS_VACIAS = [
        'de', 'del', 'la', 'el', 'los', 'las', 'y', 'x', 'con', 'en', 'botella', 'botellin', 'lata', 'original',
        'unidad', 'unidades', 'pack', 'pet', 'cerveza', 'gaseosa', 'vino', 'bolsa', 'frasco', 'sachet',
    ];

    // Si el sitio la tiene y tu producto no, es OTRA variante: no se mezclan.
    private const VARIANTES = ['sin', 'azucar', 'zero', 'cero', 'light', 'diet', 'black', 'dark', 'negra', 'rosado', 'blanco'];

    /**
     * Lee todas las páginas de {base}/products.json (Shopify y similares).
     * Devuelve null si el sitio no responde con ese formato.
     * Cada item: titulo, precio, imagen.
     */
    private function leerCatalogoJson(string $base, int $maxPaginas): ?array
    {
        $todos = [];

        for ($pagina = 1; $pagina <= $maxPaginas; $pagina++) {
            $resp = Http::withHeaders(['User-Agent' => 'Mozilla/5.0 (compatible; comparador-precios-licoreria)'])
                ->timeout(40)
                ->get(rtrim($base, '/').'/products.json', ['limit' => 250, 'page' => $pagina]);

            $productos = $resp->ok() ? $resp->json('products') : null;

            if (! is_array($productos)) {
                return $pagina === 1 ? null : $todos;
            }

            if ($productos === []) {
                break;
            }

            foreach ($productos as $p) {
                $variante = $p['variants'][0] ?? [];
                $imagen = $p['images'][0]['src'] ?? ($p['image']['src'] ?? null);

                if (empty($p['title'])) {
                    continue;
                }

                $todos[] = [
                    'titulo' => (string) $p['title'],
                    'precio' => (float) ($variante['price'] ?? 0),
                    'imagen' => $imagen,
                ];
            }

            $this->output->write('.');
            usleep(600000);
        }

        $this->newLine();

        return $todos;
    }

    /** Agrega tokens y tamaño precalculados a cada candidato. */
    private function prepararCandidatos(array $catalogo): array
    {
        return array_map(fn ($c) => $c + [
            'tokens' => $this->tokens($c['titulo']),
            'tamano' => $this->tamano($c['titulo']),
        ], $catalogo);
    }

    private function mejorCoincidencia(string $nombre, array $candidatos, float $minimo, float $tolerancia): ?array
    {
        $tokens = $this->tokens($nombre);
        $tamano = $this->tamano($nombre);

        if ($tokens === []) {
            return null;
        }

        $mejor = null;

        foreach ($candidatos as $c) {
            // Tamaño: si ambos lo tienen, deben ser (casi) el mismo.
            if ($tamano !== null && $c['tamano'] !== null) {
                $dif = abs($tamano - $c['tamano']) / max($tamano, $c['tamano']);
                if ($dif > $tolerancia) {
                    continue;
                }
            }

            // Variante distinta (sin azúcar, zero, black...): no es el mismo producto.
            $extras = array_diff($c['tokens'], $tokens);
            if (array_intersect($extras, self::VARIANTES)) {
                continue;
            }

            $cobertura = count(array_intersect($tokens, $c['tokens'])) / count($tokens);
            $score = $cobertura - 0.05 * count($extras);

            // Sin tamaño en alguno de los dos lados, la coincidencia vale menos.
            if ($tamano === null || $c['tamano'] === null) {
                $score -= 0.10;
            }

            if ($score >= $minimo && (! $mejor || $score > $mejor['score'])) {
                $mejor = $c + ['score' => $score];
            }
        }

        return $mejor;
    }

    /** Palabras que identifican el producto (sin números, tamaños ni palabras genéricas). */
    private function tokens(string $texto): array
    {
        $t = $this->limpiar($texto);
        $t = preg_replace('/(\w+)\/\w+/', '$1', $t); // "Clásico/Varietal" -> "clasico"
        $t = preg_replace('/\b\d+(?:[.,]\d+)?\s*(?:ml|cc|l|lt|lts|litros?|g|gr|kg)\b/', ' ', $t);
        $palabras = preg_split('/[^a-z0-9]+/', $t, -1, PREG_SPLIT_NO_EMPTY);

        $palabras = array_filter($palabras, fn ($w) => ! ctype_digit($w) && ! in_array($w, self::PALABRAS_VACIAS, true) && strlen($w) > 1);

        return array_values(array_unique($palabras));
    }

    /** Tamaño en ml o g (3 L -> 3000, 750ml -> 750, 2 kg -> 2000), o null si no trae. */
    private function tamano(string $texto): ?float
    {
        $t = $this->limpiar($texto);

        if (! preg_match('/(\d+(?:[.,]\d+)?)\s*(ml|cc|l|lt|lts|litros?|g|gr|kg)\b/', $t, $m)) {
            return null;
        }

        $n = (float) str_replace(',', '.', $m[1]);

        return in_array($m[2], ['l', 'lt', 'lts', 'litro', 'litros', 'kg'], true) ? $n * 1000 : $n;
    }

    private function limpiar(string $texto): string
    {
        return trim(preg_replace('/\s+/', ' ', Str::lower(Str::ascii($texto))));
    }
}
