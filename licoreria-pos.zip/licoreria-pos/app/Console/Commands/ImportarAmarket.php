<?php

namespace App\Console\Commands;

use App\Console\Commands\Concerns\CoincideProductos;
use App\Models\Producto;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Trae precios y fotos de https://amarket.com.bo para los productos que
 * coinciden con los tuyos (misma marca, misma línea y mismo tamaño).
 *
 * Por defecto SOLO MUESTRA lo que haría. Para guardar, agrega --aplicar.
 *
 *   php artisan productos:importar-amarket                        # vista previa
 *   php artisan productos:importar-amarket --aplicar --descargar  # guarda precios y fotos
 *   php artisan productos:importar-amarket --sin-fotos --aplicar  # solo precios
 *   php artisan productos:importar-amarket --codigo=SODA          # solo gaseosas
 *
 * Lee el catálogo público del sitio (products.json de Tienda Nube/Shopify),
 * con una pausa entre páginas para no cargarlo.
 */
class ImportarAmarket extends Command
{
    use CoincideProductos;

    protected $signature = 'productos:importar-amarket
        {--aplicar : Guarda los cambios (sin esto solo muestra qué haría)}
        {--sin-precios : No toca los precios}
        {--sin-fotos : No toca las fotos}
        {--descargar : Descarga las fotos a frontend/public/productos/amarket en vez de guardar la URL}
        {--pisar-fotos : También reemplaza productos que ya tienen foto}
        {--factor=0.80 : precio_compra = precio_venta × factor}
        {--minimo=0.75 : Parecido mínimo (0 a 1) para aceptar una coincidencia}
        {--tolerancia=0.05 : Diferencia de tamaño aceptada (0.05 = 5 %)}
        {--paginas=60 : Máximo de páginas de 250 productos a leer}
        {--codigo= : Solo productos cuyo código empiece así (ej. CERV, SODA)}
        {--base=https://amarket.com.bo : Sitio de origen}
        {--csv= : Ruta donde guardar el reporte en CSV}';

    public function handle(): int
    {
        $base = rtrim($this->option('base'), '/');
        $factor = (float) $this->option('factor');
        $minimo = (float) $this->option('minimo');
        $aplicar = (bool) $this->option('aplicar');

        $this->info('Leyendo el catálogo de '.$base.' ...');
        $catalogo = $this->leerCatalogoJson($base, (int) $this->option('paginas'));

        if ($catalogo === null) {
            $this->error('No pude leer '.$base.'/products.json. Si el sitio no usa ese formato, avísame y adapto el importador.');

            return self::FAILURE;
        }

        $this->info(count($catalogo).' productos leídos. Buscando coincidencias...');

        $candidatos = $this->prepararCandidatos($catalogo);

        $query = Producto::query()->orderBy('codigo');
        if ($this->option('codigo')) {
            $query->where('codigo', 'like', $this->option('codigo').'%');
        }

        $filas = [];
        $sinMatch = [];

        foreach ($query->get() as $producto) {
            $mejor = $this->mejorCoincidencia($producto->nombre, $candidatos, $minimo, (float) $this->option('tolerancia'));

            if (! $mejor) {
                $sinMatch[] = [$producto->codigo, $producto->nombre];

                continue;
            }

            $filas[] = [$producto, $mejor];
        }

        $tabla = [];
        $csv = [['codigo', 'producto', 'precio_antes', 'precio_nuevo', 'amarket', 'parecido', 'foto']];

        foreach ($filas as [$producto, $m]) {
            $nuevo = round($m['precio'], 2);
            $tabla[] = [
                $producto->codigo,
                Str::limit($producto->nombre, 34),
                number_format((float) $producto->precio_venta, 2),
                number_format($nuevo, 2),
                Str::limit($m['titulo'], 40),
                number_format($m['score'], 2),
                $m['imagen'] ? 'sí' : 'no',
            ];
            $csv[] = [$producto->codigo, $producto->nombre, $producto->precio_venta, $nuevo, $m['titulo'], round($m['score'], 2), $m['imagen']];
        }

        $this->table(['Código', 'Tu producto', 'Antes', 'Nuevo', 'En Amarket', 'Parecido', 'Foto'], $tabla);
        $this->line(count($filas).' coincidencias, '.count($sinMatch).' productos sin coincidencia (esos no se tocan).');

        if ($path = $this->option('csv')) {
            $h = fopen($path, 'w');
            foreach ($csv as $linea) {
                fputcsv($h, $linea);
            }
            fclose($h);
            $this->line('Reporte guardado en '.$path);
        }

        if (! $aplicar) {
            $this->warn('Vista previa: no se guardó nada. Revisa la tabla y repite con --aplicar para guardar.');

            return self::SUCCESS;
        }

        $precios = 0;
        $fotos = 0;

        foreach ($filas as [$producto, $m]) {
            if (! $this->option('sin-precios') && $m['precio'] > 0) {
                $venta = round($m['precio'], 2);
                $producto->forceFill([
                    'precio_venta' => $venta,
                    'precio_compra' => round($venta * $factor, 2),
                ])->saveQuietly();
                $precios++;
            }

            if (! $this->option('sin-fotos') && $m['imagen'] && ($this->option('pisar-fotos') || ! ($producto->getRawOriginal('imagen') ?: Producto::imagenPorDefecto($producto->codigo, $producto->nombre)))) {
                $ruta = $this->option('descargar') ? $this->descargarFoto($m['imagen'], $producto->codigo) : $m['imagen'];

                if ($ruta) {
                    $producto->forceFill(['imagen' => $ruta])->saveQuietly();
                    $fotos++;
                }
            }
        }

        $this->info("Listo: {$precios} precios y {$fotos} fotos guardados.");

        return self::SUCCESS;
    }

    /** Descarga la foto a frontend/public/productos/amarket y devuelve la ruta pública, o null si falla. */
    private function descargarFoto(string $url, string $codigo): ?string
    {
        $resp = Http::timeout(40)->get($url);

        if (! $resp->ok() || $resp->body() === '') {
            $this->warn("No pude descargar la foto de {$codigo}.");

            return null;
        }

        $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH) ?: '', PATHINFO_EXTENSION));
        $ext = in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true) ? $ext : 'jpg';

        $carpeta = base_path('frontend/public/productos/amarket');
        File::ensureDirectoryExists($carpeta);

        $archivo = Str::slug($codigo).'.'.$ext;
        File::put($carpeta.'/'.$archivo, $resp->body());

        return '/productos/amarket/'.$archivo;
    }
}
