<?php

namespace App\Console\Commands;

use App\Services\AlertaService;
use Illuminate\Console\Command;

class RevisarAlertas extends Command
{
    protected $signature = 'alertas:revisar {--sin-avisos : Actualiza las alertas pero no envía correo/WhatsApp}';

    protected $description = 'Revisa stock mínimo y vencimientos, actualiza las alertas del panel y avisa por correo/WhatsApp las nuevas.';

    public function handle(AlertaService $alertas): int
    {
        $r = $alertas->revisar(! $this->option('sin-avisos'));

        $this->info(sprintf(
            'Alertas: %d nueva(s), %d resuelta(s), %d activa(s).',
            count($r['nuevas']), $r['resueltas'], $r['activas']
        ));

        return self::SUCCESS;
    }
}
