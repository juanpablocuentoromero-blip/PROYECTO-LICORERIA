<?php

namespace App\Exports;

use App\Models\Pedido;
use Carbon\Carbon;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

// Reporte de fiado: una fila por venta a crédito con saldo pendiente
// (hoy, sin filtrar por fechas: lo que importa es lo que se debe AHORA).
class CuentasPorCobrarExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize
{
    public function collection()
    {
        return Pedido::with('cliente')
            ->where('metodo_pago', 'credito')
            ->where('anulada', false)
            ->where('saldo_pendiente', '>', 0)
            ->orderBy('cliente_id')
            ->orderBy('created_at')
            ->get();
    }

    public function headings(): array
    {
        return [
            'Cliente', 'NIT/CI', 'Teléfono', 'Documento', 'Fecha venta',
            'Vence', 'Días de atraso', 'Total', 'Abonado', 'Saldo',
        ];
    }

    public function map($pedido): array
    {
        $zona = config('services.licoreria.zona_horaria', 'America/La_Paz');
        $hoy = now($zona)->startOfDay();
        $atraso = 0;

        if ($pedido->fecha_vencimiento_credito) {
            $venc = Carbon::parse($pedido->fecha_vencimiento_credito->toDateString(), $zona)->startOfDay();
            $atraso = $hoy->greaterThan($venc) ? (int) $venc->diffInDays($hoy) : 0;
        }

        return [
            $pedido->cliente->nombre ?? '—',
            $pedido->cliente->nit_ci ?? '',
            $pedido->cliente->telefono ?? '',
            $pedido->nroDocumento(),
            optional($pedido->created_at)->copy()->setTimezone($zona)->format('d/m/Y'),
            $pedido->fecha_vencimiento_credito?->format('d/m/Y') ?? '',
            $atraso,
            (float) $pedido->total,
            round((float) $pedido->total - (float) $pedido->saldo_pendiente, 2),
            (float) $pedido->saldo_pendiente,
        ];
    }
}
