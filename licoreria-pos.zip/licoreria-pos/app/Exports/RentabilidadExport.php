<?php

namespace App\Exports;

use App\Models\DetallePedido;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class RentabilidadExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize
{
    public function __construct(
        private ?string $desde = null,
        private ?string $hasta = null,
    ) {
    }

    // Devuelve una fila por producto vendido en el rango (solo pedidos
    // pagados y no cancelados, igual que el resto del sistema considera
    // una venta "real"), más una fila de total general al final.
    // 2.1: el costo sale del precio_compra guardado en cada línea al vender
    // (con respaldo al costo actual solo si una línea no lo tuviera).
    public function collection()
    {
        $query = DetallePedido::query()
            ->join('pedidos', 'pedidos.id', '=', 'detalle_pedidos.pedido_id')
            ->join('productos', 'productos.id', '=', 'detalle_pedidos.producto_id')
            ->where('pedidos.pagado', true)
            ->where('pedidos.anulada', false)
            ->where('pedidos.estado', '!=', 'cancelado');

        if ($this->desde) {
            $query->whereDate('pedidos.created_at', '>=', $this->desde);
        }

        if ($this->hasta) {
            $query->whereDate('pedidos.created_at', '<=', $this->hasta);
        }

        $filas = $query
            ->selectRaw('productos.id as producto_id')
            ->selectRaw('productos.nombre as producto_nombre')
            ->selectRaw('SUM(detalle_pedidos.cantidad) as cantidad_vendida')
            ->selectRaw('SUM(detalle_pedidos.subtotal) as ingreso_total')
            ->selectRaw('SUM(detalle_pedidos.cantidad * COALESCE(detalle_pedidos.precio_compra, productos.precio_compra)) as costo_total')
            ->groupBy('productos.id', 'productos.nombre')
            ->orderByDesc('ingreso_total')
            ->get()
            ->map(function ($fila) {
                $fila->ganancia = $fila->ingreso_total - $fila->costo_total;

                return $fila;
            });

        $total = (object) [
            'producto_id' => null,
            'producto_nombre' => 'TOTAL GENERAL',
            'cantidad_vendida' => $filas->sum('cantidad_vendida'),
            'ingreso_total' => $filas->sum('ingreso_total'),
            'costo_total' => $filas->sum('costo_total'),
            'ganancia' => $filas->sum('ganancia'),
        ];

        return new Collection([...$filas->all(), $total]);
    }

    public function headings(): array
    {
        return ['Producto', 'Cantidad vendida', 'Ingreso total', 'Costo total', 'Ganancia'];
    }

    public function map($fila): array
    {
        return [
            $fila->producto_nombre,
            (int) $fila->cantidad_vendida,
            (float) $fila->ingreso_total,
            (float) $fila->costo_total,
            (float) $fila->ganancia,
        ];
    }
}
