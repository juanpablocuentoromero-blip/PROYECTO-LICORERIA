<?php

namespace App\Exports;

use App\Models\DetallePedidoCompra;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

// Una fila por producto comprado (detalle del pedido de compra), con los
// mismos filtros que la vista en pantalla del reporte de compras.
class ComprasExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize
{
    public function __construct(
        private ?string $desde = null,
        private ?string $hasta = null,
        private ?int $proveedorId = null,
        private ?string $estado = null,
        private ?int $productoId = null,
    ) {
    }

    public function collection()
    {
        $query = DetallePedidoCompra::with(['pedidoCompra.proveedor', 'pedidoCompra.usuario', 'producto'])
            ->whereHas('pedidoCompra', function ($q) {
                if ($this->desde) {
                    $q->whereDate('created_at', '>=', $this->desde);
                }

                if ($this->hasta) {
                    $q->whereDate('created_at', '<=', $this->hasta);
                }

                if ($this->proveedorId) {
                    $q->where('proveedor_id', $this->proveedorId);
                }

                if ($this->estado) {
                    $q->where('estado', $this->estado);
                } else {
                    $q->where('estado', '!=', 'cancelado');
                }
            });

        if ($this->productoId) {
            $query->where('producto_id', $this->productoId);
        }

        return $query->orderByDesc('pedido_compra_id')->orderBy('id')->get();
    }

    public function headings(): array
    {
        return [
            'Fecha', '#Pedido', 'Proveedor', 'Estado', 'Producto', 'Código', 'Paquetes', 'Unid./paquete',
            'Unidades', 'Costo paquete', 'Costo unitario', 'Subtotal', 'Lote', 'Vencimiento', 'Registrado por',
        ];
    }

    public function map($detalle): array
    {
        $pedido = $detalle->pedidoCompra;

        return [
            optional($pedido->created_at)->format('d/m/Y H:i'),
            $pedido->id,
            $pedido->proveedor->nombre ?? '—',
            $pedido->estado,
            $detalle->producto->nombre ?? '—',
            $detalle->producto->codigo ?? '—',
            $detalle->cantidad_paquetes ?? '',
            $detalle->unidades_por_paquete ?? '',
            $detalle->cantidad,
            $detalle->precio_paquete ?? '',
            $detalle->precio_unitario,
            $detalle->subtotal,
            $detalle->numero_lote ?? '',
            $detalle->fecha_vencimiento ? substr((string) $detalle->fecha_vencimiento, 0, 10) : '',
            $pedido->usuario->nombre ?? '—',
        ];
    }
}
