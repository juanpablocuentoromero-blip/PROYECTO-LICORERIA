<?php

namespace App\Exports;

use App\Models\Pedido;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class VentasExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize
{
    public function __construct(
        private ?string $desde = null,
        private ?string $hasta = null,
    ) {
    }

    public function collection()
    {
        $query = Pedido::with(['cliente', 'usuario'])->orderByDesc('created_at');

        if ($this->desde) {
            $query->whereDate('created_at', '>=', $this->desde);
        }

        if ($this->hasta) {
            $query->whereDate('created_at', '<=', $this->hasta);
        }

        return $query->get();
    }

    public function headings(): array
    {
        return [
            '#Pedido', 'Fecha', 'Cliente', 'Vendedor', 'Estado', 'Entrega', 'Método de pago', 'Pagado',
            'Subtotal', 'Descuento', 'Cupón', 'Envío', 'Total', 'Saldo pendiente',
        ];
    }

    public function map($pedido): array
    {
        return [
            $pedido->id,
            optional($pedido->created_at)->format('d/m/Y H:i'),
            $pedido->cliente->nombre ?? '—',
            $pedido->usuario->nombre ?? '—',
            $pedido->estado,
            $pedido->tipo_entrega === 'delivery' ? 'Delivery' : 'Recojo/mostrador',
            $pedido->metodo_pago,
            $pedido->pagado ? 'Sí' : 'No',
            $pedido->subtotal,
            $pedido->descuento,
            $pedido->cupon_codigo ?? '',
            $pedido->costo_envio,
            $pedido->total,
            $pedido->saldo_pendiente,
        ];
    }
}
