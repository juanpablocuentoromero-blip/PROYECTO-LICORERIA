<?php

namespace App\Exports;

use App\Models\Caja;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

// Cierres de caja (turnos): una fila por caja, con lo esperado, lo contado y la diferencia.
class CajasExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize
{
    public function __construct(
        private ?string $desde = null,
        private ?string $hasta = null,
        private ?int $usuarioId = null,
    ) {
    }

    public function collection()
    {
        $query = Caja::with(['almacen', 'usuarioApertura', 'usuarioCierre'])->orderByDesc('abierta_at');

        if ($this->desde) {
            $query->whereDate('abierta_at', '>=', $this->desde);
        }

        if ($this->hasta) {
            $query->whereDate('abierta_at', '<=', $this->hasta);
        }

        if ($this->usuarioId) {
            $query->where(fn ($q) => $q->where('usuario_apertura_id', $this->usuarioId)
                ->orWhere('usuario_cierre_id', $this->usuarioId));
        }

        return $query->get();
    }

    public function headings(): array
    {
        return [
            '#Caja', 'Almacén', 'Estado', 'Abierta', 'Abierta por', 'Cerrada', 'Cerrada por', 'Apertura',
            'Ventas efectivo', 'Ventas QR', 'Ventas tarjeta', 'Ventas total', 'Ventas a crédito', 'Abonos efectivo',
            'Ingresos caja chica', 'Egresos caja chica', 'Devoluciones efectivo', 'Esperado', 'Contado', 'Diferencia',
        ];
    }

    public function map($c): array
    {
        $cerrada = $c->estado === 'cerrada';

        return [
            $c->id,
            $c->almacen->nombre ?? '—',
            $c->estado,
            optional($c->abierta_at)->format('d/m/Y H:i'),
            $c->usuarioApertura->nombre ?? '—',
            optional($c->cerrada_at)->format('d/m/Y H:i'),
            $c->cerrada_por_nombre ?? ($c->usuarioCierre->nombre ?? ''),
            $c->monto_apertura,
            $cerrada ? $c->monto_ventas_efectivo : '',
            $cerrada ? $c->monto_ventas_qr : '',
            $cerrada ? $c->monto_ventas_tarjeta : '',
            $cerrada ? $c->monto_ventas_total : '',
            $cerrada ? $c->monto_ventas_credito : '',
            $cerrada ? $c->monto_abonos_efectivo : '',
            $cerrada ? $c->monto_ingresos_caja_chica : '',
            $cerrada ? $c->monto_egresos_caja_chica : '',
            $cerrada ? $c->monto_devoluciones_efectivo : '',
            $cerrada ? $c->monto_cierre_esperado : '',
            $cerrada ? $c->monto_cierre_real : '',
            $cerrada ? $c->diferencia : '',
        ];
    }
}
