<?php

namespace App\Exports;

use App\Models\MovimientoInventario;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class MovimientosExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize
{
    public function __construct(
        private ?string $desde = null,
        private ?string $hasta = null,
    ) {
    }

    public function collection()
    {
        $query = MovimientoInventario::with(['producto', 'usuario', 'almacen'])->orderByDesc('created_at');

        if ($this->desde) {
            $query->whereDate('created_at', '>=', $this->desde);
        }

        if ($this->hasta) {
            $query->whereDate('created_at', '<=', $this->hasta);
        }

        return $query->get();
    }

    public function headings(): array
    {
        return ['Fecha', 'Producto', 'Almacén', 'Tipo', 'Cantidad', 'Stock resultante', 'Motivo', 'Origen', 'Registrado por'];
    }

    public function map($movimiento): array
    {
        return [
            optional($movimiento->created_at)->format('d/m/Y H:i'),
            $movimiento->producto->nombre ?? '—',
            $movimiento->almacen->nombre ?? '—',
            $movimiento->tipo === 'entrada' ? 'Entrada' : 'Salida',
            $movimiento->cantidad,
            $movimiento->stock_resultante,
            $movimiento->motivo,
            $movimiento->es_ajuste ? 'Ajuste de inventario' : 'Movimiento',
            $movimiento->usuario->nombre ?? '—',
        ];
    }
}
