<?php

namespace App\Exports;

use App\Models\Cliente;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class ClientesExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize
{
    // Filtra por la fecha en que el cliente se registró (created_at).
    public function __construct(
        private ?string $desde = null,
        private ?string $hasta = null,
    ) {
    }

    public function collection()
    {
        $query = Cliente::withCount('pedidos')->orderBy('nombre');

        if ($this->desde) {
            $query->whereDate('created_at', '>=', $this->desde);
        }

        if ($this->hasta) {
            $query->whereDate('created_at', '<=', $this->hasta);
        }

        return $query->get();
    }

    public function headings(): array
    {
        return ['Nombre', 'Teléfono', 'Email', 'Dirección', 'Tiene cuenta en la tienda', 'Activo', 'Pedidos realizados'];
    }

    public function map($cliente): array
    {
        return [
            $cliente->nombre,
            $cliente->telefono ?? '—',
            $cliente->email ?? '—',
            $cliente->direccion ?? '—',
            $cliente->tieneCuenta() ? 'Sí' : 'No',
            $cliente->activo ? 'Sí' : 'No',
            $cliente->pedidos_count,
        ];
    }
}
