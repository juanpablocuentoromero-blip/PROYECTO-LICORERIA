<?php

namespace App\Exports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

// Movimientos de caja chica ya filtrados por el controlador (así el vendedor
// solo exporta lo suyo, igual que en pantalla).
class CajaChicaExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize
{
    public function __construct(private Collection $movimientos)
    {
    }

    public function collection()
    {
        return $this->movimientos;
    }

    public function headings(): array
    {
        return ['Fecha', '#Caja', 'Almacén', 'Cuenta', 'Tipo', 'Método', 'Nº documento', 'Concepto', 'Ingreso', 'Egreso', 'Registrado por'];
    }

    public function map($m): array
    {
        return [
            optional($m->created_at)->format('d/m/Y H:i'),
            $m->caja_id,
            $m->almacen->nombre ?? '—',
            $m->cuenta,
            $m->tipo === 'ingreso' ? 'Ingreso' : 'Egreso',
            $m->metodo_pago,
            $m->nro_documento ?? '',
            $m->concepto,
            $m->tipo === 'ingreso' ? $m->monto : '',
            $m->tipo === 'egreso' ? $m->monto : '',
            $m->usuario->nombre ?? '—',
        ];
    }
}
