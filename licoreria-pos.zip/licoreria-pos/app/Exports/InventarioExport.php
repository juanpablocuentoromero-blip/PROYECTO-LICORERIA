<?php

namespace App\Exports;

use App\Models\Producto;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class InventarioExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize
{
    // Filtra por la fecha en que el producto se dio de alta en el catálogo
    // (created_at). Si no se pasa desde/hasta, trae todo el inventario
    // como antes.
    public function __construct(
        private ?string $desde = null,
        private ?string $hasta = null,
    ) {
    }

    public function collection()
    {
        $query = Producto::with('categoria')->orderBy('nombre');

        if ($this->desde) {
            $query->whereDate('created_at', '>=', $this->desde);
        }

        if ($this->hasta) {
            $query->whereDate('created_at', '<=', $this->hasta);
        }

        return $query->get();
    }

    public function headings(): array
    {
        return ['Código', 'Nombre', 'Categoría', 'Precio compra', 'Precio venta', 'Stock', 'Stock mínimo', 'Valor en inventario (Bs)', 'Estado'];
    }

    public function map($producto): array
    {
        return [
            $producto->codigo,
            $producto->nombre,
            $producto->categoria->nombre ?? '—',
            $producto->precio_compra,
            $producto->precio_venta,
            $producto->stock,
            $producto->stock_minimo,
            round($producto->stock * $producto->precio_compra, 2),
            $producto->activo ? 'Activo' : 'Inactivo',
        ];
    }
}
