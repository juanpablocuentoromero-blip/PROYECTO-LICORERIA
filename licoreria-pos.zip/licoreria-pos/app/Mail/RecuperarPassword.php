<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class RecuperarPassword extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(
        public string $nombre,
        public string $enlace,
    ) {
    }

    public function build(): static
    {
        return $this
            ->subject('Recupera tu contraseña - Licorería Al Paso')
            ->view('emails.recuperar-password');
    }
}
