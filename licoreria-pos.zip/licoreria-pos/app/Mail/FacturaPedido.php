<?php

namespace App\Mail;

use App\Models\Pedido;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class FacturaPedido extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public Pedido $pedido)
    {
    }

    public function build(): static
    {
        $pdf = Pdf::loadView('emails.factura-pdf', ['pedido' => $this->pedido]);

        return $this
            ->subject('Nota de venta - Pedido #'.$this->pedido->id.' - Licorería Al Paso')
            ->view('emails.factura')
            ->attachData($pdf->output(), 'nota-venta-'.$this->pedido->id.'.pdf', [
                'mime' => 'application/pdf',
            ]);
    }
}
