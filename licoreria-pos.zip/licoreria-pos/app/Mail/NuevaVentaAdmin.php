<?php

namespace App\Mail;

use App\Models\Pedido;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class NuevaVentaAdmin extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public Pedido $pedido)
    {
    }

    public function build(): static
    {
        return $this
            ->subject('💰 Venta confirmada - Pedido #'.$this->pedido->id.' - Bs '.number_format((float) $this->pedido->total, 2))
            ->view('emails.nueva-venta-admin');
    }
}
