<?php

namespace App\Mail;

use App\Models\Pedido;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

// A diferencia de NuevaVentaAdmin (que avisa cuando el STAFF confirma que el
// pago llegó), este correo avisa apenas el CLIENTE hace el pedido desde la
// tienda online, para que el vendedor y el administrador se enteren de
// inmediato y puedan prepararlo/atenderlo — sin esperar a que alguien entre
// a revisar la pantalla de Pedidos.
class NuevoPedidoCliente extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public Pedido $pedido)
    {
    }

    public function build(): static
    {
        return $this
            ->subject('🛎️ Nuevo pedido online #'.$this->pedido->id.' - Bs '.number_format((float) $this->pedido->total, 2))
            ->view('emails.nuevo-pedido-cliente');
    }
}
