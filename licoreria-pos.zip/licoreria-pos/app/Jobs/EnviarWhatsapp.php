<?php

namespace App\Jobs;

use App\Services\WhatsappService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Log;

/**
 * 2.4 — Envío de WhatsApp (Twilio) fuera de la petición web.
 *
 * Antes la llamada HTTP a Twilio se hacía dentro del request: si Twilio
 * tardaba, el empleado se quedaba esperando al confirmar un pago. Ahora el
 * controlador solo encola este job y responde al instante.
 *
 * Reintentos: solo si la conexión con Twilio se cae (excepción) — ahí el
 * mensaje seguro no llegó, así que reintentar no duplica nada. Si Twilio
 * responde con un error (número inválido, credenciales, etc.) WhatsappService
 * lo registra en el log y devuelve false: no se reintenta.
 */
class EnviarWhatsapp implements ShouldQueue
{
    use Queueable;

    public int $tries = 3;

    public function __construct(
        public string $telefono,
        public string $mensaje,
        public ?string $urlArchivo = null,
    ) {
    }

    /** Segundos de espera entre reintentos. */
    public function backoff(): array
    {
        return [30, 120];
    }

    public function handle(WhatsappService $whatsapp): void
    {
        if (! $whatsapp->enviar($this->telefono, $this->mensaje, $this->urlArchivo)) {
            Log::warning("EnviarWhatsapp: no se pudo enviar el mensaje a {$this->telefono} (ver log de WhatsappService).");
        }
    }
}
