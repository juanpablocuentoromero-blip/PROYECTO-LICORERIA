<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RolUsuario
{
    // Uso en rutas: ->middleware('auth.usuario', 'rol:administrador')
    // Debe ir SIEMPRE después de 'auth.usuario', que es quien coloca
    // 'usuario_autenticado' en el request.
    public function handle(Request $request, Closure $next, string ...$rolesPermitidos): Response
    {
        $usuario = $request->attributes->get('usuario_autenticado');

        if (! $usuario || ! in_array($usuario->rol, $rolesPermitidos, true)) {
            return response()->json([
                'message' => 'No tienes permiso para realizar esta acción.',
            ], 403);
        }

        return $next($request);
    }
}
