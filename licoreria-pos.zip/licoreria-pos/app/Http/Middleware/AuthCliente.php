<?php

namespace App\Http\Middleware;

use App\Models\Cliente;
use App\Services\TokenAcceso;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AuthCliente
{
    public function handle(Request $request, Closure $next): Response
    {
        $token = TokenAcceso::resolver($request, Cliente::class);

        if (! $token) {
            return response()->json(['message' => 'No autenticado.'], 401);
        }

        $request->attributes->set('cliente_autenticado', $token->tokenable);
        $request->attributes->set('token_actual', $token);

        return $next($request);
    }
}
