<?php

namespace App\Http\Middleware;

use App\Models\Usuario;
use App\Services\TokenAcceso;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AuthUsuario
{
    public function handle(Request $request, Closure $next): Response
    {
        $token = TokenAcceso::resolver($request, Usuario::class);

        if (! $token) {
            return response()->json(['message' => 'No autenticado.'], 401);
        }

        $request->attributes->set('usuario_autenticado', $token->tokenable);
        $request->attributes->set('token_actual', $token);

        return $next($request);
    }
}
