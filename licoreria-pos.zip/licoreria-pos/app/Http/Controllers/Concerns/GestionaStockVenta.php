<?php

namespace App\Http\Controllers\Concerns;

use App\Models\Cliente;
use App\Models\Combo;
use App\Models\MovimientoInventario;
use App\Models\Pedido;
use App\Models\Producto;
use App\Models\StockPorAlmacen;
use Illuminate\Support\Collection;

/**
 * Lógica de stock compartida por las ventas de mostrador.
 *
 * Es la misma regla que ya usa PedidoController (combos descuentan sus
 * componentes, todo pasa por Producto::ajustarStock y deja movimiento de
 * inventario), pero comprobando contra el stock del ALMACÉN de la venta y
 * no contra la caché productos.stock.
 */
trait GestionaStockVenta
{
    // 2.1 — Costo unitario de $producto AHORA, para congelarlo en la línea
    // de venta. Un combo no tiene costo propio fiable (su precio_compra se
    // calculó al crearlo y queda viejo si cambian los componentes): se suma
    // el costo actual de cada componente por su cantidad.
    protected function costoUnitarioVenta(Producto $producto): float
    {
        $combo = Combo::where('producto_id', $producto->id)->with('items.producto')->first();

        if ($combo && $combo->items->isNotEmpty()) {
            $costo = 0.0;
            foreach ($combo->items as $item) {
                $costo += (float) ($item->producto?->precio_compra ?? 0) * (int) $item->cantidad;
            }

            return round($costo, 2);
        }

        return round((float) $producto->precio_compra, 2);
    }

    // Cuántas unidades trae una presentación del producto. "unidad" siempre
    // vale 1; "paquete" y "caja" salen de la ficha del producto y, si el
    // producto no las tiene configuradas, se rechaza en vez de adivinar.
    protected function factorPresentacion(Producto $producto, ?string $presentacion): int
    {
        $presentacion = $presentacion ?: 'unidad';

        $factor = match ($presentacion) {
            'unidad' => 1,
            'paquete' => (int) $producto->unidades_por_paquete,
            'caja' => (int) $producto->unidades_por_caja,
            default => abort(422, 'Presentación no válida: usa unidad, paquete o caja.'),
        };

        if ($factor < 1) {
            abort(422, "«{$producto->nombre}» no se vende por {$presentacion}: no tiene esa presentación configurada.");
        }

        return $factor;
    }

    // Convierte los items del pedido ({producto_id, cantidad, presentacion?})
    // en líneas EN UNIDADES, fusionando repetidos y ordenadas por producto
    // (así dos pedidos simultáneos bloquean en el mismo orden y no se
    // interbloquean). Si una línea se pidió en una sola presentación se
    // conserva ("2 cajas"); si se mezclaron, queda en unidades.
    protected function agruparLineasPedido(array $items): Collection
    {
        $ids = collect($items)->pluck('producto_id')->unique()->all();
        $productos = Producto::whereIn('id', $ids)->get()->keyBy('id');

        $grupos = [];

        foreach ($items as $item) {
            $producto = $productos->get((int) $item['producto_id']);

            if (! $producto) {
                abort(422, 'Uno de los productos ya no está disponible.');
            }

            $presentacion = $item['presentacion'] ?? 'unidad';
            $factor = $this->factorPresentacion($producto, $presentacion);
            $cantidad = (int) $item['cantidad'];

            $grupos[$producto->id] ??= [
                'producto_id' => $producto->id,
                'cantidad' => 0,
                'presentaciones' => [],
                'cantidad_presentacion' => 0,
            ];

            $grupos[$producto->id]['cantidad'] += $cantidad * $factor;
            $grupos[$producto->id]['presentaciones'][$presentacion] = true;
            $grupos[$producto->id]['cantidad_presentacion'] += $cantidad;
        }

        ksort($grupos);

        return collect($grupos)->map(function (array $g) {
            $unica = count($g['presentaciones']) === 1 ? array_key_first($g['presentaciones']) : 'unidad';

            return [
                'producto_id' => $g['producto_id'],
                'cantidad' => $g['cantidad'],
                'presentacion' => $unica,
                'cantidad_presentacion' => $unica === 'unidad' ? $g['cantidad'] : $g['cantidad_presentacion'],
            ];
        })->values();
    }

    // Reglas del fiado (5.3). Se llama DENTRO de la transacción de la venta,
    // con el cliente bloqueado: dos ventas a crédito simultáneas al mismo
    // cliente no pueden pasarse del límite entre las dos.
    protected function validarCreditoCliente(Cliente $cliente, float $total, ?int $ignorarPedidoId = null): void
    {
        if ($cliente->nit_ci === null || $cliente->nit_ci === '' || $cliente->nit_ci === '0') {
            abort(422, 'Para vender a crédito identifique al cliente con su NIT/CI (no puede ser «SIN NOMBRE»).');
        }

        $cliente = Cliente::lockForUpdate()->findOrFail($cliente->id);

        if (! $cliente->activo || ! $cliente->credito_habilitado) {
            abort(422, "«{$cliente->nombre}» no tiene el crédito habilitado. Un administrador puede habilitarlo en Clientes.");
        }

        if ($total <= 0) {
            abort(422, 'No se puede registrar a crédito una venta de Bs 0.');
        }

        if ($cliente->limite_credito !== null) {
            $deuda = (float) Pedido::where('cliente_id', $cliente->id)
                ->where('metodo_pago', 'credito')
                ->where('anulada', false)
                ->when($ignorarPedidoId, fn ($q) => $q->where('id', '!=', $ignorarPedidoId))
                ->sum('saldo_pendiente');

            if (round($deuda + $total, 2) > round((float) $cliente->limite_credito, 2)) {
                abort(422, sprintf(
                    'Supera el límite de crédito de «%s»: debe Bs %.2f, esta venta es de Bs %.2f y su límite es Bs %.2f.',
                    $cliente->nombre, $deuda, $total, (float) $cliente->limite_credito
                ));
            }
        }
    }

    // Unidades que se pueden vender ahora mismo de $producto en $almacenId.
    // Si es la "vitrina" de un combo, manda el componente que rinda menos
    // combos completos.
    protected function stockDisponibleEnAlmacen(Producto $producto, int $almacenId): int
    {
        $combo = Combo::where('producto_id', $producto->id)->with('items')->first();

        if ($combo) {
            $disponible = null;

            foreach ($combo->items as $item) {
                $stock = $this->stockEnAlmacen($item->producto_id, $almacenId);
                $posibles = intdiv($stock, max(1, (int) $item->cantidad));
                $disponible = $disponible === null ? $posibles : min($disponible, $posibles);
            }

            return $disponible ?? 0;
        }

        return $this->stockEnAlmacen($producto->id, $almacenId);
    }

    protected function stockEnAlmacen(int $productoId, int $almacenId): int
    {
        return (int) StockPorAlmacen::where('producto_id', $productoId)
            ->where('almacen_id', $almacenId)
            ->value('cantidad');
    }

    protected function verificarStockDisponible(Producto $producto, int $cantidad, int $almacenId): void
    {
        $disponible = $this->stockDisponibleEnAlmacen($producto, $almacenId);

        if ($disponible < $cantidad) {
            abort(422, "Stock insuficiente de «{$producto->nombre}»: disponible {$disponible}, solicitado {$cantidad}.");
        }
    }

    // Saca del almacén $cantidad unidades y deja el rastro en el kardex.
    protected function descontarStockVenta(
        Producto $producto, int $cantidad, int $almacenId, int $usuarioId, string $motivo
    ): void {
        $this->moverStock($producto, -$cantidad, $almacenId, $usuarioId, $motivo);
    }

    // Reverso de descontarStockVenta(): lo usa la anulación de una venta.
    protected function reponerStockVenta(
        Producto $producto, int $cantidad, int $almacenId, int $usuarioId, string $motivo
    ): void {
        $this->moverStock($producto, $cantidad, $almacenId, $usuarioId, $motivo);
    }

    // $signo * $cantidad: negativo = sale, positivo = entra. Si el producto
    // es un combo, el movimiento se aplica a cada componente (cantidad del
    // componente x combos), no al producto vitrina, que no lleva stock.
    private function moverStock(Producto $producto, int $delta, int $almacenId, int $usuarioId, string $motivo): void
    {
        $combo = Combo::where('producto_id', $producto->id)->with('items')->first();

        if ($combo) {
            foreach ($combo->items as $item) {
                $componente = Producto::lockForUpdate()->findOrFail($item->producto_id);
                $cantidadComponente = $item->cantidad * abs($delta);
                $this->registrarMovimiento(
                    $componente, $delta < 0 ? -$cantidadComponente : $cantidadComponente,
                    $almacenId, $usuarioId, "{$motivo} (combo \"{$combo->nombre}\")"
                );
            }

            return;
        }

        $this->registrarMovimiento($producto, $delta, $almacenId, $usuarioId, $motivo);
    }

    private function registrarMovimiento(
        Producto $producto, int $delta, int $almacenId, int $usuarioId, string $motivo
    ): void {
        // ajustarStock() es el único punto que mueve stock: actualiza
        // stock_por_almacen, mantiene la caché productos.stock y aborta con
        // 422 si el almacén quedaría en negativo.
        $nuevoStock = $producto->ajustarStock($delta, $almacenId);

        MovimientoInventario::create([
            'producto_id' => $producto->id,
            'almacen_id' => $almacenId,
            'usuario_id' => $usuarioId,
            'tipo' => $delta < 0 ? 'salida' : 'entrada',
            'cantidad' => abs($delta),
            'stock_resultante' => $nuevoStock,
            'motivo' => $motivo,
        ]);
    }
}
