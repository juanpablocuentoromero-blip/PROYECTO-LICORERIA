<?php

namespace App\Http\Controllers;

use App\Models\LoteProducto;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class LoteController extends Controller
{
    // GET /api/lotes
    // Filtros: producto_id, almacen_id, vence_en_dias (solo los que vencen
    // dentro de N días, incluye los ya vencidos), todos=1 (incluye lotes
    // agotados; por defecto solo se ven los que tienen unidades).
    // Ordenados por vencimiento: el que vence antes primero.
    public function index(Request $request)
    {
        $request->validate([
            'producto_id' => 'nullable|integer',
            'almacen_id' => 'nullable|integer',
            'vence_en_dias' => 'nullable|integer|min:0|max:3650',
        ]);

        $query = LoteProducto::with(['producto:id,codigo,nombre', 'almacen:id,nombre']);

        if (! $request->boolean('todos')) {
            $query->where('cantidad_disponible', '>', 0);
        }

        if ($request->filled('producto_id')) {
            $query->where('producto_id', $request->producto_id);
        }

        if ($request->filled('almacen_id')) {
            $query->where('almacen_id', $request->almacen_id);
        }

        if ($request->filled('vence_en_dias')) {
            $limite = Carbon::now(config('services.licoreria.zona_horaria', 'America/La_Paz'))
                ->addDays((int) $request->vence_en_dias)->toDateString();

            $query->whereNotNull('fecha_vencimiento')->whereDate('fecha_vencimiento', '<=', $limite);
        }

        $hoy = Carbon::now(config('services.licoreria.zona_horaria', 'America/La_Paz'))->startOfDay();

        return $query->orderByRaw('fecha_vencimiento IS NULL')
            ->orderBy('fecha_vencimiento')
            ->orderBy('id')
            ->get()
            ->map(function (LoteProducto $l) use ($hoy) {
                $dias = $l->fecha_vencimiento
                    ? (int) $hoy->diffInDays(Carbon::parse($l->fecha_vencimiento, $hoy->timezone)->startOfDay(), false)
                    : null;

                return array_merge($l->toArray(), [
                    'dias_para_vencer' => $dias,
                    'vencido' => $dias !== null && $dias < 0,
                ]);
            })
            ->values();
    }
}
