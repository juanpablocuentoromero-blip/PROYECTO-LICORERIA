<?php

namespace App\Http\Controllers;

use App\Models\Pedido;
use App\Models\ZonaDelivery;
use Illuminate\Http\Request;

/**
 * Zonas de reparto y su costo de envío (tarea 5.2).
 *
 * index() es público: la tienda necesita mostrar las zonas disponibles
 * en el checkout. Crear/editar/borrar es solo del administrador.
 */
class ZonaDeliveryController extends Controller
{
    // GET /api/zonas-delivery            (público: solo las activas)
    // GET /api/zonas-delivery?todas=1    (administrador: incluye inactivas)
    public function index(Request $request)
    {
        $query = ZonaDelivery::query();

        if (! $request->boolean('todas')) {
            $query->where('activo', true);
        }

        return $query->orderBy('nombre')->get();
    }

    // POST /api/zonas-delivery
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:100|unique:zonas_delivery,nombre',
            'costo_envio' => 'required|numeric|min:0|max:99999',
            'descripcion' => 'nullable|string|max:255',
            'activo' => 'boolean',
        ]);

        return response()->json(ZonaDelivery::create($validated), 201);
    }

    // PUT/PATCH /api/zonas-delivery/{zona}
    // Cambiar el costo no altera pedidos ya hechos: cada pedido guarda el
    // costo de envío que tenía cuando se creó.
    public function update(Request $request, ZonaDelivery $zona)
    {
        $validated = $request->validate([
            'nombre' => 'sometimes|required|string|max:100|unique:zonas_delivery,nombre,'.$zona->id,
            'costo_envio' => 'sometimes|required|numeric|min:0|max:99999',
            'descripcion' => 'nullable|string|max:255',
            'activo' => 'boolean',
        ]);

        $zona->update($validated);

        return response()->json($zona);
    }

    // DELETE /api/zonas-delivery/{zona}
    public function destroy(ZonaDelivery $zona)
    {
        if (Pedido::where('zona_delivery_id', $zona->id)->exists()) {
            abort(422, 'No se puede eliminar: hay pedidos que usaron esta zona. Desactívala en su lugar.');
        }

        $zona->delete();

        return response()->json(['message' => 'Zona eliminada correctamente']);
    }
}
