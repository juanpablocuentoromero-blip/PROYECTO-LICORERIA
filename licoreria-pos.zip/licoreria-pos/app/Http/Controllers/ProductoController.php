<?php

namespace App\Http\Controllers;

use App\Models\Almacen;
use App\Models\LoteProducto;
use App\Models\Producto;
use App\Models\StockPorAlmacen;
use App\Services\AuditoriaService;
use App\Models\Auditoria;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductoController extends Controller
{
    // Campos de producto cuyo cambio queda en la auditoría (4.4).
    private const CAMPOS_AUDITADOS = [
        'nombre', 'categoria_id', 'codigo', 'codigo_barras', 'precio_compra', 'precio_venta',
        'stock_minimo', 'fecha_vencimiento', 'activo',
    ];

    // GET /api/productos
    public function index(Request $request)
    {
        $query = Producto::with('categoria')->where('activo', true);

        if ($request->filled('categoria_id')) {
            $query->where('categoria_id', $request->categoria_id);
        }

        if ($request->filled('buscar')) {
            $query->where(function ($q) use ($request) {
                $q->where('nombre', 'like', '%'.$request->buscar.'%')
                  ->orWhere('codigo', 'like', '%'.$request->buscar.'%');
            });
        }

        if ($request->boolean('stock_bajo')) {
            $query->whereColumn('stock', '<=', 'stock_minimo');
        }

        return $this->listarPaginado($query->orderBy('nombre')->orderBy('id'), $request);
    }

    // POST /api/productos
    public function store(Request $request, AuditoriaService $auditoria)
    {
        $validated = $request->validate([
            'categoria_id' => 'required|exists:categorias,id',
            'codigo' => 'required|string|max:255|unique:productos,codigo',
            'codigo_barras' => 'nullable|string|max:255|unique:productos,codigo_barras',
            'unidades_por_paquete' => 'nullable|integer|min:1',
            'unidades_por_caja' => 'nullable|integer|min:1',
            'nombre' => 'required|string|max:255',
            'descripcion' => 'nullable|string',
            'imagen' => 'nullable|string',
            'precio_compra' => 'required|numeric|min:0',
            'precio_venta' => 'required|numeric|min:0',
            // Margen de ganancia (%) sobre el costo: con él, el precio de
            // venta se recalcula solo cuando cambia el costo (ver update() y
            // la recepción de compras).
            'margen_porcentaje' => 'nullable|numeric|min:0|max:1000',
            'stock' => 'integer|min:0',
            'stock_minimo' => 'integer|min:0',
            // El vencimiento es POR LOTE: lo que se pide al crear el producto
            // es el lote del stock inicial (n.º de lote + fecha de vencimiento),
            // no una fecha suelta del producto. productos.fecha_vencimiento
            // queda como caché del lote que vence primero.
            'fecha_vencimiento' => 'nullable|date',
            'numero_lote' => 'nullable|string|max:100',
            'activo' => 'boolean',
        ]);

        $numeroLote = $validated['numero_lote'] ?? null;
        unset($validated['numero_lote']);

        // productos.stock es una caché del total en todos los almacenes (ver
        // Producto::ajustarStock). Un producto nuevo todavía no tiene fila en
        // stock_por_almacen, así que la creamos acá para el almacén Principal
        // con el stock inicial indicado; si no, quedaría desincronizada la
        // caché apenas alguien intente vender o ajustar este producto.
        $producto = DB::transaction(function () use ($validated, $numeroLote) {
            $producto = Producto::create($validated);
            $almacenId = Almacen::principalId();
            $stockInicial = (int) ($validated['stock'] ?? 0);

            StockPorAlmacen::create([
                'producto_id' => $producto->id,
                'almacen_id' => $almacenId,
                'cantidad' => $stockInicial,
            ]);

            // Stock inicial con vencimiento o n.º de lote = primer lote del producto.
            if ($stockInicial > 0 && (! empty($validated['fecha_vencimiento']) || $numeroLote)) {
                LoteProducto::create([
                    'producto_id' => $producto->id,
                    'almacen_id' => $almacenId,
                    'numero_lote' => $numeroLote,
                    'fecha_vencimiento' => $validated['fecha_vencimiento'] ?? null,
                    'cantidad_inicial' => $stockInicial,
                    'cantidad_disponible' => $stockInicial,
                    'costo_unitario' => $producto->precio_compra,
                ]);

                $producto->sincronizarVencimiento();
            }

            return $producto;
        });

        $auditoria->registrar(
            'crear', 'producto', $producto->id, "Producto: {$producto->nombre}",
            'precio_venta', null, $producto->precio_venta
        );

        return response()->json($producto->load('categoria'), 201);
    }

    // GET /api/productos/{id}
    public function show(Producto $producto)
    {
        return $producto->load('categoria');
    }

    // PUT/PATCH /api/productos/{id}
    public function update(Request $request, Producto $producto, AuditoriaService $auditoria)
    {
        $validated = $request->validate([
            'categoria_id' => 'sometimes|required|exists:categorias,id',
            'codigo' => 'sometimes|required|string|max:255|unique:productos,codigo,'.$producto->id,
            'codigo_barras' => 'nullable|string|max:255|unique:productos,codigo_barras,'.$producto->id,
            'unidades_por_paquete' => 'nullable|integer|min:1',
            'unidades_por_caja' => 'nullable|integer|min:1',
            'nombre' => 'sometimes|required|string|max:255',
            'descripcion' => 'nullable|string',
            'imagen' => 'nullable|string',
            'precio_compra' => 'sometimes|required|numeric|min:0',
            'precio_venta' => 'sometimes|required|numeric|min:0',
            'margen_porcentaje' => 'nullable|numeric|min:0|max:1000',
            'stock' => 'integer|min:0',
            'stock_minimo' => 'integer|min:0',
            'fecha_vencimiento' => 'nullable|date',
            'activo' => 'boolean',
        ]);

        $antes = $producto->only(self::CAMPOS_AUDITADOS);
        $stockAntes = (int) $producto->stock;

        // Automatización del precio: si el producto tiene margen y el admin
        // cambió el costo sin tocar el precio de venta, el precio de venta
        // se recalcula a partir del margen.
        $margen = array_key_exists('margen_porcentaje', $validated)
            ? $validated['margen_porcentaje']
            : $producto->margen_porcentaje;

        if ($margen !== null && array_key_exists('precio_compra', $validated) && ! array_key_exists('precio_venta', $validated)) {
            $validated['precio_venta'] = Producto::precioDesdeMargen((float) $validated['precio_compra'], (float) $margen);
        }

        // Si viene 'stock' en el body, es una corrección manual del admin
        // (no una venta ni una compra), y se interpreta como el nuevo total
        // en el almacén Principal. No se escribe la columna directo: se
        // traduce a un delta contra stock_por_almacen vía ajustarStock(),
        // que es quien mantiene productos.stock en sincronía como caché.
        if (array_key_exists('stock', $validated)) {
            $nuevoStockPrincipal = $validated['stock'];
            unset($validated['stock']);

            DB::transaction(function () use ($producto, $nuevoStockPrincipal) {
                $almacenId = Almacen::principalId();
                $productoBloqueado = Producto::lockForUpdate()->findOrFail($producto->id);

                $registro = StockPorAlmacen::lockForUpdate()->firstOrCreate(
                    ['producto_id' => $productoBloqueado->id, 'almacen_id' => $almacenId],
                    ['cantidad' => 0]
                );

                $delta = $nuevoStockPrincipal - $registro->cantidad;

                if ($delta !== 0) {
                    $productoBloqueado->ajustarStock($delta, $almacenId);
                }
            });
        }

        $producto->update($validated);

        $producto = $producto->fresh('categoria');

        $auditoria->registrarCambios('producto', $producto, $antes, self::CAMPOS_AUDITADOS, "Producto: {$producto->nombre}");

        // La corrección manual de stock no deja movimiento en el kardex: este
        // es su único rastro.
        if ((int) $producto->stock !== $stockAntes) {
            $auditoria->registrar(
                'ajuste', 'inventario', $producto->id, "Corrección manual de stock: {$producto->nombre}",
                'stock', $stockAntes, $producto->stock
            );
        }

        return response()->json($producto);
    }

    // DELETE /api/productos/{id}
    public function destroy(Producto $producto, AuditoriaService $auditoria)
    {
        $producto->delete(); // soft delete

        $auditoria->registrar('eliminar', 'producto', $producto->id, "Producto: {$producto->nombre}");

        return response()->json(['message' => 'Producto eliminado correctamente']);
    }

    // GET /api/productos/{id}/historial-precios  (solo administrador)
    // Cada cambio de precio de compra o de venta, del más nuevo al más viejo,
    // con quién lo hizo. El precio inicial queda como primera fila ("crear").
    public function historialPrecios(Producto $producto)
    {
        $cambios = Auditoria::where('entidad', 'producto')
            ->where('entidad_id', $producto->id)
            ->where(function ($q) {
                $q->whereIn('campo', ['precio_compra', 'precio_venta'])
                  ->orWhere('accion', 'crear');
            })
            ->orderByDesc('created_at')
            ->orderByDesc('id')
            ->get(['id', 'usuario_nombre', 'accion', 'campo', 'valor_anterior', 'valor_nuevo', 'created_at']);

        return response()->json([
            'producto' => [
                'id' => $producto->id,
                'nombre' => $producto->nombre,
                'precio_compra' => (float) $producto->precio_compra,
                'precio_venta' => (float) $producto->precio_venta,
            ],
            'cambios' => $cambios,
        ]);
    }
}
