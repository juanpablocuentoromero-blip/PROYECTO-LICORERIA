<?php

namespace App\Http\Controllers;

use App\Models\Promocion;
use App\Services\PromocionService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

/**
 * Descuentos y promociones con reglas (tarea 5.4).
 *
 * CRUD: solo administrador (precios y márgenes son decisión de negocio).
 * calcular(): lo usan el punto de venta y la tienda online para mostrar el
 * descuento ANTES de cobrar; al registrar la venta el servidor vuelve a
 * calcular todo por su cuenta (nada del navegador se toma como cierto).
 */
class PromocionController extends Controller
{
    // GET /api/promociones
    public function index(Request $request)
    {
        $query = Promocion::with(['categoria:id,nombre', 'producto:id,nombre']);

        if ($request->filled('tipo')) {
            $query->where('tipo', $request->input('tipo'));
        }

        return $query->orderByDesc('activo')->orderBy('tipo')->orderBy('nombre')->get();
    }

    // GET /api/promociones/{promocion}
    public function show(Promocion $promocion)
    {
        return $promocion->load(['categoria:id,nombre', 'producto:id,nombre']);
    }

    // POST /api/promociones
    public function store(Request $request)
    {
        $datos = $this->validar($request);

        $promocion = Promocion::create($datos);

        return response()->json($promocion->load(['categoria:id,nombre', 'producto:id,nombre']), 201);
    }

    // PUT/PATCH /api/promociones/{promocion}
    public function update(Request $request, Promocion $promocion)
    {
        $datos = $this->validar($request, $promocion);

        $promocion->update($datos);

        return response()->json($promocion->load(['categoria:id,nombre', 'producto:id,nombre']));
    }

    // DELETE /api/promociones/{promocion}
    // Borrar una promoción no toca las ventas ya hechas: el descuento quedó
    // guardado en cada línea (detalle_pedidos), con el nombre de la promo.
    public function destroy(Promocion $promocion)
    {
        $promocion->delete();

        return response()->json(['message' => 'Promoción eliminada correctamente']);
    }

    // POST /api/ventas/promociones            (personal, pantalla de Venta)
    // POST /api/cliente/promociones           (cliente, carrito de la tienda)
    // Body: { items: [{producto_id, cantidad, descuento?}], cupon?: "CODIGO" }
    public function calcular(Request $request, PromocionService $promociones)
    {
        $validated = $request->validate([
            'items' => 'required|array|min:1|max:200',
            'items.*.producto_id' => 'required|integer',
            'items.*.cantidad' => 'required|integer|min:1|max:9999',
            'items.*.descuento' => 'nullable|numeric|min:0',
            'cupon' => 'nullable|string|max:40',
        ]);

        $calculo = $promociones->calcularParaItems($validated['items'], $validated['cupon'] ?? null);

        $lineas = [];
        foreach ($calculo['lineas'] as $productoId => $linea) {
            $lineas[] = [
                'producto_id' => (int) $productoId,
                'descuento' => $linea['descuento'],
                'etiqueta' => $linea['etiqueta'],
            ];
        }

        return response()->json([
            'lineas' => $lineas,
            'total_descuento' => $calculo['total'],
            'cupon' => $calculo['cupon'],
            'cupon_error' => $calculo['cupon_error'],
        ]);
    }

    private function validar(Request $request, ?Promocion $actual = null): array
    {
        $datos = $request->validate([
            'nombre' => 'required|string|max:120',
            'tipo' => ['required', Rule::in(['volumen', 'horario', 'cupon'])],
            'alcance' => ['required', Rule::in(['todo', 'categoria', 'producto'])],
            'categoria_id' => ['nullable', 'integer', Rule::exists('categorias', 'id')],
            'producto_id' => ['nullable', 'integer', Rule::exists('productos', 'id')->whereNull('deleted_at')],
            'tipo_descuento' => ['required', Rule::in(['porcentaje', 'monto'])],
            'valor' => 'required|numeric|gt:0|max:99999999',
            'cantidad_minima' => 'nullable|integer|min:1|max:9999',
            'hora_inicio' => ['nullable', 'date_format:H:i'],
            'hora_fin' => ['nullable', 'date_format:H:i'],
            'dias_semana' => ['nullable', 'string', 'max:20', 'regex:/^[0-6](,[0-6])*$/'],
            'codigo' => [
                'nullable', 'string', 'max:40', 'regex:/^[A-Za-z0-9_-]+$/',
                Rule::unique('promociones', 'codigo')->ignore($actual?->id),
            ],
            'usos_maximos' => 'nullable|integer|min:1',
            'fecha_inicio' => 'nullable|date',
            'fecha_fin' => 'nullable|date',
            'activo' => 'boolean',
        ]);

        if (! empty($datos['fecha_inicio']) && ! empty($datos['fecha_fin']) && $datos['fecha_fin'] < $datos['fecha_inicio']) {
            abort(422, 'La fecha de fin no puede ser anterior a la de inicio.');
        }

        if ($datos['tipo_descuento'] === 'porcentaje' && (float) $datos['valor'] > 100) {
            abort(422, 'Un descuento en porcentaje no puede pasar de 100.');
        }

        if ($datos['alcance'] === 'categoria' && empty($datos['categoria_id'])) {
            abort(422, 'Elige la categoría a la que aplica la promoción.');
        }

        if ($datos['alcance'] === 'producto' && empty($datos['producto_id'])) {
            abort(422, 'Elige el producto al que aplica la promoción.');
        }

        // Cada tipo guarda solo SUS reglas: lo demás se limpia para que una
        // promoción editada de "horario" a "volumen" no arrastre una franja
        // horaria vieja que ya no se ve en pantalla.
        switch ($datos['tipo']) {
            case 'volumen':
                if (empty($datos['cantidad_minima'])) {
                    abort(422, 'Indica desde qué cantidad aplica el descuento por volumen.');
                }
                $datos['hora_inicio'] = $datos['hora_fin'] = $datos['dias_semana'] = null;
                $datos['codigo'] = $datos['usos_maximos'] = null;
                break;

            case 'horario':
                if (empty($datos['hora_inicio']) || empty($datos['hora_fin'])) {
                    abort(422, 'Indica la hora de inicio y de fin de la promoción por horario.');
                }
                if ($datos['hora_inicio'] === $datos['hora_fin']) {
                    abort(422, 'La hora de inicio y la de fin no pueden ser iguales.');
                }
                $datos['cantidad_minima'] = null;
                $datos['codigo'] = $datos['usos_maximos'] = null;
                break;

            case 'cupon':
                if (empty($datos['codigo'])) {
                    abort(422, 'Escribe el código del cupón.');
                }
                $datos['codigo'] = strtoupper($datos['codigo']);
                $datos['cantidad_minima'] = null;
                $datos['hora_inicio'] = $datos['hora_fin'] = $datos['dias_semana'] = null;
                break;
        }

        if ($datos['alcance'] !== 'categoria') {
            $datos['categoria_id'] = null;
        }
        if ($datos['alcance'] !== 'producto') {
            $datos['producto_id'] = null;
        }

        return $datos;
    }
}
