<?php

namespace App\Http\Controllers;

use App\Mail\RecuperarPassword;
use App\Models\Cliente;
use App\Models\TokenRecuperacionPassword;
use App\Models\Usuario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class PasswordRecuperacionController extends Controller
{
    // Cuánto dura vigente el enlace del correo, en minutos.
    private const MINUTOS_VIGENCIA = 60;

    // POST /api/password/olvide
    // Recibe el email y el "tipo" de cuenta (usuario del staff o cliente
    // de la tienda) y, si existe, le manda un correo con el enlace para
    // restablecer. Responde siempre el mismo mensaje exista o no la cuenta,
    // para no filtrar qué correos están registrados.
    public function solicitar(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email',
            'tipo' => 'required|in:usuario,cliente',
        ]);

        $cuenta = $this->buscarCuenta($validated['email'], $validated['tipo']);

        if ($cuenta) {
            // Se invalida cualquier token anterior sin usar de esta misma cuenta.
            TokenRecuperacionPassword::where('email', $validated['email'])
                ->where('tipo', $validated['tipo'])
                ->delete();

            $tokenPlano = Str::random(64);

            TokenRecuperacionPassword::create([
                'email' => $validated['email'],
                'tipo' => $validated['tipo'],
                'token' => Hash::make($tokenPlano),
                'created_at' => now(),
            ]);

            $enlace = sprintf(
                '%s/restablecer-password?tipo=%s&email=%s&token=%s',
                rtrim(config('app.frontend_url'), '/'),
                $validated['tipo'],
                urlencode($validated['email']),
                $tokenPlano,
            );

            Mail::to($validated['email'])->queue(new RecuperarPassword($cuenta->nombre, $enlace));
        }

        return response()->json([
            'message' => 'Si el correo está registrado, te enviamos un enlace para restablecer tu contraseña.',
        ]);
    }

    // POST /api/password/restablecer
    public function restablecer(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email',
            'tipo' => 'required|in:usuario,cliente',
            'token' => 'required|string',
            'password' => 'required|string|min:6|confirmed',
        ]);

        $registro = TokenRecuperacionPassword::where('email', $validated['email'])
            ->where('tipo', $validated['tipo'])
            ->latest('created_at')
            ->first();

        $valido = $registro
            && $registro->created_at
            && $registro->created_at->addMinutes(self::MINUTOS_VIGENCIA)->isFuture()
            && Hash::check($validated['token'], $registro->token);

        if (! $valido) {
            return response()->json([
                'message' => 'El enlace no es válido o ya venció. Solicita uno nuevo.',
            ], 422);
        }

        $cuenta = $this->buscarCuenta($validated['email'], $validated['tipo']);

        if (! $cuenta) {
            return response()->json(['message' => 'No se encontró la cuenta.'], 404);
        }

        $cuenta->forceFill([
            'password' => Hash::make($validated['password']),
        ])->save();

        // Cierra TODAS las sesiones activas de la cuenta por seguridad.
        $cuenta->tokens()->delete();

        TokenRecuperacionPassword::where('email', $validated['email'])
            ->where('tipo', $validated['tipo'])
            ->delete();

        return response()->json(['message' => 'Tu contraseña fue actualizada. Ya puedes iniciar sesión.']);
    }

    private function buscarCuenta(string $email, string $tipo): Usuario|Cliente|null
    {
        if ($tipo === 'usuario') {
            return Usuario::where('email', $email)->where('activo', true)->first();
        }

        return Cliente::where('email', $email)
            ->where('activo', true)
            ->whereNotNull('password')
            ->first();
    }
}
