<?php

namespace App\Http\Controllers;

use App\Models\Abono;
use App\Models\Almacen;
use App\Models\Caja;
use App\Models\Devolucion;
use App\Models\MovimientoCajaChica;
use App\Models\Pedido;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class CajaController extends Controller
{
    // GET /api/caja  (solo administrador: histórico completo)
    public function index(Request $request)
    {
        $query = Caja::with(['almacen', 'usuarioApertura', 'usuarioCierre']);

        if ($request->filled('almacen_id')) {
            $query->where('almacen_id', $request->almacen_id);
        }

        if ($request->filled('estado')) {
            $query->where('estado', $request->estado);
        }

        if ($request->filled('desde')) {
            $query->whereDate('abierta_at', '>=', $request->desde);
        }

        if ($request->filled('hasta')) {
            $query->whereDate('abierta_at', '<=', $request->hasta);
        }

        return $query->orderByDesc('abierta_at')->get();
    }

    // GET /api/caja/actual
    // La caja abierta ahora mismo en el almacén indicado (o el Principal por
    // defecto). Cualquiera del staff la puede ver: es el "estado del turno"
    // que necesita el vendedor para saber si puede vender. Los totales
    // corridos (calculados al vuelo, todavía no congelados: eso solo pasa
    // al cerrar) son "Caja Central" — blindaje de caja: el vendedor sabe
    // que la caja está abierta pero NUNCA ve cuánto se ha acumulado en el
    // día; solo el administrador ve `totales`.
    public function actual(Request $request)
    {
        $almacenId = $request->input('almacen_id') ?? Almacen::principalId();

        $caja = Caja::with(['almacen', 'usuarioApertura'])
            ->where('almacen_id', $almacenId)
            ->where('estado', 'abierta')
            ->latest('abierta_at')
            ->first();

        if (! $caja) {
            return response()->json(['abierta' => false, 'caja' => null]);
        }

        $usuario = $request->attributes->get('usuario_autenticado');

        $respuesta = [
            'abierta' => true,
            'caja' => $caja,
        ];

        if ($usuario->rol === 'administrador') {
            $respuesta['totales'] = $this->calcularTotales($caja);
        } else {
            // El vendedor no ve el total acumulado de caja (blindaje), pero sí
            // necesita ver qué vendió él mismo en este turno para poder
            // cerrarlo con criterio.
            $respuesta['mis_ventas'] = $this->calcularMisVentas($caja, $usuario->id);
        }

        return response()->json($respuesta);
    }

    // GET /api/caja/mi-reporte?desde=&hasta=&usuario_id=
    // Reporte de caja para el CAJERO: sus ventas del período por día y por
    // método de pago, sus turnos de caja y su caja chica. El vendedor solo ve
    // lo suyo (nunca el acumulado de todo el negocio: blindaje de caja, y
    // tampoco el esperado/diferencia de sus cierres). El administrador ve lo
    // mismo de todos, o de un cajero puntual con usuario_id.
    public function miReporte(Request $request)
    {
        $request->validate([
            'desde' => 'nullable|date',
            'hasta' => 'nullable|date',
            'usuario_id' => 'nullable|integer|exists:usuarios,id',
        ]);

        $usuario = $request->attributes->get('usuario_autenticado');
        $esAdmin = $usuario->rol === 'administrador';

        // Vendedor: siempre él mismo. Administrador: todos, o el que elija.
        $usuarioId = $esAdmin
            ? ($request->filled('usuario_id') ? (int) $request->usuario_id : null)
            : $usuario->id;

        $tz = config('services.licoreria.zona_horaria', 'America/La_Paz');
        $desde = $request->filled('desde') ? Carbon::parse($request->desde, $tz)->startOfDay() : Carbon::now($tz)->startOfDay();
        $hasta = $request->filled('hasta') ? Carbon::parse($request->hasta, $tz)->endOfDay() : Carbon::now($tz)->endOfDay();
        $utcDesde = $desde->copy()->utc();
        $utcHasta = $hasta->copy()->utc();

        $ventas = Pedido::with('pagos')
            ->when($usuarioId, fn ($q) => $q->where('usuario_id', $usuarioId))
            ->where('pagado', true)
            ->where('metodo_pago', '!=', 'credito')
            ->where('anulada', false)
            ->whereBetween('pagado_at', [$utcDesde, $utcHasta])
            ->orderBy('pagado_at')
            ->get();

        $metodo = fn ($coleccion, string $m) => round((float) $coleccion->sum(fn ($v) => $v->pagosPorMetodo()[$m] ?? 0), 2);

        $porDia = $ventas
            ->groupBy(fn ($v) => Carbon::parse($v->pagado_at)->setTimezone($tz)->toDateString())
            ->map(fn ($g, $fecha) => [
                'fecha' => $fecha,
                'cantidad' => $g->count(),
                'efectivo' => $metodo($g, 'efectivo'),
                'qr' => $metodo($g, 'qr'),
                'tarjeta' => $metodo($g, 'tarjeta'),
                'total' => round((float) $g->sum('total'), 2),
            ])
            ->sortKeys()
            ->values()
            ->all();

        $anuladas = Pedido::where('pagado', true)->where('anulada', true)
            ->when($usuarioId, fn ($q) => $q->where('usuario_id', $usuarioId))
            ->whereBetween('pagado_at', [$utcDesde, $utcHasta])
            ->selectRaw('COUNT(*) as cantidad, COALESCE(SUM(total), 0) as monto')
            ->first();

        $credito = round((float) Pedido::where('metodo_pago', 'credito')->where('anulada', false)
            ->when($usuarioId, fn ($q) => $q->where('usuario_id', $usuarioId))
            ->whereBetween('created_at', [$utcDesde, $utcHasta])
            ->sum('total'), 2);

        $cantidad = $ventas->count();
        $total = round((float) $ventas->sum('total'), 2);

        // Turnos de caja del período en los que participó (los abrió o los cerró).
        $turnos = Caja::with(['almacen:id,nombre', 'usuarioApertura:id,nombre', 'usuarioCierre:id,nombre'])
            ->when($usuarioId, fn ($q) => $q->where(fn ($w) => $w->where('usuario_apertura_id', $usuarioId)
                ->orWhere('usuario_cierre_id', $usuarioId)))
            ->whereBetween('abierta_at', [$utcDesde, $utcHasta])
            ->orderByDesc('abierta_at')
            ->get()
            ->map(function (Caja $c) use ($esAdmin) {
                $fila = [
                    'id' => $c->id,
                    'almacen' => $c->almacen?->nombre,
                    'estado' => $c->estado,
                    'abierta_at' => $c->abierta_at,
                    'abierta_por' => $c->usuarioApertura?->nombre,
                    'cerrada_at' => $c->cerrada_at,
                    'cerrada_por' => $c->cerrada_por_nombre ?? $c->usuarioCierre?->nombre,
                    'monto_apertura' => (float) $c->monto_apertura,
                    'monto_cierre_real' => $c->estado === 'cerrada' ? (float) $c->monto_cierre_real : null,
                ];

                // Lo esperado y la diferencia son del administrador.
                if ($esAdmin && $c->estado === 'cerrada') {
                    $fila['monto_cierre_esperado'] = (float) $c->monto_cierre_esperado;
                    $fila['diferencia'] = (float) $c->diferencia;
                }

                return $fila;
            })->values()->all();

        $chica = MovimientoCajaChica::query()
            ->when($usuarioId, fn ($q) => $q->where('usuario_id', $usuarioId))
            ->whereBetween('created_at', [$utcDesde, $utcHasta])
            ->selectRaw("COUNT(*) as cantidad, COALESCE(SUM(CASE WHEN tipo = 'ingreso' THEN monto ELSE 0 END), 0) as ingresos, COALESCE(SUM(CASE WHEN tipo = 'egreso' THEN monto ELSE 0 END), 0) as egresos")
            ->first();

        return response()->json([
            'desde' => $desde->toDateString(),
            'hasta' => $hasta->toDateString(),
            'usuario' => $usuarioId ? ['id' => $usuarioId, 'nombre' => \App\Models\Usuario::find($usuarioId)?->nombre] : null,
            'resumen' => [
                'cantidad_ventas' => $cantidad,
                'efectivo' => $metodo($ventas, 'efectivo'),
                'qr' => $metodo($ventas, 'qr'),
                'tarjeta' => $metodo($ventas, 'tarjeta'),
                'total' => $total,
                'ticket_promedio' => $cantidad > 0 ? round($total / $cantidad, 2) : 0,
                'ventas_credito' => $credito,
                'cantidad_anuladas' => (int) $anuladas->cantidad,
                'monto_anulado' => round((float) $anuladas->monto, 2),
            ],
            'por_dia' => $porDia,
            'turnos' => $turnos,
            'caja_chica' => [
                'movimientos' => (int) $chica->cantidad,
                'ingresos' => round((float) $chica->ingresos, 2),
                'egresos' => round((float) $chica->egresos, 2),
                'saldo' => round((float) $chica->ingresos - (float) $chica->egresos, 2),
            ],
        ]);
    }

    // GET /api/caja/{caja}
    public function show(Caja $caja)
    {
        return $caja->load(['almacen', 'usuarioApertura', 'usuarioCierre', 'movimientosCajaChica.usuario']);
    }

    // POST /api/caja/abrir
    public function abrir(Request $request)
    {
        $validated = $request->validate([
            'almacen_id' => 'nullable|exists:almacenes,id',
            'monto_apertura' => 'required|numeric|min:0',
            'observaciones' => 'nullable|string|max:255',
        ]);

        $almacenId = $validated['almacen_id'] ?? Almacen::principalId();
        $usuario = $request->attributes->get('usuario_autenticado');

        $caja = DB::transaction(function () use ($validated, $almacenId, $usuario) {
            $yaAbierta = Caja::where('almacen_id', $almacenId)->where('estado', 'abierta')->lockForUpdate()->exists();

            if ($yaAbierta) {
                abort(422, 'Ya hay una caja abierta en este almacén. Ciérrala antes de abrir una nueva.');
            }

            return Caja::create([
                'almacen_id' => $almacenId,
                'usuario_apertura_id' => $usuario->id,
                'monto_apertura' => $validated['monto_apertura'],
                'estado' => 'abierta',
                'observaciones' => $validated['observaciones'] ?? null,
                'abierta_at' => now(),
            ]);
        });

        return response()->json($caja->load('almacen', 'usuarioApertura'), 201);
    }

    // POST /api/caja/{caja}/cerrar
    public function cerrar(Request $request, Caja $caja)
    {
        $validated = $request->validate([
            'monto_cierre_real' => 'required|numeric|min:0',
            'observaciones' => 'nullable|string|max:255',
        ]);

        $usuario = $request->attributes->get('usuario_autenticado');

        $caja = DB::transaction(function () use ($caja, $validated, $usuario) {
            $caja = Caja::lockForUpdate()->findOrFail($caja->id);

            // Se valida DENTRO de la transacción y bajo bloqueo: dos clics
            // simultáneos no pueden cerrar la misma caja dos veces.
            if ($caja->estado === 'cerrada') {
                abort(422, 'Esta caja ya está cerrada.');
            }

            // Un solo instante de cierre: la ventana de cálculo termina
            // exactamente en el mismo momento que se guarda.
            $momentoCierre = now();
            $caja->cerrada_at = $momentoCierre;

            $totales = $this->calcularTotales($caja);

            $esperado = round(
                (float) $caja->monto_apertura
                + $totales['ventas_efectivo']
                + $totales['abonos_efectivo']
                + $totales['ingresos_caja_chica']
                - $totales['egresos_caja_chica']
                - $totales['devoluciones_efectivo'],
                2
            );

            $caja->update([
                'usuario_cierre_id' => $usuario->id,
                'cerrada_por_nombre' => $usuario->nombre,
                'monto_ventas_efectivo' => $totales['ventas_efectivo'],
                'monto_ventas_qr' => $totales['ventas_qr'],
                'monto_ventas_tarjeta' => $totales['ventas_tarjeta'],
                'monto_ventas_total' => $totales['ventas_total'],
                'monto_abonos_efectivo' => $totales['abonos_efectivo'],
                'monto_abonos_qr' => $totales['abonos_qr'],
                'monto_abonos_tarjeta' => $totales['abonos_tarjeta'],
                'monto_ventas_credito' => $totales['ventas_credito'],
                'monto_devoluciones_efectivo' => $totales['devoluciones_efectivo'],
                'monto_devoluciones_total' => $totales['devoluciones_total'],
                'cantidad_devoluciones' => $totales['cantidad_devoluciones'],
                'cantidad_ventas' => $totales['cantidad_ventas'],
                'cantidad_anuladas' => $totales['cantidad_anuladas'],
                'monto_anulado' => $totales['monto_anulado'],
                'detalle_vendedores' => $totales['por_vendedor'],
                'monto_ingresos_caja_chica' => $totales['ingresos_caja_chica'],
                'monto_egresos_caja_chica' => $totales['egresos_caja_chica'],
                'monto_cierre_esperado' => $esperado,
                'monto_cierre_real' => $validated['monto_cierre_real'],
                'diferencia' => round((float) $validated['monto_cierre_real'] - $esperado, 2),
                'estado' => 'cerrada',
                'observaciones_cierre' => $validated['observaciones'] ?? null,
                'cerrada_at' => $momentoCierre,
            ]);

            return $caja;
        });

        $caja->load('almacen', 'usuarioApertura', 'usuarioCierre');

        // Blindaje de caja: el vendedor puede cerrar su turno, pero la
        // respuesta no le muestra el acumulado de todo el negocio del día
        // (eso sigue siendo exclusivo del administrador, vía "Historial de
        // cajas" o el arqueo en PDF).
        if ($usuario->rol !== 'administrador') {
            return response()->json($caja->makeHidden([
                'monto_ventas_efectivo', 'monto_ventas_qr', 'monto_ventas_tarjeta', 'monto_ventas_total',
                'monto_abonos_efectivo', 'monto_abonos_qr', 'monto_abonos_tarjeta', 'monto_ventas_credito',
                'cantidad_ventas', 'cantidad_anuladas', 'monto_anulado', 'detalle_vendedores',
                'monto_ingresos_caja_chica', 'monto_egresos_caja_chica', 'monto_cierre_esperado', 'diferencia',
                'monto_devoluciones_efectivo', 'monto_devoluciones_total', 'cantidad_devoluciones',
            ]));
        }

        return response()->json($caja);
    }

    // GET /api/caja/{caja}/arqueo-pdf  (solo administrador)
    public function arqueoPdf(Caja $caja)
    {
        $caja->load(['almacen', 'usuarioApertura', 'usuarioCierre', 'movimientosCajaChica.usuario']);

        // Las dos ramas devuelven las MISMAS claves, porque la vista las lee todas.
        $totales = $caja->estado === 'cerrada'
            ? [
                'ventas_efectivo' => (float) $caja->monto_ventas_efectivo,
                'ventas_qr' => (float) ($caja->monto_ventas_qr ?? 0),
                'ventas_tarjeta' => (float) ($caja->monto_ventas_tarjeta ?? 0),
                'ventas_total' => (float) ($caja->monto_ventas_total ?? $caja->monto_ventas_efectivo),
                'abonos_efectivo' => (float) ($caja->monto_abonos_efectivo ?? 0),
                'abonos_qr' => (float) ($caja->monto_abonos_qr ?? 0),
                'abonos_tarjeta' => (float) ($caja->monto_abonos_tarjeta ?? 0),
                'ventas_credito' => (float) ($caja->monto_ventas_credito ?? 0),
                'devoluciones_efectivo' => (float) ($caja->monto_devoluciones_efectivo ?? 0),
                'devoluciones_total' => (float) ($caja->monto_devoluciones_total ?? 0),
                'cantidad_devoluciones' => (int) ($caja->cantidad_devoluciones ?? 0),
                'cantidad_ventas' => (int) ($caja->cantidad_ventas ?? 0),
                'cantidad_anuladas' => (int) ($caja->cantidad_anuladas ?? 0),
                'monto_anulado' => (float) ($caja->monto_anulado ?? 0),
                'por_vendedor' => $caja->detalle_vendedores ?? [],
                'ingresos_caja_chica' => (float) $caja->monto_ingresos_caja_chica,
                'egresos_caja_chica' => (float) $caja->monto_egresos_caja_chica,
            ]
            : $this->calcularTotales($caja);

        $pdf = Pdf::loadView('reportes.arqueo-caja', ['caja' => $caja, 'totales' => $totales]);

        return $pdf->download('arqueo-caja-'.$caja->id.'.pdf');
    }

    // Lo que vendió un vendedor puntual en lo que va del turno (sin tocar
    // los totales generales de caja, que siguen ocultos para él).
    private function calcularMisVentas(Caja $caja, int $usuarioId): array
    {
        $finVentana = $caja->cerrada_at ?? now();

        $ventas = Pedido::with('pagos')->where('usuario_id', $usuarioId)
            ->where('pagado', true)
            ->where('metodo_pago', '!=', 'credito')
            ->where('anulada', false)
            ->whereBetween('pagado_at', [$caja->abierta_at, $finVentana])
            ->get();

        // 4.6: en una venta mixta cada método suma solo lo que se cobró por él.
        $sumar = fn ($metodo) => round((float) $ventas->sum(fn ($v) => $v->pagosPorMetodo()[$metodo] ?? 0), 2);

        return [
            'cantidad' => $ventas->count(),
            'efectivo' => $sumar('efectivo'),
            'qr' => $sumar('qr'),
            'tarjeta' => $sumar('tarjeta'),
            'total' => round((float) $ventas->sum('total'), 2),
        ];
    }

    // Calcula, SIN guardar nada, lo que pasó en el turno. Excluye ventas
    // anuladas (antes se contaban dentro del efectivo esperado) y las
    // desglosa por método de pago y por vendedor.
    public function calcularTotales(Caja $caja): array
    {
        $finVentana = $caja->cerrada_at ?? now();

        // Una venta a crédito saldada NO se cuenta aquí: su dinero entró en
        // pedazos (abonos) en los turnos en que se cobró, y ahí se suma.
        // Contarla completa otra vez duplicaría el efectivo esperado.
        $ventas = Pedido::with(['usuario:id,nombre', 'pagos'])
            ->where('pagado', true)
            ->where('metodo_pago', '!=', 'credito')
            ->where('anulada', false)
            ->whereBetween('pagado_at', [$caja->abierta_at, $finVentana])
            ->get();

        $anuladas = Pedido::where('pagado', true)
            ->where('anulada', true)
            ->whereBetween('pagado_at', [$caja->abierta_at, $finVentana])
            ->selectRaw('COUNT(*) as cantidad, COALESCE(SUM(total), 0) as monto')
            ->first();

        $sumar = fn ($coleccion, ?string $metodo = null) => round(
            (float) ($metodo ? $coleccion->where('metodo_pago', $metodo) : $coleccion)->sum('total'),
            2
        );

        // 4.6 (pagos mixtos): cuánto entró por cada método. Una venta mixta
        // reparte su total entre los métodos que se usaron.
        $porMetodo = fn ($coleccion, string $metodo) => round(
            (float) $coleccion->sum(fn ($v) => $v->pagosPorMetodo()[$metodo] ?? 0),
            2
        );

        $porVendedor = $ventas->groupBy('usuario_id')->map(function ($grupo, $usuarioId) use ($sumar, $porMetodo) {
            return [
                'usuario_id' => $usuarioId !== '' ? (int) $usuarioId : null,
                'nombre' => $grupo->first()->usuario?->nombre ?? 'Sin vendedor (pedido en línea)',
                'cantidad' => $grupo->count(),
                'efectivo' => $porMetodo($grupo, 'efectivo'),
                'qr' => $porMetodo($grupo, 'qr'),
                'tarjeta' => $porMetodo($grupo, 'tarjeta'),
                'total' => $sumar($grupo),
            ];
        })->sortByDesc('total')->values()->all();

        $ventasEfectivo = $porMetodo($ventas, 'efectivo');

        // 4.5: devoluciones hechas en este turno. Solo la parte reembolsada en
        // EFECTIVO sale de la caja; lo devuelto por QR/tarjeta o descontado de
        // una deuda no mueve efectivo.
        $dev = Devolucion::where('caja_id', $caja->id)
            ->selectRaw(
                "COUNT(*) as cantidad, COALESCE(SUM(total), 0) as total, "
                ."COALESCE(SUM(CASE WHEN metodo_reembolso = 'efectivo' THEN monto_reembolsado ELSE 0 END), 0) as efectivo"
            )->first();
        $devolucionesEfectivo = round((float) $dev->efectivo, 2);

        $ingresos = (float) MovimientoCajaChica::where('caja_id', $caja->id)
            ->where('tipo', 'ingreso')
            ->where('metodo_pago', 'efectivo')
            ->sum('monto');

        $egresos = (float) MovimientoCajaChica::where('caja_id', $caja->id)
            ->where('tipo', 'egreso')
            ->where('metodo_pago', 'efectivo')
            ->sum('monto');

        // Cobros de fiado hechos en este turno (abonos no anulados), por método.
        $abonosPorMetodo = Abono::where('caja_id', $caja->id)
            ->where('anulado', false)
            ->selectRaw('metodo_pago, COALESCE(SUM(monto), 0) as monto')
            ->groupBy('metodo_pago')
            ->pluck('monto', 'metodo_pago');

        $abonosEfectivo = round((float) $abonosPorMetodo->get('efectivo', 0), 2);
        $abonosQr = round((float) $abonosPorMetodo->get('qr', 0), 2);
        $abonosTarjeta = round((float) $abonosPorMetodo->get('tarjeta', 0), 2);

        // Lo vendido a crédito en el turno: es venta pero NO entró plata.
        $ventasCredito = round((float) Pedido::where('caja_id', $caja->id)
            ->where('metodo_pago', 'credito')
            ->where('anulada', false)
            ->sum('total'), 2);

        return [
            'ventas_efectivo' => $ventasEfectivo,
            'ventas_qr' => $porMetodo($ventas, 'qr'),
            'ventas_tarjeta' => $porMetodo($ventas, 'tarjeta'),
            'ventas_total' => $sumar($ventas),
            'devoluciones_efectivo' => $devolucionesEfectivo,
            'devoluciones_total' => round((float) $dev->total, 2),
            'cantidad_devoluciones' => (int) $dev->cantidad,
            'abonos_efectivo' => $abonosEfectivo,
            'abonos_qr' => $abonosQr,
            'abonos_tarjeta' => $abonosTarjeta,
            'abonos_total' => round($abonosEfectivo + $abonosQr + $abonosTarjeta, 2),
            'ventas_credito' => $ventasCredito,
            'cantidad_ventas' => $ventas->count(),
            'cantidad_anuladas' => (int) $anuladas->cantidad,
            'monto_anulado' => round((float) $anuladas->monto, 2),
            'por_vendedor' => $porVendedor,
            'ingresos_caja_chica' => round($ingresos, 2),
            'egresos_caja_chica' => round($egresos, 2),
            'saldo_esperado_ahora' => round((float) $caja->monto_apertura + $ventasEfectivo + $abonosEfectivo + $ingresos - $egresos - $devolucionesEfectivo, 2),
        ];
    }
}
