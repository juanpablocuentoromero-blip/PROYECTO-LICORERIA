<?php

namespace App\Http\Controllers;

use App\Models\Usuario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    // POST /api/auth/login
    // Autenticación por token de Laravel Sanctum: el token se guarda hasheado
    // en personal_access_tokens, vence solo (services.licoreria.token_staff_minutos)
    // y cada inicio de sesión crea un token NUEVO, así que el mismo usuario
    // puede tener varios dispositivos abiertos a la vez sin echarse unos a otros.
    public function login(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        $usuario = Usuario::where('email', $validated['email'])->first();

        if (! $usuario || ! Hash::check($validated['password'], $usuario->password)) {
            return response()->json(['message' => 'Credenciales incorrectas.'], 401);
        }

        if (! $usuario->activo) {
            return response()->json(['message' => 'Este usuario está inactivo.'], 403);
        }

        $nuevo = $usuario->createToken(
            Str::limit('staff | '.($request->userAgent() ?? 'desconocido'), 200, ''),
            ['*'],
            now()->addMinutes((int) config('services.licoreria.token_staff_minutos')),
        );

        return response()->json([
            'token' => $nuevo->plainTextToken,
            'expires_at' => $nuevo->accessToken->expires_at,
            'usuario' => $usuario,
        ]);
    }

    // POST /api/auth/logout
    // Cierra SOLO la sesión de este dispositivo; los demás siguen abiertos.
    public function logout(Request $request)
    {
        $request->attributes->get('token_actual')?->delete();

        return response()->json(['message' => 'Sesión cerrada.']);
    }

    // GET /api/auth/me
    public function me(Request $request)
    {
        return $request->attributes->get('usuario_autenticado');
    }

    // PUT /api/auth/perfil
    // Autoedición: cualquier usuario autenticado (administrador o vendedor)
    // puede actualizar su propio nombre/contraseña. A propósito NO permite
    // cambiar email ni rol acá -eso sigue exigiendo admin vía
    // UsuarioController::update()- para que nadie pueda auto-otorgarse
    // permisos de administrador cambiando su propio rol.
    public function actualizarPerfil(Request $request)
    {
        $usuario = $request->attributes->get('usuario_autenticado');
        $tokenActual = $request->attributes->get('token_actual');

        $validated = $request->validate([
            'nombre' => 'sometimes|required|string|max:255',
            'password' => 'nullable|string|min:6|confirmed',
        ]);

        $cambioPassword = ! empty($validated['password']);

        if ($cambioPassword) {
            $validated['password'] = Hash::make($validated['password']);
        } else {
            unset($validated['password']);
        }

        $usuario->update($validated);

        // Al cambiar la contraseña se cierran las sesiones de los demás
        // dispositivos (por si alguien más tenía la cuenta abierta); la de
        // este dispositivo se conserva.
        if ($cambioPassword && $tokenActual) {
            $usuario->tokens()->where('id', '!=', $tokenActual->id)->delete();
        }

        return response()->json($usuario);
    }
}
