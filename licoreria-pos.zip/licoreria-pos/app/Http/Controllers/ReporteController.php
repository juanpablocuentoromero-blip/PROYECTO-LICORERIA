<?php

namespace App\Http\Controllers;

use App\Exports\CajasExport;
use App\Exports\ClientesExport;
use App\Exports\ComprasExport;
use App\Exports\CuentasPorCobrarExport;
use App\Exports\InventarioExport;
use App\Exports\MovimientosExport;
use App\Exports\RentabilidadExport;
use App\Exports\VentasExport;
use App\Models\Alerta;
use App\Models\Caja;
use App\Models\Devolucion;
use App\Models\PedidoCompra;
use App\Models\Pedido;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class ReporteController extends Controller
{
    // Valida el rango de fechas opcional (desde/hasta) que aceptan los
    // reportes en Excel. Igual de laxo que libroVentas(): ambos son
    // opcionales, y si no vienen, el reporte trae todo (sin filtrar).
    private function validarRango(Request $request): array
    {
        return $request->validate([
            'desde' => 'nullable|date',
            'hasta' => 'nullable|date',
        ]);
    }

    // GET /api/reportes/ventas?desde=YYYY-MM-DD&hasta=YYYY-MM-DD
    public function ventas(Request $request)
    {
        $rango = $this->validarRango($request);

        return Excel::download(
            new VentasExport($rango['desde'] ?? null, $rango['hasta'] ?? null),
            'reporte-ventas-'.now()->format('Y-m-d').'.xlsx'
        );
    }

    // GET /api/reportes/libro-ventas?desde=YYYY-MM-DD&hasta=YYYY-MM-DD
    // Libro de ventas: listado cronológico de todas las ventas confirmadas
    // (pagadas) en un rango de fechas, con totales acumulados. Es la vista
    // en pantalla; el Excel de "ventas" de arriba sigue disponible para
    // descargar el detalle crudo.
    public function libroVentas(Request $request)
    {
        $desde = $request->filled('desde')
            ? \Illuminate\Support\Carbon::parse($request->desde)->startOfDay()
            : now()->startOfMonth();
        $hasta = $request->filled('hasta')
            ? \Illuminate\Support\Carbon::parse($request->hasta)->endOfDay()
            : now()->endOfDay();

        $ventas = Pedido::with(['cliente', 'usuario', 'pagos'])
            ->where('pagado', true)
            ->where('estado', '!=', 'cancelado')
            ->whereBetween('pagado_at', [$desde, $hasta])
            ->orderBy('pagado_at')
            ->get();

        // 4.6: una venta mixta suma a cada método lo que se cobró por él.
        $resumenPorMetodo = [];
        foreach ($ventas as $v) {
            foreach ($v->pagosPorMetodo() as $metodo => $monto) {
                $resumenPorMetodo[$metodo] = round(($resumenPorMetodo[$metodo] ?? 0) + $monto, 2);
            }
        }

        // 4.5: lo devuelto (notas de crédito) en el mismo rango.
        $totalDevuelto = round((float) Devolucion::whereBetween('created_at', [$desde->copy()->utc(), $hasta->copy()->utc()])->sum('total'), 2);

        return response()->json([
            'desde' => $desde->toDateString(),
            'hasta' => $hasta->toDateString(),
            'ventas' => $ventas,
            'total_general' => (float) $ventas->sum('total'),
            'total_devuelto' => $totalDevuelto,
            'total_neto' => round((float) $ventas->sum('total') - $totalDevuelto, 2),
            'cantidad_ventas' => $ventas->count(),
            'resumen_por_metodo' => $resumenPorMetodo,
        ]);
    }

    // GET /api/reportes/inventario?desde=YYYY-MM-DD&hasta=YYYY-MM-DD
    public function inventario(Request $request)
    {
        $rango = $this->validarRango($request);

        return Excel::download(
            new InventarioExport($rango['desde'] ?? null, $rango['hasta'] ?? null),
            'reporte-inventario-'.now()->format('Y-m-d').'.xlsx'
        );
    }

    // GET /api/reportes/movimientos?desde=YYYY-MM-DD&hasta=YYYY-MM-DD
    public function movimientos(Request $request)
    {
        $rango = $this->validarRango($request);

        return Excel::download(
            new MovimientosExport($rango['desde'] ?? null, $rango['hasta'] ?? null),
            'reporte-movimientos-'.now()->format('Y-m-d').'.xlsx'
        );
    }

    // GET /api/reportes/rentabilidad?desde=YYYY-MM-DD&hasta=YYYY-MM-DD
    // Por cada producto vendido en el rango (solo ventas pagadas y no
    // canceladas): cantidad vendida, ingreso, costo y ganancia, más un
    // total general al final.
    public function rentabilidad(Request $request)
    {
        $rango = $this->validarRango($request);

        return Excel::download(
            new RentabilidadExport($rango['desde'] ?? null, $rango['hasta'] ?? null),
            'reporte-rentabilidad-'.now()->format('Y-m-d').'.xlsx'
        );
    }

    // GET /api/reportes/clientes?desde=YYYY-MM-DD&hasta=YYYY-MM-DD
    public function clientes(Request $request)
    {
        $rango = $this->validarRango($request);

        return Excel::download(
            new ClientesExport($rango['desde'] ?? null, $rango['hasta'] ?? null),
            'reporte-clientes-'.now()->format('Y-m-d').'.xlsx'
        );
    }

    // GET /api/reportes/cuentas-por-cobrar
    // Fiado: cada venta a crédito con saldo pendiente, con días de atraso.
    public function cuentasPorCobrar()
    {
        return Excel::download(
            new CuentasPorCobrarExport(),
            'reporte-cuentas-por-cobrar-'.now()->format('Y-m-d').'.xlsx'
        );
    }

    // ------------------------------------------------------------------
    // REPORTES DE COMPRAS Y CIERRES DE CAJA
    // ------------------------------------------------------------------

    // GET /api/reportes/compras?desde=&hasta=&proveedor_id=&estado=&producto_id=&agrupar_por=
    // Vista en pantalla del reporte de compras. agrupar_por:
    // ninguno | proveedor | producto | dia | mes. Por defecto no cuenta los
    // pedidos cancelados (se pueden ver con estado=cancelado).
    public function compras(Request $request)
    {
        $request->validate([
            'desde' => 'nullable|date',
            'hasta' => 'nullable|date',
            'proveedor_id' => 'nullable|integer',
            'producto_id' => 'nullable|integer',
            'estado' => 'nullable|in:pendiente,recibido,cancelado',
            'agrupar_por' => 'nullable|in:ninguno,proveedor,producto,dia,mes',
        ]);

        $desde = $request->filled('desde') ? Carbon::parse($request->desde)->startOfDay() : now()->startOfMonth();
        $hasta = $request->filled('hasta') ? Carbon::parse($request->hasta)->endOfDay() : now()->endOfDay();
        $agrupar = $request->input('agrupar_por', 'ninguno');

        $query = PedidoCompra::with(['proveedor:id,nombre', 'usuario:id,nombre', 'detalles.producto:id,codigo,nombre'])
            ->whereBetween('created_at', [$desde, $hasta]);

        if ($request->filled('proveedor_id')) {
            $query->where('proveedor_id', $request->proveedor_id);
        }

        if ($request->filled('estado')) {
            $query->where('estado', $request->estado);
        } else {
            $query->where('estado', '!=', 'cancelado');
        }

        if ($request->filled('producto_id')) {
            $query->whereHas('detalles', fn ($q) => $q->where('producto_id', $request->producto_id));
        }

        $pedidos = $query->orderByDesc('created_at')->get();

        // Con filtro por producto, los montos son los de ESE producto, no los del pedido entero.
        $productoId = $request->filled('producto_id') ? (int) $request->producto_id : null;

        $filas = [];
        foreach ($pedidos as $pc) {
            $detalles = $pc->detalles->when($productoId, fn ($d) => $d->where('producto_id', $productoId));

            $filas[] = [
                'id' => $pc->id,
                'fecha' => optional($pc->created_at)->toDateString(),
                'proveedor_id' => $pc->proveedor_id,
                'proveedor' => $pc->proveedor?->nombre ?? '—',
                'estado' => $pc->estado,
                'registrado_por' => $pc->usuario?->nombre,
                'unidades' => (int) $detalles->sum('cantidad'),
                'total' => round((float) $detalles->sum('subtotal'), 2),
                'items' => $detalles->map(fn ($d) => [
                    'producto_id' => $d->producto_id,
                    'producto' => $d->producto?->nombre ?? '—',
                    'cantidad_paquetes' => $d->cantidad_paquetes,
                    'unidades_por_paquete' => $d->unidades_por_paquete,
                    'unidades' => (int) $d->cantidad,
                    'costo_unitario' => (float) $d->precio_unitario,
                    'subtotal' => (float) $d->subtotal,
                    'numero_lote' => $d->numero_lote,
                    'fecha_vencimiento' => $d->fecha_vencimiento ? substr((string) $d->fecha_vencimiento, 0, 10) : null,
                ])->values()->all(),
            ];
        }

        $grupos = [];
        if ($agrupar !== 'ninguno') {
            $acumulado = [];
            foreach ($filas as $f) {
                if ($agrupar === 'producto') {
                    foreach ($f['items'] as $it) {
                        $clave = (string) $it['producto_id'];
                        $acumulado[$clave] ??= ['etiqueta' => $it['producto'], 'pedidos' => [], 'unidades' => 0, 'total' => 0.0];
                        $acumulado[$clave]['pedidos'][$f['id']] = true;
                        $acumulado[$clave]['unidades'] += $it['unidades'];
                        $acumulado[$clave]['total'] = round($acumulado[$clave]['total'] + $it['subtotal'], 2);
                    }

                    continue;
                }

                $clave = match ($agrupar) {
                    'proveedor' => (string) $f['proveedor_id'],
                    'mes' => substr($f['fecha'], 0, 7),
                    default => $f['fecha'],
                };
                $etiqueta = $agrupar === 'proveedor' ? $f['proveedor'] : $clave;

                $acumulado[$clave] ??= ['etiqueta' => $etiqueta, 'pedidos' => [], 'unidades' => 0, 'total' => 0.0];
                $acumulado[$clave]['pedidos'][$f['id']] = true;
                $acumulado[$clave]['unidades'] += $f['unidades'];
                $acumulado[$clave]['total'] = round($acumulado[$clave]['total'] + $f['total'], 2);
            }

            foreach ($acumulado as $clave => $g) {
                $grupos[] = [
                    'clave' => (string) $clave,
                    'etiqueta' => $g['etiqueta'],
                    'pedidos' => count($g['pedidos']),
                    'unidades' => $g['unidades'],
                    'total' => $g['total'],
                ];
            }

            usort($grupos, in_array($agrupar, ['dia', 'mes'], true)
                ? fn ($a, $b) => strcmp($a['clave'], $b['clave'])
                : fn ($a, $b) => $b['total'] <=> $a['total']);
        }

        $porEstado = ['pendiente' => 0.0, 'recibido' => 0.0, 'cancelado' => 0.0];
        foreach ($filas as $f) {
            $porEstado[$f['estado']] = round(($porEstado[$f['estado']] ?? 0) + $f['total'], 2);
        }

        return response()->json([
            'desde' => $desde->toDateString(),
            'hasta' => $hasta->toDateString(),
            'agrupar_por' => $agrupar,
            'resumen' => [
                'pedidos' => count($filas),
                'unidades' => array_sum(array_column($filas, 'unidades')),
                'total' => round(array_sum(array_column($filas, 'total')), 2),
                'por_estado' => $porEstado,
            ],
            'grupos' => $grupos,
            'pedidos' => $filas,
        ]);
    }

    // GET /api/reportes/compras-excel  (mismos filtros que compras, sin agrupar)
    public function comprasExcel(Request $request)
    {
        $request->validate([
            'desde' => 'nullable|date',
            'hasta' => 'nullable|date',
            'proveedor_id' => 'nullable|integer',
            'producto_id' => 'nullable|integer',
            'estado' => 'nullable|in:pendiente,recibido,cancelado',
        ]);

        return Excel::download(
            new ComprasExport(
                $request->input('desde'), $request->input('hasta'),
                $request->filled('proveedor_id') ? (int) $request->proveedor_id : null,
                $request->input('estado'),
                $request->filled('producto_id') ? (int) $request->producto_id : null,
            ),
            'reporte-compras-'.now()->format('Y-m-d').'.xlsx'
        );
    }

    // GET /api/reportes/cajas-excel?desde=&hasta=&usuario_id=
    // Cierres de caja (turnos) con esperado, contado y diferencia.
    public function cajasExcel(Request $request)
    {
        $request->validate([
            'desde' => 'nullable|date',
            'hasta' => 'nullable|date',
            'usuario_id' => 'nullable|integer',
        ]);

        return Excel::download(
            new CajasExport($request->input('desde'), $request->input('hasta'), $request->filled('usuario_id') ? (int) $request->usuario_id : null),
            'reporte-cajas-'.now()->format('Y-m-d').'.xlsx'
        );
    }

    // ------------------------------------------------------------------
    // 4.1 DASHBOARD DEL ADMINISTRADOR
    // ------------------------------------------------------------------

    // GET /api/reportes/dashboard?fecha=YYYY-MM-DD&dias_top=1|7|30
    // Todo en un solo llamado: ventas del día, ticket promedio, top productos,
    // ventas por hora, caja abierta, pedidos pendientes, por cobrar y alertas.
    // Los días se cortan en hora de Bolivia, no en UTC.
    public function dashboard(Request $request, CajaController $cajas)
    {
        $request->validate([
            'fecha' => 'nullable|date',
            'dias_top' => 'nullable|in:1,7,30',
        ]);

        $tz = config('services.licoreria.zona_horaria', 'America/La_Paz');
        $dia = $request->filled('fecha') ? Carbon::parse($request->fecha, $tz) : Carbon::now($tz);
        $diasTop = (int) $request->input('dias_top', 1);

        $ini = $dia->copy()->startOfDay();
        $fin = $dia->copy()->endOfDay();
        $iniAyer = $ini->copy()->subDay();
        $finAyer = $fin->copy()->subDay();

        // Venta "del período": cobrada en el período (no crédito) o, si es
        // fiado, la del día en que se hizo (el cobro posterior son abonos, no ventas).
        $ventasEn = function (Carbon $desde, Carbon $hasta, $q = null, string $t = '') {
            $q ??= Pedido::query();
            $utcDesde = $desde->copy()->utc();
            $utcHasta = $hasta->copy()->utc();

            return $q->where("{$t}anulada", false)
                ->where("{$t}estado", '!=', 'cancelado')
                ->where(function ($w) use ($t, $utcDesde, $utcHasta) {
                    $w->where(fn ($x) => $x->where("{$t}pagado", true)
                            ->where("{$t}metodo_pago", '!=', 'credito')
                            ->whereBetween("{$t}pagado_at", [$utcDesde, $utcHasta]))
                      ->orWhere(fn ($x) => $x->where("{$t}metodo_pago", 'credito')
                            ->whereBetween("{$t}created_at", [$utcDesde, $utcHasta]));
                });
        };

        $hoy = $ventasEn($ini, $fin)->get(['id', 'total', 'metodo_pago', 'pagado_at', 'created_at']);
        $ayer = $ventasEn($iniAyer, $finAyer)->get(['id', 'total']);

        $devolucionesHoy = round((float) Devolucion::whereBetween('created_at', [$ini->copy()->utc(), $fin->copy()->utc()])->sum('total'), 2);
        $devolucionesAyer = round((float) Devolucion::whereBetween('created_at', [$iniAyer->copy()->utc(), $finAyer->copy()->utc()])->sum('total'), 2);

        $totalHoy = round((float) $hoy->sum('total'), 2);
        $netoHoy = round($totalHoy - $devolucionesHoy, 2);
        $netoAyer = round((float) $ayer->sum('total') - $devolucionesAyer, 2);
        $cantidad = $hoy->count();

        // Ventas por hora (0–23).
        $porHora = array_fill(0, 24, ['hora' => 0, 'total' => 0.0, 'cantidad' => 0]);
        foreach ($porHora as $h => $_) {
            $porHora[$h]['hora'] = $h;
        }
        foreach ($hoy as $v) {
            $momento = ($v->metodo_pago === 'credito' ? $v->created_at : ($v->pagado_at ?? $v->created_at));
            $h = (int) Carbon::parse($momento)->setTimezone($tz)->format('G');
            $porHora[$h]['total'] = round($porHora[$h]['total'] + (float) $v->total, 2);
            $porHora[$h]['cantidad']++;
        }

        // Top productos del período elegido (hoy, 7 o 30 días terminando en $dia).
        $iniTop = $ini->copy()->subDays($diasTop - 1);
        $top = $ventasEn($iniTop, $fin, DB::table('detalle_pedidos as d')
                ->join('pedidos as p', 'p.id', '=', 'd.pedido_id')
                ->join('productos as pr', 'pr.id', '=', 'd.producto_id'), 'p.')
            ->groupBy('pr.id', 'pr.nombre')
            ->selectRaw('pr.id, pr.nombre, SUM(d.cantidad) as unidades, SUM(d.subtotal) as importe')
            ->orderByDesc('unidades')
            ->limit(5)
            ->get()
            ->map(fn ($r) => [
                'producto_id' => (int) $r->id,
                'nombre' => $r->nombre,
                'unidades' => (int) $r->unidades,
                'importe' => round((float) $r->importe, 2),
            ])->values();

        // Últimos 7 días (tendencia).
        $ini7 = $ini->copy()->subDays(6);
        $semana = $ventasEn($ini7, $fin)->get(['total', 'metodo_pago', 'pagado_at', 'created_at'])
            ->groupBy(fn ($v) => Carbon::parse($v->metodo_pago === 'credito' ? $v->created_at : ($v->pagado_at ?? $v->created_at))
                ->setTimezone($tz)->toDateString());
        $ultimos7 = [];
        for ($i = 0; $i < 7; $i++) {
            $d = $ini7->copy()->addDays($i)->toDateString();
            $g = $semana->get($d, collect());
            $ultimos7[] = ['fecha' => $d, 'total' => round((float) $g->sum('total'), 2), 'cantidad' => $g->count()];
        }

        // Caja abierta.
        $caja = Caja::with('usuarioApertura:id,nombre')->where('estado', 'abierta')->latest('abierta_at')->first();
        $cajaInfo = null;
        if ($caja) {
            $t = $cajas->calcularTotales($caja);
            $cajaInfo = [
                'id' => $caja->id,
                'abierta_at' => $caja->abierta_at,
                'abierta_por' => $caja->usuarioApertura?->nombre,
                'monto_apertura' => (float) $caja->monto_apertura,
                'ventas_total' => $t['ventas_total'],
                'ventas_efectivo' => $t['ventas_efectivo'],
                'ventas_qr' => $t['ventas_qr'],
                'ventas_tarjeta' => $t['ventas_tarjeta'],
                'saldo_esperado' => $t['saldo_esperado_ahora'],
            ];

            // Blindaje de caja: el vendedor ve que la caja está abierta (y
            // desde cuándo), pero no los montos acumulados del negocio.
            if ($request->attributes->get('usuario_autenticado')?->rol !== 'administrador') {
                foreach (['monto_apertura', 'ventas_total', 'ventas_efectivo', 'ventas_qr', 'ventas_tarjeta', 'saldo_esperado'] as $campo) {
                    $cajaInfo[$campo] = null;
                }
            }
        }

        // Pedidos (tienda online / delivery) por atender.
        $pendientes = Pedido::with('cliente:id,nombre')
            ->where('anulada', false)->where('estado', 'pendiente')
            ->orderBy('created_at')->get();
        $enCurso = Pedido::where('anulada', false)->whereIn('estado', ['confirmado', 'en_camino'])->count();

        $porCobrar = Pedido::where('anulada', false)->where('saldo_pendiente', '>', 0);
        $hoyLocal = $dia->toDateString();

        return response()->json([
            'fecha' => $dia->toDateString(),
            'ventas' => [
                'total' => $totalHoy,
                'devoluciones' => $devolucionesHoy,
                'neto' => $netoHoy,
                'cantidad' => $cantidad,
                'ticket_promedio' => $cantidad > 0 ? round($totalHoy / $cantidad, 2) : 0,
                'neto_ayer' => $netoAyer,
                'variacion_vs_ayer' => $netoAyer > 0 ? round((($netoHoy - $netoAyer) / $netoAyer) * 100, 1) : null,
            ],
            'ventas_por_hora' => array_values($porHora),
            'ultimos_7_dias' => $ultimos7,
            'top_productos' => ['dias' => $diasTop, 'items' => $top],
            'caja' => $cajaInfo,
            'pedidos' => [
                'pendientes' => $pendientes->count(),
                'en_curso' => $enCurso,
                'lista' => $pendientes->take(5)->map(fn ($p) => [
                    'id' => $p->id,
                    'cliente' => $p->cliente?->nombre,
                    'total' => (float) $p->total,
                    'creado' => $p->created_at,
                ])->values(),
            ],
            'por_cobrar' => [
                'total' => round((float) (clone $porCobrar)->sum('saldo_pendiente'), 2),
                'vencido' => round((float) (clone $porCobrar)->where('fecha_vencimiento_credito', '<', $hoyLocal)->sum('saldo_pendiente'), 2),
            ],
            'alertas' => [
                'activas' => Alerta::where('activa', true)->count(),
                'criticas' => Alerta::where('activa', true)->where('severidad', 'critica')->count(),
            ],
        ]);
    }
}
