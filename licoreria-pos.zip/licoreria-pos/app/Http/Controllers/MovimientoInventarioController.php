<?php

namespace App\Http\Controllers;

use App\Models\Almacen;
use App\Models\LoteProducto;
use App\Services\AuditoriaService;
use App\Models\MovimientoInventario;
use App\Models\Producto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MovimientoInventarioController extends Controller
{
    // GET /api/movimientos-inventario
    public function index(Request $request)
    {
        $query = MovimientoInventario::with(['producto', 'usuario', 'almacen']);

        if ($request->filled('producto_id')) {
            $query->where('producto_id', $request->producto_id);
        }

        if ($request->filled('almacen_id')) {
            $query->where('almacen_id', $request->almacen_id);
        }

        if ($request->filled('tipo')) {
            $query->where('tipo', $request->tipo);
        }

        if ($request->filled('es_ajuste')) {
            $query->where('es_ajuste', $request->boolean('es_ajuste'));
        }

        return $this->listarPaginado($query->orderByDesc('created_at')->orderByDesc('id'), $request, 50);
    }

    // POST /api/movimientos-inventario
    // Para entradas manuales (compras, ajustes) o salidas manuales (mermas, ajustes)
    // usuario_id se deriva del usuario autenticado, no del body, para que el
    // registro de auditoría refleje quién hizo realmente el movimiento.
    // almacen_id es opcional: mientras el frontend no deje elegir almacén,
    // se usa el Principal por defecto.
    public function store(Request $request, AuditoriaService $auditoria)
    {
        $validated = $request->validate([
            'producto_id' => 'required|exists:productos,id',
            'almacen_id' => 'nullable|exists:almacenes,id',
            'tipo' => 'required|string|in:entrada,salida,ajuste',
            'cantidad' => 'required|integer|min:1',
            'motivo' => 'nullable|string|max:255',
            // Solo para entradas: si la mercadería viene con vencimiento o
            // número de lote, se registra el lote.
            'fecha_vencimiento' => 'nullable|date',
            'numero_lote' => 'nullable|string|max:100',
        ]);

        $validated['usuario_id'] = $request->attributes->get('usuario_autenticado')->id;
        $almacenId = $validated['almacen_id'] ?? Almacen::principalId();

        $movimiento = DB::transaction(function () use ($validated, $almacenId) {
            $producto = Producto::lockForUpdate()->findOrFail($validated['producto_id']);

            $delta = $validated['tipo'] === 'salida' ? -$validated['cantidad'] : $validated['cantidad'];
            $nuevoStock = $producto->ajustarStock($delta, $almacenId);

            if ($delta > 0 && (! empty($validated['fecha_vencimiento']) || ! empty($validated['numero_lote']))) {
                LoteProducto::create([
                    'producto_id' => $producto->id,
                    'almacen_id' => $almacenId,
                    'numero_lote' => $validated['numero_lote'] ?? null,
                    'fecha_vencimiento' => $validated['fecha_vencimiento'] ?? null,
                    'cantidad_inicial' => $delta,
                    'cantidad_disponible' => $delta,
                    'costo_unitario' => $producto->precio_compra,
                ]);

                $producto->sincronizarVencimiento();
            }

            return MovimientoInventario::create([
                'producto_id' => $producto->id,
                'almacen_id' => $almacenId,
                'usuario_id' => $validated['usuario_id'],
                'tipo' => $validated['tipo'],
                'cantidad' => $validated['cantidad'],
                'stock_resultante' => $nuevoStock,
                'motivo' => $validated['motivo'] ?? null,
            ]);
        });

        $movimiento->load('producto', 'usuario', 'almacen');

        $delta = $movimiento->tipo === 'salida' ? -$movimiento->cantidad : $movimiento->cantidad;
        $auditoria->registrar(
            'ajuste', 'inventario', $movimiento->producto_id,
            "Movimiento de inventario ({$movimiento->tipo}): ".($movimiento->producto?->nombre ?? 'producto').($movimiento->motivo ? " — {$movimiento->motivo}" : ''),
            'stock', $movimiento->stock_resultante - $delta, $movimiento->stock_resultante
        );

        return response()->json($movimiento, 201);
    }

    // GET /api/movimientos-inventario/{id}
    public function show(MovimientoInventario $movimientos_inventario)
    {
        return $movimientos_inventario->load('producto', 'usuario', 'almacen');
    }
}
