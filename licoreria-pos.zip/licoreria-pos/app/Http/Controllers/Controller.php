<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;

abstract class Controller
{
    // 2.2 — Listado con paginación OPCIONAL.
    //
    // Si la petición trae `page` o `por_pagina` responde paginado
    // ({data, current_page, last_page, total, ...}, mismo formato que ya usa
    // Auditoría). Si no trae ninguno responde la lista completa de siempre:
    // varias pantallas (pedidos, inventario, promociones, catálogo...) cargan
    // productos y clientes enteros para llenar desplegables y no deben romperse.
    protected function listarPaginado(Builder $query, Request $request, int $porDefecto = 25): Collection|LengthAwarePaginator
    {
        if (! $request->hasAny(['page', 'por_pagina'])) {
            return $query->get();
        }

        $porPagina = max(1, min(200, (int) $request->input('por_pagina', $porDefecto)));

        return $query->paginate($porPagina);
    }
}
