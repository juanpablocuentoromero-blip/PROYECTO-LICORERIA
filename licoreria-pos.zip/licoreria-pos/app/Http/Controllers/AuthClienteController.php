<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AuthClienteController extends Controller
{
    // POST /api/cliente/registro
    // Crea la cuenta del cliente en la tienda pública. Si ya existe un
    // registro de cliente con ese email (por ejemplo, cargado a mano por
    // el personal en una venta de mostrador) le "activamos" la cuenta
    // asignándole password en lugar de duplicarlo.
    public function registro(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'password' => 'required|string|min:6|confirmed',
            'telefono' => 'nullable|string|max:20',
            'direccion' => 'nullable|string|max:255',
            // Venta de alcohol: solo mayores de 18. La casilla es obligatoria
            // (el backend la exige aunque el frontend ya la pida, porque
            // cualquiera puede llamar a la API sin pasar por la pantalla).
            'mayor_edad' => 'accepted',
        ], [
            'mayor_edad.accepted' => 'Debes confirmar que eres mayor de 18 años para crear tu cuenta.',
        ]);

        $existente = Cliente::where('email', $validated['email'])->first();

        if ($existente && $existente->tieneCuenta()) {
            return response()->json([
                'message' => 'Ya existe una cuenta con este correo. Intenta iniciar sesión.',
            ], 422);
        }

        $cliente = $existente ?? new Cliente();
        $cliente->nombre = $validated['nombre'];
        $cliente->email = $validated['email'];
        $cliente->telefono = $validated['telefono'] ?? $cliente->telefono;
        $cliente->direccion = $validated['direccion'] ?? $cliente->direccion;
        $cliente->password = Hash::make($validated['password']);
        $cliente->activo = true;
        $cliente->mayor_edad_confirmada_at = now();
        $cliente->save();

        $nuevo = $this->crearToken($cliente, $request);

        return response()->json([
            'token' => $nuevo->plainTextToken,
            'expires_at' => $nuevo->accessToken->expires_at,
            'cliente' => $cliente,
        ], 201);
    }

    // POST /api/cliente/login
    public function login(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        $cliente = Cliente::where('email', $validated['email'])->first();

        if (! $cliente || ! $cliente->tieneCuenta() || ! Hash::check($validated['password'], $cliente->password)) {
            return response()->json(['message' => 'Credenciales incorrectas.'], 401);
        }

        if (! $cliente->activo) {
            return response()->json(['message' => 'Esta cuenta está inactiva.'], 403);
        }

        $nuevo = $this->crearToken($cliente, $request);

        return response()->json([
            'token' => $nuevo->plainTextToken,
            'expires_at' => $nuevo->accessToken->expires_at,
            'cliente' => $cliente,
        ]);
    }

    // POST /api/cliente/logout
    public function logout(Request $request)
    {
        // Cierra SOLO la sesión de este dispositivo.
        $request->attributes->get('token_actual')?->delete();

        return response()->json(['message' => 'Sesión cerrada.']);
    }

    // GET /api/cliente/me
    public function me(Request $request)
    {
        return $request->attributes->get('cliente_autenticado');
    }

    // PUT /api/cliente/perfil
    public function actualizarPerfil(Request $request)
    {
        $cliente = $request->attributes->get('cliente_autenticado');
        $tokenActual = $request->attributes->get('token_actual');

        $validated = $request->validate([
            'nombre' => 'sometimes|required|string|max:255',
            'telefono' => 'nullable|string|max:20',
            'direccion' => 'nullable|string|max:255',
            'password' => 'nullable|string|min:6|confirmed',
        ]);

        $cambioPassword = ! empty($validated['password']);

        if ($cambioPassword) {
            $validated['password'] = Hash::make($validated['password']);
        } else {
            unset($validated['password']);
        }

        $cliente->update($validated);

        // Al cambiar la contraseña se cierran las sesiones de los demás
        // dispositivos; la de este dispositivo se conserva.
        if ($cambioPassword && $tokenActual) {
            $cliente->tokens()->where('id', '!=', $tokenActual->id)->delete();
        }

        return response()->json($cliente);
    }

    // Token de Sanctum (hasheado en la base, con vencimiento). Cada login o
    // registro crea uno nuevo: así el cliente puede tener celular y PC abiertos.
    private function crearToken(Cliente $cliente, Request $request)
    {
        return $cliente->createToken(
            Str::limit('cliente | '.($request->userAgent() ?? 'desconocido'), 200, ''),
            ['*'],
            now()->addMinutes((int) config('services.licoreria.token_cliente_minutos')),
        );
    }
}
