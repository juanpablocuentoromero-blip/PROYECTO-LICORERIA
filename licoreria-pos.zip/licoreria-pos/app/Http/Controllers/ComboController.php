<?php

namespace App\Http\Controllers;

use App\Models\Almacen;
use App\Models\Categoria;
use App\Models\Combo;
use App\Models\ComboItem;
use App\Models\Producto;
use App\Models\StockPorAlmacen;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

// Combos/promociones (ej. "botella + hielo + gaseosa"). Es una acción
// exclusiva del administrador: crea/edita la promoción y, con ella, el
// producto "vitrina" que la representa en el catálogo y en el escáner de
// caja. El vendedor solo la ve (y la vende) como un producto normal a
// través de GET /api/productos; no tiene rutas propias sobre combos.
class ComboController extends Controller
{
    // GET /api/combos
    public function index()
    {
        return Combo::with(['producto', 'items.producto'])
            ->orderByDesc('id')
            ->get()
            ->map(fn (Combo $combo) => $this->conStockDisponible($combo));
    }

    // GET /api/combos/{id}
    public function show(Combo $combo)
    {
        $combo->load(['producto', 'items.producto']);

        return $this->conStockDisponible($combo);
    }

    // POST /api/combos
    // Espera: nombre, descripcion?, precio, categoria_id?, codigo?,
    // items: [{producto_id, cantidad}, ...] (mínimo 2 componentes, si no
    // no es un "combo" sino simplemente el producto suelto).
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:255',
            'descripcion' => 'nullable|string',
            'precio' => 'required|numeric|min:0',
            'codigo' => 'nullable|string|max:255|unique:productos,codigo',
            'categoria_id' => 'nullable|exists:categorias,id',
            'activo' => 'boolean',
            'items' => 'required|array|min:2',
            'items.*.producto_id' => 'required|exists:productos,id|distinct',
            'items.*.cantidad' => 'required|integer|min:1',
        ]);

        $combo = DB::transaction(function () use ($validated) {
            $categoriaId = $validated['categoria_id']
                ?? Categoria::firstOrCreate(['nombre' => 'Combos y Promociones'])->id;

            $precioCompraEstimado = 0;
            foreach ($validated['items'] as $item) {
                $componente = Producto::findOrFail($item['producto_id']);
                $precioCompraEstimado += $componente->precio_compra * $item['cantidad'];
            }

            $producto = Producto::create([
                'categoria_id' => $categoriaId,
                'codigo' => $validated['codigo'] ?? 'COMBO-'.Str::upper(Str::random(8)),
                'nombre' => $validated['nombre'],
                'descripcion' => $validated['descripcion'] ?? null,
                'precio_compra' => $precioCompraEstimado,
                'precio_venta' => $validated['precio'],
                'stock' => 0, // el stock real vive en los componentes, no aquí
                'stock_minimo' => 0,
                'activo' => $validated['activo'] ?? true,
            ]);

            // Fila de bookkeeping para que el resto del sistema (que espera
            // stock_por_almacen para cualquier producto) no se rompa.
            StockPorAlmacen::create([
                'producto_id' => $producto->id,
                'almacen_id' => Almacen::principalId(),
                'cantidad' => 0,
            ]);

            $combo = Combo::create([
                'producto_id' => $producto->id,
                'nombre' => $validated['nombre'],
                'descripcion' => $validated['descripcion'] ?? null,
                'precio' => $validated['precio'],
                'activo' => $validated['activo'] ?? true,
            ]);

            foreach ($validated['items'] as $item) {
                ComboItem::create([
                    'combo_id' => $combo->id,
                    'producto_id' => $item['producto_id'],
                    'cantidad' => $item['cantidad'],
                ]);
            }

            return $combo;
        });

        return response()->json($this->conStockDisponible($combo->load(['producto', 'items.producto'])), 201);
    }

    // PUT/PATCH /api/combos/{id}
    // Permite ajustar nombre/precio/descripcion/vigencia y reemplazar la
    // lista de componentes por completo (más simple y menos propenso a
    // errores que hacer diffs parciales sobre los items existentes).
    public function update(Request $request, Combo $combo)
    {
        $validated = $request->validate([
            'nombre' => 'sometimes|required|string|max:255',
            'descripcion' => 'nullable|string',
            'precio' => 'sometimes|required|numeric|min:0',
            'activo' => 'boolean',
            'items' => 'sometimes|array|min:2',
            'items.*.producto_id' => 'required_with:items|exists:productos,id|distinct',
            'items.*.cantidad' => 'required_with:items|integer|min:1',
        ]);

        $combo = DB::transaction(function () use ($validated, $combo) {
            $combo->update(collect($validated)->except('items')->toArray());

            $combo->producto->update([
                'nombre' => $validated['nombre'] ?? $combo->producto->nombre,
                'descripcion' => $validated['descripcion'] ?? $combo->producto->descripcion,
                'precio_venta' => $validated['precio'] ?? $combo->producto->precio_venta,
                'activo' => $validated['activo'] ?? $combo->producto->activo,
            ]);

            if (array_key_exists('items', $validated)) {
                $combo->items()->delete();

                foreach ($validated['items'] as $item) {
                    ComboItem::create([
                        'combo_id' => $combo->id,
                        'producto_id' => $item['producto_id'],
                        'cantidad' => $item['cantidad'],
                    ]);
                }
            }

            return $combo;
        });

        return response()->json($this->conStockDisponible($combo->load(['producto', 'items.producto'])));
    }

    // DELETE /api/combos/{id}
    // Desactiva el combo y su producto vitrina en vez de borrarlos, para no
    // perder el historial de ventas ya hechas con detalle_pedidos apuntando
    // a este producto.
    public function destroy(Combo $combo)
    {
        DB::transaction(function () use ($combo) {
            $combo->update(['activo' => false]);
            $combo->producto->update(['activo' => false]);
        });

        return response()->json(['message' => 'Combo desactivado correctamente']);
    }

    private function conStockDisponible(Combo $combo): Combo
    {
        $combo->setAttribute('stock_disponible', $combo->stockDisponible());

        return $combo;
    }
}
