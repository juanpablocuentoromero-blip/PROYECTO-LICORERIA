<?php

namespace App\Http\Controllers;

use App\Models\Almacen;
use App\Models\DetallePedidoCompra;
use App\Models\LoteProducto;
use App\Models\MovimientoInventario;
use App\Models\PedidoCompra;
use App\Models\Producto;
use App\Services\AuditoriaService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PedidoCompraController extends Controller
{
    // Reglas de validación de las líneas, compartidas por store() y update().
    // Una línea se puede armar de dos maneras:
    //  - por UNIDADES: cantidad + precio_unitario (como siempre), o
    //  - por PAQUETES/cajas: cantidad_paquetes + (unidades_por_paquete, que si
    //    no viene se toma del producto) + precio_paquete (o precio_unitario).
    // En ambos casos el stock siempre se cuenta en unidades.
    private function reglasItems(): array
    {
        return [
            'items' => 'required|array|min:1',
            'items.*.producto_id' => 'required|exists:productos,id',
            'items.*.cantidad' => 'nullable|integer|min:1',
            'items.*.cantidad_paquetes' => 'nullable|integer|min:1',
            'items.*.unidades_por_paquete' => 'nullable|integer|min:1',
            'items.*.precio_unitario' => 'nullable|numeric|min:0',
            'items.*.precio_paquete' => 'nullable|numeric|min:0',
            'items.*.numero_lote' => 'nullable|string|max:100',
            'items.*.fecha_vencimiento' => 'nullable|date',
        ];
    }

    // Convierte lo que mandó el frontend en líneas listas para guardar,
    // calculando solas las unidades y el costo por unidad (automatización
    // del valor del producto). Devuelve [lineas, subtotal].
    private function armarLineas(array $items): array
    {
        $subtotal = 0.0;
        $lineas = [];

        foreach ($items as $item) {
            $producto = Producto::findOrFail($item['producto_id']);
            $paquetes = $item['cantidad_paquetes'] ?? null;

            if ($paquetes) {
                $porPaquete = $item['unidades_por_paquete'] ?? $producto->unidades_por_paquete;

                if (! $porPaquete) {
                    abort(422, "Indica cuántas unidades trae el paquete de «{$producto->nombre}».");
                }

                if (isset($item['precio_paquete'])) {
                    $precioPaquete = round((float) $item['precio_paquete'], 2);
                } elseif (isset($item['precio_unitario'])) {
                    $precioPaquete = round((float) $item['precio_unitario'] * $porPaquete, 2);
                } else {
                    abort(422, "Indica el costo del paquete de «{$producto->nombre}».");
                }

                $unidades = (int) $paquetes * (int) $porPaquete;
                $costoUnitario = round($precioPaquete / $porPaquete, 2);
                $lineaSubtotal = round($precioPaquete * $paquetes, 2);
            } else {
                if (empty($item['cantidad'])) {
                    abort(422, "Indica la cantidad de «{$producto->nombre}».");
                }

                if (! isset($item['precio_unitario'])) {
                    abort(422, "Indica el costo unitario de «{$producto->nombre}».");
                }

                $porPaquete = null;
                $precioPaquete = null;
                $unidades = (int) $item['cantidad'];
                $costoUnitario = round((float) $item['precio_unitario'], 2);
                $lineaSubtotal = round($costoUnitario * $unidades, 2);
            }

            $subtotal = round($subtotal + $lineaSubtotal, 2);

            $lineas[] = [
                'producto_id' => $producto->id,
                'cantidad' => $unidades,
                'cantidad_paquetes' => $paquetes,
                'unidades_por_paquete' => $porPaquete,
                'precio_paquete' => $precioPaquete,
                'precio_unitario' => $costoUnitario,
                'subtotal' => $lineaSubtotal,
                'numero_lote' => $item['numero_lote'] ?? null,
                'fecha_vencimiento' => $item['fecha_vencimiento'] ?? null,
            ];
        }

        return [$lineas, $subtotal];
    }

    // GET /api/pedidos-compra
    // Filtros: estado, proveedor_id, desde, hasta (por fecha de creación).
    public function index(Request $request)
    {
        $query = PedidoCompra::with(['proveedor', 'usuario', 'detalles.producto']);

        if ($request->filled('estado')) {
            $query->where('estado', $request->estado);
        }

        if ($request->filled('proveedor_id')) {
            $query->where('proveedor_id', $request->proveedor_id);
        }

        if ($request->filled('desde')) {
            $query->whereDate('created_at', '>=', $request->desde);
        }

        if ($request->filled('hasta')) {
            $query->whereDate('created_at', '<=', $request->hasta);
        }

        return $query->orderByDesc('created_at')->get();
    }

    // POST /api/pedidos-compra
    // Espera: proveedor_id, observaciones, items (ver reglasItems()).
    // Se crea en estado "pendiente" y a propósito NO toca el stock todavía:
    // el stock recién sube cuando la mercadería realmente llega (ver recibir()).
    public function store(Request $request)
    {
        $validated = $request->validate(array_merge([
            'proveedor_id' => 'required|exists:proveedores,id',
            'observaciones' => 'nullable|string',
        ], $this->reglasItems()));

        $usuarioId = $request->attributes->get('usuario_autenticado')->id;

        $pedidoCompra = DB::transaction(function () use ($validated, $usuarioId) {
            [$lineas, $subtotal] = $this->armarLineas($validated['items']);

            $pedidoCompra = PedidoCompra::create([
                'proveedor_id' => $validated['proveedor_id'],
                'usuario_id' => $usuarioId,
                'estado' => 'pendiente',
                'subtotal' => $subtotal,
                'total' => $subtotal,
                'observaciones' => $validated['observaciones'] ?? null,
            ]);

            foreach ($lineas as $linea) {
                DetallePedidoCompra::create(['pedido_compra_id' => $pedidoCompra->id, ...$linea]);
            }

            return $pedidoCompra;
        });

        return response()->json($pedidoCompra->load('detalles.producto', 'proveedor'), 201);
    }

    // GET /api/pedidos-compra/{id}
    public function show(PedidoCompra $pedidoCompra)
    {
        return $pedidoCompra->load(['proveedor', 'usuario', 'detalles.producto']);
    }

    // PUT/PATCH /api/pedidos-compra/{id}
    // Editar un pedido de compra: solo mientras sigue "pendiente" (todavía
    // no tocó el stock). Cambia el proveedor, las observaciones y/o reemplaza
    // todas las líneas por las que lleguen en items.
    public function update(Request $request, PedidoCompra $pedidoCompra)
    {
        $validated = $request->validate(array_merge([
            'proveedor_id' => 'sometimes|required|exists:proveedores,id',
            'observaciones' => 'nullable|string',
        ], array_merge($this->reglasItems(), ['items' => 'sometimes|required|array|min:1'])));

        $pedidoCompra = DB::transaction(function () use ($pedidoCompra, $validated) {
            $pedido = PedidoCompra::lockForUpdate()->findOrFail($pedidoCompra->id);

            if ($pedido->estado !== 'pendiente') {
                abort(422, 'Solo se puede editar un pedido de compra que sigue pendiente.');
            }

            $cambios = [];

            if (array_key_exists('proveedor_id', $validated)) {
                $cambios['proveedor_id'] = $validated['proveedor_id'];
            }

            if (array_key_exists('observaciones', $validated)) {
                $cambios['observaciones'] = $validated['observaciones'];
            }

            if (isset($validated['items'])) {
                [$lineas, $subtotal] = $this->armarLineas($validated['items']);

                $pedido->detalles()->delete();

                foreach ($lineas as $linea) {
                    DetallePedidoCompra::create(['pedido_compra_id' => $pedido->id, ...$linea]);
                }

                $cambios['subtotal'] = $subtotal;
                $cambios['total'] = $subtotal;
            }

            $pedido->update($cambios);

            return $pedido;
        });

        return response()->json($pedidoCompra->load('detalles.producto', 'proveedor', 'usuario'));
    }

    // POST /api/pedidos-compra/{id}/recibir
    // Marca la mercadería como recibida: SUMA el stock de cada producto,
    // registra un movimiento de inventario tipo "entrada" por cada línea,
    // crea el LOTE si la línea trae fecha de vencimiento o número de lote,
    // y cierra el pedido de compra. No se puede deshacer desde acá (si se
    // recibió por error, se ajusta el stock vía un ajuste de inventario).
    //
    // Automatización del valor del producto: el costo unitario de la
    // compra pasa a ser el nuevo precio_compra del producto y, si el
    // producto tiene margen de ganancia (%), su precio_venta se recalcula.
    // Se puede evitar mandando actualizar_costos=false. Cada cambio de
    // precio queda en la auditoría / historial de precios.
    public function recibir(Request $request, PedidoCompra $pedidoCompra, AuditoriaService $auditoria)
    {
        $request->validate(['actualizar_costos' => 'sometimes|boolean']);
        $actualizarCostos = $request->boolean('actualizar_costos', true);

        if ($pedidoCompra->estado !== 'pendiente') {
            abort(422, 'Este pedido de compra ya no está pendiente.');
        }

        DB::transaction(function () use ($pedidoCompra, $actualizarCostos, $auditoria) {
            $almacenId = Almacen::principalId();

            foreach ($pedidoCompra->detalles as $detalle) {
                $producto = Producto::lockForUpdate()->findOrFail($detalle->producto_id);
                $nuevoStock = $producto->ajustarStock($detalle->cantidad, $almacenId);

                MovimientoInventario::create([
                    'producto_id' => $producto->id,
                    'almacen_id' => $almacenId,
                    'usuario_id' => $pedidoCompra->usuario_id,
                    'tipo' => 'entrada',
                    'cantidad' => $detalle->cantidad,
                    'stock_resultante' => $nuevoStock,
                    'motivo' => 'Compra a proveedor - Pedido de compra #'.$pedidoCompra->id,
                ]);

                if ($detalle->fecha_vencimiento || $detalle->numero_lote) {
                    LoteProducto::create([
                        'producto_id' => $producto->id,
                        'almacen_id' => $almacenId,
                        'pedido_compra_id' => $pedidoCompra->id,
                        'numero_lote' => $detalle->numero_lote,
                        'fecha_vencimiento' => $detalle->fecha_vencimiento,
                        'cantidad_inicial' => $detalle->cantidad,
                        'cantidad_disponible' => $detalle->cantidad,
                        'costo_unitario' => $detalle->precio_unitario,
                    ]);

                    $producto->sincronizarVencimiento();
                }

                if ($actualizarCostos) {
                    $this->actualizarValorProducto($producto, (float) $detalle->precio_unitario, $auditoria);
                }
            }

            $pedidoCompra->update(['estado' => 'recibido', 'recibido_at' => now()]);
        });

        return response()->json($pedidoCompra->load('detalles.producto', 'proveedor'));
    }

    // Costo nuevo = costo de la última compra. Si el producto tiene margen,
    // el precio de venta se recalcula a partir de ese costo.
    private function actualizarValorProducto(Producto $producto, float $costoUnitario, AuditoriaService $auditoria): void
    {
        $antes = $producto->only(['precio_compra', 'precio_venta']);

        $cambios = [];

        if ($costoUnitario > 0 && round((float) $producto->precio_compra, 2) !== round($costoUnitario, 2)) {
            $cambios['precio_compra'] = round($costoUnitario, 2);
        }

        if ($producto->margen_porcentaje !== null) {
            $costoVigente = $cambios['precio_compra'] ?? (float) $producto->precio_compra;
            $sugerido = Producto::precioDesdeMargen($costoVigente, (float) $producto->margen_porcentaje);

            if ($sugerido !== null && round((float) $producto->precio_venta, 2) !== $sugerido) {
                $cambios['precio_venta'] = $sugerido;
            }
        }

        if ($cambios === []) {
            return;
        }

        $producto->update($cambios);

        $auditoria->registrarCambios(
            'producto', $producto->fresh(), $antes, ['precio_compra', 'precio_venta'],
            "Producto: {$producto->nombre} (actualizado por compra recibida)"
        );
    }

    // DELETE /api/pedidos-compra/{id}
    // Cancela un pedido de compra. Solo mientras sigue "pendiente": si ya
    // se recibió, el stock ya se sumó y cancelarlo requeriría revertir
    // movimientos de inventario que pudieron haberse usado en ventas
    // posteriores, así que esa combinación no se permite acá.
    public function destroy(PedidoCompra $pedidoCompra)
    {
        if ($pedidoCompra->estado !== 'pendiente') {
            abort(422, 'Solo se puede cancelar un pedido de compra que sigue pendiente.');
        }

        $pedidoCompra->update(['estado' => 'cancelado']);

        return response()->json(['message' => 'Pedido de compra cancelado']);
    }
}
