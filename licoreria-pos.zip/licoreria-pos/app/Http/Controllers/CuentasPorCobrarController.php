<?php

namespace App\Http\Controllers;

use App\Models\Abono;
use App\Models\Almacen;
use App\Models\Caja;
use App\Models\Cliente;
use App\Models\Pedido;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Cuentas por cobrar / fiado (tarea 5.3).
 *
 * Una venta a crédito es un pedido con metodo_pago = 'credito', SIN pagar y
 * con saldo_pendiente = total. Cada cobro posterior es un "abono":
 *  - baja el saldo de la venta (cuando llega a 0 la venta pasa a pagada);
 *  - queda ligado a la caja abierta, para que el efectivo cobrado entre al
 *    arqueo de ese turno (CajaController::calcularTotales).
 *
 * Quién puede hacer qué:
 *  - Administrador y vendedor: ver deudas, registrar abonos, estado de cuenta.
 *  - Solo administrador: anular un abono y el reporte en Excel.
 *    (Habilitar el crédito y fijar el límite de cada cliente vive en
 *    ClienteController, también solo administrador.)
 */
class CuentasPorCobrarController extends Controller
{
    // GET /api/cuentas-por-cobrar?buscar=&solo_vencidas=1
    // Una fila por cliente que debe algo, con lo que debe y cuánto de eso ya
    // está vencido.
    public function index(Request $request)
    {
        $hoy = $this->hoy();

        $query = Pedido::query()
            ->where('metodo_pago', 'credito')
            ->where('anulada', false)
            ->where('saldo_pendiente', '>', 0);

        if ($request->filled('buscar')) {
            $texto = $request->input('buscar');
            $query->whereHas('cliente', function ($q) use ($texto) {
                $q->where('nombre', 'like', '%'.$texto.'%')
                    ->orWhere('nit_ci', 'like', '%'.$texto.'%');
            });
        }

        $filas = $query
            ->selectRaw(
                'cliente_id, COUNT(*) as cantidad_ventas, SUM(total) as total_credito, '
                .'SUM(saldo_pendiente) as deuda, MIN(fecha_vencimiento_credito) as primer_vencimiento, '
                .'SUM(CASE WHEN fecha_vencimiento_credito IS NOT NULL AND fecha_vencimiento_credito < ? '
                .'THEN saldo_pendiente ELSE 0 END) as vencido',
                [$hoy]
            )
            ->groupBy('cliente_id')
            ->get();

        $clientes = Cliente::whereIn('id', $filas->pluck('cliente_id'))->get()->keyBy('id');

        $resultado = $filas->map(function ($f) use ($clientes) {
            $cliente = $clientes->get($f->cliente_id);
            $deuda = round((float) $f->deuda, 2);

            return [
                'cliente_id' => (int) $f->cliente_id,
                'nombre' => $cliente?->nombre ?? 'Cliente eliminado',
                'nit_ci' => $cliente?->nit_ci,
                'telefono' => $cliente?->telefono,
                'limite_credito' => $cliente?->limite_credito !== null ? (float) $cliente->limite_credito : null,
                'cantidad_ventas' => (int) $f->cantidad_ventas,
                'total_credito' => round((float) $f->total_credito, 2),
                'deuda' => $deuda,
                'vencido' => round((float) $f->vencido, 2),
                'primer_vencimiento' => $f->primer_vencimiento
                    ? Carbon::parse($f->primer_vencimiento)->format('d/m/Y')
                    : null,
            ];
        });

        if ($request->boolean('solo_vencidas')) {
            $resultado = $resultado->filter(fn ($r) => $r['vencido'] > 0);
        }

        // Primero los que tienen deuda vencida, y dentro de cada grupo, la deuda mayor.
        $resultado = $resultado->sortBy([['vencido', 'desc'], ['deuda', 'desc']])->values();

        return response()->json([
            'clientes' => $resultado,
            'resumen' => [
                'clientes_con_deuda' => $resultado->count(),
                'deuda_total' => round((float) $resultado->sum('deuda'), 2),
                'vencido_total' => round((float) $resultado->sum('vencido'), 2),
            ],
        ]);
    }

    // GET /api/cuentas-por-cobrar/clientes/{cliente}
    // Detalle de un cliente: ventas pendientes y últimos abonos.
    public function cliente(Cliente $cliente)
    {
        return response()->json($this->armarEstadoCliente($cliente));
    }

    // POST /api/cuentas-por-cobrar/abonos
    // Body: { cliente_id, monto, metodo_pago, pedido_id?, observaciones? }
    // Con pedido_id se abona a esa venta; sin él, el monto se reparte entre
    // las deudas del cliente empezando por la más antigua.
    public function abonar(Request $request)
    {
        $validated = $request->validate([
            'cliente_id' => 'required|integer|exists:clientes,id',
            'pedido_id' => 'nullable|integer|exists:pedidos,id',
            'monto' => 'required|numeric|gt:0|max:9999999',
            'metodo_pago' => 'required|string|in:efectivo,qr,tarjeta',
            'observaciones' => 'nullable|string|max:255',
        ]);

        $usuario = $request->attributes->get('usuario_autenticado');
        $monto = round((float) $validated['monto'], 2);

        $abonos = DB::transaction(function () use ($validated, $usuario, $monto) {
            // El cobro entra al arqueo de la caja abierta, igual que una venta.
            $caja = Caja::where('almacen_id', Almacen::principalId())
                ->where('estado', 'abierta')
                ->latest('abierta_at')
                ->first();

            if (! $caja) {
                abort(422, 'La caja está cerrada. Abre el turno para poder registrar cobros.');
            }

            // Se bloquea al cliente: dos abonos simultáneos no pueden
            // "gastar" el mismo saldo dos veces.
            Cliente::lockForUpdate()->findOrFail($validated['cliente_id']);

            $query = Pedido::where('cliente_id', $validated['cliente_id'])
                ->where('metodo_pago', 'credito')
                ->where('anulada', false)
                ->where('saldo_pendiente', '>', 0);

            if (! empty($validated['pedido_id'])) {
                $query->where('id', $validated['pedido_id']);
            }

            $pedidos = $query->orderBy('created_at')->orderBy('id')->lockForUpdate()->get();

            if ($pedidos->isEmpty()) {
                abort(422, 'No hay deuda pendiente para abonar.');
            }

            $deuda = round((float) $pedidos->sum('saldo_pendiente'), 2);
            if ($monto > $deuda) {
                abort(422, sprintf('El abono (Bs %.2f) supera la deuda pendiente (Bs %.2f).', $monto, $deuda));
            }

            $resto = $monto;
            $creados = [];

            foreach ($pedidos as $pedido) {
                if ($resto <= 0) {
                    break;
                }

                $aplica = round(min($resto, (float) $pedido->saldo_pendiente), 2);

                $creados[] = Abono::create([
                    'pedido_id' => $pedido->id,
                    'cliente_id' => $pedido->cliente_id,
                    'usuario_id' => $usuario->id,
                    'caja_id' => $caja->id,
                    'monto' => $aplica,
                    'metodo_pago' => $validated['metodo_pago'],
                    'observaciones' => $validated['observaciones'] ?? null,
                ]);

                $nuevoSaldo = round((float) $pedido->saldo_pendiente - $aplica, 2);
                $pedido->saldo_pendiente = max(0, $nuevoSaldo);

                // Saldada del todo: pasa a pagada. A partir de ahí cuenta en
                // el libro de ventas y en rentabilidad (el sistema reconoce la
                // venta cuando está cobrada).
                if ($nuevoSaldo <= 0) {
                    $pedido->pagado = true;
                    $pedido->pagado_at = now();
                }

                $pedido->save();
                $resto = round($resto - $aplica, 2);
            }

            return collect($creados);
        });

        $cliente = Cliente::findOrFail($validated['cliente_id']);

        return response()->json([
            'message' => 'Abono registrado.',
            'abonos' => $abonos->map(fn (Abono $a) => [
                'id' => $a->id,
                'pedido_id' => $a->pedido_id,
                'monto' => (float) $a->monto,
                'metodo_pago' => $a->metodo_pago,
            ])->values(),
            'estado' => $this->armarEstadoCliente($cliente),
        ], 201);
    }

    // POST /api/cuentas-por-cobrar/abonos/{abono}/anular   (solo administrador)
    // Un abono nunca se borra: se anula y la venta vuelve a deber ese monto.
    public function anularAbono(Request $request, Abono $abono)
    {
        $validated = $request->validate([
            'motivo' => 'required|string|max:255',
        ]);

        $usuario = $request->attributes->get('usuario_autenticado');

        DB::transaction(function () use ($abono, $validated, $usuario) {
            $abono = Abono::lockForUpdate()->findOrFail($abono->id);

            if ($abono->anulado) {
                abort(422, 'Este abono ya fue anulado.');
            }

            $pedido = Pedido::lockForUpdate()->findOrFail($abono->pedido_id);

            if ($pedido->anulada) {
                abort(422, 'La venta ya está anulada.');
            }

            $pedido->saldo_pendiente = round((float) $pedido->saldo_pendiente + (float) $abono->monto, 2);
            $pedido->pagado = false;
            $pedido->pagado_at = null;
            $pedido->save();

            $abono->update([
                'anulado' => true,
                'anulado_at' => now(),
                'motivo_anulacion' => $validated['motivo'],
                'usuario_anulacion_id' => $usuario->id,
            ]);
        });

        return response()->json([
            'message' => 'Abono anulado: la venta volvió a deber ese monto.',
            'estado' => $this->armarEstadoCliente(Cliente::findOrFail($abono->cliente_id)),
        ]);
    }

    // GET /api/cuentas-por-cobrar/clientes/{cliente}/estado-pdf
    // Estado de cuenta para entregar o mandar al cliente.
    public function estadoCuentaPdf(Cliente $cliente)
    {
        $estado = $this->armarEstadoCliente($cliente, 500);

        $pdf = Pdf::loadView('reportes.estado-cuenta', [
            'estado' => $estado,
            'generado' => $this->local(now())->format('d/m/Y H:i'),
        ]);

        return $pdf->download('estado-cuenta-'.$cliente->id.'.pdf');
    }

    // ------------------------------------------------------------------
    // Internos
    // ------------------------------------------------------------------

    private function armarEstadoCliente(Cliente $cliente, int $limiteAbonos = 50): array
    {
        $hoy = $this->hoy();

        $pedidos = Pedido::where('cliente_id', $cliente->id)
            ->where('metodo_pago', 'credito')
            ->where('anulada', false)
            ->where('saldo_pendiente', '>', 0)
            ->orderBy('created_at')
            ->orderBy('id')
            ->get();

        $ventas = $pedidos->map(function (Pedido $p) use ($hoy) {
            $diasAtraso = $this->diasDeAtraso($p->fecha_vencimiento_credito, $hoy);

            return [
                'id' => $p->id,
                'nro_documento' => $p->nroDocumento(),
                'fecha' => $this->local($p->created_at)->format('d/m/Y'),
                'total' => round((float) $p->total, 2),
                'abonado' => round((float) $p->total - (float) $p->saldo_pendiente, 2),
                'saldo' => round((float) $p->saldo_pendiente, 2),
                'fecha_vencimiento' => $p->fecha_vencimiento_credito?->format('d/m/Y'),
                'dias_atraso' => $diasAtraso,
                'vencida' => $diasAtraso > 0,
            ];
        })->values();

        $abonos = Abono::with(['usuario:id,nombre', 'pedido:id,nro_factura'])
            ->where('cliente_id', $cliente->id)
            ->orderByDesc('created_at')
            ->orderByDesc('id')
            ->limit($limiteAbonos)
            ->get()
            ->map(fn (Abono $a) => [
                'id' => $a->id,
                'pedido_id' => $a->pedido_id,
                'nro_documento' => $a->pedido?->nroDocumento(),
                'fecha' => $this->local($a->created_at)->format('d/m/Y H:i'),
                'monto' => (float) $a->monto,
                'metodo_pago' => $a->metodo_pago,
                'vendedor' => $a->usuario?->nombre,
                'observaciones' => $a->observaciones,
                'anulado' => (bool) $a->anulado,
                'motivo_anulacion' => $a->motivo_anulacion,
            ])
            ->values();

        $deuda = round((float) $ventas->sum('saldo'), 2);
        $limite = $cliente->limite_credito !== null ? (float) $cliente->limite_credito : null;

        return [
            'cliente' => [
                'id' => $cliente->id,
                'nombre' => $cliente->nombre,
                'nit_ci' => $cliente->nit_ci,
                'telefono' => $cliente->telefono,
                'email' => $cliente->email,
                'credito_habilitado' => (bool) $cliente->credito_habilitado,
                'limite_credito' => $limite,
            ],
            'deuda_total' => $deuda,
            'vencido_total' => round((float) $ventas->where('vencida', true)->sum('saldo'), 2),
            'disponible' => $limite !== null ? round(max(0, $limite - $deuda), 2) : null,
            'ventas' => $ventas,
            'abonos' => $abonos,
        ];
    }

    // Días que lleva vencida una deuda (0 si no vence o aún está a tiempo).
    private function diasDeAtraso(?Carbon $vencimiento, string $hoy): int
    {
        if (! $vencimiento) {
            return 0;
        }

        $segundos = Carbon::parse($hoy)->startOfDay()->timestamp - $vencimiento->copy()->startOfDay()->timestamp;

        return max(0, intdiv($segundos, 86400));
    }

    private function zona(): string
    {
        return config('services.licoreria.zona_horaria', 'America/La_Paz');
    }

    // Fecha de hoy según el reloj del negocio (el servidor corre en UTC).
    private function hoy(): string
    {
        return now($this->zona())->toDateString();
    }

    private function local(?Carbon $fecha): Carbon
    {
        return ($fecha ?? now())->copy()->setTimezone($this->zona());
    }
}
