<?php

namespace App\Http\Controllers;

use App\Models\Proveedor;
use Illuminate\Http\Request;

class ProveedorController extends Controller
{
    // GET /api/proveedores
    public function index(Request $request)
    {
        $query = Proveedor::query();

        if ($request->filled('buscar')) {
            $query->where('nombre', 'like', '%'.$request->buscar.'%');
        }

        return $query->orderBy('nombre')->get();
    }

    // POST /api/proveedores
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:255',
            'contacto' => 'nullable|string|max:255',
            'telefono' => 'nullable|string|max:20',
            'email' => 'nullable|email|max:255',
            'direccion' => 'nullable|string|max:255',
            'activo' => 'boolean',
        ]);

        $proveedor = Proveedor::create($validated);

        return response()->json($proveedor, 201);
    }

    // GET /api/proveedores/{id}
    public function show(Proveedor $proveedor)
    {
        return $proveedor->load('pedidosCompra');
    }

    // PUT/PATCH /api/proveedores/{id}
    public function update(Request $request, Proveedor $proveedor)
    {
        $validated = $request->validate([
            'nombre' => 'sometimes|required|string|max:255',
            'contacto' => 'nullable|string|max:255',
            'telefono' => 'nullable|string|max:20',
            'email' => 'nullable|email|max:255',
            'direccion' => 'nullable|string|max:255',
            'activo' => 'boolean',
        ]);

        $proveedor->update($validated);

        return response()->json($proveedor);
    }

    // DELETE /api/proveedores/{id}
    public function destroy(Proveedor $proveedor)
    {
        if ($proveedor->pedidosCompra()->exists()) {
            abort(422, 'No se puede eliminar: este proveedor tiene pedidos de compra registrados. Desactívalo en su lugar.');
        }

        $proveedor->delete();

        return response()->json(['message' => 'Proveedor eliminado correctamente']);
    }
}
