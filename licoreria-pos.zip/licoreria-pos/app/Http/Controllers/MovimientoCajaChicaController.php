<?php

namespace App\Http\Controllers;

use App\Exports\CajaChicaExport;
use App\Models\Almacen;
use App\Models\Caja;
use App\Models\MovimientoCajaChica;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Maatwebsite\Excel\Facades\Excel;

class MovimientoCajaChicaController extends Controller
{
    // Filtros comunes (todo menos las fechas) de index() y de los reportes.
    // El vendedor solo ve sus propios movimientos; el administrador ve todo
    // y además puede filtrar por usuario_id.
    private function consulta(Request $request)
    {
        $usuario = $request->attributes->get('usuario_autenticado');

        $query = MovimientoCajaChica::with(['usuario', 'almacen', 'caja']);

        if ($usuario->rol !== 'administrador') {
            $query->where('usuario_id', $usuario->id);
        } elseif ($request->filled('usuario_id')) {
            $query->where('usuario_id', $request->usuario_id);
        }

        if ($request->filled('caja_id')) {
            $query->where('caja_id', $request->caja_id);
        }

        if ($request->filled('almacen_id')) {
            $query->where('almacen_id', $request->almacen_id);
        }

        if ($request->filled('cuenta')) {
            $query->where('cuenta', $request->cuenta);
        }

        if ($request->filled('tipo')) {
            $query->where('tipo', $request->tipo);
        }

        if ($request->filled('metodo_pago')) {
            $query->where('metodo_pago', $request->metodo_pago);
        }

        return $query;
    }

    // GET /api/caja-chica
    // Filtros: fecha_desde, fecha_hasta, cuenta, tipo (ingreso|egreso),
    // metodo_pago (efectivo|cheque -> "Ver cheques" del panel es este mismo
    // filtro con metodo_pago=cheque), caja_id, almacen_id.
    // El vendedor solo ve sus propios movimientos; el administrador ve todo.
    public function index(Request $request)
    {
        $query = $this->consulta($request);

        if ($request->filled('fecha_desde')) {
            $query->whereDate('created_at', '>=', $request->fecha_desde);
        }

        if ($request->filled('fecha_hasta')) {
            $query->whereDate('created_at', '<=', $request->fecha_hasta);
        }

        return $query->orderByDesc('created_at')->get();
    }

    // Rango del reporte en hora de Bolivia (los días se cortan ahí, no en UTC).
    private function rangoReporte(Request $request): array
    {
        $request->validate([
            'desde' => 'nullable|date',
            'hasta' => 'nullable|date',
            'cuenta' => 'nullable|string|max:100',
            'tipo' => 'nullable|in:ingreso,egreso',
            'metodo_pago' => 'nullable|in:efectivo,cheque',
            'caja_id' => 'nullable|integer',
            'usuario_id' => 'nullable|integer',
        ]);

        $tz = config('services.licoreria.zona_horaria', 'America/La_Paz');
        $desde = $request->filled('desde') ? Carbon::parse($request->desde, $tz)->startOfDay() : Carbon::now($tz)->startOfMonth();
        $hasta = $request->filled('hasta') ? Carbon::parse($request->hasta, $tz)->endOfDay() : Carbon::now($tz)->endOfDay();

        return [$desde, $hasta, $tz];
    }

    // GET /api/caja-chica/reporte?desde=&hasta=&cuenta=&tipo=&metodo_pago=&caja_id=&usuario_id=
    // Reporte de caja chica: totales, por cuenta, por día (y por usuario para
    // el administrador) y el detalle de movimientos. El vendedor solo ve lo suyo.
    public function reporte(Request $request)
    {
        [$desde, $hasta, $tz] = $this->rangoReporte($request);

        $movimientos = $this->consulta($request)
            ->whereBetween('created_at', [$desde->copy()->utc(), $hasta->copy()->utc()])
            ->orderBy('created_at')->orderBy('id')
            ->get();

        $suma = fn ($col, ?string $tipo = null, ?string $metodo = null) => round((float) $col
            ->when($tipo, fn ($c) => $c->where('tipo', $tipo))
            ->when($metodo, fn ($c) => $c->where('metodo_pago', $metodo))
            ->sum('monto'), 2);

        $resumen = [
            'cantidad' => $movimientos->count(),
            'ingresos' => $suma($movimientos, 'ingreso'),
            'egresos' => $suma($movimientos, 'egreso'),
            'ingresos_efectivo' => $suma($movimientos, 'ingreso', 'efectivo'),
            'egresos_efectivo' => $suma($movimientos, 'egreso', 'efectivo'),
            'ingresos_cheque' => $suma($movimientos, 'ingreso', 'cheque'),
            'egresos_cheque' => $suma($movimientos, 'egreso', 'cheque'),
        ];
        $resumen['saldo'] = round($resumen['ingresos'] - $resumen['egresos'], 2);

        $agrupar = function ($clave) use ($movimientos, $suma) {
            return $movimientos->groupBy($clave)->map(function ($g, $k) use ($suma) {
                $i = $suma($g, 'ingreso');
                $e = $suma($g, 'egreso');

                return ['etiqueta' => (string) $k, 'cantidad' => $g->count(), 'ingresos' => $i, 'egresos' => $e, 'saldo' => round($i - $e, 2)];
            })->values()->all();
        };

        $porCuenta = $agrupar(fn ($m) => $m->cuenta);
        usort($porCuenta, fn ($a, $b) => ($b['ingresos'] + $b['egresos']) <=> ($a['ingresos'] + $a['egresos']));

        $porDia = $agrupar(fn ($m) => Carbon::parse($m->created_at)->setTimezone($tz)->toDateString());
        usort($porDia, fn ($a, $b) => strcmp($a['etiqueta'], $b['etiqueta']));

        $usuario = $request->attributes->get('usuario_autenticado');
        $porUsuario = $usuario->rol === 'administrador'
            ? $agrupar(fn ($m) => $m->usuario?->nombre ?? 'Sin usuario')
            : [];

        return response()->json([
            'desde' => $desde->toDateString(),
            'hasta' => $hasta->toDateString(),
            'resumen' => $resumen,
            'por_cuenta' => $porCuenta,
            'por_dia' => $porDia,
            'por_usuario' => $porUsuario,
            'movimientos' => $movimientos->values(),
        ]);
    }

    // GET /api/caja-chica/reporte-excel  (mismos filtros que reporte)
    public function reporteExcel(Request $request)
    {
        [$desde, $hasta] = $this->rangoReporte($request);

        $movimientos = $this->consulta($request)
            ->whereBetween('created_at', [$desde->copy()->utc(), $hasta->copy()->utc()])
            ->orderBy('created_at')->orderBy('id')
            ->get();

        return Excel::download(new CajaChicaExport($movimientos), 'reporte-caja-chica-'.now()->format('Y-m-d').'.xlsx');
    }

    // GET /api/caja-chica/resumen
    // Totales rápidos de la caja abierta (o la indicada por almacen_id):
    // cuánto entró y salió de caja chica en el turno actual.
    public function resumen(Request $request)
    {
        $almacenId = $request->input('almacen_id') ?? Almacen::principalId();

        $caja = Caja::where('almacen_id', $almacenId)->where('estado', 'abierta')->latest('abierta_at')->first();

        if (! $caja) {
            return response()->json(['caja_abierta' => false, 'ingresos' => 0, 'egresos' => 0, 'saldo' => 0]);
        }

        $ingresos = (float) MovimientoCajaChica::where('caja_id', $caja->id)->where('tipo', 'ingreso')->sum('monto');
        $egresos = (float) MovimientoCajaChica::where('caja_id', $caja->id)->where('tipo', 'egreso')->sum('monto');

        return response()->json([
            'caja_abierta' => true,
            'caja_id' => $caja->id,
            'ingresos' => round($ingresos, 2),
            'egresos' => round($egresos, 2),
            'saldo' => round($ingresos - $egresos, 2),
        ]);
    }

    // POST /api/caja-chica
    // Requiere una caja abierta en el almacén: todo movimiento de caja
    // chica pertenece al turno vigente, nunca "flota" sin caja.
    public function store(Request $request)
    {
        $validated = $request->validate([
            'almacen_id' => 'nullable|exists:almacenes,id',
            'cuenta' => 'required|string|max:100',
            'tipo' => 'required|string|in:ingreso,egreso',
            'metodo_pago' => 'required|string|in:efectivo,cheque',
            'nro_documento' => 'nullable|string|max:100',
            'concepto' => 'required|string|max:255',
            'monto' => 'required|numeric|min:0.01',
        ]);

        $almacenId = $validated['almacen_id'] ?? Almacen::principalId();
        $usuario = $request->attributes->get('usuario_autenticado');

        $caja = Caja::where('almacen_id', $almacenId)->where('estado', 'abierta')->latest('abierta_at')->first();

        if (! $caja) {
            abort(422, 'No hay una caja abierta en este almacén. Abre la caja antes de registrar movimientos.');
        }

        $movimiento = MovimientoCajaChica::create([
            'caja_id' => $caja->id,
            'almacen_id' => $almacenId,
            'usuario_id' => $usuario->id,
            'cuenta' => $validated['cuenta'],
            'tipo' => $validated['tipo'],
            'metodo_pago' => $validated['metodo_pago'],
            'nro_documento' => $validated['nro_documento'] ?? null,
            'concepto' => $validated['concepto'],
            'monto' => $validated['monto'],
        ]);

        return response()->json($movimiento->load('usuario', 'almacen', 'caja'), 201);
    }

    // GET /api/caja-chica/{movimiento}
    public function show(Request $request, MovimientoCajaChica $movimiento)
    {
        $this->autorizarPropio($request, $movimiento);

        return $movimiento->load('usuario', 'almacen', 'caja');
    }

    // PUT/PATCH /api/caja-chica/{movimiento}
    // Solo se puede editar mientras la caja del movimiento sigue abierta:
    // si ya se cerró, el arqueo ya congeló esos montos y editarlos
    // descuadraría un cierre que ya se le entregó al administrador.
    public function update(Request $request, MovimientoCajaChica $movimiento)
    {
        $this->autorizarPropio($request, $movimiento);

        if ($movimiento->caja->estado === 'cerrada') {
            abort(422, 'No se puede editar: la caja de este movimiento ya está cerrada.');
        }

        $validated = $request->validate([
            'cuenta' => 'sometimes|required|string|max:100',
            'tipo' => 'sometimes|required|string|in:ingreso,egreso',
            'metodo_pago' => 'sometimes|required|string|in:efectivo,cheque',
            'nro_documento' => 'nullable|string|max:100',
            'concepto' => 'sometimes|required|string|max:255',
            'monto' => 'sometimes|required|numeric|min:0.01',
        ]);

        $movimiento->update($validated);

        return response()->json($movimiento->load('usuario', 'almacen', 'caja'));
    }

    // DELETE /api/caja-chica/{movimiento}  (solo administrador, ver routes/api.php)
    public function destroy(MovimientoCajaChica $movimiento)
    {
        if ($movimiento->caja->estado === 'cerrada') {
            abort(422, 'No se puede eliminar: la caja de este movimiento ya está cerrada.');
        }

        $movimiento->delete();

        return response()->json(['message' => 'Movimiento eliminado correctamente']);
    }

    // GET /api/caja-chica/{movimiento}/recibo-pdf
    public function reciboPdf(Request $request, MovimientoCajaChica $movimiento)
    {
        $this->autorizarPropio($request, $movimiento);

        $movimiento->load('usuario', 'almacen', 'caja');

        $pdf = Pdf::loadView('reportes.recibo-caja-chica', ['movimiento' => $movimiento]);

        return $pdf->download('recibo-caja-chica-'.$movimiento->id.'.pdf');
    }

    // El vendedor solo puede ver/editar sus propios movimientos; el
    // administrador puede todo. Centralizado acá para no repetirlo en
    // cada método.
    private function autorizarPropio(Request $request, MovimientoCajaChica $movimiento): void
    {
        $usuario = $request->attributes->get('usuario_autenticado');

        if ($usuario->rol !== 'administrador' && $movimiento->usuario_id !== $usuario->id) {
            abort(403, 'No puedes ver ni modificar movimientos de caja chica de otro usuario.');
        }
    }
}
