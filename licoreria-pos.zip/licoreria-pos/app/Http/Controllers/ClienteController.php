<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Validation\Rule;

class ClienteController extends Controller
{
    // GET /api/clientes
    public function index(Request $request)
    {
        $query = Cliente::query();

        if ($request->filled('buscar')) {
            $query->where('nombre', 'like', '%'.$request->buscar.'%');
        }

        return $this->listarPaginado($query->orderBy('nombre')->orderBy('id'), $request);
    }

    // POST /api/clientes
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:255',
            'nit_ci' => ['nullable', 'string', 'max:20', Rule::unique('clientes', 'nit_ci')],
            'telefono' => 'nullable|string|max:20',
            'email' => 'nullable|email|max:255',
            'direccion' => 'nullable|string|max:255',
            'activo' => 'boolean',
            'credito_habilitado' => 'boolean',
            'limite_credito' => 'nullable|numeric|min:0|max:9999999',
        ]);

        $validated = $this->filtrarCredito($request, $validated, null);

        $cliente = Cliente::create($validated);

        return response()->json($cliente, 201);
    }

    // GET /api/clientes/{id}
    public function show(Cliente $cliente)
    {
        return $cliente->load('pedidos');
    }

    // PUT/PATCH /api/clientes/{id}
    public function update(Request $request, Cliente $cliente)
    {
        $validated = $request->validate([
            'nombre' => 'sometimes|required|string|max:255',
            'nit_ci' => ['nullable', 'string', 'max:20', Rule::unique('clientes', 'nit_ci')->ignore($cliente->id)],
            'telefono' => 'nullable|string|max:20',
            'email' => 'nullable|email|max:255',
            'direccion' => 'nullable|string|max:255',
            'activo' => 'boolean',
            'credito_habilitado' => 'boolean',
            'limite_credito' => 'nullable|numeric|min:0|max:9999999',
        ]);

        $validated = $this->filtrarCredito($request, $validated, $cliente);

        $cliente->update($validated);

        return response()->json($cliente);
    }

    // DELETE /api/clientes/{id}
    public function destroy(Cliente $cliente)
    {
        $cliente->delete();

        return response()->json(['message' => 'Cliente eliminado correctamente']);
    }

    // Crédito / fiado (5.3): habilitarlo y fijar el límite es decisión del
    // administrador. Si quien edita es un vendedor, esos dos campos se
    // descartan en silencio (puede seguir editando el resto del cliente).
    // Además, para fiar hace falta un NIT/CI real: el POS identifica al
    // cliente por ese documento, así que sin él no se podría ni vender.
    private function filtrarCredito(Request $request, array $validated, ?Cliente $actual): array
    {
        $usuario = $request->attributes->get('usuario_autenticado');

        if (! $usuario || $usuario->rol !== 'administrador') {
            return Arr::except($validated, ['credito_habilitado', 'limite_credito']);
        }

        $habilita = array_key_exists('credito_habilitado', $validated)
            ? (bool) $validated['credito_habilitado']
            : (bool) ($actual?->credito_habilitado);

        $nit = array_key_exists('nit_ci', $validated) ? $validated['nit_ci'] : $actual?->nit_ci;

        if ($habilita && ($nit === null || trim((string) $nit) === '' || trim((string) $nit) === '0')) {
            abort(422, 'Para habilitar el crédito el cliente necesita un NIT/CI (distinto de 0).');
        }

        return $validated;
    }
}
