<?php

namespace App\Http\Controllers;

use App\Models\Producto;

/**
 * Imagen de respaldo para productos sin foto: una tarjeta SVG con el nombre,
 * la categoría y el tamaño. Se genera al vuelo, así ningún producto se ve
 * vacío mientras consigues su foto real.
 */
class ImagenGenericaController extends Controller
{
    private const PALETA = [
        ['#0f766e', '#14b8a6'], ['#1d4ed8', '#60a5fa'], ['#9a3412', '#fb923c'], ['#7e22ce', '#c084fc'],
        ['#be123c', '#fb7185'], ['#4d7c0f', '#a3e635'], ['#0e7490', '#22d3ee'], ['#a16207', '#facc15'],
    ];

    // GET /api/imagen-generica/{codigo}
    public function show(string $codigo)
    {
        $producto = Producto::with('categoria')->where('codigo', $codigo)->first();

        $nombre = $producto?->nombre ?? 'Sin foto';
        $categoria = $producto?->categoria?->nombre ?? 'Producto';

        [$oscuro, $claro] = self::PALETA[crc32($categoria) % count(self::PALETA)];

        // Nombre en hasta 4 líneas de ~16 letras.
        $lineas = array_slice(explode("\n", wordwrap($nombre, 16, "\n", true)), 0, 4);
        $textos = '';
        foreach ($lineas as $i => $linea) {
            $y = 210 + $i * 38;
            $textos .= '<text x="200" y="'.$y.'" text-anchor="middle" font-size="30" font-weight="700" fill="#ffffff">'
                .htmlspecialchars($linea, ENT_XML1 | ENT_QUOTES, 'UTF-8').'</text>';
        }

        $svg = '<?xml version="1.0" encoding="UTF-8"?>'
            .'<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400" font-family="Arial, Helvetica, sans-serif">'
            .'<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
            .'<stop offset="0" stop-color="'.$oscuro.'"/><stop offset="1" stop-color="'.$claro.'"/></linearGradient></defs>'
            .'<rect width="400" height="400" fill="url(#g)"/>'
            .'<text x="200" y="70" text-anchor="middle" font-size="22" letter-spacing="3" fill="#ffffff" opacity="0.85">'
            .htmlspecialchars(mb_strtoupper($categoria), ENT_XML1 | ENT_QUOTES, 'UTF-8').'</text>'
            .'<line x1="150" y1="95" x2="250" y2="95" stroke="#ffffff" stroke-opacity="0.6" stroke-width="2"/>'
            .$textos
            .'<text x="200" y="372" text-anchor="middle" font-size="18" fill="#ffffff" opacity="0.8">Licorería Al Paso</text>'
            .'</svg>';

        return response($svg, 200, [
            'Content-Type' => 'image/svg+xml; charset=UTF-8',
            'Cache-Control' => 'public, max-age=86400',
        ]);
    }
}
