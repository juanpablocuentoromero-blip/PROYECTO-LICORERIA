<?php

namespace App\Http\Controllers;

use App\Models\Pedido;
use App\Models\Repartidor;
use Illuminate\Http\Request;

/**
 * Repartidores (tarea 5.2). El personal los ve para asignarlos a un pedido;
 * solo el administrador los crea, edita o elimina.
 */
class RepartidorController extends Controller
{
    // GET /api/repartidores            (solo activos)
    // GET /api/repartidores?todos=1    (incluye inactivos)
    public function index(Request $request)
    {
        $query = Repartidor::query();

        if (! $request->boolean('todos')) {
            $query->where('activo', true);
        }

        return $query->orderBy('nombre')->get();
    }

    // POST /api/repartidores
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:100',
            'telefono' => 'nullable|string|max:20',
            'activo' => 'boolean',
        ]);

        return response()->json(Repartidor::create($validated), 201);
    }

    // PUT/PATCH /api/repartidores/{repartidor}
    public function update(Request $request, Repartidor $repartidor)
    {
        $validated = $request->validate([
            'nombre' => 'sometimes|required|string|max:100',
            'telefono' => 'nullable|string|max:20',
            'activo' => 'boolean',
        ]);

        $repartidor->update($validated);

        return response()->json($repartidor);
    }

    // DELETE /api/repartidores/{repartidor}
    public function destroy(Repartidor $repartidor)
    {
        if (Pedido::where('repartidor_id', $repartidor->id)->exists()) {
            abort(422, 'No se puede eliminar: tiene pedidos asignados. Desactívalo en su lugar.');
        }

        $repartidor->delete();

        return response()->json(['message' => 'Repartidor eliminado correctamente']);
    }
}
