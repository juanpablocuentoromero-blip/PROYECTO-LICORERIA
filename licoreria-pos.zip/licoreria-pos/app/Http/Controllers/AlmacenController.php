<?php

namespace App\Http\Controllers;

use App\Models\Almacen;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AlmacenController extends Controller
{
    // GET /api/almacenes
    // Visible para todo el staff (admin y vendedor): se necesita para
    // selectores de almacén en caja, movimientos de inventario y traspasos.
    public function index(Request $request)
    {
        $query = Almacen::query();

        if (! $request->boolean('incluir_inactivos')) {
            $query->where('activo', true);
        }

        return $query->orderByDesc('es_principal')->orderBy('nombre')->get();
    }

    // POST /api/almacenes  (solo administrador)
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:255|unique:almacenes,nombre',
            'direccion' => 'nullable|string|max:255',
            'activo' => 'boolean',
        ]);

        $almacen = Almacen::create($validated);

        return response()->json($almacen, 201);
    }

    // GET /api/almacenes/{id}
    public function show(Almacen $almacen)
    {
        return $almacen->load('stocks.producto');
    }

    // PUT/PATCH /api/almacenes/{id}  (solo administrador)
    // El nombre y el estado "principal" del almacén marcado como principal
    // no se pueden tocar desde acá: cambiar cuál es el principal es una
    // operación delicada (afecta a dónde cae todo el stock nuevo) que
    // todavía no tiene un flujo dedicado, así que por ahora se evita dejar
    // el sistema sin almacén principal por accidente.
    public function update(Request $request, Almacen $almacen)
    {
        $validated = $request->validate([
            'nombre' => 'sometimes|required|string|max:255|unique:almacenes,nombre,'.$almacen->id,
            'direccion' => 'nullable|string|max:255',
            'activo' => 'boolean',
        ]);

        if ($almacen->es_principal && array_key_exists('activo', $validated) && ! $validated['activo']) {
            abort(422, 'No se puede desactivar el almacén principal.');
        }

        $almacen->update($validated);

        return response()->json($almacen);
    }

    // DELETE /api/almacenes/{id}  (solo administrador)
    public function destroy(Almacen $almacen)
    {
        if ($almacen->es_principal) {
            abort(422, 'No se puede eliminar el almacén principal.');
        }

        if ($almacen->stocks()->where('cantidad', '>', 0)->exists()) {
            abort(422, 'No se puede eliminar: este almacén todavía tiene stock. Traspasa las existencias antes de eliminarlo.');
        }

        if ($almacen->movimientos()->exists()) {
            abort(422, 'No se puede eliminar: este almacén tiene movimientos de inventario en su historial.');
        }

        DB::transaction(function () use ($almacen) {
            // Filas de stock en 0 son solo bookkeeping (se crean automáticamente
            // la primera vez que se toca un producto en este almacén); no hay
            // nada que perder al limpiarlas antes de borrar el almacén.
            $almacen->stocks()->delete();
            $almacen->delete();
        });

        return response()->json(['message' => 'Almacén eliminado correctamente']);
    }
}
