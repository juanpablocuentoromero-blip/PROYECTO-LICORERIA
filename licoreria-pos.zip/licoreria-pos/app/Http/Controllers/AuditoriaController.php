<?php

namespace App\Http\Controllers;

use App\Models\Auditoria;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * 4.4 — Consulta del registro de auditoría. Solo administrador.
 */
class AuditoriaController extends Controller
{
    // GET /api/auditoria?entidad=&usuario_id=&campo=&desde=&hasta=&buscar=&page=
    public function index(Request $request): JsonResponse
    {
        $request->validate([
            'entidad' => 'nullable|in:producto,usuario,inventario',
            'usuario_id' => 'nullable|integer',
            'campo' => 'nullable|string|max:60',
            'desde' => 'nullable|date',
            'hasta' => 'nullable|date',
            'buscar' => 'nullable|string|max:100',
            'por_pagina' => 'nullable|integer|min:10|max:200',
        ]);

        $q = Auditoria::query();

        foreach (['entidad', 'usuario_id', 'campo'] as $filtro) {
            if ($request->filled($filtro)) {
                $q->where($filtro, $request->input($filtro));
            }
        }

        if ($request->filled('desde')) {
            $q->whereDate('created_at', '>=', $request->input('desde'));
        }

        if ($request->filled('hasta')) {
            $q->whereDate('created_at', '<=', $request->input('hasta'));
        }

        if ($request->filled('buscar')) {
            $q->where('descripcion', 'like', '%'.$request->input('buscar').'%');
        }

        $pagina = $q->orderByDesc('created_at')->orderByDesc('id')
            ->paginate((int) $request->input('por_pagina', 50));

        return response()->json($pagina);
    }
}
