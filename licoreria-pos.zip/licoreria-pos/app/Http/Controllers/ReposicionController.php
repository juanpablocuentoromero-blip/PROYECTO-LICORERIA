<?php

namespace App\Http\Controllers;

use App\Models\Combo;
use App\Models\DetalleDevolucion;
use App\Models\DetallePedidoCompra;
use App\Models\PedidoCompra;
use App\Models\Producto;
use App\Models\Proveedor;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * 4.3 — Sugerencia de reposición.
 *
 * Con lo vendido en las últimas semanas calcula cuántos días de stock le
 * quedan a cada producto y cuánto conviene pedir para cubrir
 * `dias_cobertura`. Luego deja generar borradores de pedido de compra (uno por
 * proveedor) que el administrador revisa y recibe en "Compras".
 *
 * Solo administrador.
 */
class ReposicionController extends Controller
{
    // GET /api/reposicion/sugerencias?dias_historial=28&dias_cobertura=14&dias_entrega=3&todos=0
    public function sugerencias(Request $request): JsonResponse
    {
        $v = $request->validate([
            'dias_historial' => 'nullable|integer|min:7|max:180',
            'dias_cobertura' => 'nullable|integer|min:1|max:90',
            'dias_entrega' => 'nullable|integer|min:0|max:30',
            'todos' => 'nullable|boolean',
        ]);

        $diasHistorial = (int) ($v['dias_historial'] ?? 28);
        $diasCobertura = (int) ($v['dias_cobertura'] ?? 14);
        $diasEntrega = (int) ($v['dias_entrega'] ?? 3);
        $verTodos = (bool) ($v['todos'] ?? false);

        $desde = now()->subDays($diasHistorial);

        $vendidas = $this->unidadesVendidas($desde);
        $enCamino = $this->unidadesEnCamino();
        $proveedorYPrecio = $this->ultimoProveedorYPrecio();
        $proveedores = Proveedor::whereIn('id', collect($proveedorYPrecio)->pluck('proveedor_id')->filter()->unique())
            ->get(['id', 'nombre'])->keyBy('id');

        $idsCombo = Combo::pluck('producto_id')->all();
        $items = [];

        foreach (Producto::with('categoria:id,nombre')->where('activo', true)->whereNotIn('id', $idsCombo)->get() as $p) {
            $unidades = (int) ($vendidas[$p->id] ?? 0);
            $promedioDiario = $unidades / $diasHistorial;
            $stock = (int) $p->stock;
            $pendiente = (int) ($enCamino[$p->id] ?? 0);

            $diasStock = $promedioDiario > 0 ? round($stock / $promedioDiario, 1) : null;

            // Objetivo: cubrir los días pedidos + los de entrega, sin bajar nunca del mínimo.
            $objetivo = max(
                (int) ceil($promedioDiario * ($diasCobertura + $diasEntrega)),
                (int) $p->stock_minimo
            );

            $faltante = $objetivo - $stock - $pendiente;
            $cantidad = max(0, $faltante);

            // Se pide por paquete/caja completa si el producto la tiene.
            $paquete = (int) ($p->unidades_por_paquete ?? 1);
            if ($cantidad > 0 && $paquete > 1) {
                $cantidad = (int) (ceil($cantidad / $paquete) * $paquete);
            }

            if ($cantidad === 0 && ! $verTodos) {
                continue;
            }

            $ref = $proveedorYPrecio[$p->id] ?? null;
            $precio = (float) ($ref['precio'] ?? $p->precio_compra);

            $urgencia = 'normal';
            if ($stock <= 0) {
                $urgencia = 'urgente';
            } elseif ($diasStock !== null && $diasStock <= $diasEntrega) {
                $urgencia = 'urgente';
            } elseif ($stock <= (int) $p->stock_minimo || ($diasStock !== null && $diasStock <= $diasEntrega + 7)) {
                $urgencia = 'pronto';
            }

            $items[] = [
                'producto_id' => $p->id,
                'codigo' => $p->codigo,
                'nombre' => $p->nombre,
                'categoria' => $p->categoria?->nombre,
                'stock' => $stock,
                'stock_minimo' => (int) $p->stock_minimo,
                'en_camino' => $pendiente,
                'vendido_periodo' => $unidades,
                'ventas_por_semana' => round($promedioDiario * 7, 1),
                'dias_stock' => $diasStock,
                'cantidad_sugerida' => $cantidad,
                'unidades_por_paquete' => $paquete,
                'precio_compra' => round($precio, 2),
                'costo_estimado' => round($cantidad * $precio, 2),
                'urgencia' => $urgencia,
                'proveedor_id' => $ref['proveedor_id'] ?? null,
                'proveedor' => isset($ref['proveedor_id']) ? ($proveedores[$ref['proveedor_id']]->nombre ?? null) : null,
            ];
        }

        $orden = ['urgente' => 0, 'pronto' => 1, 'normal' => 2];
        usort($items, fn ($a, $b) => [$orden[$a['urgencia']], $a['dias_stock'] ?? PHP_INT_MAX, $a['nombre']]
            <=> [$orden[$b['urgencia']], $b['dias_stock'] ?? PHP_INT_MAX, $b['nombre']]);

        return response()->json([
            'parametros' => [
                'dias_historial' => $diasHistorial,
                'dias_cobertura' => $diasCobertura,
                'dias_entrega' => $diasEntrega,
            ],
            'items' => $items,
            'resumen' => [
                'productos' => count($items),
                'urgentes' => count(array_filter($items, fn ($i) => $i['urgencia'] === 'urgente')),
                'costo_estimado' => round(array_sum(array_column($items, 'costo_estimado')), 2),
            ],
            'proveedores' => Proveedor::orderBy('nombre')->get(['id', 'nombre']),
        ]);
    }

    // POST /api/reposicion/generar-borradores
    // items: [{producto_id, cantidad, precio_unitario?, proveedor_id?}], proveedor_id? (por defecto
    // para los que no tengan uno). Crea un pedido de compra PENDIENTE por proveedor: no mueve
    // stock hasta que se reciba en Compras.
    public function generarBorradores(Request $request): JsonResponse
    {
        $v = $request->validate([
            'proveedor_id' => 'nullable|exists:proveedores,id',
            'items' => 'required|array|min:1|max:300',
            'items.*.producto_id' => 'required|exists:productos,id',
            'items.*.cantidad' => 'required|integer|min:1|max:99999',
            'items.*.precio_unitario' => 'nullable|numeric|min:0',
            'items.*.proveedor_id' => 'nullable|exists:proveedores,id',
        ]);

        $usuario = $request->attributes->get('usuario_autenticado');
        $ref = $this->ultimoProveedorYPrecio();
        $productos = Producto::whereIn('id', collect($v['items'])->pluck('producto_id'))->get()->keyBy('id');

        // Agrupar por proveedor: el elegido en la línea, si no el último al que
        // se le compró ese producto, si no el general del request.
        $grupos = [];
        $sinProveedor = [];

        foreach ($v['items'] as $item) {
            $producto = $productos[$item['producto_id']];
            $proveedorId = $item['proveedor_id'] ?? ($ref[$producto->id]['proveedor_id'] ?? null) ?? ($v['proveedor_id'] ?? null);

            if (! $proveedorId) {
                $sinProveedor[] = $producto->nombre;

                continue;
            }

            $grupos[$proveedorId][] = [
                'producto_id' => $producto->id,
                'cantidad' => (int) $item['cantidad'],
                'precio_unitario' => (float) ($item['precio_unitario'] ?? $ref[$producto->id]['precio'] ?? $producto->precio_compra),
            ];
        }

        if ($sinProveedor) {
            abort(422, 'Falta elegir proveedor para: '.implode(', ', array_slice($sinProveedor, 0, 8)).(count($sinProveedor) > 8 ? '…' : '').'.');
        }

        $creados = DB::transaction(function () use ($grupos, $usuario) {
            $creados = [];

            foreach ($grupos as $proveedorId => $lineas) {
                $subtotal = round(array_sum(array_map(fn ($l) => $l['cantidad'] * $l['precio_unitario'], $lineas)), 2);

                $pedido = PedidoCompra::create([
                    'proveedor_id' => $proveedorId,
                    'usuario_id' => $usuario->id,
                    'estado' => 'pendiente',
                    'subtotal' => $subtotal,
                    'total' => $subtotal,
                    'observaciones' => 'Borrador generado por la sugerencia de reposición. Revisar antes de enviar al proveedor.',
                ]);

                foreach ($lineas as $l) {
                    DetallePedidoCompra::create([
                        'pedido_compra_id' => $pedido->id,
                        'producto_id' => $l['producto_id'],
                        'cantidad' => $l['cantidad'],
                        'precio_unitario' => $l['precio_unitario'],
                        'subtotal' => round($l['cantidad'] * $l['precio_unitario'], 2),
                    ]);
                }

                $creados[] = $pedido->id;
            }

            return $creados;
        });

        return response()->json([
            'message' => count($creados) === 1
                ? 'Se creó 1 borrador de pedido de compra.'
                : 'Se crearon '.count($creados).' borradores de pedido de compra (uno por proveedor).',
            'pedidos' => PedidoCompra::with(['proveedor', 'detalles.producto'])->whereIn('id', $creados)->get(),
        ], 201);
    }

    // ------------------------------------------------------------------

    // [producto_id => unidades vendidas desde $desde], neto de devoluciones.
    // Los combos se descomponen: vender un combo consume sus componentes.
    private function unidadesVendidas($desde): array
    {
        $filas = DB::table('detalle_pedidos as d')
            ->join('pedidos as p', 'p.id', '=', 'd.pedido_id')
            ->where('p.anulada', false)
            ->where('p.estado', '!=', 'cancelado')
            ->where(fn ($q) => $q->where('p.pagado', true)->orWhere('p.metodo_pago', 'credito'))
            ->where('p.created_at', '>=', $desde)
            ->groupBy('d.producto_id')
            ->selectRaw('d.producto_id, SUM(d.cantidad) as unidades')
            ->pluck('unidades', 'producto_id');

        $devueltas = DetalleDevolucion::where('created_at', '>=', $desde)
            ->groupBy('producto_id')
            ->selectRaw('producto_id, SUM(cantidad) as unidades')
            ->pluck('unidades', 'producto_id');

        $totales = [];
        $combos = Combo::with('items')->get()->keyBy('producto_id');

        foreach ($filas as $productoId => $unidades) {
            $neto = (int) $unidades - (int) ($devueltas[$productoId] ?? 0);

            if ($neto <= 0) {
                continue;
            }

            if ($combos->has($productoId)) {
                foreach ($combos[$productoId]->items as $item) {
                    $totales[$item->producto_id] = ($totales[$item->producto_id] ?? 0) + $neto * (int) $item->cantidad;
                }
            } else {
                $totales[$productoId] = ($totales[$productoId] ?? 0) + $neto;
            }
        }

        return $totales;
    }

    // Unidades ya pedidas a proveedores que todavía no llegaron.
    private function unidadesEnCamino(): array
    {
        return DB::table('detalle_pedidos_compra as d')
            ->join('pedidos_compra as c', 'c.id', '=', 'd.pedido_compra_id')
            ->where('c.estado', 'pendiente')
            ->groupBy('d.producto_id')
            ->selectRaw('d.producto_id, SUM(d.cantidad) as unidades')
            ->pluck('unidades', 'producto_id')
            ->map(fn ($u) => (int) $u)
            ->all();
    }

    // [producto_id => ['proveedor_id' => ..., 'precio' => ...]] de la última compra
    // (no cancelada) de cada producto.
    private function ultimoProveedorYPrecio(): array
    {
        $filas = DB::table('detalle_pedidos_compra as d')
            ->join('pedidos_compra as c', 'c.id', '=', 'd.pedido_compra_id')
            ->where('c.estado', '!=', 'cancelado')
            ->orderBy('c.id') // el último gana al sobrescribir
            ->get(['d.producto_id', 'c.proveedor_id', 'd.precio_unitario']);

        $ref = [];
        foreach ($filas as $f) {
            $ref[$f->producto_id] = ['proveedor_id' => (int) $f->proveedor_id, 'precio' => (float) $f->precio_unitario];
        }

        return $ref;
    }
}
