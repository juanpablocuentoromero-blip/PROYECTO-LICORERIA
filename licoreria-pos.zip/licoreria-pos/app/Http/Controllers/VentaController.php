<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\GestionaStockVenta;
use App\Models\Almacen;
use App\Models\Caja;
use App\Models\Cliente;
use App\Models\Combo;
use App\Models\DetallePedido;
use App\Models\DetalleDevolucion;
use App\Models\Devolucion;
use App\Models\PagoVenta;
use App\Models\Pedido;
use App\Models\Producto;
use App\Services\FidelizacionService;
use App\Services\PromocionService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

/**
 * Ventas de mostrador (punto de venta) e historial de ventas.
 *
 * Una "venta" es una fila de `pedidos` con sus `detalle_pedidos`: así el
 * stock, el arqueo de caja, el libro de ventas y los reportes siguen
 * leyendo de un único lugar.
 *
 * POS:        contexto(), buscarProducto(), buscarCliente(), store()
 * Historial:  index(), show(), anular()
 */
class VentaController extends Controller
{
    use GestionaStockVenta;

    // ------------------------------------------------------------------
    // PUNTO DE VENTA
    // ------------------------------------------------------------------

    // GET /api/ventas/contexto
    // Datos que la pantalla necesita para arrancar: en qué almacén se vende
    // (el vendedor no puede listar almacenes, así que se lo damos acá), el
    // cliente por defecto y si hay caja abierta (sin caja no se puede vender).
    public function contexto(): JsonResponse
    {
        $almacen = Almacen::findOrFail(Almacen::principalId());
        $caja = $this->cajaAbierta($almacen->id);
        $cliente = $this->clienteGenerico();

        return response()->json([
            'almacen' => ['id' => $almacen->id, 'nombre' => $almacen->nombre],
            'caja_abierta' => (bool) $caja,
            'caja_id' => $caja?->id,
            'cliente_defecto' => $this->presentarCliente($cliente),
        ]);
    }

    // GET /api/ventas/buscar-producto?codigo=7501234567890
    //
    // Pensado para el lector de código de barras: primero busca una
    // coincidencia EXACTA por código (el lector escribe el código completo y
    // pulsa Enter). Si no hay, busca por nombre/código parcial para que el
    // cajero pueda escribir "paceña" y elegir de una lista.
    //
    // Respuestas:
    //   200 { exacto: true,  productos: [p] }        -> agregar directo
    //   200 { exacto: false, productos: [p1, p2..] } -> mostrar lista
    //   404 { message }                              -> no existe
    public function buscarProducto(Request $request): JsonResponse
    {
        $texto = trim((string) $request->query('codigo', ''));

        if ($texto === '') {
            return response()->json(['message' => 'Escanee un código o escriba un nombre.'], 422);
        }

        $almacenId = Almacen::principalId();

        $exacto = Producto::with('categoria')
            ->where('activo', true)
            ->where('codigo', $texto)
            ->first();

        if ($exacto) {
            return response()->json([
                'exacto' => true,
                'productos' => [$this->presentarProducto($exacto, $almacenId)],
            ]);
        }

        // Se escapan % _ \ para que "50%" se busque literal y no como comodín.
        $patron = '%'.addcslashes($texto, '%_\\').'%';

        $productos = Producto::with('categoria')
            ->where('activo', true)
            ->where(function ($q) use ($patron) {
                $q->where('nombre', 'like', $patron)->orWhere('codigo', 'like', $patron);
            })
            ->orderBy('nombre')
            ->limit(15)
            ->get();

        if ($productos->isEmpty()) {
            return response()->json(['message' => "No existe ningún producto con el código o nombre «{$texto}»."], 404);
        }

        return response()->json([
            'exacto' => false,
            'productos' => $productos->map(fn (Producto $p) => $this->presentarProducto($p, $almacenId))->values(),
        ]);
    }

    // GET /api/ventas/cliente?nit_ci=1234567
    // Devuelve siempre 200: "no encontrado" es un resultado normal (cliente
    // nuevo), no un error, y así no ensucia la consola del navegador.
    public function buscarCliente(Request $request): JsonResponse
    {
        $nit = trim((string) $request->query('nit_ci', ''));

        if ($nit === '' || $nit === '0') {
            return response()->json(['encontrado' => true, 'cliente' => $this->presentarCliente($this->clienteGenerico())]);
        }

        $cliente = Cliente::where('nit_ci', $nit)->where('activo', true)->first();

        return response()->json([
            'encontrado' => (bool) $cliente,
            'cliente' => $cliente ? $this->presentarCliente($cliente) : null,
        ]);
    }

    // POST /api/ventas
    //
    // Registra la venta completa en UNA transacción: valida caja abierta y
    // stock, guarda cabecera y líneas, descuenta el stock del almacén y deja
    // el movimiento de inventario. Si algo falla, no queda nada a medias.
    //
    // Los precios NUNCA se toman del body: se leen de la base. Del cliente
    // solo llegan producto, cantidad y descuento manual. Las promociones y
    // el cupón (5.4) los calcula el servidor con PromocionService.
    //
    // metodo_pago = 'credito' (5.3, fiado): la venta queda SIN cobrar, con
    // saldo pendiente y fecha de vencimiento. Exige un cliente identificado
    // (NIT/CI distinto de 0) con crédito habilitado y dentro de su límite.
    public function store(Request $request, PromocionService $promociones, FidelizacionService $fidelizacion): JsonResponse
    {
        $validated = $request->validate([
            'nit_ci' => 'nullable|string|max:20',
            'razon_social' => 'nullable|string|max:255',
            'metodo_pago' => 'required|string|in:efectivo,qr,tarjeta,credito,mixto',
            'monto_recibido' => 'nullable|numeric|min:0',
            // 4.6 Pagos mixtos: [{metodo_pago, monto}, ...]; deben sumar el total.
            'pagos' => 'nullable|array|min:1|max:3',
            'pagos.*.metodo_pago' => 'required|string|in:efectivo,qr,tarjeta',
            'pagos.*.monto' => 'required|numeric|min:0.01',
            'observaciones' => 'nullable|string|max:255',
            'cupon' => 'nullable|string|max:40',
            // 6.4: puntos de fidelización que el cliente quiere canjear como descuento.
            'puntos_canje' => 'nullable|integer|min:0|max:1000000',
            'dias_credito' => 'nullable|integer|min:0|max:365',
            'items' => 'required|array|min:1|max:200',
            'items.*.producto_id' => ['required', 'integer', Rule::exists('productos', 'id')->whereNull('deleted_at')],
            'items.*.cantidad' => 'required|integer|min:1|max:9999',
            'items.*.descuento' => 'nullable|numeric|min:0',
        ]);

        $usuario = $request->attributes->get('usuario_autenticado');
        $esCredito = $validated['metodo_pago'] === 'credito';

        // Si el mismo producto viene en dos líneas se fusionan. Además se
        // ordena por id: todas las ventas bloquean los productos en el mismo
        // orden, así dos cajas simultáneas no se interbloquean entre sí.
        $lineasPedidas = collect($validated['items'])
            ->groupBy('producto_id')
            ->map(fn ($grupo, $productoId) => [
                'producto_id' => (int) $productoId,
                'cantidad' => (int) $grupo->sum('cantidad'),
                'descuento' => round((float) $grupo->sum(fn ($i) => $i['descuento'] ?? 0), 2),
            ])
            ->sortKeys()
            ->values();

        $venta = DB::transaction(function () use ($validated, $lineasPedidas, $usuario, $esCredito, $promociones, $fidelizacion) {
            $almacenId = Almacen::principalId();

            // Las ventas en efectivo entran al arqueo de la caja abierta
            // (CajaController::calcularTotales); sin caja abierta quedarían
            // fuera de todo cierre.
            $caja = $this->cajaAbierta($almacenId);
            if (! $caja) {
                abort(422, 'La caja está cerrada. Pida al administrador que abra el turno para poder vender.');
            }

            // 1) Validar todas las líneas ANTES de escribir nada.
            $subtotal = 0.0;
            $descuentoManualTotal = 0.0;
            $lineas = [];

            foreach ($lineasPedidas as $pedida) {
                $producto = Producto::lockForUpdate()->find($pedida['producto_id']);

                if (! $producto || ! $producto->activo) {
                    abort(422, 'Uno de los productos ya no está disponible para la venta.');
                }

                $this->verificarStockDisponible($producto, $pedida['cantidad'], $almacenId);

                $bruto = round((float) $producto->precio_venta * $pedida['cantidad'], 2);

                if ($pedida['descuento'] > $bruto) {
                    abort(422, sprintf(
                        'El descuento de «%s» (Bs %.2f) no puede superar el importe de la línea (Bs %.2f).',
                        $producto->nombre, $pedida['descuento'], $bruto
                    ));
                }

                $subtotal = round($subtotal + $bruto, 2);
                $descuentoManualTotal = round($descuentoManualTotal + $pedida['descuento'], 2);

                $lineas[] = [
                    'producto' => $producto,
                    'cantidad' => $pedida['cantidad'],
                    'bruto' => $bruto,
                    'manual' => $pedida['descuento'],
                ];
            }

            // 1b) Promociones y cupón (5.4). Se calculan sobre lo que queda
            // de cada línea después del descuento manual del cajero.
            $idsCombo = $promociones->idsDeCombos(array_map(fn ($l) => $l['producto']->id, $lineas));
            $entradaPromos = [];
            foreach ($lineas as $l) {
                $entradaPromos[$l['producto']->id] = [
                    'producto_id' => $l['producto']->id,
                    'categoria_id' => (int) $l['producto']->categoria_id,
                    'cantidad' => $l['cantidad'],
                    'base' => round($l['bruto'] - $l['manual'], 2),
                    'es_combo' => in_array($l['producto']->id, $idsCombo, true),
                ];
            }

            $calculo = $promociones->calcular($entradaPromos, $validated['cupon'] ?? null);

            if (! empty($validated['cupon']) && $calculo['cupon_error']) {
                abort(422, $calculo['cupon_error']);
            }

            if ($calculo['cupon']) {
                $promociones->consumirCupon($calculo['cupon']['id']);
            }

            foreach ($lineas as $i => $l) {
                $promoLinea = $calculo['lineas'][$l['producto']->id] ?? ['descuento' => 0.0, 'etiqueta' => null];
                $lineas[$i]['promo'] = $promoLinea['descuento'];
                $lineas[$i]['etiqueta'] = $promoLinea['etiqueta'];
                $lineas[$i]['descuento'] = round($l['manual'] + $promoLinea['descuento'], 2);
                $lineas[$i]['neto'] = round($l['bruto'] - $lineas[$i]['descuento'], 2);
            }

            $descuentoTotal = round($descuentoManualTotal + $calculo['total'], 2);
            $total = round($subtotal - $descuentoTotal, 2);

            // 1c) Canje de puntos (6.4). Es un descuento más: se valida contra
            // el saldo real del cliente (bloqueado) y se reparte entre las
            // líneas para que subtotales, devoluciones y rentabilidad cuadren.
            $cliente = $this->resolverCliente($validated['nit_ci'] ?? null, $validated['razon_social'] ?? null);
            $puntosCanjeados = 0;
            $descuentoPuntos = 0.0;
            $puntosPedidos = (int) ($validated['puntos_canje'] ?? 0);

            if ($puntosPedidos > 0) {
                if ($esCredito) {
                    abort(422, 'Los puntos no se pueden canjear en una venta a crédito.');
                }

                [$puntosCanjeados, $descuentoPuntos] = $fidelizacion->prepararCanje($cliente, $puntosPedidos, $total);

                $reparto = $fidelizacion->repartirDescuento(
                    array_map(fn ($l) => $l['neto'], $lineas),
                    $descuentoPuntos
                );

                foreach ($lineas as $i => $l) {
                    $lineas[$i]['descuento'] = round($l['descuento'] + $reparto[$i], 2);
                    $lineas[$i]['neto'] = round($l['neto'] - $reparto[$i], 2);
                }

                $descuentoTotal = round($descuentoTotal + $descuentoPuntos, 2);
                $total = round($subtotal - $descuentoTotal, 2);
            }

            // 4.6) Cómo se cobra. Sin `pagos` es un solo método por el total
            // (como siempre); con `pagos` se reparte entre efectivo/QR/tarjeta.
            $pagos = $this->resolverPagos($validated, $total, $esCredito);
            $metodoVenta = $esCredito ? 'credito' : (count($pagos) > 1 ? 'mixto' : array_key_first($pagos));
            $efectivoACobrar = $pagos['efectivo'] ?? 0.0;

            if (
                $efectivoACobrar > 0
                && isset($validated['monto_recibido'])
                && round((float) $validated['monto_recibido'], 2) < $efectivoACobrar
            ) {
                abort(422, sprintf('El monto recibido (Bs %.2f) es menor al efectivo a cobrar (Bs %.2f).', $validated['monto_recibido'], $efectivoACobrar));
            }

            // 2) Escribir.
            // Fiado (5.3): solo a un cliente identificado que lo tenga
            // habilitado y sin pasarse de su límite.
            if ($esCredito) {
                $this->validarCredito($cliente, $total);
            }

            // Una venta de mostrador se cobra y se entrega en el acto:
            // nace pagada y entregada (así entra al arqueo y al libro).
            // La de crédito nace entregada pero SIN pagar: debe el total.
            $hoy = now(config('services.licoreria.zona_horaria', 'America/La_Paz'));

            $venta = Pedido::create([
                'cliente_id' => $cliente->id,
                'usuario_id' => $usuario->id,
                'almacen_id' => $almacenId,
                'caja_id' => $caja->id,
                'estado' => 'entregado',
                'metodo_pago' => $metodoVenta,
                'tipo_venta' => 'sin_factura',
                'subtotal' => $subtotal,
                'descuento' => $descuentoTotal,
                'cupon_codigo' => $calculo['cupon']['codigo'] ?? null,
                'puntos_canjeados' => $puntosCanjeados,
                'descuento_puntos' => $descuentoPuntos,
                'total' => $total,
                'observaciones' => $validated['observaciones'] ?? null,
                'pagado' => ! $esCredito,
                'pagado_at' => $esCredito ? null : now(),
                'saldo_pendiente' => $esCredito ? $total : 0,
                'fecha_vencimiento_credito' => $esCredito
                    ? $hoy->copy()->addDays((int) ($validated['dias_credito'] ?? config('services.licoreria.dias_credito_defecto', 30)))->toDateString()
                    : null,
            ]);

            // Una fila por método usado: de ahí sale el arqueo por método.
            foreach ($pagos as $metodo => $monto) {
                PagoVenta::create([
                    'pedido_id' => $venta->id,
                    'caja_id' => $caja->id,
                    'metodo_pago' => $metodo,
                    'monto' => $monto,
                ]);
            }

            foreach ($lineas as $linea) {
                DetallePedido::create([
                    'pedido_id' => $venta->id,
                    'producto_id' => $linea['producto']->id,
                    'cantidad' => $linea['cantidad'],
                    'precio_unitario' => $linea['producto']->precio_venta,
                    'precio_compra' => $this->costoUnitarioVenta($linea['producto']),
                    'precio_venta' => $linea['producto']->precio_venta,
                    'descuento' => $linea['descuento'],
                    'descuento_promocion' => $linea['promo'],
                    'promocion_aplicada' => $linea['etiqueta'],
                    'subtotal' => $linea['neto'],
                ]);

                $this->descontarStockVenta(
                    $linea['producto'], $linea['cantidad'], $almacenId,
                    $usuario->id, "Venta mostrador #{$venta->id}"
                );
            }

            // 6.4: primero se descuenta lo canjeado y luego se acumula lo ganado
            // por lo que realmente se pagó.
            if ($puntosCanjeados > 0) {
                $fidelizacion->registrarCanje($venta, $cliente, $puntosCanjeados);
            }

            $fidelizacion->acumularVenta($venta);

            return $venta;
        });

        // refresh(): acumularVenta() escribió puntos_ganados con su propia lectura.
        $venta->refresh()->load(['cliente', 'usuario', 'detalles.producto', 'pagos']);

        $recibido = isset($validated['monto_recibido']) ? round((float) $validated['monto_recibido'], 2) : null;
        $efectivoCobrado = (float) ($venta->pagosPorMetodo()['efectivo'] ?? 0);
        $cambio = (! $esCredito && $efectivoCobrado > 0 && $recibido !== null)
            ? round($recibido - $efectivoCobrado, 2)
            : 0.0;

        return response()->json([
            'message' => $esCredito ? 'Venta a crédito registrada.' : 'Venta registrada.',
            'venta' => array_merge($this->presentar($venta), [
                'subtotal' => (float) $venta->subtotal,
                'descuento' => (float) $venta->descuento,
                'cupon_codigo' => $venta->cupon_codigo,
                'puntos_canjeados' => (int) $venta->puntos_canjeados,
                'descuento_puntos' => (float) $venta->descuento_puntos,
                'puntos_ganados' => (int) $venta->puntos_ganados,
                'puntos_saldo' => (int) ($venta->cliente?->puntos_saldo ?? 0),
                'nit_ci' => $venta->cliente?->nit_ci,
                'fecha_vencimiento' => $venta->fecha_vencimiento_credito?->format('d/m/Y'),
                'detalles' => $venta->detalles->map(fn ($d) => [
                    'codigo' => $d->producto?->codigo,
                    'descripcion' => $d->producto?->nombre ?? 'Producto eliminado',
                    'cantidad' => (int) $d->cantidad,
                    'precio_unitario' => (float) $d->precio_unitario,
                    'descuento' => (float) $d->descuento,
                    'descuento_promocion' => (float) $d->descuento_promocion,
                    'promocion' => $d->promocion_aplicada,
                    'subtotal' => (float) $d->subtotal,
                ])->values(),
            ]),
            'recibido' => $recibido,
            'cambio' => $cambio,
        ], 201);
    }

    // 4.6 — Devuelve [metodo => monto] que debe sumar exactamente el total.
    // Crédito no genera pagos (es una deuda) y no se mezcla con nada.
    private function resolverPagos(array $validated, float $total, bool $esCredito): array
    {
        $metodo = $validated['metodo_pago'];

        if ($esCredito) {
            if (! empty($validated['pagos'])) {
                abort(422, 'Una venta a crédito no se puede combinar con otros métodos de pago.');
            }

            return [];
        }

        if (empty($validated['pagos'])) {
            if ($metodo === 'mixto') {
                abort(422, 'Para un pago mixto indica cuánto se paga con cada método.');
            }

            return [$metodo => round($total, 2)];
        }

        // Si repiten un método se juntan; el orden de la lista no importa.
        $pagos = collect($validated['pagos'])
            ->groupBy('metodo_pago')
            ->map(fn ($g) => round((float) $g->sum('monto'), 2))
            ->all();

        $suma = round(array_sum($pagos), 2);

        if (abs($suma - $total) > 0.009) {
            abort(422, sprintf('Los pagos suman Bs %.2f y el total de la venta es Bs %.2f. Deben coincidir.', $suma, $total));
        }

        return $pagos;
    }

    // Reglas del fiado (5.3). Se llama DENTRO de la transacción de la venta,
    // con el cliente bloqueado: dos ventas a crédito simultáneas al mismo
    // cliente no pueden pasarse del límite entre las dos.
    private function validarCredito(Cliente $cliente, float $total): void
    {
        if ($cliente->nit_ci === null || $cliente->nit_ci === '' || $cliente->nit_ci === '0') {
            abort(422, 'Para vender a crédito identifique al cliente con su NIT/CI (no puede ser «SIN NOMBRE»).');
        }

        $cliente = Cliente::lockForUpdate()->findOrFail($cliente->id);

        if (! $cliente->activo || ! $cliente->credito_habilitado) {
            abort(422, "«{$cliente->nombre}» no tiene el crédito habilitado. Un administrador puede habilitarlo en Clientes.");
        }

        if ($total <= 0) {
            abort(422, 'No se puede registrar a crédito una venta de Bs 0.');
        }

        if ($cliente->limite_credito !== null) {
            $deuda = (float) Pedido::where('cliente_id', $cliente->id)
                ->where('metodo_pago', 'credito')
                ->where('anulada', false)
                ->sum('saldo_pendiente');

            if (round($deuda + $total, 2) > round((float) $cliente->limite_credito, 2)) {
                abort(422, sprintf(
                    'Supera el límite de crédito de «%s»: debe Bs %.2f, esta venta es de Bs %.2f y su límite es Bs %.2f.',
                    $cliente->nombre, $deuda, $total, (float) $cliente->limite_credito
                ));
            }
        }
    }

    // Caja abierta ahora mismo en el almacén (o null).
    private function cajaAbierta(int $almacenId): ?Caja
    {
        return Caja::where('almacen_id', $almacenId)
            ->where('estado', 'abierta')
            ->latest('abierta_at')
            ->first();
    }

    // Cliente "SIN NOMBRE" / NIT 0. Si alguien lo borró se recrea, porque
    // pedidos.cliente_id es obligatorio y las ventas rápidas dependen de él.
    private function clienteGenerico(): Cliente
    {
        return Cliente::firstOrCreate(
            ['nit_ci' => '0'],
            ['nombre' => 'SIN NOMBRE', 'activo' => true]
        );
    }

    // Traduce lo escrito en la cabecera (NIT/CI + razón social) a un cliente:
    //  - vacío o "0"      -> SIN NOMBRE
    //  - NIT ya conocido  -> ese cliente (con la razón social escrita si cambió)
    //  - NIT nuevo        -> se crea al vuelo
    private function resolverCliente(?string $nit, ?string $razonSocial): Cliente
    {
        $nit = trim((string) $nit);
        $razonSocial = trim((string) $razonSocial);

        if ($nit === '' || $nit === '0') {
            return $this->clienteGenerico();
        }

        if ($razonSocial === '') {
            abort(422, 'Escriba la razón social del cliente, o use NIT/CI 0 para ventas SIN NOMBRE.');
        }

        $cliente = Cliente::where('nit_ci', $nit)->first();

        if ($cliente) {
            if ($cliente->nombre !== $razonSocial) {
                $cliente->update(['nombre' => $razonSocial]);
            }

            return $cliente;
        }

        return Cliente::create(['nit_ci' => $nit, 'nombre' => $razonSocial, 'activo' => true]);
    }

    private function presentarCliente(Cliente $cliente): array
    {
        return [
            'id' => $cliente->id,
            'nit_ci' => $cliente->nit_ci,
            'nombre' => $cliente->nombre,
            // 6.4: saldo de puntos para mostrarlo en caja al identificar al cliente.
            'puntos_saldo' => (int) $cliente->puntos_saldo,
        ];
    }

    // Formato mínimo que necesita la fila del carrito. `stock` es lo que se
    // puede vender AHORA en el almacén (para un combo, según sus componentes).
    private function presentarProducto(Producto $producto, int $almacenId): array
    {
        return [
            'id' => $producto->id,
            'codigo' => $producto->codigo,
            'nombre' => $producto->nombre,
            'categoria' => $producto->categoria?->nombre,
            'imagen' => $producto->imagen,
            'precio_venta' => (float) $producto->precio_venta,
            'stock' => $this->stockDisponibleEnAlmacen($producto, $almacenId),
            'es_combo' => Combo::where('producto_id', $producto->id)->exists(),
            'fecha_vencimiento' => $producto->fecha_vencimiento,
            // Presentaciones: el cajero suma de a paquete o de a caja (el stock sigue en unidades).
            'unidades_por_paquete' => $producto->unidades_por_paquete ? (int) $producto->unidades_por_paquete : null,
            'unidades_por_caja' => $producto->unidades_por_caja ? (int) $producto->unidades_por_caja : null,
        ];
    }

    // ------------------------------------------------------------------
    // HISTORIAL DE VENTAS
    // ------------------------------------------------------------------

    // Formato plano que consume la tabla superior de la pantalla. La tabla
    // inferior (detalle de la venta) se llena con show(), no acá: el
    // historial de un mes entero con todas sus líneas sería una respuesta
    // enorme para mostrar nada más que las cabeceras.
    private function presentar(Pedido $venta): array
    {
        return [
            'id' => $venta->id,
            // Las notas de venta no tienen número fiscal; se muestra el id
            // interno para que la fila no quede con un guion vacío.
            'nro_documento' => $venta->nro_factura ?: 'S/F-'.str_pad((string) $venta->id, 6, '0', STR_PAD_LEFT),
            'nro_factura' => $venta->nro_factura,
            'tipo_venta' => $venta->tipo_venta,
            'fecha' => $venta->created_at?->format('d/m/Y'),
            'hora' => $venta->created_at?->format('H:i:s'),
            // La pantalla lista ventas de mostrador, donde lo habitual es
            // que el comprador no se identifique.
            'cliente' => $venta->cliente?->nombre ?: 'SIN NOMBRE',
            'cliente_id' => $venta->cliente_id,
            'vendedor' => $venta->usuario?->nombre ?? '—',
            'vendedor_id' => $venta->usuario_id,
            'metodo_pago' => $venta->metodo_pago,
            // 4.6: reparto por método (en una venta simple, un solo elemento).
            'pagos' => $venta->esCredito() ? [] : collect($venta->pagosPorMetodo())
                ->map(fn ($monto, $metodo) => ['metodo_pago' => $metodo, 'monto' => $monto])->values(),
            // 4.5: lo que ya se devolvió con notas de crédito y lo que aún se puede devolver.
            'monto_devuelto' => (float) $venta->monto_devuelto,
            'total' => (float) $venta->total,
            // "Cobrado" y "saldo" son lo que audita el cajero: una venta a
            // crédito figura con total pero sin cobrar.
            // En una venta a crédito el saldo es lo que aún debe el cliente
            // (total menos abonos); en las demás es todo o nada.
            'cobrado' => $venta->esCredito()
                ? round((float) $venta->total - (float) $venta->saldo_pendiente, 2)
                : ($venta->pagado ? (float) $venta->total : 0.0),
            'saldo' => $venta->esCredito()
                ? (float) $venta->saldo_pendiente
                : ($venta->pagado ? 0.0 : (float) $venta->total),
            'pagado' => (bool) $venta->pagado,
            'es_credito' => $venta->esCredito(),
            'fecha_vencimiento' => $venta->fecha_vencimiento_credito?->format('d/m/Y'),
            'anulada' => (bool) $venta->anulada,
            'motivo_anulacion' => $venta->motivo_anulacion,
            'anulada_at' => $venta->anulada_at?->format('d/m/Y H:i'),
            'anulada_por' => $venta->usuarioAnulacion?->nombre,
            'estado' => $venta->anulada ? 'anulada' : $venta->estado,
        ];
    }

    // GET /api/ventas
    // Filtros: desde, hasta (YYYY-MM-DD), cliente (texto), vendedor_id,
    // estado (todas|validas|anuladas), tipo (todas|factura|sin_factura),
    // buscar (nro de documento).
    public function index(Request $request): JsonResponse
    {
        $query = Pedido::with(['cliente', 'usuario', 'usuarioAnulacion']);

        if ($request->filled('desde')) {
            $query->whereDate('created_at', '>=', $request->input('desde'));
        }

        if ($request->filled('hasta')) {
            $query->whereDate('created_at', '<=', $request->input('hasta'));
        }

        if ($request->filled('vendedor_id')) {
            $query->where('usuario_id', $request->input('vendedor_id'));
        }

        // Filtrado por cliente: se busca contra la tabla relacionada, no
        // contra un campo del pedido, porque el nombre vive en clientes.
        if ($request->filled('cliente')) {
            $texto = $request->input('cliente');
            $query->whereHas('cliente', function ($q) use ($texto) {
                $q->where('nombre', 'like', "%{$texto}%");
            });
        }

        if ($request->filled('buscar')) {
            $query->where('nro_factura', 'like', '%'.$request->input('buscar').'%');
        }

        match ($request->input('estado', 'todas')) {
            'validas' => $query->where('anulada', false),
            'anuladas' => $query->where('anulada', true),
            default => null,
        };

        $tipo = $request->input('tipo', 'todas');
        if (in_array($tipo, ['factura', 'sin_factura'], true)) {
            $query->where('tipo_venta', $tipo);
        }

        // Los totales se calculan en SQL sobre TODO el resultado filtrado (no
        // solo la página que se muestra) y excluyen lo anulado: una factura
        // anulada no vendió nada, aunque siga listada.
        $cantidad = (clone $query)->count();
        $validas = (clone $query)->where('anulada', false);

        $totalValidas = round((float) (clone $validas)->sum('total'), 2);

        // Por cobrar = lo que todavía falta entrar: en el fiado, el saldo
        // pendiente (ya descontados los abonos); en lo demás, el total.
        $porCobrar = round((float) (clone $validas)->where('pagado', false)
            ->selectRaw("COALESCE(SUM(CASE WHEN metodo_pago = 'credito' THEN saldo_pendiente ELSE total END), 0) as por_cobrar")
            ->value('por_cobrar'), 2);

        $query->orderByDesc('created_at')->orderByDesc('id');

        // 2.2: paginado solo si el cliente lo pide (page / por_pagina).
        $respuesta = [];
        if ($request->hasAny(['page', 'por_pagina'])) {
            $pagina = $query->paginate(max(1, min(200, (int) $request->input('por_pagina', 25))));
            $filas = collect($pagina->items());
            $respuesta['paginacion'] = [
                'current_page' => $pagina->currentPage(),
                'last_page' => $pagina->lastPage(),
                'per_page' => $pagina->perPage(),
                'total' => $pagina->total(),
            ];
        } else {
            $filas = $query->get();
        }

        return response()->json([
            'ventas' => $filas->map(fn (Pedido $v) => $this->presentar($v))->values(),
            'resumen' => [
                'cantidad' => $cantidad,
                'total' => $totalValidas,
                'cobrado' => round($totalValidas - $porCobrar, 2),
                'por_cobrar' => $porCobrar,
            ],
        ] + $respuesta);
    }

    // GET /api/ventas/{venta}
    // Alimenta la tabla inferior: qué productos componen la venta elegida.
    public function show(Pedido $venta): JsonResponse
    {
        $venta->load(['cliente', 'usuario', 'usuarioAnulacion', 'detalles.producto', 'pagos', 'devoluciones.usuario']);

        // 4.5: cuánto de cada línea ya se devolvió (para saber cuánto queda por devolver).
        $devuelto = DetalleDevolucion::whereIn('detalle_pedido_id', $venta->detalles->pluck('id'))
            ->selectRaw('detalle_pedido_id, SUM(cantidad) as cantidad, SUM(monto) as monto')
            ->groupBy('detalle_pedido_id')
            ->get()->keyBy('detalle_pedido_id');

        return response()->json([
            'venta' => $this->presentar($venta),
            'devoluciones' => $venta->devoluciones->map(fn (Devolucion $d) => [
                'id' => $d->id,
                'nro_nota' => $d->nroNota(),
                'fecha' => $d->created_at?->format('d/m/Y H:i'),
                'total' => (float) $d->total,
                'metodo_reembolso' => $d->metodo_reembolso,
                'monto_reembolsado' => (float) $d->monto_reembolsado,
                'aplicado_a_saldo' => (float) $d->aplicado_a_saldo,
                'motivo' => $d->motivo,
                'usuario' => $d->usuario?->nombre,
            ])->values(),
            'detalles' => $venta->detalles->map(fn ($d) => [
                'id' => $d->id,
                'codigo' => $d->producto?->codigo ?? str_pad((string) $d->producto_id, 4, '0', STR_PAD_LEFT),
                'descripcion' => $d->producto?->nombre ?? 'Producto eliminado',
                'cantidad' => (int) $d->cantidad,
                'precio_unitario' => (float) $d->precio_unitario,
                'descuento' => (float) $d->descuento,
                'descuento_promocion' => (float) $d->descuento_promocion,
                'promocion' => $d->promocion_aplicada,
                'subtotal' => (float) $d->subtotal,
                'cantidad_devuelta' => (int) ($devuelto[$d->id]->cantidad ?? 0),
                'monto_devuelto' => (float) ($devuelto[$d->id]->monto ?? 0),
            ])->values(),
        ]);
    }

    // POST /api/ventas/{venta}/anular   (solo administrador)
    //
    // Anular NO borra la venta: la marca como anulada, devuelve la mercadería
    // al almacén de donde salió y deja un movimiento de inventario de
    // entrada por cada línea, para que el kardex cuadre con las existencias.
    public function anular(Request $request, Pedido $venta, FidelizacionService $fidelizacion): JsonResponse
    {
        $validated = $request->validate([
            'motivo' => 'required|string|max:255',
        ]);

        $usuario = $request->attributes->get('usuario_autenticado');

        DB::transaction(function () use ($venta, $validated, $usuario, $fidelizacion) {
            // Se relee bajo bloqueo: dos clics simultáneos no pueden
            // devolver el stock dos veces.
            $venta = Pedido::lockForUpdate()->findOrFail($venta->id);

            if ($venta->anulada) {
                abort(422, 'Esta venta ya fue anulada.');
            }

            // Venta a crédito con cobros: primero hay que anular los abonos
            // (Cuentas por cobrar), si no quedaría dinero cobrado sin venta.
            if ($venta->abonos()->where('anulado', false)->exists()) {
                abort(422, 'Esta venta a crédito ya tiene abonos registrados. Anula primero los abonos en Cuentas por cobrar.');
            }

            // 4.5: con notas de crédito ya emitidas, anular repondría dos veces el
            // stock y descontaría dos veces el dinero ya devuelto.
            if ($venta->devoluciones()->exists()) {
                abort(422, 'Esta venta ya tiene devoluciones (notas de crédito). No se puede anular completa.');
            }

            $almacenId = $venta->almacen_id ?? Almacen::principalId();
            $documento = $venta->nro_factura ?: $venta->id;

            foreach ($venta->detalles as $detalle) {
                $producto = Producto::lockForUpdate()->find($detalle->producto_id);

                // Si el producto fue eliminado del catálogo después de la
                // venta no hay stock que reponer, pero la anulación debe
                // completarse igual: el documento fiscal manda.
                if (! $producto) {
                    continue;
                }

                $this->reponerStockVenta(
                    $producto, (int) $detalle->cantidad, $almacenId,
                    $usuario->id, "Anulación de venta #{$documento}"
                );
            }

            $venta->update([
                'anulada' => true,
                'anulada_at' => now(),
                'motivo_anulacion' => $validated['motivo'],
                'usuario_anulacion_id' => $usuario->id,
                'estado' => 'cancelado',
            ]);

            // 6.4: devuelve los puntos canjeados y quita los ganados.
            $fidelizacion->revertirVenta($venta, $usuario->id);
        });

        $venta->refresh()->load(['cliente', 'usuario', 'usuarioAnulacion']);

        return response()->json([
            'message' => 'Venta anulada y stock repuesto.',
            'venta' => $this->presentar($venta),
        ]);
    }

    // POST /api/ventas/{venta}/devolucion   (solo administrador)
    //
    // 4.5 — Devolución parcial / nota de crédito: el cliente devuelve UNO O
    // VARIOS productos de una venta sin anularla completa. Por cada devolución:
    //  - se repone el stock (y deja movimiento de entrada en el kardex),
    //  - se emite una nota de crédito (NC-000001) con lo devuelto,
    //  - el dinero se devuelve por efectivo/QR/tarjeta, o se descuenta de la
    //    deuda si la venta fue a crédito,
    //  - lo devuelto en EFECTIVO sale del arqueo de la caja abierta.
    // El monto de cada línea es proporcional a lo que realmente se pagó por ella
    // (con sus descuentos), no al precio de lista.
    public function devolver(Request $request, Pedido $venta, FidelizacionService $fidelizacion): JsonResponse
    {
        $validated = $request->validate([
            'motivo' => 'required|string|max:255',
            'metodo_reembolso' => 'nullable|string|in:efectivo,qr,tarjeta',
            'items' => 'required|array|min:1|max:200',
            'items.*.detalle_id' => 'required|integer',
            'items.*.cantidad' => 'required|integer|min:1|max:9999',
        ]);

        $usuario = $request->attributes->get('usuario_autenticado');

        $devolucion = DB::transaction(function () use ($venta, $validated, $usuario, $fidelizacion) {
            // Bajo bloqueo: dos devoluciones simultáneas no pueden devolver dos veces lo mismo.
            $venta = Pedido::lockForUpdate()->findOrFail($venta->id);

            if ($venta->anulada) {
                abort(422, 'Esta venta está anulada: no se pueden registrar devoluciones.');
            }

            if (! $venta->pagado && ! $venta->esCredito()) {
                abort(422, 'Esta venta todavía no está cobrada. Si el cliente no la quiere, anúlala en vez de devolver.');
            }

            $detalles = $venta->detalles()->get()->keyBy('id');

            $yaDevuelto = DetalleDevolucion::whereIn('detalle_pedido_id', $detalles->keys())
                ->selectRaw('detalle_pedido_id, SUM(cantidad) as cantidad, SUM(monto) as monto')
                ->groupBy('detalle_pedido_id')
                ->get()->keyBy('detalle_pedido_id');

            // Si la misma línea viene dos veces, se suman.
            $pedidas = collect($validated['items'])->groupBy('detalle_id')
                ->map(fn ($g) => (int) $g->sum('cantidad'));

            $lineas = [];
            $total = 0.0;

            foreach ($pedidas as $detalleId => $cantidad) {
                $detalle = $detalles->get((int) $detalleId);

                if (! $detalle) {
                    abort(422, 'Una de las líneas no pertenece a esta venta.');
                }

                $cantPrevia = (int) ($yaDevuelto[$detalle->id]->cantidad ?? 0);
                $montoPrevio = (float) ($yaDevuelto[$detalle->id]->monto ?? 0);
                $restante = (int) $detalle->cantidad - $cantPrevia;
                $nombre = $detalle->producto?->nombre ?? 'Producto';

                if ($cantidad > $restante) {
                    abort(422, "De «{$nombre}» solo se pueden devolver {$restante} unidad(es) más (vendidas: {$detalle->cantidad}, ya devueltas: {$cantPrevia}).");
                }

                // Al devolver lo que queda, se devuelve el saldo exacto: así los
                // redondeos de las devoluciones parciales nunca descuadran el total.
                $monto = $cantidad === $restante
                    ? round((float) $detalle->subtotal - $montoPrevio, 2)
                    : round((float) $detalle->subtotal * $cantidad / (int) $detalle->cantidad, 2);

                $lineas[] = ['detalle' => $detalle, 'cantidad' => $cantidad, 'monto' => $monto];
                $total = round($total + $monto, 2);
            }

            // Dónde va el dinero: primero se descuenta de la deuda (fiado); lo
            // que sobre —porque el cliente ya había pagado— se devuelve.
            $aplicadoASaldo = 0.0;
            if ($venta->esCredito()) {
                $aplicadoASaldo = round(min($total, (float) $venta->saldo_pendiente), 2);
            }
            $reembolso = round($total - $aplicadoASaldo, 2);

            $almacenId = $venta->almacen_id ?? Almacen::principalId();
            $caja = $this->cajaAbierta($almacenId);

            $metodoReembolso = null;
            if ($reembolso > 0) {
                $pagosVenta = $venta->pagosPorMetodo();
                // Por defecto se devuelve por el mismo medio con que se pagó.
                $metodoReembolso = $validated['metodo_reembolso']
                    ?? (count($pagosVenta) === 1 && in_array(array_key_first($pagosVenta), ['efectivo', 'qr', 'tarjeta'], true)
                        ? array_key_first($pagosVenta)
                        : 'efectivo');

                if ($metodoReembolso === 'efectivo' && ! $caja) {
                    abort(422, 'Para devolver en efectivo la caja debe estar abierta: el dinero sale del arqueo del turno.');
                }
            }

            $devolucion = Devolucion::create([
                'pedido_id' => $venta->id,
                'usuario_id' => $usuario->id,
                'caja_id' => $caja?->id,
                'total' => $total,
                'aplicado_a_saldo' => $aplicadoASaldo,
                'monto_reembolsado' => $reembolso,
                'metodo_reembolso' => $metodoReembolso,
                'motivo' => $validated['motivo'],
            ]);

            $documento = $venta->nro_factura ?: $venta->id;

            foreach ($lineas as $l) {
                DetalleDevolucion::create([
                    'devolucion_id' => $devolucion->id,
                    'detalle_pedido_id' => $l['detalle']->id,
                    'producto_id' => $l['detalle']->producto_id,
                    'cantidad' => $l['cantidad'],
                    'monto' => $l['monto'],
                ]);

                $producto = Producto::lockForUpdate()->find($l['detalle']->producto_id);

                // Si el producto se borró del catálogo no hay stock que reponer,
                // pero la devolución se registra igual.
                if ($producto) {
                    $this->reponerStockVenta(
                        $producto, $l['cantidad'], $almacenId, $usuario->id,
                        "Devolución {$devolucion->nroNota()} de venta #{$documento}"
                    );
                }
            }

            $cambios = ['monto_devuelto' => round((float) $venta->monto_devuelto + $total, 2)];

            if ($aplicadoASaldo > 0) {
                $nuevoSaldo = max(0, round((float) $venta->saldo_pendiente - $aplicadoASaldo, 2));
                $cambios['saldo_pendiente'] = $nuevoSaldo;

                // La deuda quedó en cero por la devolución: la venta queda saldada.
                if ($nuevoSaldo <= 0 && ! $venta->pagado) {
                    $cambios['pagado'] = true;
                    $cambios['pagado_at'] = now();
                }
            }

            $venta->update($cambios);

            // 6.4: quita los puntos en proporción a lo devuelto.
            $fidelizacion->revertirDevolucion($venta, $devolucion);

            return $devolucion;
        });

        $venta->refresh()->load(['cliente', 'usuario', 'usuarioAnulacion', 'pagos']);

        return response()->json([
            'message' => "Devolución registrada: {$devolucion->nroNota()}.",
            'devolucion' => $this->presentarDevolucion($devolucion->load(['detalles.producto', 'usuario', 'pedido'])),
            'venta' => $this->presentar($venta),
        ], 201);
    }

    // GET /api/devoluciones/{devolucion}/nota-pdf
    public function notaCreditoPdf(Devolucion $devolucion)
    {
        $devolucion->load(['detalles.producto', 'usuario', 'pedido.cliente']);

        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('reportes.nota-credito', ['devolucion' => $devolucion]);

        return $pdf->download('nota-credito-'.$devolucion->nroNota().'.pdf');
    }

    private function presentarDevolucion(Devolucion $d): array
    {
        return [
            'id' => $d->id,
            'nro_nota' => $d->nroNota(),
            'venta_id' => $d->pedido_id,
            'fecha' => $d->created_at?->format('d/m/Y H:i'),
            'total' => (float) $d->total,
            'aplicado_a_saldo' => (float) $d->aplicado_a_saldo,
            'monto_reembolsado' => (float) $d->monto_reembolsado,
            'metodo_reembolso' => $d->metodo_reembolso,
            'motivo' => $d->motivo,
            'usuario' => $d->usuario?->nombre,
            'detalles' => $d->detalles->map(fn (DetalleDevolucion $x) => [
                'producto' => $x->producto?->nombre ?? 'Producto eliminado',
                'cantidad' => (int) $x->cantidad,
                'monto' => (float) $x->monto,
            ])->values(),
        ];
    }
}
