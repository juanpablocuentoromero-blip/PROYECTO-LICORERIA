<?php

namespace App\Http\Controllers;

use App\Models\Almacen;
use App\Models\Combo;
use App\Models\LoteProducto;
use App\Models\MovimientoInventario;
use App\Models\Producto;
use App\Models\StockPorAlmacen;
use App\Services\AuditoriaService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Ajustes de inventario por conteo físico.
 *
 * El administrador no dice "entran 3" o "salen 2": dice "contando en el
 * estante hay 17". El sistema compara contra lo que tiene registrado, calcula
 * la diferencia y deja un movimiento marcado como ajuste (con motivo y
 * responsable) para que el kardex siga cuadrando.
 */
class InventarioAjusteController extends Controller
{
    // GET /api/inventario/ajustes?desde=&hasta=&producto_id=
    public function index(Request $request)
    {
        $query = MovimientoInventario::with(['producto', 'usuario', 'almacen'])->where('es_ajuste', true);

        if ($request->filled('producto_id')) {
            $query->where('producto_id', $request->producto_id);
        }

        if ($request->filled('desde')) {
            $query->whereDate('created_at', '>=', $request->desde);
        }

        if ($request->filled('hasta')) {
            $query->whereDate('created_at', '<=', $request->hasta);
        }

        return $this->listarPaginado($query->orderByDesc('created_at')->orderByDesc('id'), $request, 50);
    }

    // POST /api/inventario/ajustes
    // { motivo, almacen_id?, items: [{producto_id, stock_real, fecha_vencimiento?, numero_lote?}] }
    public function store(Request $request, AuditoriaService $auditoria)
    {
        $validated = $request->validate([
            'motivo' => 'required|string|max:200',
            'almacen_id' => 'nullable|exists:almacenes,id',
            'items' => 'required|array|min:1',
            'items.*.producto_id' => 'required|exists:productos,id|distinct',
            'items.*.stock_real' => 'required|integer|min:0',
            'items.*.fecha_vencimiento' => 'nullable|date',
            'items.*.numero_lote' => 'nullable|string|max:100',
        ]);

        $usuarioId = $request->attributes->get('usuario_autenticado')->id;
        $almacenId = $validated['almacen_id'] ?? Almacen::principalId();
        $motivo = trim($validated['motivo']);

        $resultado = DB::transaction(function () use ($validated, $usuarioId, $almacenId, $motivo) {
            $ajustes = [];
            $sinCambios = 0;

            foreach ($validated['items'] as $item) {
                $producto = Producto::lockForUpdate()->findOrFail($item['producto_id']);

                // La "vitrina" de un combo no lleva stock propio.
                if (Combo::where('producto_id', $producto->id)->exists()) {
                    abort(422, "«{$producto->nombre}» es un combo y no lleva stock propio: ajusta sus componentes.");
                }

                $registro = StockPorAlmacen::lockForUpdate()->firstOrCreate(
                    ['producto_id' => $producto->id, 'almacen_id' => $almacenId],
                    ['cantidad' => 0]
                );

                $anterior = (int) $registro->cantidad;
                $delta = (int) $item['stock_real'] - $anterior;

                if ($delta === 0) {
                    $sinCambios++;

                    continue;
                }

                $nuevoStock = $producto->ajustarStock($delta, $almacenId);

                if ($delta > 0 && (! empty($item['fecha_vencimiento']) || ! empty($item['numero_lote']))) {
                    LoteProducto::create([
                        'producto_id' => $producto->id,
                        'almacen_id' => $almacenId,
                        'numero_lote' => $item['numero_lote'] ?? null,
                        'fecha_vencimiento' => $item['fecha_vencimiento'] ?? null,
                        'cantidad_inicial' => $delta,
                        'cantidad_disponible' => $delta,
                        'costo_unitario' => $producto->precio_compra,
                    ]);

                    $producto->sincronizarVencimiento();
                }

                MovimientoInventario::create([
                    'producto_id' => $producto->id,
                    'almacen_id' => $almacenId,
                    'usuario_id' => $usuarioId,
                    'tipo' => $delta > 0 ? 'entrada' : 'salida',
                    'cantidad' => abs($delta),
                    'stock_resultante' => $nuevoStock,
                    'motivo' => mb_substr("Ajuste de inventario: {$motivo}", 0, 255),
                    'es_ajuste' => true,
                ]);

                $ajustes[] = [
                    'producto_id' => $producto->id,
                    'nombre' => $producto->nombre,
                    'stock_anterior' => $anterior,
                    'stock_nuevo' => (int) $item['stock_real'],
                    'diferencia' => $delta,
                    'valor_diferencia' => round($delta * (float) $producto->precio_compra, 2),
                ];
            }

            return ['ajustes' => $ajustes, 'sin_cambios' => $sinCambios];
        });

        foreach ($resultado['ajustes'] as $a) {
            $auditoria->registrar(
                'ajuste', 'inventario', $a['producto_id'],
                "Ajuste de inventario ({$motivo}): {$a['nombre']}",
                'stock', $a['stock_anterior'], $a['stock_nuevo']
            );
        }

        return response()->json([
            'message' => count($resultado['ajustes']) === 0
                ? 'El stock contado coincide con el del sistema: no hubo nada que ajustar.'
                : 'Ajuste registrado en '.count($resultado['ajustes']).' producto(s).',
            'ajustes' => $resultado['ajustes'],
            'sin_cambios' => $resultado['sin_cambios'],
            'valor_total_diferencia' => round(array_sum(array_column($resultado['ajustes'], 'valor_diferencia')), 2),
        ], 201);
    }
}
