<?php

namespace App\Http\Controllers;

use App\Models\Alerta;
use App\Services\AlertaService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

/**
 * 4.2 — La campana del panel. La ven administrador y vendedor; solo el
 * administrador puede forzar la revisión (que además manda avisos).
 */
class AlertaController extends Controller
{
    // GET /api/alertas
    // Si hace más de 30 min que nadie revisó (no corrió el cron, p. ej. en
    // desarrollo), se refrescan acá, sin enviar correos.
    public function index(AlertaService $servicio): JsonResponse
    {
        Cache::remember('alertas_ultima_revision', now()->addMinutes(30), function () use ($servicio) {
            $servicio->revisar(false);

            return now()->toIso8601String();
        });

        $alertas = Alerta::with('producto:id,nombre,codigo,stock,stock_minimo,fecha_vencimiento')
            ->where('activa', true)
            ->orderBy('leida')
            ->orderByRaw("CASE severidad WHEN 'critica' THEN 0 ELSE 1 END")
            ->orderByDesc('updated_at')
            ->get();

        return response()->json([
            'alertas' => $alertas,
            'no_leidas' => $alertas->where('leida', false)->count(),
            'total' => $alertas->count(),
        ]);
    }

    // POST /api/alertas/revisar — fuerza la revisión (y avisa las nuevas por correo/WhatsApp).
    public function revisar(AlertaService $servicio): JsonResponse
    {
        $r = $servicio->revisar(true);
        Cache::put('alertas_ultima_revision', now()->toIso8601String(), now()->addMinutes(30));

        return response()->json([
            'message' => sprintf('Revisión lista: %d nueva(s), %d resuelta(s), %d activa(s).', count($r['nuevas']), $r['resueltas'], $r['activas']),
            'nuevas' => count($r['nuevas']),
            'resueltas' => $r['resueltas'],
            'activas' => $r['activas'],
        ]);
    }

    // POST /api/alertas/{alerta}/leer
    public function leer(Alerta $alerta): JsonResponse
    {
        $alerta->update(['leida' => true, 'leida_at' => now()]);

        return response()->json($alerta);
    }

    // POST /api/alertas/leer-todas
    public function leerTodas(): JsonResponse
    {
        Alerta::where('activa', true)->where('leida', false)->update(['leida' => true, 'leida_at' => now()]);

        return response()->json(['message' => 'Alertas marcadas como leídas.']);
    }
}
