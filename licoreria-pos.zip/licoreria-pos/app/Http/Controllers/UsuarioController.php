<?php

namespace App\Http\Controllers;

use App\Models\Usuario;
use App\Services\AuditoriaService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UsuarioController extends Controller
{
    // El frontend ya oculta los botones de gestión de usuarios a quien no es
    // administrador, pero eso por sí solo no protege la API: cualquiera con
    // un token válido podría llamar estos endpoints directamente. Este chequeo
    // repite la regla en el servidor, que es donde realmente cuenta.
    private function requireAdmin(Request $request): void
    {
        $usuario = $request->attributes->get('usuario_autenticado');

        if (! $usuario || $usuario->rol !== 'administrador') {
            abort(403, 'Solo un usuario con rol administrador puede gestionar usuarios.');
        }
    }

    // GET /api/usuarios
    public function index()
    {
        return Usuario::orderBy('nombre')->get();
    }

    // POST /api/usuarios
    public function store(Request $request, AuditoriaService $auditoria)
    {
        $this->requireAdmin($request);

        $validated = $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:usuarios,email',
            'password' => 'required|string|min:6',
            'rol' => 'required|string|max:50',
            'activo' => 'boolean',
        ]);

        $validated['password'] = Hash::make($validated['password']);

        $usuario = Usuario::create($validated);

        $auditoria->registrar('crear', 'usuario', $usuario->id, "Usuario: {$usuario->nombre}", 'rol', null, $usuario->rol);

        return response()->json($usuario, 201);
    }

    // GET /api/usuarios/{id}
    public function show(Usuario $usuario)
    {
        return $usuario;
    }

    // PUT/PATCH /api/usuarios/{id}
    public function update(Request $request, Usuario $usuario, AuditoriaService $auditoria)
    {
        $this->requireAdmin($request);

        $validated = $request->validate([
            'nombre' => 'sometimes|required|string|max:255',
            'email' => 'sometimes|required|email|max:255|unique:usuarios,email,'.$usuario->id,
            'password' => 'nullable|string|min:6',
            'rol' => 'sometimes|required|string|max:50',
            'activo' => 'boolean',
        ]);

        $cambioPassword = ! empty($validated['password']);

        if ($cambioPassword) {
            $validated['password'] = Hash::make($validated['password']);
        } else {
            unset($validated['password']);
        }

        $antes = $usuario->only(['nombre', 'email', 'rol', 'activo']);

        $usuario->update($validated);

        $auditoria->registrarCambios('usuario', $usuario, $antes, ['nombre', 'email', 'rol', 'activo'], "Usuario: {$usuario->nombre}");

        // Nunca se guarda la contraseña (ni su hash): solo que cambió.
        if ($cambioPassword) {
            $auditoria->registrar('actualizar', 'usuario', $usuario->id, "Usuario: {$usuario->nombre}", 'password', null, 'contraseña restablecida');
        }

        // Si el admin le cambió la contraseña o lo desactivó, se cierran sus
        // sesiones abiertas en todos los dispositivos.
        if ($cambioPassword || ! $usuario->activo) {
            $usuario->tokens()->delete();
        }

        return response()->json($usuario);
    }

    // DELETE /api/usuarios/{id}
    public function destroy(Request $request, Usuario $usuario, AuditoriaService $auditoria)
    {
        $this->requireAdmin($request);

        $auditoria->registrar('eliminar', 'usuario', $usuario->id, "Usuario: {$usuario->nombre}", 'rol', $usuario->rol, null);

        $usuario->tokens()->delete();
        $usuario->delete();

        return response()->json(['message' => 'Usuario eliminado correctamente']);
    }
}
