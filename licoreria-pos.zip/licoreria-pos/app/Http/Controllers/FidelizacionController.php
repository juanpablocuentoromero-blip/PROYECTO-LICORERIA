<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Services\AuditoriaService;
use App\Services\FidelizacionService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * 6.4 — Puntos de fidelización: consulta (staff y cliente) y ajuste manual.
 * Ganar y canjear puntos NO pasa por acá: ocurre dentro de la venta
 * (VentaController) y del cobro de pedidos online (PedidoController).
 */
class FidelizacionController extends Controller
{
    // GET /api/fidelizacion/config   (staff)
    public function configuracion(FidelizacionService $fidelizacion): JsonResponse
    {
        return response()->json($fidelizacion->configuracion());
    }

    // GET /api/clientes/{cliente}/puntos   (staff)
    // `maximo_canjeable` depende del total de la venta en curso (?total=).
    public function puntos(Request $request, Cliente $cliente, FidelizacionService $fidelizacion): JsonResponse
    {
        $resumen = $fidelizacion->resumen($cliente);
        $resumen['participa'] = $fidelizacion->esElegible($cliente);

        if ($request->filled('total')) {
            $total = max(0, (float) $request->query('total'));
            $max = $fidelizacion->maximoCanjeable($cliente, $total);
            $resumen['maximo_canjeable'] = $max;
            $resumen['descuento_maximo'] = $fidelizacion->valorDePuntos($max);
        }

        return response()->json($resumen);
    }

    // POST /api/clientes/{cliente}/puntos/ajuste   (solo administrador)
    public function ajustar(Request $request, Cliente $cliente, FidelizacionService $fidelizacion, AuditoriaService $auditoria): JsonResponse
    {
        $validated = $request->validate([
            // Positivo suma, negativo resta. Cero no tiene sentido.
            'puntos' => 'required|integer|not_in:0|between:-100000,100000',
            'motivo' => 'required|string|max:200',
        ]);

        if (! $fidelizacion->esElegible($cliente)) {
            abort(422, 'Este cliente no participa del programa de puntos (cliente sin identificar).');
        }

        $usuario = $request->attributes->get('usuario_autenticado');
        $antes = (int) $cliente->puntos_saldo;

        $fidelizacion->ajustar($cliente, (int) $validated['puntos'], $validated['motivo'], $usuario->id);

        $auditoria->registrar(
            'ajuste_puntos', 'cliente', $cliente->id,
            "Ajuste de puntos de {$cliente->nombre}: {$validated['motivo']}",
            'puntos_saldo', $antes, (int) $cliente->fresh()->puntos_saldo
        );

        return response()->json([
            'message' => 'Puntos ajustados.',
            ...$fidelizacion->resumen($cliente),
        ]);
    }

    // GET /api/cliente/puntos   (cliente de la tienda)
    public function misPuntos(Request $request, FidelizacionService $fidelizacion): JsonResponse
    {
        $cliente = $request->attributes->get('cliente_autenticado');

        return response()->json($fidelizacion->resumen($cliente));
    }
}
