<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\GestionaStockVenta;
use App\Mail\FacturaPedido;
use App\Mail\NuevaVentaAdmin;
use App\Mail\NuevoPedidoCliente;
use App\Models\Almacen;
use App\Models\Cliente;
use App\Models\DetallePedido;
use App\Models\Pedido;
use App\Models\Producto;
use App\Models\Promocion;
use App\Models\Repartidor;
use App\Models\Usuario;
use App\Models\ZonaDelivery;
use App\Services\AuditoriaService;
use App\Services\PromocionService;
use App\Services\QrPagoService;
use App\Jobs\EnviarWhatsapp;
use App\Services\FidelizacionService;
use App\Services\WhatsappService;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;

class PedidoController extends Controller
{
    // Misma lógica de stock que ya usa VentaController (mostrador): valida
    // y descuenta contra el stock real del almacén (StockPorAlmacen), no
    // contra la caché productos.stock. Antes PedidoController tenía su
    // propia copia de estos métodos, ya desactualizada frente al trait.
    use GestionaStockVenta;

    // GET /api/pedidos
    // El vendedor ve sus propios pedidos de mostrador (usuario_id igual al
    // suyo) MÁS todos los pedidos que llegan por la tienda online (origen
    // = 'online'), porque esos nunca quedan a nombre de un vendedor
    // particular (ver crearComoCliente) y cualquiera del personal tiene que
    // poder atenderlos. El administrador ve todos. Mismo patrón general que
    // MovimientoCajaChicaController::index().
    public function index(Request $request)
    {
        $usuario = $request->attributes->get('usuario_autenticado');

        $query = Pedido::with(['cliente', 'usuario', 'detalles.producto', 'zonaDelivery', 'repartidor']);

        if ($usuario->rol !== 'administrador') {
            $query->where(function ($q) use ($usuario) {
                $q->where('usuario_id', $usuario->id)
                    ->orWhere('origen', 'online');
            });
        }

        if ($request->filled('estado')) {
            $query->where('estado', $request->estado);
        }

        if ($request->filled('cliente_id')) {
            $query->where('cliente_id', $request->cliente_id);
        }

        return $this->listarPaginado($query->orderByDesc('created_at')->orderByDesc('id'), $request);
    }

    // GET /api/pedidos/nuevos?desde_id=123
    // Lo consulta el frontend cada pocos segundos (ver
    // PedidoNotificacionesService) para avisar con sonido y una tarjetita
    // cuando entra un pedido nuevo desde la tienda online, sin depender de
    // que alguien esté mirando la pantalla de Pedidos. Misma visibilidad
    // que index(): el vendedor ve los pedidos "online" igual que el
    // administrador, porque cualquiera del personal los puede atender.
    public function nuevos(Request $request)
    {
        $desdeId = (int) $request->input('desde_id', 0);

        $pedidos = Pedido::with('cliente')
            ->where('origen', 'online')
            ->where('id', '>', $desdeId)
            ->orderByDesc('id')
            ->limit(20)
            ->get()
            ->map(fn (Pedido $p) => [
                'id' => $p->id,
                'total' => (float) $p->total,
                'cliente_nombre' => $p->cliente->nombre ?? null,
                'tipo_entrega' => $p->tipo_entrega,
                'created_at' => $p->created_at,
            ]);

        return response()->json([
            'ultimo_id' => (int) (Pedido::where('origen', 'online')->max('id') ?? 0),
            'nuevos' => $pedidos,
        ]);
    }

    // POST /api/pedidos
    // Espera: cliente_id, metodo_pago, direccion_entrega, observaciones,
    // items: [{producto_id, cantidad}, ...]
    // usuario_id ya NO se toma del body: se deriva del usuario autenticado
    // (AuthUsuario middleware) para evitar que un usuario registre pedidos
    // "a nombre de" otro usuario.
    public function store(Request $request)
    {
        $validated = $request->validate([
            'cliente_id' => 'required|exists:clientes,id',
            // 'credito' = fiado: exige cliente identificado (NIT/CI) con el crédito
            // habilitado y dentro de su límite (ver validarCreditoCliente). Queda
            // sin cobrar y se cobra después con abonos en Cuentas por cobrar.
            'metodo_pago' => 'required|string|in:efectivo,qr,tarjeta,credito',
            'dias_credito' => 'nullable|integer|min:0|max:365',
            'direccion_entrega' => 'nullable|string|max:255',
            // Obligatorio en todo pedido: si no viene, se usa el del cliente
            // (ver exigirTelefono()).
            'telefono' => ['nullable', 'string', 'max:20', 'regex:/^[0-9+\-\s()]{7,20}$/'],
            'observaciones' => 'nullable|string',
            'items' => 'required|array|min:1',
            'items.*.producto_id' => 'required|exists:productos,id',
            'items.*.cantidad' => 'required|integer|min:1|max:99999',
            // Cómo se pide la línea: por unidad, paquete o caja. `cantidad` es
            // cuántas de esas presentaciones; el servidor lo pasa a unidades.
            'items.*.presentacion' => 'nullable|string|in:unidad,paquete,caja',
        ], [
            'telefono.regex' => 'El teléfono solo puede llevar números, +, espacios, guiones y paréntesis (mínimo 7 dígitos).',
        ]);

        $validated['usuario_id'] = $request->attributes->get('usuario_autenticado')->id;
        $validated['telefono_contacto'] = $this->exigirTelefono(
            $validated['telefono'] ?? null,
            Cliente::findOrFail($validated['cliente_id'])
        );

        // Las líneas se pasan a UNIDADES (paquete/caja -> unidades), se
        // fusionan los productos repetidos y se ordenan por id: así dos
        // pedidos simultáneos bloquean los productos en el mismo orden y no
        // se interbloquean entre sí (mismo patrón que VentaController::store()).
        $lineasPedidas = $this->agruparLineasPedido($validated['items']);
        $esCredito = $validated['metodo_pago'] === 'credito';

        $pedido = DB::transaction(function () use ($validated, $lineasPedidas, $esCredito) {
            $almacenId = Almacen::principalId();
            $subtotal = 0.0;
            $lineas = [];

            foreach ($lineasPedidas as $pedida) {
                $producto = Producto::lockForUpdate()->findOrFail($pedida['producto_id']);

                $this->verificarStockDisponible($producto, $pedida['cantidad'], $almacenId);

                $lineaSubtotal = round((float) $producto->precio_venta * $pedida['cantidad'], 2);
                $subtotal = round($subtotal + $lineaSubtotal, 2);

                $lineas[] = [
                    'producto' => $producto,
                    'cantidad' => $pedida['cantidad'],
                    'presentacion' => $pedida['presentacion'],
                    'cantidad_presentacion' => $pedida['cantidad_presentacion'],
                    'precio_unitario' => $producto->precio_venta,
                    'subtotal' => $lineaSubtotal,
                ];
            }

            $datosCredito = [];
            if ($esCredito) {
                $this->validarCreditoCliente(Cliente::findOrFail($validated['cliente_id']), $subtotal);

                $dias = (int) ($validated['dias_credito'] ?? config('services.licoreria.dias_credito_defecto', 30));
                $datosCredito = [
                    'saldo_pendiente' => $subtotal,
                    'fecha_vencimiento_credito' => now(config('services.licoreria.zona_horaria', 'America/La_Paz'))
                        ->addDays($dias)->toDateString(),
                ];
            }

            $pedido = Pedido::create([
                'cliente_id' => $validated['cliente_id'],
                'usuario_id' => $validated['usuario_id'],
                'origen' => 'mostrador',
                'estado' => 'pendiente',
                'direccion_entrega' => $validated['direccion_entrega'] ?? null,
                'telefono_contacto' => $validated['telefono_contacto'],
                'metodo_pago' => $validated['metodo_pago'],
                'subtotal' => $subtotal,
                'total' => $subtotal,
                'observaciones' => $validated['observaciones'] ?? null,
            ] + $datosCredito);

            foreach ($lineas as $linea) {
                DetallePedido::create([
                    'pedido_id' => $pedido->id,
                    'producto_id' => $linea['producto']->id,
                    'cantidad' => $linea['cantidad'],
                    'presentacion' => $linea['presentacion'],
                    'cantidad_presentacion' => $linea['cantidad_presentacion'],
                    'precio_unitario' => $linea['precio_unitario'],
                    'precio_compra' => $this->costoUnitarioVenta($linea['producto']),
                    'precio_venta' => $linea['precio_unitario'],
                    'subtotal' => $linea['subtotal'],
                ]);

                $this->descontarStockVenta(
                    $linea['producto'], $linea['cantidad'], $almacenId,
                    $validated['usuario_id'], "Venta - Pedido #{$pedido->id}"
                );
            }

            return $pedido;
        });

        return response()->json($pedido->load('detalles.producto', 'cliente'), 201);
    }

    // GET /api/cliente/mis-pedidos
    // Historial de compras del cliente autenticado (solo lo suyo: nunca
    // recibe cliente_id por parámetro, siempre se deriva del token).
    public function misPedidos(Request $request)
    {
        $cliente = $request->attributes->get('cliente_autenticado');

        return Pedido::with(['detalles.producto', 'zonaDelivery', 'repartidor:id,nombre,telefono'])
            ->where('cliente_id', $cliente->id)
            ->orderByDesc('created_at')
            ->get();
    }

    // POST /api/cliente/pedidos
    // Checkout público: el cliente autenticado arma su propio pedido desde
    // el carrito de la tienda. A diferencia de store() (uso interno del
    // personal), acá el cliente_id NUNCA viene del body -siempre se deriva
    // del token- así nadie puede comprar "a nombre de" otro cliente.
    //
    // La tabla pedidos exige un usuario_id (empleado que atendió la venta),
    // así que a los pedidos que llegan por la tienda online se les asigna
    // el usuario "de sistema" configurado en LICORERIA_USUARIO_PEDIDOS_ID
    // (o, si no se configuró, el primer administrador activo). Esto es solo
    // contable: el pedido sigue perteneciendo al cliente que lo hizo.
    //
    // Además del pedido en sí, acá se resuelven (siempre en el servidor):
    //  - 5.1 la confirmación de mayoría de edad (casilla obligatoria);
    //  - 5.2 recojo en tienda o delivery, con el costo de envío de la zona;
    //  - 5.4 promociones automáticas y cupón de descuento.
    public function crearComoCliente(Request $request, PromocionService $promociones)
    {
        $cliente = $request->attributes->get('cliente_autenticado');

        $validated = $request->validate([
            'metodo_pago' => 'required|string|in:efectivo,qr',
            'tipo_entrega' => 'nullable|string|in:recojo,delivery',
            'zona_delivery_id' => 'nullable|integer|exists:zonas_delivery,id',
            'direccion_entrega' => 'nullable|string|max:255',
            // Obligatorio: si el cliente no lo manda, se usa el de su cuenta.
            'telefono' => ['nullable', 'string', 'max:20', 'regex:/^[0-9+\-\s()]{7,20}$/'],
            'observaciones' => 'nullable|string',
            'cupon' => 'nullable|string|max:40',
            'mayor_edad' => 'accepted',
            'items' => 'required|array|min:1',
            'items.*.producto_id' => 'required|exists:productos,id',
            'items.*.cantidad' => 'required|integer|min:1|max:99999',
            'items.*.presentacion' => 'nullable|string|in:unidad,paquete,caja',
        ], [
            'mayor_edad.accepted' => 'Debes confirmar que eres mayor de 18 años para hacer un pedido.',
            'telefono.regex' => 'El teléfono solo puede llevar números, +, espacios, guiones y paréntesis (mínimo 7 dígitos).',
        ]);

        $validated['telefono_contacto'] = $this->exigirTelefono($validated['telefono'] ?? null, $cliente);

        $tipoEntrega = $validated['tipo_entrega'] ?? 'delivery';

        // Si el negocio aún no configuró zonas activas, el delivery se acepta
        // solo con la dirección (envío sin costo, a coordinar). Con zonas
        // configuradas, elegir una es obligatorio.
        $hayZonas = ZonaDelivery::where('activo', true)->exists();

        if ($tipoEntrega === 'delivery') {
            if ($hayZonas && empty($validated['zona_delivery_id'])) {
                abort(422, 'Elige la zona de entrega.');
            }
            if (trim((string) ($validated['direccion_entrega'] ?? '')) === '') {
                abort(422, 'Ingresa una dirección de entrega.');
            }
        }

        $usuarioSistemaId = config('services.licoreria.usuario_pedidos_id');
        $usuarioSistema = $usuarioSistemaId
            ? \App\Models\Usuario::find($usuarioSistemaId)
            : null;
        $usuarioSistema ??= \App\Models\Usuario::where('rol', 'administrador')->where('activo', true)->first();

        if (! $usuarioSistema) {
            abort(500, 'La tienda no tiene un usuario configurado para recibir pedidos online. Contacta al administrador.');
        }

        $validated['cliente_id'] = $cliente->id;
        $validated['usuario_id'] = $usuarioSistema->id;

        // Mismo criterio que store(): pasar a unidades, agrupar y ordenar por
        // producto_id evita deadlocks entre pedidos simultáneos.
        $lineasPedidas = $this->agruparLineasPedido($validated['items']);

        $pedido = DB::transaction(function () use ($validated, $lineasPedidas, $tipoEntrega, $promociones, $cliente) {
            $almacenId = Almacen::principalId();
            $subtotal = 0.0;
            $lineas = [];

            foreach ($lineasPedidas as $pedida) {
                $producto = Producto::lockForUpdate()->findOrFail($pedida['producto_id']);

                $this->verificarStockDisponible($producto, $pedida['cantidad'], $almacenId);

                $lineaSubtotal = round((float) $producto->precio_venta * $pedida['cantidad'], 2);
                $subtotal = round($subtotal + $lineaSubtotal, 2);

                $lineas[] = [
                    'producto' => $producto,
                    'cantidad' => $pedida['cantidad'],
                    'presentacion' => $pedida['presentacion'],
                    'cantidad_presentacion' => $pedida['cantidad_presentacion'],
                    'precio_unitario' => $producto->precio_venta,
                    'bruto' => $lineaSubtotal,
                ];
            }

            // 5.4) Promociones y cupón, calculados con precios de la base.
            $idsCombo = $promociones->idsDeCombos(array_map(fn ($l) => $l['producto']->id, $lineas));
            $entradaPromos = [];
            foreach ($lineas as $l) {
                $entradaPromos[$l['producto']->id] = [
                    'producto_id' => $l['producto']->id,
                    'categoria_id' => (int) $l['producto']->categoria_id,
                    'cantidad' => $l['cantidad'],
                    'base' => $l['bruto'],
                    'es_combo' => in_array($l['producto']->id, $idsCombo, true),
                ];
            }

            $calculo = $promociones->calcular($entradaPromos, $validated['cupon'] ?? null);

            if (! empty($validated['cupon']) && $calculo['cupon_error']) {
                abort(422, $calculo['cupon_error']);
            }

            if ($calculo['cupon']) {
                $promociones->consumirCupon($calculo['cupon']['id']);
            }

            $descuentoTotal = $calculo['total'];

            // 5.2) Costo de envío: lo define la zona elegida (se congela en
            // el pedido; si luego cambia la tarifa, este pedido no se altera).
            $zonaId = null;
            $costoEnvio = 0.0;
            if ($tipoEntrega === 'delivery' && ! empty($validated['zona_delivery_id'])) {
                $zona = ZonaDelivery::where('id', $validated['zona_delivery_id'])->where('activo', true)->first();
                if (! $zona) {
                    abort(422, 'La zona de entrega elegida ya no está disponible. Elige otra.');
                }
                $zonaId = $zona->id;
                $costoEnvio = round((float) $zona->costo_envio, 2);
            }

            $total = round($subtotal - $descuentoTotal + $costoEnvio, 2);

            $pedido = Pedido::create([
                'cliente_id' => $validated['cliente_id'],
                'usuario_id' => $validated['usuario_id'],
                'origen' => 'online',
                'estado' => 'pendiente',
                'direccion_entrega' => trim((string) ($validated['direccion_entrega'] ?? '')) ?: null,
                'telefono_contacto' => $validated['telefono_contacto'],
                'tipo_entrega' => $tipoEntrega,
                'zona_delivery_id' => $zonaId,
                'costo_envio' => $costoEnvio,
                'metodo_pago' => $validated['metodo_pago'],
                'subtotal' => $subtotal,
                'descuento' => $descuentoTotal,
                'cupon_codigo' => $calculo['cupon']['codigo'] ?? null,
                'total' => $total,
                'observaciones' => $validated['observaciones'] ?? null,
                'mayor_edad_confirmada' => true,
            ]);

            foreach ($lineas as $linea) {
                $promoLinea = $calculo['lineas'][$linea['producto']->id] ?? ['descuento' => 0.0, 'etiqueta' => null];

                DetallePedido::create([
                    'pedido_id' => $pedido->id,
                    'producto_id' => $linea['producto']->id,
                    'cantidad' => $linea['cantidad'],
                    'presentacion' => $linea['presentacion'],
                    'cantidad_presentacion' => $linea['cantidad_presentacion'],
                    'precio_unitario' => $linea['precio_unitario'],
                    'precio_compra' => $this->costoUnitarioVenta($linea['producto']),
                    'precio_venta' => $linea['precio_unitario'],
                    'descuento' => $promoLinea['descuento'],
                    'descuento_promocion' => $promoLinea['descuento'],
                    'promocion_aplicada' => $promoLinea['etiqueta'],
                    'subtotal' => round($linea['bruto'] - $promoLinea['descuento'], 2),
                ]);

                $this->descontarStockVenta(
                    $linea['producto'], $linea['cantidad'], $almacenId,
                    $validated['usuario_id'], "Venta online - Pedido #{$pedido->id}"
                );
            }

            // Constancia de mayoría de edad en la cuenta (si aún no la tenía).
            if (! $cliente->mayor_edad_confirmada_at) {
                $cliente->forceFill(['mayor_edad_confirmada_at' => now()])->save();
            }

            return $pedido;
        });

        $pedido->load('detalles.producto', 'cliente', 'zonaDelivery');

        // Aviso inmediato a quien tiene que atender el pedido: el
        // administrador y TODOS los vendedores activos (no solo el
        // "usuario de sistema" al que quedó contablemente asignado). No
        // debe romper la creación del pedido si el correo falla (ej. SMTP
        // no configurado en desarrollo).
        $destinatarios = Usuario::where('activo', true)
            ->whereIn('rol', ['administrador', 'vendedor'])
            ->pluck('email')
            ->push(config('services.licoreria.admin_email'))
            ->filter()
            ->unique();

        foreach ($destinatarios as $email) {
            try {
                Mail::to($email)->queue(new NuevoPedidoCliente($pedido));
            } catch (\Throwable $e) {
                Log::warning("No se pudo notificar el nuevo pedido a {$email}: ".$e->getMessage());
            }
        }

        return response()->json($pedido, 201);
    }

    // GET /api/cliente/pedidos/{pedido}/qr
    // Igual que qr(), pero verifica que el pedido sea del cliente
    // autenticado antes de mostrarle el código (nadie puede ver el QR de
    // pago de un pedido ajeno adivinando el id en la URL).
    public function qrCliente(Request $request, Pedido $pedido, QrPagoService $qrService)
    {
        $cliente = $request->attributes->get('cliente_autenticado');

        if ($pedido->cliente_id !== $cliente->id) {
            abort(403, 'Este pedido no te pertenece.');
        }

        $referencia = $pedido->referencia_pago ?? $qrService->generarReferencia($pedido);

        if (! $pedido->referencia_pago) {
            $pedido->update(['referencia_pago' => $referencia]);
        }

        $html = $qrService->generarHtml($pedido, $referencia);

        return response($html, 200)->header('Content-Type', 'text/html; charset=UTF-8');
    }

    // El teléfono es obligatorio en todo pedido. Se usa el que llega en la
    // petición o, si no, el que ya tiene el cliente; si no hay ninguno, 422.
    // Si el cliente es real (tiene NIT/CI distinto de 0) y todavía no tenía
    // teléfono, se le guarda en su ficha. El cliente genérico "SIN NOMBRE"
    // no se toca: lo comparten todas las ventas rápidas.
    private function exigirTelefono(?string $telefono, Cliente $cliente): string
    {
        $telefono = trim((string) $telefono);

        if ($telefono === '') {
            $telefono = trim((string) $cliente->telefono);
        }

        if ($telefono === '') {
            abort(422, 'El teléfono es obligatorio para registrar el pedido.');
        }

        $esGenerico = in_array(trim((string) $cliente->nit_ci), ['', '0'], true);

        if (! $esGenerico && trim((string) $cliente->telefono) === '') {
            $cliente->update(['telefono' => $telefono]);
        }

        return $telefono;
    }

    // Teléfono al que se escribe por WhatsApp: el del pedido y, para pedidos
    // viejos que no lo tienen, el de la ficha del cliente.
    private function telefonoDelPedido(Pedido $pedido): ?string
    {
        return $pedido->telefono_contacto ?: ($pedido->cliente->telefono ?? null);
    }

    // GET /api/pedidos/{id}
    public function show(Pedido $pedido)
    {
        return $pedido->load(['cliente', 'usuario', 'detalles.producto', 'zonaDelivery', 'repartidor']);
    }

    // GET /api/pedidos/{id}/qr
    // Devuelve el bloque HTML de cobro (QR real de Yolo Pago + monto,
    // referencia y cuentas). Ver QrPagoService.
    public function qr(Pedido $pedido, QrPagoService $qrService)
    {
        $referencia = $pedido->referencia_pago ?? $qrService->generarReferencia($pedido);

        if (! $pedido->referencia_pago) {
            $pedido->update(['referencia_pago' => $referencia]);
        }

        $html = $qrService->generarHtml($pedido, $referencia);

        return response($html, 200)->header('Content-Type', 'text/html; charset=UTF-8');
    }

    // POST /api/pedidos/{id}/confirmar-pago
    // El empleado usa este endpoint cuando confirma que el dinero realmente
    // llegó: efectivo en caja, QR/transferencia verificada en el banco, o
    // datáfono aprobado. A partir de ahí se dispara automáticamente:
    //   1) correo de notificación al administrador
    //   2) factura en PDF por correo al cliente (si tiene email)
    //   3) factura por WhatsApp al cliente (si tiene teléfono y Twilio está
    //      configurado; ver WhatsappService para el alcance del sandbox)
    public function confirmarPago(Request $request, Pedido $pedido, WhatsappService $whatsapp, FidelizacionService $fidelizacion)
    {
        if ($pedido->estado === 'cancelado') {
            abort(422, 'No se puede confirmar el pago de un pedido cancelado.');
        }

        if ($pedido->pagado) {
            abort(422, 'Este pedido ya estaba marcado como pagado.');
        }

        // Una venta a crédito no se cobra de una sola vez desde acá: cada
        // cobro se registra como abono en "Cuentas por cobrar", así la caja
        // y el saldo del cliente quedan cuadrados.
        if ($pedido->esCredito()) {
            abort(422, 'Esta venta es a crédito: registra los cobros como abonos en Cuentas por cobrar.');
        }

        $validated = $request->validate([
            'metodo_pago' => 'required|string|in:efectivo,qr,tarjeta',
        ]);

        $pedido->update([
            'metodo_pago' => $validated['metodo_pago'],
            'pagado' => true,
            'pagado_at' => now(),
        ]);

        // 6.4: el cobro confirmado da puntos al cliente. Un fallo acá nunca
        // debe impedir confirmar el pago (idempotente: se puede reintentar).
        try {
            $fidelizacion->acumularVenta($pedido);
        } catch (\Throwable $e) {
            Log::warning("No se pudieron acumular puntos del pedido #{$pedido->id}: ".$e->getMessage());
        }

        $pedido->load(['cliente', 'usuario', 'detalles.producto']);

        // 1) Notificar al administrador. No debe romper la confirmación del
        //    pago si el correo falla (ej. SMTP no configurado en desarrollo).
        try {
            Mail::to(config('services.licoreria.admin_email'))->queue(new NuevaVentaAdmin($pedido));
        } catch (\Throwable $e) {
            Log::warning('No se pudo enviar la notificación de venta al admin: '.$e->getMessage());
        }

        // 2) Factura por correo al cliente.
        if ($pedido->cliente->email) {
            try {
                Mail::to($pedido->cliente->email)->queue(new FacturaPedido($pedido));
            } catch (\Throwable $e) {
                Log::warning('No se pudo encolar la factura por correo: '.$e->getMessage());
            }
        }

        // 3) Factura por WhatsApp al cliente (Twilio). La URL de la factura
        //    tiene que ser pública y firmada (sin login) porque Twilio la
        //    descarga desde sus propios servidores, no desde el navegador
        //    del cliente.
        if ($this->telefonoDelPedido($pedido) && $whatsapp->habilitado()) {
            $urlFactura = URL::temporarySignedRoute(
                'pedidos.factura-pdf-publica',
                now()->addHours(24),
                ['pedido' => $pedido->id]
            );

            $mensaje = "¡Gracias por tu compra en Licorería Al Paso! 🍾\n".
                "Pedido #{$pedido->id} — Total: Bs ".number_format((float) $pedido->total, 2)."\n".
                'Aquí tienes tu nota de venta:';

            try {
                EnviarWhatsapp::dispatch($this->telefonoDelPedido($pedido), $mensaje, $urlFactura);
            } catch (\Throwable $e) {
                Log::warning('No se pudo encolar la factura por WhatsApp: '.$e->getMessage());
            }
        }

        return response()->json($pedido);
    }

    // GET /api/pedidos/{id}/factura-pdf-descarga  (staff autenticado)
    // A diferencia de facturaPdfPublica() (que exige firma para que Twilio
    // la descargue sin sesión), esta ruta la usa el propio panel: el
    // vendedor/administrador con sesión activa descarga el PDF con un clic
    // desde la pantalla de Pedidos.
    public function facturaPdfDescarga(Pedido $pedido)
    {
        if (! $pedido->pagado) {
            abort(422, 'Solo se puede descargar la factura de un pedido pagado.');
        }

        $pedido->load(['cliente', 'detalles.producto']);

        $pdf = Pdf::loadView('emails.factura-pdf', ['pedido' => $pedido]);

        return $pdf->download('nota-venta-'.$pedido->id.'.pdf');
    }

    // GET /api/pedidos/{id}/ticket?ancho=58|80&formato=html|pdf   (staff)
    // Ticket para impresora térmica (5.5). El panel pide formato=html (por
    // defecto) y lo imprime en un marco oculto; formato=pdf descarga el mismo
    // ticket como PDF del ancho del rollo. Sirve también para ventas a crédito
    // (muestra saldo y vencimiento), por eso no exige que el pedido esté pagado.
    public function ticketTermico(Request $request, Pedido $pedido)
    {
        $validated = $request->validate([
            'ancho' => 'nullable|integer|in:58,80',
            'formato' => 'nullable|string|in:html,pdf',
        ]);

        $ancho = (int) ($validated['ancho'] ?? 80);
        $formato = $validated['formato'] ?? 'html';

        $pedido->load(['cliente', 'usuario', 'detalles.producto', 'zonaDelivery']);

        if ($formato === 'html') {
            return response()
                ->view('tickets.termico', ['pedido' => $pedido, 'ancho' => $ancho, 'pdf' => false])
                ->header('Content-Type', 'text/html; charset=UTF-8');
        }

        // DomPDF necesita alto fijo: se estima por la cantidad de líneas
        // (cada producto ocupa 2-3 filas) y se deja holgura para el pie.
        $puntosPorMm = 72 / 25.4;
        $filas = 24 + ($pedido->detalles->count() * 3);
        $altoMm = max(120, $filas * 4.6);

        $pdf = Pdf::loadView('tickets.termico', ['pedido' => $pedido, 'ancho' => $ancho, 'pdf' => true])
            ->setPaper([0, 0, $ancho * $puntosPorMm, $altoMm * $puntosPorMm]);

        return $pdf->download('ticket-'.$pedido->id.'-'.$ancho.'mm.pdf');
    }

    // POST /api/pedidos/{id}/reenviar-factura
    // Reenvía la factura manualmente por correo y/o WhatsApp (por si el
    // cliente la perdió o el envío automático de confirmarPago() falló).
    public function reenviarFactura(Request $request, Pedido $pedido, WhatsappService $whatsapp)
    {
        if (! $pedido->pagado) {
            abort(422, 'Solo se puede reenviar la factura de un pedido pagado.');
        }

        $validated = $request->validate([
            'canal' => 'required|string|in:correo,whatsapp',
        ]);

        $pedido->load(['cliente', 'detalles.producto']);
        $resultado = ['enviado' => false, 'motivo' => null];

        if ($validated['canal'] === 'correo') {
            if (! $pedido->cliente->email) {
                abort(422, 'Este cliente no tiene un correo registrado.');
            }
            // 'enviado' = aceptado para envío: el correo sale desde la cola.
            try {
                Mail::to($pedido->cliente->email)->queue(new FacturaPedido($pedido));
                $resultado['enviado'] = true;
            } catch (\Throwable $e) {
                Log::warning('No se pudo encolar el reenvío de la factura por correo: '.$e->getMessage());
                abort(500, 'No se pudo programar el correo. Intenta más tarde.');
            }
        } else {
            if (! $this->telefonoDelPedido($pedido)) {
                abort(422, 'Este pedido no tiene un teléfono registrado.');
            }
            if (! $whatsapp->habilitado()) {
                abort(422, 'El envío de WhatsApp no está configurado en el sistema.');
            }

            $urlFactura = URL::temporarySignedRoute(
                'pedidos.factura-pdf-publica',
                now()->addHours(24),
                ['pedido' => $pedido->id]
            );

            $mensaje = "Aquí tienes de nuevo tu factura de Licorería Al Paso 🍾\n".
                "Pedido #{$pedido->id} — Total: Bs ".number_format((float) $pedido->total, 2);

            // 'enviado' = aceptado para envío: el WhatsApp sale desde la cola.
            try {
                EnviarWhatsapp::dispatch($this->telefonoDelPedido($pedido), $mensaje, $urlFactura);
                $resultado['enviado'] = true;
            } catch (\Throwable $e) {
                Log::warning('No se pudo encolar el reenvío de la factura por WhatsApp: '.$e->getMessage());
                abort(500, 'No se pudo programar el WhatsApp. Intenta más tarde.');
            }
        }

        return response()->json($resultado);
    }

    // GET /pedidos/{id}/factura-pdf (ruta pública firmada, ver routes/api.php)
    // Sin esta ruta pública, Twilio no podría descargar el PDF: sus
    // servidores no tienen el token de sesión del empleado que confirmó el
    // pago. La firma (signed URL) reemplaza el login: solo es válida para
    // este pedido y expira sola (24h).
    public function facturaPdfPublica(Request $request, Pedido $pedido)
    {
        if (! $request->hasValidSignature()) {
            abort(403, 'Enlace inválido o vencido.');
        }

        $pedido->load(['cliente', 'detalles.producto']);

        $pdf = Pdf::loadView('emails.factura-pdf', ['pedido' => $pedido]);

        return $pdf->stream('nota-venta-'.$pedido->id.'.pdf');
    }

    // PUT/PATCH /api/pedidos/{id}  (solo cambio de estado / datos generales, no de items)
    // IMPORTANTE: "cancelado" NO es un estado válido aquí. Cancelar un pedido
    // tiene que pasar por destroy() (DELETE), que es el único lugar que
    // restituye el stock. Si se permitiera aquí, se podría marcar un pedido
    // como cancelado sin devolver el inventario.
    //
    // Delivery (5.2): "en_camino" solo existe para pedidos con delivery y
    // exige un repartidor asignado (se puede mandar en la misma llamada o
    // haberlo asignado antes con repartidor_id).
    public function update(Request $request, Pedido $pedido)
    {
        if ($pedido->estado === 'cancelado') {
            abort(422, 'Este pedido ya está cancelado y no puede modificarse.');
        }

        $validated = $request->validate([
            'estado' => 'sometimes|required|string|in:pendiente,confirmado,en_camino,entregado',
            'direccion_entrega' => 'nullable|string|max:255',
            // El teléfono del pedido se puede corregir, pero nunca quedar vacío.
            'telefono_contacto' => ['sometimes', 'required', 'string', 'max:20', 'regex:/^[0-9+\-\s()]{7,20}$/'],
            'metodo_pago' => 'sometimes|required|string|max:50|not_in:credito',
            'observaciones' => 'nullable|string',
            'repartidor_id' => 'nullable|integer|exists:repartidores,id',
        ], [
            'telefono_contacto.regex' => 'El teléfono solo puede llevar números, +, espacios, guiones y paréntesis (mínimo 7 dígitos).',
        ]);

        if ($pedido->esCredito() && isset($validated['metodo_pago'])) {
            abort(422, 'No se puede cambiar el método de pago de una venta a crédito.');
        }

        if (! empty($validated['repartidor_id'])) {
            if ($pedido->tipo_entrega !== 'delivery') {
                abort(422, 'Solo los pedidos con delivery pueden tener repartidor.');
            }

            if (! Repartidor::where('id', $validated['repartidor_id'])->where('activo', true)->exists()) {
                abort(422, 'Ese repartidor está inactivo.');
            }
        }

        if (($validated['estado'] ?? null) === 'en_camino') {
            if ($pedido->tipo_entrega !== 'delivery') {
                abort(422, 'Solo los pedidos con delivery pueden marcarse «en camino».');
            }

            $repartidorId = array_key_exists('repartidor_id', $validated)
                ? $validated['repartidor_id']
                : $pedido->repartidor_id;

            if (! $repartidorId) {
                abort(422, 'Asigna un repartidor antes de marcar el pedido en camino.');
            }

            $validated['repartidor_id'] = $repartidorId;

            if ($pedido->estado !== 'en_camino') {
                $validated['en_camino_at'] = now();
            }
        }

        $pedido->update($validated);

        return response()->json($pedido->load('detalles.producto', 'cliente', 'zonaDelivery', 'repartidor'));
    }

    // PUT /api/pedidos/{id}/items  (staff)
    // Cambia los PRODUCTOS de un pedido que todavía no se cobró: quitar uno
    // que se acabó, agregar otro, cambiar cantidades o presentación. El
    // stock se corrige solo (lo que sobra vuelve, lo que falta se descuenta)
    // y el total se recalcula. Body: { items: [{producto_id, cantidad, presentacion?}] }
    public function editarItems(Request $request, Pedido $pedido, PromocionService $promociones, AuditoriaService $auditoria)
    {
        $items = $request->validate($this->reglasItemsEdicion())['items'];
        $usuario = $request->attributes->get('usuario_autenticado');
        $totalAntes = (float) $pedido->total;

        $resultado = $this->reemplazarItems($pedido, $items, $usuario->id, $promociones, false);

        $auditoria->registrar(
            'actualizar', 'pedido', $pedido->id, "Pedido #{$pedido->id}: productos editados",
            'total', $totalAntes, $resultado['pedido']->total
        );

        $respuesta = $resultado['pedido']
            ->load(['cliente', 'usuario', 'detalles.producto', 'zonaDelivery', 'repartidor'])
            ->toArray();
        $respuesta['aviso'] = $resultado['aviso'];

        return response()->json($respuesta);
    }

    // PUT /api/cliente/pedidos/{id}/items
    // El cliente corrige SU pedido mientras siga «pendiente» (nadie lo
    // confirmó todavía): olvidó algo, quiere más o menos. Así no tiene que
    // hacer otro pedido. Una vez confirmado, el local ya lo está armando y
    // el cambio se pide por teléfono/WhatsApp.
    public function clienteEditarItems(Request $request, Pedido $pedido, PromocionService $promociones)
    {
        $cliente = $request->attributes->get('cliente_autenticado');

        if ($pedido->cliente_id !== $cliente->id) {
            abort(403, 'Este pedido no te pertenece.');
        }

        $items = $request->validate($this->reglasItemsEdicion())['items'];
        $usuarioId = $pedido->usuario_id;

        $resultado = $this->reemplazarItems($pedido, $items, $usuarioId, $promociones, true);

        $respuesta = $resultado['pedido']
            ->load(['detalles.producto', 'zonaDelivery', 'repartidor:id,nombre,telefono'])
            ->toArray();
        $respuesta['aviso'] = $resultado['aviso'];

        return response()->json($respuesta);
    }

    private function reglasItemsEdicion(): array
    {
        return [
            'items' => 'required|array|min:1|max:200',
            'items.*.producto_id' => 'required|integer|exists:productos,id',
            'items.*.cantidad' => 'required|integer|min:1|max:99999',
            'items.*.presentacion' => 'nullable|string|in:unidad,paquete,caja',
        ];
    }

    // Núcleo de la edición de productos. Todo en una transacción: si algo
    // falla (p. ej. no alcanza el stock de lo nuevo) no queda nada a medias.
    // Devuelve ['pedido' => Pedido, 'aviso' => ?string].
    private function reemplazarItems(Pedido $pedidoRecibido, array $items, int $usuarioId, PromocionService $promociones, bool $esCliente): array
    {
        $lineasNuevas = $this->agruparLineasPedido($items)->keyBy('producto_id');

        return DB::transaction(function () use ($pedidoRecibido, $lineasNuevas, $usuarioId, $promociones, $esCliente) {
            // Bloqueado: dos ediciones (o una edición y un cobro) simultáneas
            // no pueden pisarse ni mover el stock dos veces.
            $pedido = Pedido::lockForUpdate()->findOrFail($pedidoRecibido->id);
            $aviso = null;

            if ($pedido->estado === 'cancelado' || $pedido->anulada) {
                abort(422, 'Este pedido está cancelado y no puede modificarse.');
            }

            if ($pedido->pagado) {
                abort(422, 'Este pedido ya está pagado: no se pueden cambiar los productos. Registra una devolución desde Historial de ventas.');
            }

            if ($pedido->devoluciones()->exists()) {
                abort(422, 'Este pedido tiene devoluciones (notas de crédito): no se puede modificar.');
            }

            if ($esCliente) {
                if ($pedido->origen !== 'online') {
                    abort(403, 'Este pedido no se puede modificar desde la tienda.');
                }

                if ($pedido->estado !== 'pendiente') {
                    abort(422, 'Tu pedido ya fue confirmado y se está preparando. Para cambiarlo, comunícate con el local.');
                }
            } elseif ($pedido->estado === 'entregado') {
                abort(422, 'El pedido ya fue entregado: no se puede modificar.');
            }

            if ($pedido->esCredito() && $pedido->abonos()->where('anulado', false)->exists()) {
                abort(422, 'Esta venta a crédito ya tiene abonos registrados: anúlalos primero en Cuentas por cobrar.');
            }

            $almacenId = Almacen::principalId();
            $actuales = $pedido->detalles()->get()->keyBy('producto_id');
            $ids = $actuales->keys()->merge($lineasNuevas->keys())->unique()->sort()->values();
            $motivo = "Edición - Pedido #{$pedido->id}";
            $subtotal = 0.0;
            $lineas = [];

            foreach ($ids as $productoId) {
                $producto = Producto::withTrashed()->lockForUpdate()->findOrFail($productoId);
                $detalle = $actuales->get($productoId);
                $nueva = $lineasNuevas->get($productoId);
                $antes = (int) ($detalle?->cantidad ?? 0);
                $despues = (int) ($nueva['cantidad'] ?? 0);

                if (! $detalle && ($producto->trashed() || ! $producto->activo)) {
                    abort(422, "«{$producto->nombre}» ya no está disponible para la venta.");
                }

                $delta = $despues - $antes;

                if ($delta > 0) {
                    $this->verificarStockDisponible($producto, $delta, $almacenId);
                    $this->descontarStockVenta($producto, $delta, $almacenId, $usuarioId, $motivo);
                } elseif ($delta < 0) {
                    $this->reponerStockVenta($producto, -$delta, $almacenId, $usuarioId, $motivo);
                }

                if ($despues === 0) {
                    $detalle?->delete();

                    continue;
                }

                // Lo que ya estaba en el pedido conserva el precio con el que
                // se pidió; solo lo nuevo toma el precio de hoy.
                $precio = $detalle ? (float) $detalle->precio_unitario : (float) $producto->precio_venta;
                $bruto = round($precio * $despues, 2);
                $subtotal = round($subtotal + $bruto, 2);

                $lineas[$productoId] = [
                    'producto' => $producto,
                    'detalle' => $detalle,
                    'cantidad' => $despues,
                    'presentacion' => $nueva['presentacion'],
                    'cantidad_presentacion' => $nueva['cantidad_presentacion'],
                    'precio' => $precio,
                    'bruto' => $bruto,
                ];
            }

            // Descuentos: los pedidos de la tienda llevan promociones/cupón
            // (se recalculan con las líneas nuevas). Los de mostrador no.
            $promoPorLinea = [];
            $descuentoTotal = (float) $pedido->descuento;
            $cuponCodigo = $pedido->cupon_codigo;

            if ($pedido->origen === 'online') {
                $codigoCupon = $promociones->normalizarCodigo($pedido->cupon_codigo);

                // El cupón ya se había gastado con este pedido: se libera el
                // uso para poder evaluarlo de nuevo contra el pedido editado.
                if ($codigoCupon !== null) {
                    Promocion::where('tipo', 'cupon')->where('codigo', $codigoCupon)
                        ->where('usos_actuales', '>', 0)->decrement('usos_actuales');
                }

                $idsCombo = $promociones->idsDeCombos(array_keys($lineas));
                $entrada = [];
                foreach ($lineas as $productoId => $l) {
                    $entrada[$productoId] = [
                        'producto_id' => (int) $productoId,
                        'categoria_id' => (int) $l['producto']->categoria_id,
                        'cantidad' => $l['cantidad'],
                        'base' => $l['bruto'],
                        'es_combo' => in_array((int) $productoId, $idsCombo, true),
                    ];
                }

                $calculo = $promociones->calcular($entrada, $codigoCupon);

                if ($calculo['cupon']) {
                    $promociones->consumirCupon($calculo['cupon']['id']);
                } elseif ($codigoCupon !== null) {
                    $cuponCodigo = null;
                    $aviso = 'El cupón «'.$codigoCupon.'» ya no aplica a los productos del pedido y se quitó.';
                }

                $promoPorLinea = $calculo['lineas'];
                $descuentoTotal = (float) $calculo['total'];
            }

            foreach ($lineas as $productoId => $l) {
                $descuentoLinea = (float) ($promoPorLinea[$productoId]['descuento'] ?? 0.0);
                $datos = [
                    'cantidad' => $l['cantidad'],
                    'presentacion' => $l['presentacion'],
                    'cantidad_presentacion' => $l['cantidad_presentacion'],
                    'precio_unitario' => $l['precio'],
                    'precio_venta' => $l['precio'],
                    'descuento' => $descuentoLinea,
                    'descuento_promocion' => $descuentoLinea,
                    'promocion_aplicada' => $promoPorLinea[$productoId]['etiqueta'] ?? null,
                    'subtotal' => round($l['bruto'] - $descuentoLinea, 2),
                ];

                if ($l['detalle']) {
                    $l['detalle']->update($datos);
                } else {
                    DetallePedido::create($datos + [
                        'pedido_id' => $pedido->id,
                        'producto_id' => $productoId,
                        'precio_compra' => $this->costoUnitarioVenta($l['producto']),
                    ]);
                }
            }

            $total = round($subtotal - $descuentoTotal + (float) $pedido->costo_envio, 2);

            $cambios = [
                'subtotal' => $subtotal,
                'descuento' => $descuentoTotal,
                'cupon_codigo' => $cuponCodigo,
                'total' => $total,
                'observaciones' => trim(
                    ((string) $pedido->observaciones === '' ? '' : $pedido->observaciones."\n")
                    .'['.now(config('services.licoreria.zona_horaria', 'America/La_Paz'))->format('d/m H:i')
                    .($esCliente ? '] El cliente modificó los productos del pedido.' : '] Productos del pedido modificados por el personal.')
                ),
            ];

            // Fiado: la deuda sigue al total (sin abonos, ya verificado) y se
            // vuelve a comprobar el límite de crédito del cliente.
            if ($pedido->esCredito()) {
                $this->validarCreditoCliente(Cliente::findOrFail($pedido->cliente_id), $total, $pedido->id);
                $cambios['saldo_pendiente'] = $total;
            }

            $pedido->update($cambios);

            return ['pedido' => $pedido->fresh(), 'aviso' => $aviso];
        });
    }

    // DELETE /api/pedidos/{id}  (cancela el pedido y regresa el stock)
    public function destroy(Request $request, Pedido $pedido, FidelizacionService $fidelizacion)
    {
        $validated = $request->validate([
            'motivo' => 'nullable|string|max:255',
        ]);

        $usuario = $request->attributes->get('usuario_autenticado');

        DB::transaction(function () use ($pedido, $validated, $usuario, $fidelizacion) {
            // Se relee bajo bloqueo (mismo patrón que VentaController::anular):
            // dos solicitudes simultáneas no pueden cancelar y devolver el
            // stock dos veces.
            $pedido = Pedido::lockForUpdate()->findOrFail($pedido->id);

            if ($pedido->estado === 'cancelado' || $pedido->anulada) {
                abort(422, 'Este pedido ya está cancelado.');
            }

            // Una venta a crédito con cobros registrados no se puede cancelar
            // sin más: habría dinero cobrado sin venta. Primero hay que anular
            // los abonos (Cuentas por cobrar, solo administrador).
            if ($pedido->abonos()->where('anulado', false)->exists()) {
                abort(422, 'Esta venta a crédito ya tiene abonos registrados. Anula primero los abonos en Cuentas por cobrar.');
            }

            // 4.5: con notas de crédito ya emitidas, anular repondría dos veces el
            // stock y descontaría dos veces el dinero ya devuelto.
            if ($pedido->devoluciones()->exists()) {
                abort(422, 'Esta venta ya tiene devoluciones (notas de crédito). No se puede anular completa.');
            }

            $almacenId = Almacen::principalId();

            foreach ($pedido->detalles as $detalle) {
                $producto = Producto::lockForUpdate()->findOrFail($detalle->producto_id);
                $this->reponerStockVenta(
                    $producto, $detalle->cantidad, $almacenId,
                    $pedido->usuario_id, "Cancelación - Pedido #{$pedido->id}"
                );
            }

            $pedido->update([
                'estado' => 'cancelado',
                'anulada' => true,
                'anulada_at' => now(),
                'motivo_anulacion' => $validated['motivo'] ?? 'Cancelado desde pedidos',
                'usuario_anulacion_id' => $usuario?->id,
            ]);

            // 6.4: si ya había dado puntos, se quitan.
            $fidelizacion->revertirVenta($pedido, $usuario?->id);
        });

        return response()->json(['message' => 'Pedido cancelado y stock restituido']);
    }
}
