export const environment = {
  production: true,
  // Ajusta esta URL al dominio real donde quede publicado el backend Laravel.
  apiUrl: 'https://api.licoreria-al-paso.com/api',
};
