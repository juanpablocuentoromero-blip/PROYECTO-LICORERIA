import { Producto } from '../models/producto.model';

/**
 * Presentaciones de venta de un producto. El stock siempre se cuenta en
 * UNIDADES; "paquete" y "caja" son solo una forma cómoda de pedir varias
 * unidades de una vez (la ficha del producto dice cuántas trae cada una).
 */
export type Presentacion = 'unidad' | 'paquete' | 'caja';

export interface OpcionPresentacion {
  valor: Presentacion;
  etiqueta: string;
  factor: number;
}

type ConPresentaciones = Pick<Producto, 'unidades_por_paquete' | 'unidades_por_caja'>;

/** Unidades que trae una presentación (unidad = 1; 0 si el producto no la tiene). */
export function factorDe(p: ConPresentaciones, presentacion: Presentacion): number {
  if (presentacion === 'paquete') return Number(p.unidades_por_paquete) || 0;
  if (presentacion === 'caja') return Number(p.unidades_por_caja) || 0;
  return 1;
}

/** Presentaciones disponibles: siempre "unidad"; paquete/caja solo si están configuradas. */
export function opcionesDe(p: ConPresentaciones): OpcionPresentacion[] {
  const opciones: OpcionPresentacion[] = [{ valor: 'unidad', etiqueta: 'Unidad', factor: 1 }];
  const paquete = factorDe(p, 'paquete');
  const caja = factorDe(p, 'caja');
  if (paquete > 1) opciones.push({ valor: 'paquete', etiqueta: `Paquete (${paquete} u.)`, factor: paquete });
  if (caja > 1) opciones.push({ valor: 'caja', etiqueta: `Caja (${caja} u.)`, factor: caja });
  return opciones;
}

/** Cuántas presentaciones completas caben en `unidades` de stock. */
export function maximoEn(p: ConPresentaciones, presentacion: Presentacion, unidades: number): number {
  const factor = factorDe(p, presentacion);
  return factor > 0 ? Math.max(0, Math.floor(unidades / factor)) : 0;
}

/** "3 cajas", "1 paquete", "5 unidades"… para mostrar en carrito, tickets y detalle. */
export function textoCantidad(presentacion: Presentacion | string | undefined, cantidad: number): string {
  const n = Number(cantidad) || 0;
  switch (presentacion) {
    case 'caja':
      return `${n} caja${n === 1 ? '' : 's'}`;
    case 'paquete':
      return `${n} paquete${n === 1 ? '' : 's'}`;
    default:
      return `${n} unidad${n === 1 ? '' : 'es'}`;
  }
}

/** Convierte lo que escribió la persona en un entero ≥ 0 (vacío o basura = 0). */
export function enteroSeguro(valor: unknown): number {
  const n = Math.floor(Number(valor));
  return Number.isFinite(n) && n > 0 ? n : 0;
}
