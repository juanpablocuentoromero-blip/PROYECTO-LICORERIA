import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { map } from 'rxjs';
import { AuthService } from '../services/auth.service';

export const adminGuard: CanActivateFn = (route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  return auth.asegurarSesion().pipe(
    map((valida) => {
      if (!valida) {
        router.navigate(['/login'], { queryParams: { expirada: 1, returnUrl: state.url } });
        return false;
      }

      if (auth.usuarioActual()?.rol === 'administrador') return true;

      // Vendedor logueado (staff sin permiso): lo mandamos al catálogo en
      // vez de al login, ya tiene sesión, solo no tiene acceso.
      router.navigate(['/catalogo']);
      return false;
    }),
  );
};
