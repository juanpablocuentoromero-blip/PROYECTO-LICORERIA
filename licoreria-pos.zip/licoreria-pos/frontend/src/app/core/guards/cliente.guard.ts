import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { ClienteAuthService } from '../services/cliente-auth.service';

// El perfil (datos de cuenta + historial de pedidos) es solo del cliente
// dueño de la sesión. El staff tiene su propio panel de "Clientes" para
// ver/editar cualquier ficha; esta pantalla no es esa.
export const clienteGuard: CanActivateFn = (route, state) => {
  const clienteAuth = inject(ClienteAuthService);
  const router = inject(Router);

  if (clienteAuth.estaAutenticado()) return true;

  router.navigate(['/acceso'], { queryParams: { returnUrl: state.url } });
  return false;
};
