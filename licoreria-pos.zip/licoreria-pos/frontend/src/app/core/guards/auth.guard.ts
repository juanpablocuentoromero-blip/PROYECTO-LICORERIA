import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { map } from 'rxjs';
import { AuthService } from '../services/auth.service';

// Antes este guard solo miraba si había un string guardado en localStorage.
// Con un token viejo (por re-seed de la BD, o por haber iniciado sesión en
// otro navegador) la app te dejaba entrar a zonas privadas y después la API
// respondía 401 en cada llamada. Ahora validamos el token contra
// /api/auth/me una sola vez por carga de la app.
export const authGuard: CanActivateFn = (route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  return auth.asegurarSesion().pipe(
    map((valida) => {
      if (valida) return true;
      router.navigate(['/login'], { queryParams: { expirada: 1, returnUrl: state.url } });
      return false;
    }),
  );
};
