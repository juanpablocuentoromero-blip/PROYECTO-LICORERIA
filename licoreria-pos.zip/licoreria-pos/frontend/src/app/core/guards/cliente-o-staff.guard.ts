import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { ClienteAuthService } from '../services/cliente-auth.service';

// El listado del catálogo es público, pero abrir el detalle de un
// producto (donde en el futuro se agrega al carrito / se compra) exige
// tener sesión: de cliente (comprador) o de staff (para revisar/editar
// la ficha). Si el visitante no tiene ninguna, lo mandamos directo a
// crear cuenta o iniciar sesión, y luego lo regresamos a este mismo
// producto.
export const clienteOStaffGuard: CanActivateFn = (route, state) => {
  const auth = inject(AuthService);
  const clienteAuth = inject(ClienteAuthService);
  const router = inject(Router);

  if (auth.estaAutenticado() || clienteAuth.estaAutenticado()) {
    return true;
  }

  router.navigate(['/acceso'], { queryParams: { returnUrl: state.url } });
  return false;
};
