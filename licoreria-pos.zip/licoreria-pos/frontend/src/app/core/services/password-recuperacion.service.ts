import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export type TipoCuenta = 'usuario' | 'cliente';

interface MensajeResponse {
  message: string;
}

@Injectable({ providedIn: 'root' })
export class PasswordRecuperacionService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/password`;

  solicitar(email: string, tipo: TipoCuenta): Observable<MensajeResponse> {
    return this.http.post<MensajeResponse>(`${this.baseUrl}/olvide`, { email, tipo });
  }

  restablecer(payload: {
    email: string;
    tipo: TipoCuenta;
    token: string;
    password: string;
    password_confirmation: string;
  }): Observable<MensajeResponse> {
    return this.http.post<MensajeResponse>(`${this.baseUrl}/restablecer`, payload);
  }
}
