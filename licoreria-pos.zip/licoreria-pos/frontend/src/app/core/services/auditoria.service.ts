import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { HistorialPrecios, PaginaAuditoria } from '../models/paso4.model';

export interface FiltroAuditoria {
  entidad?: string;
  usuario_id?: number | null;
  desde?: string;
  hasta?: string;
  buscar?: string;
  page?: number;
}

@Injectable({ providedIn: 'root' })
export class AuditoriaService {
  private http = inject(HttpClient);

  listar(filtro: FiltroAuditoria): Observable<PaginaAuditoria> {
    let params = new HttpParams();
    for (const [k, v] of Object.entries(filtro)) {
      if (v !== undefined && v !== null && v !== '') params = params.set(k, String(v));
    }
    return this.http.get<PaginaAuditoria>(`${environment.apiUrl}/auditoria`, { params });
  }

  historialPrecios(productoId: number): Observable<HistorialPrecios> {
    return this.http.get<HistorialPrecios>(`${environment.apiUrl}/productos/${productoId}/historial-precios`);
  }
}
