import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { RespuestaReposicion } from '../models/paso4.model';

export interface LineaBorrador {
  producto_id: number;
  cantidad: number;
  precio_unitario: number;
  proveedor_id?: number | null;
}

@Injectable({ providedIn: 'root' })
export class ReposicionService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/reposicion`;

  sugerencias(p: { dias_historial: number; dias_cobertura: number; dias_entrega: number; todos: boolean }): Observable<RespuestaReposicion> {
    return this.http.get<RespuestaReposicion>(`${this.baseUrl}/sugerencias`, {
      params: {
        dias_historial: String(p.dias_historial),
        dias_cobertura: String(p.dias_cobertura),
        dias_entrega: String(p.dias_entrega),
        todos: p.todos ? '1' : '0',
      },
    });
  }

  generarBorradores(items: LineaBorrador[], proveedorId?: number | null): Observable<{ message: string; pedidos: { id: number }[] }> {
    return this.http.post<{ message: string; pedidos: { id: number }[] }>(`${this.baseUrl}/generar-borradores`, {
      items,
      proveedor_id: proveedorId ?? null,
    });
  }
}
