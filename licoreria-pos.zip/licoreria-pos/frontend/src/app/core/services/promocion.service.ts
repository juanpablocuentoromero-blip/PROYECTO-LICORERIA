import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  ItemPromo,
  Promocion,
  PromocionPayload,
  RespuestaCalculoPromo,
} from '../models/paso5.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class PromocionService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/promociones`;

  // ---- Administración (solo administrador)
  listar(): Observable<Promocion[]> {
    return this.http.get<Promocion[]>(this.baseUrl);
  }

  crear(payload: PromocionPayload): Observable<Promocion> {
    return this.http.post<Promocion>(this.baseUrl, payload);
  }

  actualizar(id: number, payload: PromocionPayload): Observable<Promocion> {
    return this.http.put<Promocion>(`${this.baseUrl}/${id}`, payload);
  }

  eliminar(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.baseUrl}/${id}`);
  }

  // ---- Vista previa (el servidor vuelve a calcular todo al cobrar)
  /** Pantalla de Venta (personal). */
  calcularPos(items: ItemPromo[], cupon?: string): Observable<RespuestaCalculoPromo> {
    return this.http.post<RespuestaCalculoPromo>(`${environment.apiUrl}/ventas/promociones`, {
      items,
      cupon: cupon || undefined,
    });
  }

  /** Carrito de la tienda (cliente con sesión). */
  calcularTienda(items: ItemPromo[], cupon?: string): Observable<RespuestaCalculoPromo> {
    return this.http.post<RespuestaCalculoPromo>(`${environment.apiUrl}/cliente/promociones/calcular`, {
      items,
      cupon: cupon || undefined,
    });
  }
}
