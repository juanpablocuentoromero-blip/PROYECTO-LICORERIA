import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  FiltroVentas,
  RespuestaDetalleVenta,
  RespuestaVentas,
  VentaRegistrada,
} from '../models/venta.model';
import {
  ContextoVenta,
  RespuestaBuscarCliente,
  RespuestaBuscarProducto,
  RespuestaRegistrarVenta,
  VentaPayload,
} from '../models/punto-venta.model';
import { environment } from '../../../environments/environment';
import { PayloadDevolucion, RespuestaDevolucion } from '../models/paso4.model';

@Injectable({ providedIn: 'root' })
export class VentaService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/ventas`;

  private params(filtro: FiltroVentas): HttpParams {
    let params = new HttpParams();
    for (const [clave, valor] of Object.entries(filtro)) {
      if (valor !== undefined && valor !== null && valor !== '') {
        params = params.set(clave, String(valor));
      }
    }
    return params;
  }

  // ---------------------------------------------------------------
  // Punto de venta
  // ---------------------------------------------------------------

  /** Almacén de trabajo, cliente por defecto y si hay caja abierta. */
  contexto(): Observable<ContextoVenta> {
    return this.http.get<ContextoVenta>(`${this.baseUrl}/contexto`);
  }

  /** Código de barras exacto o, si no hay, búsqueda por nombre. 404 si no existe. */
  buscarProducto(codigo: string): Observable<RespuestaBuscarProducto> {
    return this.http.get<RespuestaBuscarProducto>(`${this.baseUrl}/buscar-producto`, {
      params: { codigo },
    });
  }

  buscarCliente(nitCi: string): Observable<RespuestaBuscarCliente> {
    return this.http.get<RespuestaBuscarCliente>(`${this.baseUrl}/cliente`, {
      params: { nit_ci: nitCi },
    });
  }

  /** Registra la venta completa (descuenta stock y entra al arqueo de caja). */
  registrar(payload: VentaPayload): Observable<RespuestaRegistrarVenta> {
    return this.http.post<RespuestaRegistrarVenta>(this.baseUrl, payload);
  }

  // ---------------------------------------------------------------
  // Historial de ventas
  // ---------------------------------------------------------------

  listar(filtro: FiltroVentas = {}): Observable<RespuestaVentas> {
    return this.http.get<RespuestaVentas>(this.baseUrl, { params: this.params(filtro) });
  }

  detalle(id: number): Observable<RespuestaDetalleVenta> {
    return this.http.get<RespuestaDetalleVenta>(`${this.baseUrl}/${id}`);
  }

  anular(id: number, motivo: string): Observable<{ message: string; venta: VentaRegistrada }> {
    return this.http.post<{ message: string; venta: VentaRegistrada }>(
      `${this.baseUrl}/${id}/anular`,
      { motivo },
    );
  }

  /**
   * Descarga el PDF del comprobante. Reutiliza el endpoint de factura que
   * ya existe en PedidoController: la venta y el pedido son la misma fila,
   * así que no hace falta un generador de PDF aparte.
   */
  descargarPdf(id: number, nroDocumento: string): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http
        .get(`${environment.apiUrl}/pedidos/${id}/factura-pdf-descarga`, { responseType: 'blob' })
        .subscribe({
          next: (blob) => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `venta-${nroDocumento}.pdf`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
            resolve();
          },
          error: (err) => reject(err),
        });
    });
  }

  // ---------------------------------------------------------------
  // 4.5 Devoluciones parciales / nota de crédito
  // ---------------------------------------------------------------

  devolver(ventaId: number, payload: PayloadDevolucion): Observable<RespuestaDevolucion> {
    return this.http.post<RespuestaDevolucion>(`${this.baseUrl}/${ventaId}/devolucion`, payload);
  }

  descargarNotaCredito(devolucionId: number, nroNota: string): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http
        .get(`${environment.apiUrl}/devoluciones/${devolucionId}/nota-pdf`, { responseType: 'blob' })
        .subscribe({
          next: (blob) => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `nota-credito-${nroNota}.pdf`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
            resolve();
          },
          error: (err) => reject(err),
        });
    });
  }
}
