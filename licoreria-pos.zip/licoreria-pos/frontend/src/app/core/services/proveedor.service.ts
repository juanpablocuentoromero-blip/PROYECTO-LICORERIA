import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Proveedor, ProveedorPayload } from '../models/proveedor.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ProveedorService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/proveedores`;

  listar(params?: { buscar?: string }): Observable<Proveedor[]> {
    return this.http.get<Proveedor[]>(this.baseUrl, { params: params as any });
  }

  crear(payload: ProveedorPayload): Observable<Proveedor> {
    return this.http.post<Proveedor>(this.baseUrl, payload);
  }

  actualizar(id: number, payload: Partial<ProveedorPayload>): Observable<Proveedor> {
    return this.http.put<Proveedor>(`${this.baseUrl}/${id}`, payload);
  }

  eliminar(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.baseUrl}/${id}`);
  }
}
