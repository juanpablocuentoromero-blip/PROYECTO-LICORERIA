import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, tap, map, catchError } from 'rxjs';
import { Usuario } from '../models/usuario.model';
import { environment } from '../../../environments/environment';

interface LoginResponse {
  token: string;
  usuario: Usuario;
}

const TOKEN_KEY = 'labodega_token';
const USUARIO_KEY = 'labodega_usuario';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/auth`;

  usuarioActual = signal<Usuario | null>(this.leerUsuarioGuardado());

  // Si el token de localStorage ya fue validado contra el servidor en esta
  // carga de la app. null = todavía no lo sabemos.
  private sesionValidada: boolean | null = null;

  private leerUsuarioGuardado(): Usuario | null {
    const raw = localStorage.getItem(USUARIO_KEY);
    try {
      return raw ? (JSON.parse(raw) as Usuario) : null;
    } catch {
      return null;
    }
  }

  login(email: string, password: string): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.baseUrl}/login`, { email, password }).pipe(
      tap((res) => {
        localStorage.setItem(TOKEN_KEY, res.token);
        localStorage.setItem(USUARIO_KEY, JSON.stringify(res.usuario));
        this.usuarioActual.set(res.usuario);
        this.sesionValidada = true;
      }),
    );
  }

  logout(): void {
    this.http.post(`${this.baseUrl}/logout`, {}).subscribe({ complete: () => {}, error: () => {} });
    this.limpiarSesion();
  }

  // Borra la sesión local SIN llamar al servidor. Lo usa el interceptor
  // cuando la API responde 401: el token guardado ya no sirve (se venció,
  // se inició sesión en otro navegador, o se re-sembró la base de datos).
  limpiarSesion(): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USUARIO_KEY);
    this.usuarioActual.set(null);
    this.sesionValidada = null;
  }

  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  // Ojo: esto SOLO dice "hay un token guardado", no que el token sirva.
  // Para decidir si dejamos entrar a una pantalla usa asegurarSesion().
  estaAutenticado(): boolean {
    return !!this.getToken();
  }

  me(): Observable<Usuario> {
    return this.http.get<Usuario>(`${this.baseUrl}/me`).pipe(
      tap((usuario) => {
        localStorage.setItem(USUARIO_KEY, JSON.stringify(usuario));
        this.usuarioActual.set(usuario);
      }),
    );
  }

  // Valida el token contra el servidor una sola vez por carga de la app.
  // Este es el arreglo de fondo: antes el guard solo miraba localStorage,
  // así que con un token viejo la app se veía "logueada" pero cada llamada
  // a la API devolvía 401 ("No autenticado.").
  asegurarSesion(): Observable<boolean> {
    if (!this.getToken()) return of(false);
    if (this.sesionValidada === true) return of(true);

    return this.me().pipe(
      map(() => {
        this.sesionValidada = true;
        return true;
      }),
      catchError(() => {
        this.limpiarSesion();
        return of(false);
      }),
    );
  }

  actualizarPerfil(
    payload: Partial<{ nombre: string; password: string; password_confirmation: string }>,
  ): Observable<Usuario> {
    return this.http.put<Usuario>(`${this.baseUrl}/perfil`, payload).pipe(
      tap((usuario) => {
        localStorage.setItem(USUARIO_KEY, JSON.stringify(usuario));
        this.usuarioActual.set(usuario);
      }),
    );
  }
}
