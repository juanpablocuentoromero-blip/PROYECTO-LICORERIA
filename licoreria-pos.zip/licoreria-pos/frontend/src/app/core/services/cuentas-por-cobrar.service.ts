import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  AbonoPayload,
  EstadoCuentaCliente,
  RespuestaDeudores,
} from '../models/paso5.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class CuentasPorCobrarService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/cuentas-por-cobrar`;

  deudores(filtro: { buscar?: string; solo_vencidas?: boolean } = {}): Observable<RespuestaDeudores> {
    const params: Record<string, string> = {};
    if (filtro.buscar) params['buscar'] = filtro.buscar;
    if (filtro.solo_vencidas) params['solo_vencidas'] = '1';
    return this.http.get<RespuestaDeudores>(this.baseUrl, { params });
  }

  estadoCliente(clienteId: number): Observable<EstadoCuentaCliente> {
    return this.http.get<EstadoCuentaCliente>(`${this.baseUrl}/clientes/${clienteId}`);
  }

  abonar(payload: AbonoPayload): Observable<{ message: string; estado: EstadoCuentaCliente }> {
    return this.http.post<{ message: string; estado: EstadoCuentaCliente }>(`${this.baseUrl}/abonos`, payload);
  }

  anularAbono(id: number, motivo: string): Observable<{ message: string; estado: EstadoCuentaCliente }> {
    return this.http.post<{ message: string; estado: EstadoCuentaCliente }>(
      `${this.baseUrl}/abonos/${id}/anular`,
      { motivo },
    );
  }

  /** Estado de cuenta en PDF (se descarga). */
  descargarEstadoPdf(clienteId: number, nombre: string): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http.get(`${this.baseUrl}/clientes/${clienteId}/estado-pdf`, { responseType: 'blob' }).subscribe({
        next: (blob) => {
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `estado-cuenta-${nombre.replace(/\s+/g, '-').toLowerCase()}.pdf`;
          document.body.appendChild(a);
          a.click();
          a.remove();
          window.URL.revokeObjectURL(url);
          resolve();
        },
        error: (err) => reject(err),
      });
    });
  }

  /** Excel de deudas (solo administrador). */
  descargarReporteExcel(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http.get(`${environment.apiUrl}/reportes/cuentas-por-cobrar`, { responseType: 'blob' }).subscribe({
        next: (blob) => {
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = 'reporte-cuentas-por-cobrar.xlsx';
          document.body.appendChild(a);
          a.click();
          a.remove();
          window.URL.revokeObjectURL(url);
          resolve();
        },
        error: (err) => reject(err),
      });
    });
  }
}
