import { Injectable, computed, signal } from '@angular/core';
import { Producto } from '../models/producto.model';
import { ItemCarrito } from '../models/carrito.model';
import { Presentacion, enteroSeguro, factorDe } from '../utils/presentacion';

const STORAGE_KEY = 'labodega_carrito';

/**
 * Carrito de la tienda. Una línea = un producto en UNA presentación
 * (unidad, paquete o caja); el mismo producto puede estar en varias líneas
 * (p. ej. 2 cajas + 3 unidades). El stock se compara siempre en unidades.
 */
@Injectable({ providedIn: 'root' })
export class CarritoService {
  private itemsSignal = signal<ItemCarrito[]>(this.leerGuardado());

  items = this.itemsSignal.asReadonly();

  /** Unidades totales del carrito (lo que se descuenta del stock). */
  totalUnidades = computed(() =>
    this.itemsSignal().reduce((suma, item) => suma + this.unidadesDe(item), 0),
  );

  totalMonto = computed(() =>
    this.itemsSignal().reduce((suma, item) => suma + this.subtotalDe(item), 0),
  );

  private leerGuardado(): ItemCarrito[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      const items = raw ? (JSON.parse(raw) as Partial<ItemCarrito>[]) : [];
      // Carritos guardados antes de las presentaciones no traen `presentacion`.
      return items
        .filter((i) => i && i.producto)
        .map((i) => ({
          producto: i.producto as Producto,
          cantidad: enteroSeguro(i.cantidad),
          presentacion: (i.presentacion as Presentacion) ?? 'unidad',
        }))
        .filter((i) => i.cantidad > 0);
    } catch {
      return [];
    }
  }

  private guardar(items: ItemCarrito[]): void {
    this.itemsSignal.set(items);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }

  /** Unidades que representa una línea (2 cajas de 12 = 24). */
  unidadesDe(item: ItemCarrito): number {
    return item.cantidad * factorDe(item.producto, item.presentacion);
  }

  subtotalDe(item: ItemCarrito): number {
    return this.unidadesDe(item) * Number(item.producto.precio_venta);
  }

  /** Cantidad de una línea concreta (producto + presentación). */
  cantidadDe(productoId: number, presentacion: Presentacion = 'unidad'): number {
    return (
      this.itemsSignal().find((i) => i.producto.id === productoId && i.presentacion === presentacion)?.cantidad ?? 0
    );
  }

  /** Unidades de este producto ya en el carrito, en cualquier presentación. */
  unidadesDeProducto(productoId: number): number {
    return this.itemsSignal()
      .filter((i) => i.producto.id === productoId)
      .reduce((s, i) => s + this.unidadesDe(i), 0);
  }

  /** Máximo de esa presentación que se puede tener en esa línea según el stock. */
  maximoPara(producto: Producto, presentacion: Presentacion): number {
    const factor = factorDe(producto, presentacion);
    if (factor < 1) return 0;
    const otras = this.itemsSignal()
      .filter((i) => i.producto.id === producto.id && i.presentacion !== presentacion)
      .reduce((s, i) => s + this.unidadesDe(i), 0);
    return Math.max(0, Math.floor((Number(producto.stock) - otras) / factor));
  }

  /** Suma `cantidad` a la línea. Devuelve cuántas quedaron (recortado al stock). */
  agregar(producto: Producto, cantidad = 1, presentacion: Presentacion = 'unidad'): number {
    return this.establecer(producto, this.cantidadDe(producto.id, presentacion) + enteroSeguro(cantidad), presentacion);
  }

  /** Fija la cantidad de la línea (la persona la escribe directo). 0 la quita. */
  establecer(producto: Producto, cantidad: number, presentacion: Presentacion = 'unidad'): number {
    const pedida = enteroSeguro(cantidad);
    const final = Math.min(pedida, this.maximoPara(producto, presentacion));
    let items = this.itemsSignal().filter(
      (i) => !(i.producto.id === producto.id && i.presentacion === presentacion),
    );
    if (final > 0) items = [...items, { producto, cantidad: final, presentacion }];
    // Mantener el orden en que se fue armando el carrito.
    this.guardar(this.ordenarComoAntes(items));
    return final;
  }

  /** Compatibilidad con los botones − / +. */
  actualizarCantidad(productoId: number, cantidad: number, presentacion: Presentacion = 'unidad'): void {
    const item = this.itemsSignal().find((i) => i.producto.id === productoId && i.presentacion === presentacion);
    if (item) this.establecer(item.producto, cantidad, presentacion);
  }

  quitar(productoId: number, presentacion: Presentacion = 'unidad'): void {
    this.guardar(
      this.itemsSignal().filter((i) => !(i.producto.id === productoId && i.presentacion === presentacion)),
    );
  }

  vaciar(): void {
    this.guardar([]);
  }

  private ordenarComoAntes(nuevos: ItemCarrito[]): ItemCarrito[] {
    const clave = (i: ItemCarrito) => `${i.producto.id}|${i.presentacion}`;
    const previos = this.itemsSignal().map(clave);
    return [...nuevos].sort((a, b) => {
      const ia = previos.indexOf(clave(a));
      const ib = previos.indexOf(clave(b));
      return (ia < 0 ? Infinity : ia) - (ib < 0 ? Infinity : ib);
    });
  }
}
