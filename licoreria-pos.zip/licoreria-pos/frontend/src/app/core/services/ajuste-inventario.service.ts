import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AjusteInventarioPayload, AjusteInventarioResultado, LoteProducto } from '../models/lote.model';
import { MovimientoInventario } from '../models/movimiento.model';
import { Pagina } from '../models/pagina.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AjusteInventarioService {
  private http = inject(HttpClient);
  private api = environment.apiUrl;

  /** Ajuste por conteo físico: se manda cuánto HAY y la API calcula la diferencia. */
  ajustar(payload: AjusteInventarioPayload): Observable<AjusteInventarioResultado> {
    return this.http.post<AjusteInventarioResultado>(`${this.api}/inventario/ajustes`, payload);
  }

  listarAjustes(page = 1, porPagina = 20): Observable<Pagina<MovimientoInventario>> {
    return this.http.get<Pagina<MovimientoInventario>>(`${this.api}/inventario/ajustes`, {
      params: { page: String(page), por_pagina: String(porPagina) },
    });
  }

  /** Lotes con unidades, el que vence antes primero. veceEnDias filtra por "vence dentro de N días". */
  lotes(params?: { producto_id?: number; vence_en_dias?: number; todos?: boolean }): Observable<LoteProducto[]> {
    const p: Record<string, string> = {};
    if (params?.producto_id) p['producto_id'] = String(params.producto_id);
    if (params?.vence_en_dias !== undefined) p['vence_en_dias'] = String(params.vence_en_dias);
    if (params?.todos) p['todos'] = '1';
    return this.http.get<LoteProducto[]>(`${this.api}/lotes`, { params: p });
  }
}
