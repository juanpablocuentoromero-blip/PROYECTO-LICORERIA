import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Pedido } from '../models/pedido.model';
import { CheckoutPayload } from '../models/checkout.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class PedidoClienteService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/cliente`;

  crear(payload: CheckoutPayload): Observable<Pedido> {
    return this.http.post<Pedido>(`${this.baseUrl}/pedidos`, payload);
  }

  /** El cliente cambia los productos de su pedido mientras siga «pendiente». */
  editarItems(pedidoId: number, items: { producto_id: number; cantidad: number; presentacion?: string }[]): Observable<Pedido> {
    return this.http.put<Pedido>(`${this.baseUrl}/pedidos/${pedidoId}/items`, { items });
  }

  misPedidos(): Observable<Pedido[]> {
    return this.http.get<Pedido[]>(`${this.baseUrl}/mis-pedidos`);
  }

  obtenerQr(pedidoId: number): Observable<string> {
    return this.http.get(`${this.baseUrl}/pedidos/${pedidoId}/qr`, { responseType: 'text' });
  }
}
