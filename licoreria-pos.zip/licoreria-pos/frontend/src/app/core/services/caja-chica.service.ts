import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MovimientoCajaChica, MovimientoCajaChicaPayload, ResumenCajaChica } from '../models/caja-chica.model';
import { FiltrosCajaChica, ReporteCajaChica } from '../models/reportes.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class CajaChicaService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/caja-chica`;

  resumen(almacenId?: number): Observable<ResumenCajaChica> {
    return this.http.get<ResumenCajaChica>(`${this.baseUrl}/resumen`, {
      params: almacenId ? { almacen_id: almacenId } : {},
    });
  }

  listar(params?: {
    fecha_desde?: string; fecha_hasta?: string; cuenta?: string;
    tipo?: string; metodo_pago?: string; caja_id?: number; almacen_id?: number;
  }): Observable<MovimientoCajaChica[]> {
    return this.http.get<MovimientoCajaChica[]>(this.baseUrl, { params: params as any });
  }

  /** Reporte de caja chica: totales, por cuenta y por día (el vendedor solo ve lo suyo). */
  reporte(filtros: FiltrosCajaChica): Observable<ReporteCajaChica> {
    return this.http.get<ReporteCajaChica>(`${this.baseUrl}/reporte`, { params: this.limpiar(filtros) });
  }

  descargarReporteExcel(filtros: FiltrosCajaChica): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http.get(`${this.baseUrl}/reporte-excel`, { params: this.limpiar(filtros), responseType: 'blob' }).subscribe({
        next: (blob) => {
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `reporte-caja-chica-${new Date().toISOString().slice(0, 10)}.xlsx`;
          document.body.appendChild(a);
          a.click();
          a.remove();
          window.URL.revokeObjectURL(url);
          resolve();
        },
        error: (err) => reject(err),
      });
    });
  }

  private limpiar(filtros: object): Record<string, string> {
    const out: Record<string, string> = {};
    for (const [k, v] of Object.entries(filtros)) {
      if (v !== undefined && v !== null && v !== '') out[k] = String(v);
    }
    return out;
  }

  crear(payload: MovimientoCajaChicaPayload): Observable<MovimientoCajaChica> {
    return this.http.post<MovimientoCajaChica>(this.baseUrl, payload);
  }

  actualizar(id: number, payload: Partial<MovimientoCajaChicaPayload>): Observable<MovimientoCajaChica> {
    return this.http.put<MovimientoCajaChica>(`${this.baseUrl}/${id}`, payload);
  }

  eliminar(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.baseUrl}/${id}`);
  }

  // Recibo individual en PDF (requiere sesión: se pide como blob).
  descargarReciboPdf(id: number): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http.get(`${this.baseUrl}/${id}/recibo-pdf`, { responseType: 'blob' }).subscribe({
        next: (blob) => {
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `recibo-caja-chica-${id}.pdf`;
          document.body.appendChild(a);
          a.click();
          a.remove();
          window.URL.revokeObjectURL(url);
          resolve();
        },
        error: (err) => reject(err),
      });
    });
  }
}
