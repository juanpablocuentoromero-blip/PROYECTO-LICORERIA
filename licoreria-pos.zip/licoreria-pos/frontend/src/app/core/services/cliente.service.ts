import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Cliente, ClientePayload } from '../models/cliente.model';
import { Pagina } from '../models/pagina.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ClienteService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/clientes`;

  listar(buscar?: string): Observable<Cliente[]> {
    return this.http.get<Cliente[]>(this.baseUrl, { params: buscar ? { buscar } : {} });
  }

  /** Lista paginada (2.2) para la pantalla de Clientes. */
  listarPagina(buscar: string | undefined, page: number, porPagina = 25): Observable<Pagina<Cliente>> {
    const params: Record<string, string> = { page: String(page), por_pagina: String(porPagina) };
    if (buscar) params['buscar'] = buscar;
    return this.http.get<Pagina<Cliente>>(this.baseUrl, { params });
  }

  crear(payload: ClientePayload): Observable<Cliente> {
    return this.http.post<Cliente>(this.baseUrl, payload);
  }

  actualizar(id: number, payload: ClientePayload): Observable<Cliente> {
    return this.http.put<Cliente>(`${this.baseUrl}/${id}`, payload);
  }

  eliminar(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.baseUrl}/${id}`);
  }
}
