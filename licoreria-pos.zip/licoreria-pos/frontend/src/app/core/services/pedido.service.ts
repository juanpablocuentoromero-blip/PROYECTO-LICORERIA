import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Pedido, PedidoPayload } from '../models/pedido.model';
import { Pagina } from '../models/pagina.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class PedidoService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/pedidos`;

  listar(params?: { estado?: string; cliente_id?: number }): Observable<Pedido[]> {
    return this.http.get<Pedido[]>(this.baseUrl, { params: params as any });
  }

  /** Lista paginada (2.2) para la pantalla de Pedidos. */
  listarPagina(page: number, params?: { estado?: string; cliente_id?: number }, porPagina = 25): Observable<Pagina<Pedido>> {
    return this.http.get<Pagina<Pedido>>(this.baseUrl, {
      params: { ...(params as any), page: String(page), por_pagina: String(porPagina) },
    });
  }

  crear(payload: PedidoPayload): Observable<Pedido> {
    return this.http.post<Pedido>(this.baseUrl, payload);
  }

  cambiarEstado(id: number, estado: string, repartidorId?: number | null): Observable<Pedido> {
    const body: Record<string, unknown> = { estado };
    if (repartidorId) body['repartidor_id'] = repartidorId;
    return this.http.put<Pedido>(`${this.baseUrl}/${id}`, body);
  }

  /** Asigna (o cambia) el repartidor de un pedido con delivery. */
  asignarRepartidor(id: number, repartidorId: number): Observable<Pedido> {
    return this.http.put<Pedido>(`${this.baseUrl}/${id}`, { repartidor_id: repartidorId });
  }

  /** Corrige datos del pedido sin tocar productos ni total. */
  editar(id: number, datos: { direccion_entrega?: string | null; telefono_contacto?: string; observaciones?: string | null }): Observable<Pedido> {
    return this.http.put<Pedido>(`${this.baseUrl}/${id}`, datos);
  }

  /** Cambia los PRODUCTOS de un pedido sin cobrar: ajusta stock y total en el servidor. */
  editarItems(id: number, items: { producto_id: number; cantidad: number; presentacion?: string }[]): Observable<Pedido> {
    return this.http.put<Pedido>(`${this.baseUrl}/${id}/items`, { items });
  }

  cancelar(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.baseUrl}/${id}`);
  }

  obtenerQr(id: number): Observable<string> {
    return this.http.get(`${this.baseUrl}/${id}/qr`, { responseType: 'text' });
  }

  confirmarPago(id: number, metodo_pago: 'efectivo' | 'qr' | 'tarjeta'): Observable<Pedido> {
    return this.http.post<Pedido>(`${this.baseUrl}/${id}/confirmar-pago`, { metodo_pago });
  }

  // Descarga la factura en PDF directamente (el navegador la guarda o el
  // usuario la abre para imprimir).
  descargarFactura(id: number): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http.get(`${this.baseUrl}/${id}/factura-pdf-descarga`, { responseType: 'blob' }).subscribe({
        next: (blob) => {
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `nota-venta-${id}.pdf`;
          document.body.appendChild(a);
          a.click();
          a.remove();
          window.URL.revokeObjectURL(url);
          resolve();
        },
        error: (err) => reject(err),
      });
    });
  }

  reenviarFactura(id: number, canal: 'correo' | 'whatsapp'): Observable<{ enviado: boolean }> {
    return this.http.post<{ enviado: boolean }>(`${this.baseUrl}/${id}/reenviar-factura`, { canal });
  }
}
