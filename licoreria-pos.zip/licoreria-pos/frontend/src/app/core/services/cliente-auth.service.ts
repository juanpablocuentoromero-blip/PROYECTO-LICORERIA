import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { Cliente } from '../models/cliente.model';
import {
  ClienteAuthResponse,
  LoginClientePayload,
  RegistroClientePayload,
} from '../models/cliente-auth.model';
import { environment } from '../../../environments/environment';

const TOKEN_KEY = 'labodega_cliente_token';
const CLIENTE_KEY = 'labodega_cliente';

@Injectable({ providedIn: 'root' })
export class ClienteAuthService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/cliente`;

  clienteActual = signal<Cliente | null>(this.leerClienteGuardado());

  private leerClienteGuardado(): Cliente | null {
    const raw = localStorage.getItem(CLIENTE_KEY);
    return raw ? JSON.parse(raw) : null;
  }

  registro(payload: RegistroClientePayload): Observable<ClienteAuthResponse> {
    return this.http.post<ClienteAuthResponse>(`${this.baseUrl}/registro`, payload).pipe(
      tap((res) => this.guardarSesion(res)),
    );
  }

  login(payload: LoginClientePayload): Observable<ClienteAuthResponse> {
    return this.http.post<ClienteAuthResponse>(`${this.baseUrl}/login`, payload).pipe(
      tap((res) => this.guardarSesion(res)),
    );
  }

  logout(): void {
    this.http.post(`${this.baseUrl}/logout`, {}).subscribe({ complete: () => {}, error: () => {} });
    this.limpiarSesion();
  }

  // Borra la sesión local SIN llamar al servidor. Lo usa el interceptor
  // cuando la API responde 401 (token vencido o cerrado desde otro dispositivo).
  limpiarSesion(): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(CLIENTE_KEY);
    this.clienteActual.set(null);
  }

  private guardarSesion(res: ClienteAuthResponse): void {
    localStorage.setItem(TOKEN_KEY, res.token);
    localStorage.setItem(CLIENTE_KEY, JSON.stringify(res.cliente));
    this.clienteActual.set(res.cliente);
  }

  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  estaAutenticado(): boolean {
    return !!this.getToken();
  }

  obtenerPerfil(): Observable<Cliente> {
    return this.http.get<Cliente>(`${this.baseUrl}/me`).pipe(
      tap((cliente) => {
        localStorage.setItem(CLIENTE_KEY, JSON.stringify(cliente));
        this.clienteActual.set(cliente);
      }),
    );
  }

  actualizarPerfil(payload: Partial<{
    nombre: string;
    telefono: string;
    direccion: string;
    password: string;
    password_confirmation: string;
  }>): Observable<Cliente> {
    return this.http.put<Cliente>(`${this.baseUrl}/perfil`, payload).pipe(
      tap((cliente) => {
        localStorage.setItem(CLIENTE_KEY, JSON.stringify(cliente));
        this.clienteActual.set(cliente);
      }),
    );
  }
}
