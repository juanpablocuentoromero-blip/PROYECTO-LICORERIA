import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Repartidor, ZonaDelivery } from '../models/paso5.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class DeliveryService {
  private http = inject(HttpClient);
  private zonasUrl = `${environment.apiUrl}/zonas-delivery`;
  private repartidoresUrl = `${environment.apiUrl}/repartidores`;

  // ---- Zonas
  /** Público: solo las activas. Con `todas` (administrador) también las inactivas. */
  zonas(todas = false): Observable<ZonaDelivery[]> {
    return this.http.get<ZonaDelivery[]>(this.zonasUrl, { params: todas ? { todas: '1' } : {} });
  }

  crearZona(payload: Partial<ZonaDelivery>): Observable<ZonaDelivery> {
    return this.http.post<ZonaDelivery>(this.zonasUrl, payload);
  }

  actualizarZona(id: number, payload: Partial<ZonaDelivery>): Observable<ZonaDelivery> {
    return this.http.put<ZonaDelivery>(`${this.zonasUrl}/${id}`, payload);
  }

  eliminarZona(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.zonasUrl}/${id}`);
  }

  // ---- Repartidores
  repartidores(todos = false): Observable<Repartidor[]> {
    return this.http.get<Repartidor[]>(this.repartidoresUrl, { params: todos ? { todos: '1' } : {} });
  }

  crearRepartidor(payload: Partial<Repartidor>): Observable<Repartidor> {
    return this.http.post<Repartidor>(this.repartidoresUrl, payload);
  }

  actualizarRepartidor(id: number, payload: Partial<Repartidor>): Observable<Repartidor> {
    return this.http.put<Repartidor>(`${this.repartidoresUrl}/${id}`, payload);
  }

  eliminarRepartidor(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.repartidoresUrl}/${id}`);
  }
}
