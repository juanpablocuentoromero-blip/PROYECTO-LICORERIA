import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  AbrirCajaPayload, Caja, CajaActualResponse, CerrarCajaPayload,
} from '../models/caja.model';
import { ReporteCajero } from '../models/reportes.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class CajaService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/caja`;

  actual(almacenId?: number): Observable<CajaActualResponse> {
    return this.http.get<CajaActualResponse>(`${this.baseUrl}/actual`, {
      params: almacenId ? { almacen_id: almacenId } : {},
    });
  }

  /** Reporte de caja del cajero (el vendedor solo ve lo suyo; el admin puede elegir usuario_id). */
  miReporte(params?: { desde?: string; hasta?: string; usuario_id?: number }): Observable<ReporteCajero> {
    const p: Record<string, string> = {};
    if (params?.desde) p['desde'] = params.desde;
    if (params?.hasta) p['hasta'] = params.hasta;
    if (params?.usuario_id) p['usuario_id'] = String(params.usuario_id);
    return this.http.get<ReporteCajero>(`${this.baseUrl}/mi-reporte`, { params: p });
  }

  historial(params?: { almacen_id?: number; estado?: string; desde?: string; hasta?: string }): Observable<Caja[]> {
    return this.http.get<Caja[]>(this.baseUrl, { params: params as any });
  }

  ver(id: number): Observable<Caja> {
    return this.http.get<Caja>(`${this.baseUrl}/${id}`);
  }

  abrir(payload: AbrirCajaPayload): Observable<Caja> {
    return this.http.post<Caja>(`${this.baseUrl}/abrir`, payload);
  }

  cerrar(id: number, payload: CerrarCajaPayload): Observable<Caja> {
    return this.http.post<Caja>(`${this.baseUrl}/${id}/cerrar`, payload);
  }

  // Descarga el arqueo en PDF (requiere sesión, por eso se pide como blob
  // en vez de un <a href> directo, igual que la factura de pedidos).
  descargarArqueoPdf(id: number): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http.get(`${this.baseUrl}/${id}/arqueo-pdf`, { responseType: 'blob' }).subscribe({
        next: (blob) => {
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `arqueo-caja-${id}.pdf`;
          document.body.appendChild(a);
          a.click();
          a.remove();
          window.URL.revokeObjectURL(url);
          resolve();
        },
        error: (err) => reject(err),
      });
    });
  }
}
