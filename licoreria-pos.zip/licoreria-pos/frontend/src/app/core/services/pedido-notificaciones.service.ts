import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { AuthService } from './auth.service';

export interface PedidoNuevoAviso {
  id: number;
  total: number;
  cliente_nombre?: string | null;
  created_at?: string;
}

interface RespuestaNuevos {
  ultimo_id: number;
  nuevos: PedidoNuevoAviso[];
}

const CLAVE_ULTIMO_ID = 'labodega_pedidos_ultimo_id_visto';
const INTERVALO_MS = 20000;

/**
 * Avisa (sonido + insignia + tarjetita) cuando llega un pedido nuevo desde
 * la tienda online, sin que el personal tenga que estar mirando la
 * pantalla de Pedidos. Funciona por sondeo (poll) cada 20s porque el
 * backend no tiene WebSockets configurados; es liviano y de sobra para el
 * volumen de un solo local.
 *
 * El "último id visto" se guarda en localStorage para que, al recargar la
 * página, no se vuelvan a anunciar pedidos que el personal ya vio.
 */
@Injectable({ providedIn: 'root' })
export class PedidoNotificacionesService {
  private http = inject(HttpClient);
  private auth = inject(AuthService);
  private baseUrl = `${environment.apiUrl}/pedidos/nuevos`;

  /** Pedidos nuevos todavía no descartados, para mostrar como tarjetitas. */
  readonly pendientes = signal<PedidoNuevoAviso[]>([]);
  /** Cantidad para la insignia junto a "Pedidos" en el menú. */
  readonly cantidadNueva = signal(0);

  private ultimoId = 0;
  private temporizador?: ReturnType<typeof setInterval>;
  private audio?: AudioContext;
  private activo = false;

  iniciar(): void {
    if (this.activo) return;
    this.activo = true;

    const guardado = Number(localStorage.getItem(CLAVE_ULTIMO_ID) ?? '0');
    this.ultimoId = Number.isFinite(guardado) ? guardado : 0;

    this.consultar(true);
    this.temporizador = setInterval(() => this.consultar(false), INTERVALO_MS);
  }

  detener(): void {
    this.activo = false;
    if (this.temporizador) clearInterval(this.temporizador);
    this.temporizador = undefined;
    this.pendientes.set([]);
    this.cantidadNueva.set(0);
  }

  /** El personal ya miró la lista: se apaga la insignia y se recuerda hasta dónde llegó. */
  marcarVistos(): void {
    this.cantidadNueva.set(0);
    this.pendientes.set([]);
    localStorage.setItem(CLAVE_ULTIMO_ID, String(this.ultimoId));
  }

  descartarAviso(id: number): void {
    this.pendientes.set(this.pendientes().filter((p) => p.id !== id));
  }

  private consultar(esPrimeraCarga: boolean): void {
    if (!this.auth.estaAutenticado()) return;

    this.http.get<RespuestaNuevos>(this.baseUrl, { params: { desde_id: this.ultimoId } }).subscribe({
      next: (res) => {
        if (res.nuevos.length > 0) {
          // En la primera carga de la sesión no se suena la alarma (podría
          // ser el backlog de toda la noche); en las siguientes consultas
          // sí, porque ahí es cuando "acaba de llegar" de verdad.
          if (!esPrimeraCarga) this.sonarAviso();

          const existentes = new Set(this.pendientes().map((p) => p.id));
          const nuevosSinDuplicar = res.nuevos.filter((p) => !existentes.has(p.id));
          this.pendientes.set([...nuevosSinDuplicar, ...this.pendientes()].slice(0, 8));
          this.cantidadNueva.set(this.cantidadNueva() + nuevosSinDuplicar.length);
        }
        if (res.ultimo_id > this.ultimoId) this.ultimoId = res.ultimo_id;
      },
      error: () => {
        // Sin conexión puntual: se reintenta solo en el próximo ciclo.
      },
    });
  }

  private sonarAviso(): void {
    try {
      this.audio ??= new AudioContext();
      // Dos notas ascendentes, distinto del beep de "error" del punto de
      // venta, para que se reconozca de oído como "llegó un pedido".
      [880, 1108].forEach((frecuencia, i) => {
        const osc = this.audio!.createOscillator();
        const ganancia = this.audio!.createGain();
        osc.type = 'sine';
        osc.frequency.value = frecuencia;
        ganancia.gain.value = 0.05;
        osc.connect(ganancia);
        ganancia.connect(this.audio!.destination);
        const inicio = this.audio!.currentTime + i * 0.14;
        osc.start(inicio);
        osc.stop(inicio + 0.13);
      });
    } catch {
      // Sin audio disponible: el aviso visual (insignia + tarjetita) sigue funcionando.
    }
  }
}
