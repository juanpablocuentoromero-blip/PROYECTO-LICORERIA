import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Producto } from '../models/producto.model';
import { Pagina } from '../models/pagina.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ProductoService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/productos`;

  listar(params?: { categoria_id?: number; buscar?: string; stock_bajo?: boolean }): Observable<Producto[]> {
    return this.http.get<Producto[]>(this.baseUrl, { params: params as any });
  }

  /** Lista paginada (2.2) para la pantalla de Productos. `listar()` sigue trayendo todo (desplegables). */
  listarPagina(page: number, params?: { categoria_id?: number; buscar?: string; stock_bajo?: boolean }, porPagina = 25): Observable<Pagina<Producto>> {
    return this.http.get<Pagina<Producto>>(this.baseUrl, {
      params: { ...(params as any), page: String(page), por_pagina: String(porPagina) },
    });
  }

  obtener(id: number): Observable<Producto> {
    return this.http.get<Producto>(`${this.baseUrl}/${id}`);
  }

  crear(producto: Partial<Producto>): Observable<Producto> {
    return this.http.post<Producto>(this.baseUrl, producto);
  }

  actualizar(id: number, producto: Partial<Producto>): Observable<Producto> {
    return this.http.put<Producto>(`${this.baseUrl}/${id}`, producto);
  }

  eliminar(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
