import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

export type AnchoTicket = 58 | 80;

const ANCHO_KEY = 'labodega_ticket_ancho';

/**
 * Ticket para impresora térmica (5.5).
 *
 * El servidor devuelve el ticket como HTML del ancho del rollo
 * (GET /pedidos/{id}/ticket). Se pide con el token (por eso va por
 * HttpClient y no con una URL directa), se carga en un marco oculto y se
 * imprime desde ahí: el navegador respeta el @page del ticket y manda el
 * trabajo a la térmica sin márgenes ni hoja A4. El ancho elegido (58/80) se
 * recuerda en este equipo, porque cada caja tiene su propia impresora.
 */
@Injectable({ providedIn: 'root' })
export class TicketService {
  private http = inject(HttpClient);

  ancho(): AnchoTicket {
    return localStorage.getItem(ANCHO_KEY) === '58' ? 58 : 80;
  }

  guardarAncho(ancho: AnchoTicket): void {
    localStorage.setItem(ANCHO_KEY, String(ancho));
  }

  /** Abre el diálogo de impresión con el ticket del pedido. */
  imprimir(pedidoId: number, ancho: AnchoTicket = this.ancho()): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http
        .get(`${environment.apiUrl}/pedidos/${pedidoId}/ticket`, {
          params: { ancho: String(ancho), formato: 'html' },
          responseType: 'text',
        })
        .subscribe({
          next: (html) => {
            const marco = document.createElement('iframe');
            marco.setAttribute('aria-hidden', 'true');
            marco.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden;';
            // El HTML del ticket ya trae su propio window.print() al cargar.
            marco.srcdoc = html;
            document.body.appendChild(marco);
            // Se limpia después de un rato: quitarlo antes cancelaría la impresión.
            setTimeout(() => marco.remove(), 60000);
            resolve();
          },
          error: (err) => reject(err),
        });
    });
  }

  /** Descarga el mismo ticket como PDF del ancho del rollo. */
  descargarPdf(pedidoId: number, ancho: AnchoTicket = this.ancho()): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http
        .get(`${environment.apiUrl}/pedidos/${pedidoId}/ticket`, {
          params: { ancho: String(ancho), formato: 'pdf' },
          responseType: 'blob',
        })
        .subscribe({
          next: (blob) => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `ticket-${pedidoId}-${ancho}mm.pdf`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
            resolve();
          },
          error: (err) => reject(err),
        });
    });
  }
}
