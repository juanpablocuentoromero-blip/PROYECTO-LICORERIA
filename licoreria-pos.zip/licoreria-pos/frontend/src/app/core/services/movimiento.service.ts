import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MovimientoInventario, MovimientoPayload } from '../models/movimiento.model';
import { Pagina } from '../models/pagina.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class MovimientoService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/movimientos-inventario`;

  listar(params?: { producto_id?: number; tipo?: string }): Observable<MovimientoInventario[]> {
    return this.http.get<MovimientoInventario[]>(this.baseUrl, { params: params as any });
  }

  /** Lista paginada (2.2) del historial de movimientos. */
  listarPagina(page: number, params?: { producto_id?: number; tipo?: string }, porPagina = 50): Observable<Pagina<MovimientoInventario>> {
    return this.http.get<Pagina<MovimientoInventario>>(this.baseUrl, {
      params: { ...(params as any), page: String(page), por_pagina: String(porPagina) },
    });
  }

  crear(payload: MovimientoPayload): Observable<MovimientoInventario> {
    return this.http.post<MovimientoInventario>(this.baseUrl, payload);
  }
}
