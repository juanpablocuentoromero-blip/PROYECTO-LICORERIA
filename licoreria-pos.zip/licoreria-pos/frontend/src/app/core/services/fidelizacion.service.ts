import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ConfigFidelizacion, ResumenPuntos } from '../models/fidelizacion.model';
import { environment } from '../../../environments/environment';

/** 6.4 — Puntos de fidelización. Ganar y canjear ocurre al vender (VentaService). */
@Injectable({ providedIn: 'root' })
export class FidelizacionService {
  private http = inject(HttpClient);
  private baseUrl = environment.apiUrl;

  /** Reglas vigentes (para calcular la vista previa del canje en caja). */
  configuracion(): Observable<ConfigFidelizacion> {
    return this.http.get<ConfigFidelizacion>(`${this.baseUrl}/fidelizacion/config`);
  }

  /** Saldo y movimientos de un cliente; con `total` calcula cuánto puede canjear. */
  puntosDeCliente(clienteId: number, total?: number): Observable<ResumenPuntos> {
    let params = new HttpParams();
    if (total !== undefined) params = params.set('total', String(total));
    return this.http.get<ResumenPuntos>(`${this.baseUrl}/clientes/${clienteId}/puntos`, { params });
  }

  /** Solo administrador: positivo suma, negativo resta. */
  ajustar(clienteId: number, puntos: number, motivo: string): Observable<ResumenPuntos> {
    return this.http.post<ResumenPuntos>(`${this.baseUrl}/clientes/${clienteId}/puntos/ajuste`, {
      puntos,
      motivo,
    });
  }

  /** Cliente de la tienda: sus propios puntos. */
  misPuntos(): Observable<ResumenPuntos> {
    return this.http.get<ResumenPuntos>(`${this.baseUrl}/cliente/puntos`);
  }
}
