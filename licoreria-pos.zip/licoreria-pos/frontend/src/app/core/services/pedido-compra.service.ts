import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PedidoCompra, PedidoCompraPayload } from '../models/pedido-compra.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class PedidoCompraService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/pedidos-compra`;

  listar(params?: { estado?: string; proveedor_id?: number }): Observable<PedidoCompra[]> {
    return this.http.get<PedidoCompra[]>(this.baseUrl, { params: params as any });
  }

  crear(payload: PedidoCompraPayload): Observable<PedidoCompra> {
    return this.http.post<PedidoCompra>(this.baseUrl, payload);
  }

  actualizar(id: number, payload: Partial<PedidoCompraPayload>): Observable<PedidoCompra> {
    return this.http.put<PedidoCompra>(`${this.baseUrl}/${id}`, payload);
  }

  recibir(id: number, actualizarCostos = true): Observable<PedidoCompra> {
    return this.http.post<PedidoCompra>(`${this.baseUrl}/${id}/recibir`, { actualizar_costos: actualizarCostos });
  }

  cancelar(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.baseUrl}/${id}`);
  }
}
