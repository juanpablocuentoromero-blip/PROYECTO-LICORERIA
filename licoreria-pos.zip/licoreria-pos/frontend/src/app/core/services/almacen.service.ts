import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Almacen, AlmacenPayload } from '../models/almacen.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AlmacenService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/almacenes`;

  listar(incluirInactivos = false): Observable<Almacen[]> {
    return this.http.get<Almacen[]>(this.baseUrl, {
      params: incluirInactivos ? { incluir_inactivos: '1' } : {},
    });
  }

  crear(payload: AlmacenPayload): Observable<Almacen> {
    return this.http.post<Almacen>(this.baseUrl, payload);
  }

  actualizar(id: number, payload: Partial<AlmacenPayload>): Observable<Almacen> {
    return this.http.put<Almacen>(`${this.baseUrl}/${id}`, payload);
  }

  eliminar(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.baseUrl}/${id}`);
  }
}
