import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Dashboard } from '../models/paso4.model';

@Injectable({ providedIn: 'root' })
export class DashboardService {
  private http = inject(HttpClient);

  obtener(diasTop: 1 | 7 | 30 = 1, fecha?: string): Observable<Dashboard> {
    const params: Record<string, string> = { dias_top: String(diasTop) };
    if (fecha) params['fecha'] = fecha;
    return this.http.get<Dashboard>(`${environment.apiUrl}/reportes/dashboard`, { params });
  }
}
