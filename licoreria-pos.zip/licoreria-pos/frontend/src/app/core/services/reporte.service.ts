import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { FiltrosCompras, ReporteCompras } from '../models/reportes.model';

export type TipoReporte =
  | 'rentabilidad' | 'ventas' | 'inventario' | 'movimientos' | 'clientes'
  | 'compras-excel' | 'cajas-excel';

export interface LibroVentas {
  desde: string;
  hasta: string;
  ventas: any[];
  total_general: number;
  /** 4.5: lo devuelto con notas de crédito en el período. */
  total_devuelto?: number;
  total_neto?: number;
  cantidad_ventas: number;
  resumen_por_metodo: Record<string, number>;
}

@Injectable({ providedIn: 'root' })
export class ReporteService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/reportes`;

  libroVentas(desde?: string, hasta?: string) {
    return this.http.get<LibroVentas>(`${this.baseUrl}/libro-ventas`, { params: { desde: desde ?? '', hasta: hasta ?? '' } });
  }

  /** Reporte de compras en pantalla (con filtros y agrupación). */
  compras(filtros: FiltrosCompras): Observable<ReporteCompras> {
    return this.http.get<ReporteCompras>(`${this.baseUrl}/compras`, { params: this.limpiar(filtros) });
  }

  /** Descarga un Excel de cualquier ruta de reportes (ej. 'compras-excel', 'cajas-excel'). */
  descargarExcel(ruta: string, filtros: object, nombre: string): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http.get(`${this.baseUrl}/${ruta}`, { params: this.limpiar(filtros), responseType: 'blob' }).subscribe({
        next: (blob) => {
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${nombre}-${new Date().toISOString().slice(0, 10)}.xlsx`;
          document.body.appendChild(a);
          a.click();
          a.remove();
          window.URL.revokeObjectURL(url);
          resolve();
        },
        error: (err) => reject(err),
      });
    });
  }

  /** Quita los filtros vacíos para no mandar "?estado=&proveedor_id=". */
  private limpiar(filtros: object): Record<string, string> {
    const out: Record<string, string> = {};
    for (const [k, v] of Object.entries(filtros)) {
      if (v !== undefined && v !== null && v !== '') out[k] = String(v);
    }
    return out;
  }

  descargar(tipo: TipoReporte, desde?: string, hasta?: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const params: Record<string, string> = {};
      if (desde) params['desde'] = desde;
      if (hasta) params['hasta'] = hasta;

      this.http.get(`${this.baseUrl}/${tipo}`, { params, responseType: 'blob' }).subscribe({
        next: (blob) => {
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `reporte-${tipo.replace('-excel', '')}-${new Date().toISOString().slice(0, 10)}.xlsx`;
          document.body.appendChild(a);
          a.click();
          a.remove();
          window.URL.revokeObjectURL(url);
          resolve();
        },
        error: (err) => reject(err),
      });
    });
  }
}
