import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Alerta, RespuestaAlertas } from '../models/paso4.model';

/** 4.2 — Estado de la campana de alertas (solo administrador). */
@Injectable({ providedIn: 'root' })
export class AlertaService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/alertas`;

  readonly alertas = signal<Alerta[]>([]);
  readonly noLeidas = signal(0);

  cargar(): void {
    this.http.get<RespuestaAlertas>(this.baseUrl).subscribe({
      next: (r) => { this.alertas.set(r.alertas); this.noLeidas.set(r.no_leidas); },
      error: () => { /* la campana es accesoria: si falla no molesta */ },
    });
  }

  revisar(): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(`${this.baseUrl}/revisar`, {}).pipe(tap(() => this.cargar()));
  }

  leer(id: number): void {
    this.http.post(`${this.baseUrl}/${id}/leer`, {}).subscribe(() => this.cargar());
  }

  leerTodas(): void {
    this.http.post(`${this.baseUrl}/leer-todas`, {}).subscribe(() => this.cargar());
  }

  limpiar(): void {
    this.alertas.set([]);
    this.noLeidas.set(0);
  }
}
