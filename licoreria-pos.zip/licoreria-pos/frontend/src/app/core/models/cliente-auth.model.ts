import { Cliente } from './cliente.model';

export interface RegistroClientePayload {
  nombre: string;
  email: string;
  password: string;
  password_confirmation: string;
  telefono?: string;
  direccion?: string;
  /** Casilla "soy mayor de 18 años": el servidor la exige. */
  mayor_edad: boolean;
}

export interface LoginClientePayload {
  email: string;
  password: string;
}

export interface ClienteAuthResponse {
  token: string;
  cliente: Cliente;
}
