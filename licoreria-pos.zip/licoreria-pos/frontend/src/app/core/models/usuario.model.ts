export interface Usuario {
  id: number;
  nombre: string;
  email: string;
  rol: 'administrador' | 'vendedor';
  activo: boolean;
  created_at?: string;
}

export interface UsuarioPayload {
  nombre: string;
  email: string;
  password?: string;
  rol: string;
  activo?: boolean;
}
