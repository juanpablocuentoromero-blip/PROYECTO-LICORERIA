export interface Almacen {
  id: number;
  nombre: string;
  direccion?: string;
  es_principal: boolean;
  activo: boolean;
  created_at?: string;
}

export interface AlmacenPayload {
  nombre: string;
  direccion?: string;
  activo?: boolean;
}
