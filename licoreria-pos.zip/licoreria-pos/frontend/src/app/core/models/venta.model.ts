export interface VentaRegistrada {
  id: number;
  /** Número fiscal (0026-000002) o el interno S/F-000012 si es nota de venta. */
  nro_documento: string;
  nro_factura: string | null;
  tipo_venta: 'factura' | 'sin_factura';
  fecha: string;
  hora: string;
  cliente: string;
  cliente_id: number | null;
  vendedor: string;
  vendedor_id: number | null;
  metodo_pago: string;
  total: number;
  cobrado: number;
  saldo: number;
  pagado: boolean;
  es_credito?: boolean;
  fecha_vencimiento?: string | null;
  anulada: boolean;
  motivo_anulacion: string | null;
  anulada_at: string | null;
  anulada_por: string | null;
  estado: string;
  /** 4.6: cómo se cobró (una fila por método). */
  pagos?: { metodo_pago: string; monto: number }[];
  /** 4.5: total ya devuelto con notas de crédito. */
  monto_devuelto?: number;
}

export interface DetalleVenta {
  id: number;
  codigo: string;
  descripcion: string;
  cantidad: number;
  precio_unitario: number;
  subtotal: number;
  /** 4.5: unidades de esta línea ya devueltas y su importe. */
  cantidad_devuelta?: number;
  monto_devuelto?: number;
}

export interface ResumenVentas {
  cantidad: number;
  total: number;
  cobrado: number;
  por_cobrar: number;
}

export interface RespuestaVentas {
  ventas: VentaRegistrada[];
  resumen: ResumenVentas;
  /** Presente cuando se pidió una página (2.2). El resumen es de TODO lo filtrado, no solo de la página. */
  paginacion?: import('./pagina.model').Paginacion;
}

export interface RespuestaDetalleVenta {
  venta: VentaRegistrada;
  detalles: DetalleVenta[];
  devoluciones?: import('./paso4.model').DevolucionResumen[];
}

export interface FiltroVentas {
  desde?: string;
  hasta?: string;
  cliente?: string;
  vendedor_id?: number | null;
  estado?: 'todas' | 'validas' | 'anuladas';
  tipo?: 'todas' | 'factura' | 'sin_factura';
  buscar?: string;
  page?: number;
  por_pagina?: number;
}
