export interface ItemCheckout {
  producto_id: number;
  cantidad: number;
  presentacion?: 'unidad' | 'paquete' | 'caja';
}

export interface CheckoutPayload {
  metodo_pago: 'efectivo' | 'qr';
  tipo_entrega: 'recojo' | 'delivery';
  zona_delivery_id?: number | null;
  direccion_entrega?: string;
  observaciones?: string;
  cupon?: string;
  /** Casilla "soy mayor de 18 años": el servidor la exige. */
  mayor_edad: boolean;
  items: ItemCheckout[];
}
