export interface Cliente {
  id: number;
  nombre: string;
  telefono?: string;
  email?: string;
  direccion?: string;
  nit_ci?: string | null;
  activo: boolean;
  /** Fiado (solo lo edita el administrador). */
  credito_habilitado?: boolean;
  limite_credito?: number | string | null;
}

export interface ClientePayload {
  nombre: string;
  telefono?: string;
  email?: string;
  direccion?: string;
  nit_ci?: string | null;
  activo?: boolean;
  credito_habilitado?: boolean;
  limite_credito?: number | null;
}
