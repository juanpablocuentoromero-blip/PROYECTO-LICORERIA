export interface Categoria {
  id: number;
  nombre: string;
  descripcion?: string;
  activo: boolean;
}

export interface Producto {
  id: number;
  categoria_id: number;
  categoria?: Categoria;
  codigo: string;
  codigo_barras?: string;
  unidades_por_paquete?: number | null;
  /** Unidades que trae una caja (p. ej. 12 cervezas). Null = no se vende por caja. */
  unidades_por_caja?: number | null;
  nombre: string;
  descripcion?: string;
  imagen?: string;
  precio_compra: number;
  precio_venta: number;
  /** Margen de ganancia (%) sobre el costo, para calcular el precio de venta solo. */
  margen_porcentaje?: number | string | null;
  stock: number;
  stock_minimo: number;
  fecha_vencimiento?: string;
  activo: boolean;
}

export interface ProductoPayload {
  categoria_id: number;
  codigo: string;
  codigo_barras?: string;
  unidades_por_paquete?: number | null;
  unidades_por_caja?: number | null;
  nombre: string;
  descripcion?: string;
  imagen?: string;
  precio_compra: number;
  precio_venta: number;
  margen_porcentaje?: number | null;
  stock?: number;
  stock_minimo?: number;
  /** Vencimiento del LOTE del stock inicial (el vencimiento es por lote, no por unidad). */
  fecha_vencimiento?: string;
  numero_lote?: string;
  activo?: boolean;
}
