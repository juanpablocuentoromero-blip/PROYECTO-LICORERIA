import { VentaRegistrada } from './venta.model';

export type MetodoPago = 'efectivo' | 'qr' | 'tarjeta' | 'credito' | 'mixto';

/** Producto tal como lo devuelve GET /ventas/buscar-producto. */
export interface ProductoPos {
  id: number;
  codigo: string;
  nombre: string;
  categoria: string | null;
  imagen?: string | null;
  precio_venta: number;
  /** Unidades vendibles ahora mismo en el almacén (en un combo, según sus componentes). */
  stock: number;
  es_combo: boolean;
  fecha_vencimiento: string | null;
  unidades_por_paquete?: number | null;
  unidades_por_caja?: number | null;
}

export interface RespuestaBuscarProducto {
  /** true = coincidió exactamente con un código de barras; false = búsqueda por nombre. */
  exacto: boolean;
  productos: ProductoPos[];
}

export interface ClientePos {
  id: number;
  nit_ci: string | null;
  nombre: string;
  /** Puntos de fidelización disponibles (6.4). */
  puntos_saldo?: number;
}

export interface RespuestaBuscarCliente {
  encontrado: boolean;
  cliente: ClientePos | null;
}

/** Datos con los que arranca la pantalla (GET /ventas/contexto). */
export interface ContextoVenta {
  almacen: { id: number; nombre: string };
  caja_abierta: boolean;
  caja_id: number | null;
  cliente_defecto: ClientePos;
}

export interface ItemVentaPayload {
  producto_id: number;
  cantidad: number;
  /** Descuento de la línea en Bs (no en porcentaje). */
  descuento: number;
}

export interface VentaPayload {
  nit_ci: string;
  razon_social: string;
  metodo_pago: MetodoPago;
  monto_recibido?: number | null;
  /** 4.6 Pagos mixtos: debe sumar el total de la venta. */
  pagos?: { metodo_pago: 'efectivo' | 'qr' | 'tarjeta'; monto: number }[];
  observaciones?: string;
  /** Código de cupón (5.4). */
  cupon?: string;
  /** Puntos de fidelización a canjear como descuento (6.4). */
  puntos_canje?: number;
  /** Plazo del fiado en días (solo metodo_pago = 'credito'). */
  dias_credito?: number;
  items: ItemVentaPayload[];
}

export interface DetalleVentaRegistrada {
  codigo: string | null;
  descripcion: string;
  cantidad: number;
  precio_unitario: number;
  descuento: number;
  descuento_promocion?: number;
  promocion?: string | null;
  subtotal: number;
}

export interface RespuestaRegistrarVenta {
  message: string;
  venta: VentaRegistrada & {
    subtotal: number;
    descuento: number;
    nit_ci: string | null;
    cupon_codigo?: string | null;
    puntos_canjeados?: number;
    descuento_puntos?: number;
    puntos_ganados?: number;
    /** Saldo del cliente después de esta venta. */
    puntos_saldo?: number;
    fecha_vencimiento?: string | null;
    detalles: DetalleVentaRegistrada[];
  };
  recibido: number | null;
  cambio: number;
}
