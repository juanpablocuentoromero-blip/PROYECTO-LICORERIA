import { Proveedor } from './proveedor.model';
import { Usuario } from './usuario.model';
import { Producto } from './producto.model';

export interface DetallePedidoCompra {
  id: number;
  producto_id: number;
  producto?: Producto;
  /** Unidades totales que entran al stock. */
  cantidad: number;
  /** Si se compró por paquete/caja: cuántos paquetes y cuántas unidades trae cada uno. */
  cantidad_paquetes?: number | null;
  unidades_por_paquete?: number | null;
  precio_paquete?: number | string | null;
  /** Costo por unidad (calculado solo cuando se compra por paquete). */
  precio_unitario: number;
  subtotal: number;
  numero_lote?: string | null;
  fecha_vencimiento?: string | null;
}

export interface PedidoCompra {
  id: number;
  proveedor_id: number;
  proveedor?: Proveedor;
  usuario_id: number;
  usuario?: Usuario;
  estado: 'pendiente' | 'recibido' | 'cancelado';
  subtotal: number;
  total: number;
  observaciones?: string;
  recibido_at?: string;
  detalles?: DetallePedidoCompra[];
  created_at?: string;
}

/** Línea que se manda a la API: por unidades (cantidad + precio_unitario) o por paquetes. */
export interface ItemCompra {
  producto_id: number;
  cantidad?: number;
  cantidad_paquetes?: number;
  unidades_por_paquete?: number;
  precio_unitario?: number;
  precio_paquete?: number;
  numero_lote?: string;
  fecha_vencimiento?: string;
}

export interface PedidoCompraPayload {
  proveedor_id: number;
  observaciones?: string;
  items: ItemCompra[];
}
