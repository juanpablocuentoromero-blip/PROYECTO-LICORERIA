/** Respuesta paginada de Laravel (->paginate()). Mismo formato en todas las listas. */
export interface Pagina<T> {
  data: T[];
  current_page: number;
  last_page: number;
  per_page: number;
  total: number;
}

/** Resumen de paginación que acompaña a /ventas (que además trae `resumen`). */
export interface Paginacion {
  current_page: number;
  last_page: number;
  per_page: number;
  total: number;
}
