/** 6.4 Fidelización — reglas del programa (GET /fidelizacion/config). */
export interface ConfigFidelizacion {
  activo: boolean;
  /** Bs pagados que dan 1 punto. */
  bs_por_punto: number;
  /** Bs de descuento que vale 1 punto al canjear. */
  valor_punto: number;
  /** Máximo de la venta que se puede pagar con puntos (%). */
  tope_canje_pct: number;
  min_puntos_canje: number;
}

export type TipoMovimientoPuntos =
  | 'acumulo'
  | 'canje'
  | 'reverso_acumulo'
  | 'reverso_canje'
  | 'reverso_devolucion'
  | 'ajuste';

export interface MovimientoPuntos {
  id: number;
  tipo: TipoMovimientoPuntos;
  /** Con signo: positivo suma, negativo resta. */
  puntos: number;
  saldo_despues: number;
  pedido_id: number | null;
  descripcion: string | null;
  fecha: string;
}

/** GET /clientes/{id}/puntos (staff) y GET /cliente/puntos (tienda). */
export interface ResumenPuntos {
  cliente_id: number;
  saldo: number;
  /** Bs que valen los puntos del saldo. */
  equivale_a: number;
  configuracion: ConfigFidelizacion;
  movimientos: MovimientoPuntos[];
  /** Solo en la consulta del personal. */
  participa?: boolean;
  maximo_canjeable?: number;
  descuento_maximo?: number;
}
