// Modelos de las funcionalidades del Paso 5 (delivery, fiado, promociones).

export interface ZonaDelivery {
  id: number;
  nombre: string;
  costo_envio: number | string;
  descripcion?: string | null;
  activo: boolean;
}

export interface Repartidor {
  id: number;
  nombre: string;
  telefono?: string | null;
  activo: boolean;
}

export type TipoPromocion = 'volumen' | 'horario' | 'cupon';
export type AlcancePromocion = 'todo' | 'categoria' | 'producto';

export interface Promocion {
  id: number;
  nombre: string;
  tipo: TipoPromocion;
  alcance: AlcancePromocion;
  categoria_id: number | null;
  producto_id: number | null;
  categoria?: { id: number; nombre: string } | null;
  producto?: { id: number; nombre: string } | null;
  tipo_descuento: 'porcentaje' | 'monto';
  valor: number | string;
  cantidad_minima: number | null;
  hora_inicio: string | null;
  hora_fin: string | null;
  dias_semana: string | null;
  codigo: string | null;
  usos_maximos: number | null;
  usos_actuales: number;
  fecha_inicio: string | null;
  fecha_fin: string | null;
  activo: boolean;
}

export interface PromocionPayload {
  nombre: string;
  tipo: TipoPromocion;
  alcance: AlcancePromocion;
  categoria_id?: number | null;
  producto_id?: number | null;
  tipo_descuento: 'porcentaje' | 'monto';
  valor: number;
  cantidad_minima?: number | null;
  hora_inicio?: string | null;
  hora_fin?: string | null;
  dias_semana?: string | null;
  codigo?: string | null;
  usos_maximos?: number | null;
  fecha_inicio?: string | null;
  fecha_fin?: string | null;
  activo: boolean;
}

export interface ItemPromo {
  producto_id: number;
  cantidad: number;
  descuento?: number;
}

export interface RespuestaCalculoPromo {
  lineas: { producto_id: number; descuento: number; etiqueta: string | null }[];
  total_descuento: number;
  cupon: { id: number; codigo: string; nombre: string; descuento: number } | null;
  cupon_error: string | null;
}

// ---- Cuentas por cobrar (fiado)

export interface DeudorResumen {
  cliente_id: number;
  nombre: string;
  nit_ci: string | null;
  telefono: string | null;
  limite_credito: number | null;
  cantidad_ventas: number;
  total_credito: number;
  deuda: number;
  vencido: number;
  primer_vencimiento: string | null;
}

export interface RespuestaDeudores {
  clientes: DeudorResumen[];
  resumen: { clientes_con_deuda: number; deuda_total: number; vencido_total: number };
}

export interface VentaCredito {
  id: number;
  nro_documento: string;
  fecha: string;
  total: number;
  abonado: number;
  saldo: number;
  fecha_vencimiento: string | null;
  dias_atraso: number;
  vencida: boolean;
}

export interface AbonoRegistrado {
  id: number;
  pedido_id: number;
  nro_documento: string | null;
  fecha: string;
  monto: number;
  metodo_pago: string;
  vendedor: string | null;
  observaciones: string | null;
  anulado: boolean;
  motivo_anulacion: string | null;
}

export interface EstadoCuentaCliente {
  cliente: {
    id: number;
    nombre: string;
    nit_ci: string | null;
    telefono: string | null;
    email: string | null;
    credito_habilitado: boolean;
    limite_credito: number | null;
  };
  deuda_total: number;
  vencido_total: number;
  disponible: number | null;
  ventas: VentaCredito[];
  abonos: AbonoRegistrado[];
}

export interface AbonoPayload {
  cliente_id: number;
  pedido_id?: number | null;
  monto: number;
  metodo_pago: 'efectivo' | 'qr' | 'tarjeta';
  observaciones?: string;
}
