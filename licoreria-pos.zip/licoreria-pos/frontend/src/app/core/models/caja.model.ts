import { Almacen } from './almacen.model';
import { Usuario } from './usuario.model';

export interface Caja {
  id: number;
  almacen_id: number;
  almacen?: Almacen;
  usuario_apertura_id: number;
  usuario_apertura?: Usuario;
  usuario_cierre_id?: number;
  usuario_cierre?: Usuario;
  monto_apertura: number;
  monto_ventas_efectivo?: number;
  monto_ingresos_caja_chica?: number;
  monto_egresos_caja_chica?: number;
  monto_cierre_esperado?: number;
  monto_cierre_real?: number;
  diferencia?: number;
  estado: 'abierta' | 'cerrada';
  observaciones?: string;
  abierta_at: string;
  cerrada_at?: string;
  cerrada_por_nombre?: string;
  monto_ventas_qr?: number;
  monto_ventas_tarjeta?: number;
  monto_ventas_total?: number;
  cantidad_ventas?: number;
  cantidad_anuladas?: number;
  monto_anulado?: number;
  observaciones_cierre?: string;
  detalle_vendedores?: DetalleVendedorCierre[];
}

export interface DetalleVendedorCierre {
  usuario_id: number | null;
  nombre: string;
  cantidad: number;
  efectivo: number;
  qr: number;
  tarjeta: number;
  total: number;
}

export interface TotalesCajaActual {
  ventas_efectivo: number;
  /** Abonos de fiado cobrados en efectivo en este turno. */
  abonos_efectivo?: number;
  ingresos_caja_chica: number;
  egresos_caja_chica: number;
  saldo_esperado_ahora: number;
}

// Lo que vendió el vendedor autenticado en lo que va del turno (sin el
// acumulado de todo el negocio, que sigue siendo solo para el administrador).
export interface MisVentasCajaActual {
  cantidad: number;
  efectivo: number;
  qr: number;
  tarjeta: number;
  total: number;
}

export interface CajaActualResponse {
  abierta: boolean;
  caja: Caja | null;
  totales?: TotalesCajaActual;
  mis_ventas?: MisVentasCajaActual;
}

export interface AbrirCajaPayload {
  almacen_id?: number;
  monto_apertura: number;
  observaciones?: string;
}

export interface CerrarCajaPayload {
  monto_cierre_real: number;
  observaciones?: string;
}
