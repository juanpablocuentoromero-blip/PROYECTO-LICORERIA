export type AgruparCompras = 'ninguno' | 'proveedor' | 'producto' | 'dia' | 'mes';

export interface FiltrosCompras {
  desde?: string;
  hasta?: string;
  proveedor_id?: number;
  producto_id?: number;
  estado?: 'pendiente' | 'recibido' | 'cancelado' | '';
  agrupar_por?: AgruparCompras;
}

export interface ReporteComprasItem {
  producto_id: number;
  producto: string;
  cantidad_paquetes: number | null;
  unidades_por_paquete: number | null;
  unidades: number;
  costo_unitario: number;
  subtotal: number;
  numero_lote: string | null;
  fecha_vencimiento: string | null;
}

export interface ReporteComprasPedido {
  id: number;
  fecha: string;
  proveedor_id: number;
  proveedor: string;
  estado: 'pendiente' | 'recibido' | 'cancelado';
  registrado_por?: string | null;
  unidades: number;
  total: number;
  items: ReporteComprasItem[];
}

export interface ReporteCompras {
  desde: string;
  hasta: string;
  agrupar_por: AgruparCompras;
  resumen: {
    pedidos: number;
    unidades: number;
    total: number;
    por_estado: Record<string, number>;
  };
  grupos: { clave: string; etiqueta: string; pedidos: number; unidades: number; total: number }[];
  pedidos: ReporteComprasPedido[];
}

export interface FiltrosCajaChica {
  desde?: string;
  hasta?: string;
  cuenta?: string;
  tipo?: 'ingreso' | 'egreso' | '';
  metodo_pago?: 'efectivo' | 'cheque' | '';
  usuario_id?: number;
}

export interface FilaAgrupadaCajaChica {
  etiqueta: string;
  cantidad: number;
  ingresos: number;
  egresos: number;
  saldo: number;
}

export interface ReporteCajaChica {
  desde: string;
  hasta: string;
  resumen: {
    cantidad: number;
    ingresos: number;
    egresos: number;
    saldo: number;
    ingresos_efectivo: number;
    egresos_efectivo: number;
    ingresos_cheque: number;
    egresos_cheque: number;
  };
  por_cuenta: FilaAgrupadaCajaChica[];
  por_dia: FilaAgrupadaCajaChica[];
  por_usuario: FilaAgrupadaCajaChica[];
  movimientos: {
    id: number;
    created_at: string;
    cuenta: string;
    tipo: 'ingreso' | 'egreso';
    metodo_pago: string;
    nro_documento?: string | null;
    concepto: string;
    monto: number | string;
    usuario?: { nombre: string };
    caja_id: number;
  }[];
}

export interface ReporteCajero {
  desde: string;
  hasta: string;
  usuario: { id: number; nombre: string } | null;
  resumen: {
    cantidad_ventas: number;
    efectivo: number;
    qr: number;
    tarjeta: number;
    total: number;
    ticket_promedio: number;
    ventas_credito: number;
    cantidad_anuladas: number;
    monto_anulado: number;
  };
  por_dia: { fecha: string; cantidad: number; efectivo: number; qr: number; tarjeta: number; total: number }[];
  turnos: {
    id: number;
    almacen?: string | null;
    estado: string;
    abierta_at: string;
    abierta_por?: string | null;
    cerrada_at?: string | null;
    cerrada_por?: string | null;
    monto_apertura: number;
    monto_cierre_real: number | null;
    monto_cierre_esperado?: number;
    diferencia?: number;
  }[];
  caja_chica: { movimientos: number; ingresos: number; egresos: number; saldo: number };
}
