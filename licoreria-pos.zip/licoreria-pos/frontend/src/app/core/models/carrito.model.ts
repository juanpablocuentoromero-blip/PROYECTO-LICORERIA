import { Producto } from './producto.model';
import { Presentacion } from '../utils/presentacion';

export interface ItemCarrito {
  producto: Producto;
  /** Cuántas presentaciones (unidades, paquetes o cajas) según `presentacion`. */
  cantidad: number;
  presentacion: Presentacion;
}
