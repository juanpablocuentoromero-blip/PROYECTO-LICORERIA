export interface LoteProducto {
  id: number;
  producto_id: number;
  producto?: { id: number; codigo: string; nombre: string };
  almacen?: { id: number; nombre: string };
  numero_lote?: string | null;
  fecha_vencimiento?: string | null;
  cantidad_inicial: number;
  cantidad_disponible: number;
  costo_unitario: number | string;
  dias_para_vencer: number | null;
  vencido: boolean;
}

export interface AjusteItemPayload {
  producto_id: number;
  stock_real: number;
  fecha_vencimiento?: string;
  numero_lote?: string;
}

export interface AjusteInventarioPayload {
  motivo: string;
  almacen_id?: number;
  items: AjusteItemPayload[];
}

export interface AjusteInventarioResultado {
  message: string;
  ajustes: {
    producto_id: number;
    nombre: string;
    stock_anterior: number;
    stock_nuevo: number;
    diferencia: number;
    valor_diferencia: number;
  }[];
  sin_cambios: number;
  valor_total_diferencia: number;
}
