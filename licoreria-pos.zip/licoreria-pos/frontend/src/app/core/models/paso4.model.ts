// ---------- 4.1 Dashboard ----------
export interface DashboardVentas {
  total: number;
  devoluciones: number;
  neto: number;
  cantidad: number;
  ticket_promedio: number;
  neto_ayer: number;
  variacion_vs_ayer: number | null;
}

export interface VentaPorHora { hora: number; total: number; cantidad: number; }
export interface VentaPorDia { fecha: string; total: number; cantidad: number; }
export interface TopProducto { producto_id: number; nombre: string; unidades: number; importe: number; }

export interface DashboardCaja {
  id: number;
  abierta_at: string;
  abierta_por: string | null;
  monto_apertura: number;
  ventas_total: number;
  ventas_efectivo: number;
  ventas_qr: number;
  ventas_tarjeta: number;
  saldo_esperado: number;
}

export interface Dashboard {
  fecha: string;
  ventas: DashboardVentas;
  ventas_por_hora: VentaPorHora[];
  ultimos_7_dias: VentaPorDia[];
  top_productos: { dias: number; items: TopProducto[] };
  caja: DashboardCaja | null;
  pedidos: {
    pendientes: number;
    en_curso: number;
    lista: { id: number; cliente: string | null; total: number; creado: string }[];
  };
  por_cobrar: { total: number; vencido: number };
  alertas: { activas: number; criticas: number };
}

// ---------- 4.2 Alertas ----------
export interface Alerta {
  id: number;
  tipo: 'stock_minimo' | 'vencimiento';
  producto_id: number;
  severidad: 'aviso' | 'critica';
  titulo: string;
  mensaje: string;
  leida: boolean;
  updated_at: string;
}

export interface RespuestaAlertas {
  alertas: Alerta[];
  no_leidas: number;
  total: number;
}

// ---------- 4.3 Reposición ----------
export interface SugerenciaReposicion {
  producto_id: number;
  codigo: string;
  nombre: string;
  categoria: string | null;
  stock: number;
  stock_minimo: number;
  en_camino: number;
  vendido_periodo: number;
  ventas_por_semana: number;
  dias_stock: number | null;
  cantidad_sugerida: number;
  unidades_por_paquete: number;
  precio_compra: number;
  costo_estimado: number;
  urgencia: 'urgente' | 'pronto' | 'normal';
  proveedor_id: number | null;
  proveedor: string | null;
}

export interface RespuestaReposicion {
  parametros: { dias_historial: number; dias_cobertura: number; dias_entrega: number };
  items: SugerenciaReposicion[];
  resumen: { productos: number; urgentes: number; costo_estimado: number };
  proveedores: { id: number; nombre: string }[];
}

// ---------- 4.4 Auditoría ----------
export interface RegistroAuditoria {
  id: number;
  usuario_id: number | null;
  usuario_nombre: string | null;
  accion: string;
  entidad: 'producto' | 'usuario' | 'inventario';
  entidad_id: number | null;
  descripcion: string;
  campo: string | null;
  valor_anterior: string | null;
  valor_nuevo: string | null;
  created_at: string;
}

export interface PaginaAuditoria {
  data: RegistroAuditoria[];
  current_page: number;
  last_page: number;
  total: number;
}

export interface CambioPrecio {
  id: number;
  usuario_nombre: string | null;
  accion: string;
  campo: string | null;
  valor_anterior: string | null;
  valor_nuevo: string | null;
  created_at: string;
}

export interface HistorialPrecios {
  producto: { id: number; nombre: string; precio_compra: number; precio_venta: number };
  cambios: CambioPrecio[];
}

// ---------- 4.5 Devoluciones ----------
export interface DevolucionResumen {
  id: number;
  nro_nota: string;
  fecha: string;
  total: number;
  metodo_reembolso: string | null;
  monto_reembolsado: number;
  aplicado_a_saldo: number;
  motivo: string;
  usuario: string | null;
}

export interface PayloadDevolucion {
  motivo: string;
  metodo_reembolso?: 'efectivo' | 'qr' | 'tarjeta' | null;
  items: { detalle_id: number; cantidad: number }[];
}

export interface RespuestaDevolucion {
  message: string;
  devolucion: DevolucionResumen & { venta_id: number; detalles: { producto: string; cantidad: number; monto: number }[] };
}
