import { Almacen } from './almacen.model';
import { Usuario } from './usuario.model';
import { Caja } from './caja.model';

export type CuentaCajaChica = 'Servicios' | 'Limpieza' | 'Transporte' | 'Mantenimiento' | 'Otros';

export const CUENTAS_CAJA_CHICA: CuentaCajaChica[] = [
  'Servicios', 'Limpieza', 'Transporte', 'Mantenimiento', 'Otros',
];

export interface MovimientoCajaChica {
  id: number;
  caja_id: number;
  caja?: Caja;
  almacen_id: number;
  almacen?: Almacen;
  usuario_id: number;
  usuario?: Usuario;
  cuenta: string;
  tipo: 'ingreso' | 'egreso';
  metodo_pago: 'efectivo' | 'cheque';
  nro_documento?: string;
  concepto: string;
  monto: number;
  created_at?: string;
}

export interface MovimientoCajaChicaPayload {
  almacen_id?: number;
  cuenta: string;
  tipo: 'ingreso' | 'egreso';
  metodo_pago: 'efectivo' | 'cheque';
  nro_documento?: string;
  concepto: string;
  monto: number;
}

export interface ResumenCajaChica {
  caja_abierta: boolean;
  caja_id?: number;
  ingresos: number;
  egresos: number;
  saldo: number;
}
