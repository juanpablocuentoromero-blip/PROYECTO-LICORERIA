import { Cliente } from './cliente.model';
import { Usuario } from './usuario.model';
import { Producto } from './producto.model';
import { Repartidor, ZonaDelivery } from './paso5.model';

export interface DetallePedido {
  id: number;
  producto_id: number;
  producto?: Producto;
  /** Siempre en UNIDADES. */
  cantidad: number;
  presentacion?: 'unidad' | 'paquete' | 'caja';
  /** Cuántas presentaciones se pidieron (p. ej. 2 cajas). */
  cantidad_presentacion?: number | null;
  precio_unitario: number;
  descuento?: number | string;
  promocion_aplicada?: string | null;
  subtotal: number;
}

export interface Pedido {
  id: number;
  cliente_id: number;
  cliente?: Cliente;
  usuario_id: number;
  usuario?: Usuario;
  origen?: 'mostrador' | 'online';
  estado: 'pendiente' | 'confirmado' | 'en_camino' | 'entregado' | 'cancelado';
  direccion_entrega?: string;
  telefono_contacto?: string | null;
  metodo_pago: string;
  pagado?: boolean;
  pagado_at?: string;
  referencia_pago?: string;
  subtotal: number;
  descuento?: number | string;
  cupon_codigo?: string | null;
  total: number;
  observaciones?: string;
  detalles?: DetallePedido[];
  tipo_entrega?: 'recojo' | 'delivery';
  zona_delivery_id?: number | null;
  zona_delivery?: ZonaDelivery | null;
  costo_envio?: number | string;
  repartidor_id?: number | null;
  repartidor?: Repartidor | null;
  en_camino_at?: string | null;
  saldo_pendiente?: number | string;
  fecha_vencimiento_credito?: string | null;
  /** Mensaje del servidor al editar productos (p. ej. un cupón que dejó de aplicar). */
  aviso?: string | null;
  created_at?: string;
}

export interface ItemCarrito {
  producto_id: number;
  cantidad: number;
  presentacion?: 'unidad' | 'paquete' | 'caja';
}

export interface PedidoPayload {
  cliente_id: number;
  usuario_id: number;
  metodo_pago: string;
  /** Solo con método «credito» (fiado): días para pagar. */
  dias_credito?: number;
  direccion_entrega?: string;
  /** Obligatorio: si el cliente ya tiene uno, el formulario lo trae precargado. */
  telefono: string;
  observaciones?: string;
  items: ItemCarrito[];
}
