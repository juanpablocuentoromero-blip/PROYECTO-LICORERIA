import { Producto } from './producto.model';
import { Usuario } from './usuario.model';
import { Almacen } from './almacen.model';

export interface MovimientoInventario {
  id: number;
  producto_id: number;
  producto?: Producto;
  almacen_id?: number;
  almacen?: Almacen;
  usuario_id: number;
  usuario?: Usuario;
  tipo: 'entrada' | 'salida' | 'ajuste';
  cantidad: number;
  stock_resultante: number;
  motivo?: string;
  es_ajuste?: boolean;
  created_at?: string;
}

export interface MovimientoPayload {
  producto_id: number;
  almacen_id?: number;
  usuario_id: number;
  tipo: string;
  cantidad: number;
  motivo?: string;
  /** Solo para entradas: registra el lote con su vencimiento. */
  fecha_vencimiento?: string;
  numero_lote?: string;
}
