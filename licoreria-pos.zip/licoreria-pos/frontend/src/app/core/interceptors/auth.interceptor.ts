import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { ClienteAuthService } from '../services/cliente-auth.service';

// Rutas que nunca deben llevar Authorization (login/registro: todavía no
// hay token que mandar).
const RUTAS_SIN_TOKEN = ['/auth/login', '/cliente/login', '/cliente/registro'];

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const clienteAuth = inject(ClienteAuthService);
  const router = inject(Router);

  if (RUTAS_SIN_TOKEN.some((ruta) => req.url.includes(ruta))) {
    return next(req);
  }

  // Las rutas bajo /cliente/* son del cliente (tienda pública); todo lo
  // demás es del staff (panel administrativo). Cada una usa su propio
  // token porque son dos sistemas de sesión independientes.
  const esRutaCliente = req.url.includes('/cliente/');
  const token = esRutaCliente ? clienteAuth.getToken() : auth.getToken();

  const peticion = token
    ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } })
    : req;

  return next(peticion).pipe(
    catchError((err: HttpErrorResponse) => {
      // Si la API dice 401, el token guardado ya no sirve. Antes esto se
      // quedaba mudo y el usuario veía "No autenticado." pegado en la
      // pantalla sin entender por qué. Ahora limpiamos la sesión y lo
      // mandamos a iniciar sesión otra vez.
      if (err.status === 401 && !esRutaCliente && auth.getToken()) {
        const volverA = router.url && !router.url.startsWith('/login') ? router.url : '/catalogo';
        auth.limpiarSesion();
        router.navigate(['/login'], { queryParams: { expirada: 1, returnUrl: volverA } });
      }

      // Lo mismo para el cliente de la tienda: los tokens ahora vencen
      // (30 días) o se cierran al cambiar la contraseña en otro dispositivo.
      // Sin esto el cliente vería la sesión "abierta" pero cada petición
      // fallaría con 401.
      if (err.status === 401 && esRutaCliente && clienteAuth.getToken()) {
        const volverA = router.url && !router.url.startsWith('/acceso') ? router.url : '/catalogo';
        clienteAuth.limpiarSesion();
        router.navigate(['/acceso'], { queryParams: { returnUrl: volverA } });
      }

      return throwError(() => err);
    }),
  );
};
