import { Component, ElementRef, HostListener, effect, inject, signal } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive, Router } from '@angular/router';
import { AuthService } from './core/services/auth.service';
import { ClienteAuthService } from './core/services/cliente-auth.service';
import { ConfirmDialogComponent } from './shared/confirm-dialog/confirm-dialog.component';
import { PedidoNotificacionesService } from './core/services/pedido-notificaciones.service';
import { AvisoEdadComponent } from './shared/aviso-edad/aviso-edad.component';
import { EdadService } from './shared/aviso-edad/edad.service';
import { AlertaService } from './core/services/alerta.service';
import { AlertasCampanaComponent } from './shared/alertas-campana/alertas-campana.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, ConfirmDialogComponent, AvisoEdadComponent, AlertasCampanaComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  auth = inject(AuthService);
  clienteAuth = inject(ClienteAuthService);
  pedidoNotis = inject(PedidoNotificacionesService);
  edad = inject(EdadService);
  private alertas = inject(AlertaService);
  private temporizadorAlertas?: ReturnType<typeof setInterval>;
  private router = inject(Router);
  private el = inject(ElementRef<HTMLElement>);

  constructor() {
    // Prende/apaga el sondeo de pedidos nuevos según haya o no personal con
    // sesión iniciada. usuarioActual() es una signal (a diferencia de
    // estaAutenticado(), que es un método plano), así que este effect
    // reacciona solo a login/logout reales.
    effect(() => {
      if (this.auth.usuarioActual()) {
        this.pedidoNotis.iniciar();
      } else {
        this.pedidoNotis.detener();
      }
    });

    // 4.2: la campana de alertas la ven administrador y vendedor; se refresca cada 5 min.
    effect(() => {
      const esPersonal = !!this.auth.usuarioActual();
      if (this.temporizadorAlertas) {
        clearInterval(this.temporizadorAlertas);
        this.temporizadorAlertas = undefined;
      }
      if (esPersonal) {
        this.alertas.cargar();
        this.temporizadorAlertas = setInterval(() => this.alertas.cargar(), 5 * 60 * 1000);
      } else {
        this.alertas.limpiar();
      }
    });
  }

  // Efecto parallax del logo: el mouse mueve el logo unos pocos píxeles en
  // sentido contrario al cursor, dando sensación de profundidad. Se expone
  // como variables CSS (--parallax-x / --parallax-y) que .brand-logo lee
  // en app.css, así que aplica a las tres cabeceras (visitante, cliente y
  // sidebar de staff) sin repetir lógica.
  @HostListener('window:mousemove', ['$event'])
  onMouseMoveParallax(evento: MouseEvent): void {
    const anchoMitad = window.innerWidth / 2;
    const altoMitad = window.innerHeight / 2;
    const x = (evento.clientX - anchoMitad) / anchoMitad; // -1 a 1
    const y = (evento.clientY - altoMitad) / altoMitad;   // -1 a 1
    const host = this.el.nativeElement;
    host.style.setProperty('--parallax-x', x.toFixed(3));
    host.style.setProperty('--parallax-y', y.toFixed(3));
  }

  @HostListener('window:deviceorientation', ['$event'])
  onTiltParallax(evento: DeviceOrientationEvent): void {
    // Respaldo para celulares sin mouse: usa la inclinación del teléfono.
    if (evento.gamma == null || evento.beta == null) return;
    const x = Math.max(-1, Math.min(1, evento.gamma / 30));
    const y = Math.max(-1, Math.min(1, (evento.beta - 45) / 30));
    const host = this.el.nativeElement;
    host.style.setProperty('--parallax-x', x.toFixed(3));
    host.style.setProperty('--parallax-y', y.toFixed(3));
  }

  // Menú hamburguesa del staff en pantallas angostas (celular/tablet).
  menuAbierto = signal(false);
  toggleMenu(): void { this.menuAbierto.set(!this.menuAbierto()); }
  cerrarMenu(): void { this.menuAbierto.set(false); }

  get esAdmin(): boolean {
    return this.auth.usuarioActual()?.rol === 'administrador';
  }

  cerrarSesion(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }

  cerrarSesionCliente(): void {
    this.clienteAuth.logout();
    this.router.navigate(['/catalogo']);
  }

  // ---------- Aviso de pedidos nuevos (tarjetitas flotantes) ----------
  irAPedido(id: number): void {
    this.pedidoNotis.descartarAviso(id);
    this.pedidoNotis.marcarVistos();
    this.router.navigate(['/pedidos']);
  }

  formatoBs(monto: number): string {
    return (monto ?? 0).toLocaleString('es-BO', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
}
