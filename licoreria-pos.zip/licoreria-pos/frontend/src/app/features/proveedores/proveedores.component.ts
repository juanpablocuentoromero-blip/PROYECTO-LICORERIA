import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProveedorService } from '../../core/services/proveedor.service';
import { Proveedor } from '../../core/models/proveedor.model';
import { BASE_THEME } from '../../shared/theme/theme';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';

@Component({
  selector: 'app-proveedores',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Compras &middot; Proveedores</div>
          <h1>Proveedores</h1>
          <p class="subtitle">Quiénes te abastecen, para poder armarles pedidos de compra.</p>
        </div>
      </header>

      <section class="composer" [class.open]="formAbierto()">
        <button class="composer-toggle" (click)="toggleForm()">
          <span class="plus" [class.rotated]="formAbierto()">+</span>
          {{ editandoId() ? 'Editando proveedor' : (formAbierto() ? 'Cerrar' : 'Nuevo proveedor') }}
        </button>

        @if (formAbierto()) {
          <form class="composer-form" (ngSubmit)="guardar()">
            <div class="form-grid">
              <div class="field">
                <label>Nombre / Razón social</label>
                <input type="text" [(ngModel)]="nombre" name="nombre" required autocomplete="off" />
              </div>
              <div class="field">
                <label>Persona de contacto <span>(opcional)</span></label>
                <input type="text" [(ngModel)]="contacto" name="contacto" />
              </div>
              <div class="field">
                <label>Teléfono <span>(opcional)</span></label>
                <input type="text" [(ngModel)]="telefono" name="telefono" />
              </div>
              <div class="field">
                <label>Email <span>(opcional)</span></label>
                <input type="email" [(ngModel)]="email" name="email" />
              </div>
              <div class="field">
                <label>Dirección <span>(opcional)</span></label>
                <input type="text" [(ngModel)]="direccion" name="direccion" />
              </div>
            </div>

            <div class="field-row" style="margin-top:14px">
              <button type="submit" class="btn-primary" [disabled]="guardando() || !nombre.trim()">
                {{ guardando() ? 'Guardando…' : (editandoId() ? 'Guardar cambios' : 'Crear proveedor') }}
              </button>
              @if (editandoId()) {
                <button type="button" class="btn-secondary" (click)="cancelarEdicion()">Cancelar edición</button>
              }
              @if (error()) { <span class="form-error">{{ error() }}</span> }
            </div>
          </form>
        }
      </section>

      @if (cargando()) {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando proveedores…</p></div>
      } @else if (proveedores().length === 0) {
        <div class="estado-vacio">
          <p>Todavía no hay proveedores registrados.</p>
          <span>Crea el primero para poder armarle un pedido de compra.</span>
        </div>
      } @else {
        <table>
          <thead><tr><th>Nombre</th><th>Contacto</th><th>Teléfono</th><th>Email</th><th>Estado</th><th></th></tr></thead>
          <tbody>
            @for (p of proveedores(); track p.id) {
              <tr>
                <td data-label="Nombre">{{ p.nombre }}</td>
                <td data-label="Contacto">{{ p.contacto || '—' }}</td>
                <td data-label="Teléfono">{{ p.telefono || '—' }}</td>
                <td data-label="Email">{{ p.email || '—' }}</td>
                <td data-label="Estado">
                  <span class="badge" [class.badge-off]="!p.activo">{{ p.activo ? 'Activo' : 'Inactivo' }}</span>
                </td>
                <td data-label="Acciones">
                  <button class="link-action" (click)="editar(p)">Editar</button>
                  <button class="link-danger" (click)="eliminar(p)">Eliminar</button>
                </td>
              </tr>
            }
          </tbody>
        </table>
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .composer { background: var(--verde-botella); border: 1px solid #2c4536; border-radius: 14px; padding: 16px 20px; margin-bottom: 28px; }
    .composer-toggle { background: none; border: none; color: var(--cobre-claro); font-size: 15px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 10px; padding: 4px 0; }
    .plus { display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; border-radius: 50%; border: 1.5px solid var(--cobre-claro); font-size: 16px; line-height: 1; transition: transform 0.25s ease; }
    .plus.rotated { transform: rotate(45deg); }
    .composer-form { margin-top: 18px; }
  `],
})
export class ProveedoresComponent implements OnInit {
  private proveedorService = inject(ProveedorService);
  private confirmDialog = inject(ConfirmDialogService);

  proveedores = signal<Proveedor[]>([]);
  cargando = signal(true);
  guardando = signal(false);
  formAbierto = signal(false);
  error = signal('');
  editandoId = signal<number | null>(null);

  nombre = '';
  contacto = '';
  telefono = '';
  email = '';
  direccion = '';

  ngOnInit(): void {
    this.cargar();
  }

  cargar(): void {
    this.cargando.set(true);
    this.proveedorService.listar().subscribe({
      next: (data) => { this.proveedores.set(data); this.cargando.set(false); },
      error: () => { this.error.set('No se pudo conectar con el servidor.'); this.cargando.set(false); },
    });
  }

  toggleForm(): void {
    if (this.formAbierto() && this.editandoId()) {
      this.cancelarEdicion();
      return;
    }
    this.formAbierto.set(!this.formAbierto());
    this.error.set('');
  }

  private limpiarForm(): void {
    this.nombre = '';
    this.contacto = '';
    this.telefono = '';
    this.email = '';
    this.direccion = '';
  }

  editar(p: Proveedor): void {
    this.editandoId.set(p.id);
    this.nombre = p.nombre;
    this.contacto = p.contacto ?? '';
    this.telefono = p.telefono ?? '';
    this.email = p.email ?? '';
    this.direccion = p.direccion ?? '';
    this.formAbierto.set(true);
    this.error.set('');
  }

  cancelarEdicion(): void {
    this.editandoId.set(null);
    this.limpiarForm();
    this.formAbierto.set(false);
    this.error.set('');
  }

  guardar(): void {
    if (!this.nombre.trim()) return;
    this.guardando.set(true);
    this.error.set('');

    const payload = {
      nombre: this.nombre.trim(),
      contacto: this.contacto.trim() || undefined,
      telefono: this.telefono.trim() || undefined,
      email: this.email.trim() || undefined,
      direccion: this.direccion.trim() || undefined,
    };

    const id = this.editandoId();
    const peticion = id ? this.proveedorService.actualizar(id, payload) : this.proveedorService.crear(payload);

    peticion.subscribe({
      next: (resultado) => {
        if (id) {
          this.proveedores.set(this.proveedores().map((p) => (p.id === id ? resultado : p)));
        } else {
          this.proveedores.set([resultado, ...this.proveedores()]);
        }
        this.limpiarForm();
        this.editandoId.set(null);
        this.guardando.set(false);
        this.formAbierto.set(false);
      },
      error: () => {
        this.error.set('No se pudo guardar. Revisa los datos e intenta de nuevo.');
        this.guardando.set(false);
      },
    });
  }

  async eliminar(p: Proveedor): Promise<void> {
    const ok = await this.confirmDialog.confirm({
      titulo: 'Eliminar proveedor',
      mensaje: `¿Estás seguro de que quieres eliminar al proveedor "${p.nombre}"?`,
      textoConfirmar: 'Sí, eliminar',
      peligroso: true,
    });
    if (!ok) return;

    this.proveedorService.eliminar(p.id).subscribe({
      next: () => this.proveedores.set(this.proveedores().filter((x) => x.id !== p.id)),
      error: (err) => this.error.set(err?.error?.message || 'No se pudo eliminar el proveedor.'),
    });
  }
}
