import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import { CuentasPorCobrarService } from '../../core/services/cuentas-por-cobrar.service';
import { DeudorResumen, EstadoCuentaCliente, RespuestaDeudores } from '../../core/models/paso5.model';
import { BASE_THEME } from '../../shared/theme/theme';

/**
 * Cuentas por cobrar / fiado (5.3).
 * Lista de clientes con deuda → detalle con ventas pendientes, formulario de
 * abono y estado de cuenta. El abono entra al arqueo de la caja abierta.
 */
@Component({
  selector: 'app-cuentas-por-cobrar',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Ventas &middot; Crédito</div>
          <h1>Cuentas por cobrar</h1>
          <p class="subtitle">Ventas a crédito (fiado), abonos y saldo pendiente por cliente.</p>
        </div>
        <div class="acciones-cabecera">
          <input class="buscador" type="text" placeholder="Buscar cliente o NIT/CI…" [(ngModel)]="buscar" (ngModelChange)="cargar()" />
          @if (esAdmin) {
            <button class="btn-secondary" [disabled]="exportando()" (click)="exportar()">
              {{ exportando() ? 'Generando…' : '⬇ Excel' }}
            </button>
          }
        </div>
      </header>

      @if (error()) { <p class="form-error">{{ error() }}</p> }
      @if (mensajeOk()) { <p class="form-ok">{{ mensajeOk() }}</p> }

      @if (data(); as d) {
        <section class="resumen-tarjetas">
          <div class="tarjeta"><span>Clientes con deuda</span><strong>{{ d.resumen.clientes_con_deuda }}</strong></div>
          <div class="tarjeta"><span>Total por cobrar</span><strong>Bs {{ d.resumen.deuda_total | number: '1.2-2' }}</strong></div>
          <div class="tarjeta" [class.alerta]="d.resumen.vencido_total > 0">
            <span>De lo cual vencido</span><strong>Bs {{ d.resumen.vencido_total | number: '1.2-2' }}</strong>
          </div>
        </section>

        <label class="solo-vencidas">
          <input type="checkbox" [(ngModel)]="soloVencidas" (ngModelChange)="cargar()" /> Solo con deuda vencida
        </label>

        @if (d.clientes.length === 0) {
          <div class="estado-vacio"><p>No hay deudas pendientes.</p><span>Para fiar: 1) en Clientes activa «Crédito» al cliente (con NIT/CI y límite); 2) vende con método «Crédito» en Venta o en Pedidos. La deuda aparece aquí y se cobra con abonos (la caja debe estar abierta).</span></div>
        } @else {
          <table>
            <thead><tr><th>Cliente</th><th>NIT/CI</th><th>Ventas</th><th>Deuda</th><th>Vencido</th><th>Vence</th><th></th></tr></thead>
            <tbody>
              @for (c of d.clientes; track c.cliente_id) {
                <tr [class.fila-activa]="esSeleccionado(c.cliente_id)">
                  <td data-label="Cliente">{{ c.nombre }}@if (c.telefono) { <small class="sub">{{ c.telefono }}</small> }</td>
                  <td data-label="NIT/CI">{{ c.nit_ci || '—' }}</td>
                  <td data-label="Ventas">{{ c.cantidad_ventas }}</td>
                  <td data-label="Deuda"><strong>Bs {{ c.deuda | number: '1.2-2' }}</strong></td>
                  <td data-label="Vencido">
                    @if (c.vencido > 0) { <span class="badge badge-danger">Bs {{ c.vencido | number: '1.2-2' }}</span> } @else { — }
                  </td>
                  <td data-label="Vence">{{ c.primer_vencimiento || '—' }}</td>
                  <td><button class="link-action" (click)="abrir(c)">Ver / cobrar</button></td>
                </tr>
              }
            </tbody>
          </table>
        }
      } @else {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando…</p></div>
      }

      @if (seleccionado(); as e) {
        <div class="modal-fondo" (click)="cerrar()">
          <div class="modal-panel" (click)="$event.stopPropagation()">
            <div class="modal-cabecera">
              <div>
                <h3>{{ e.cliente.nombre }}</h3>
                <p class="subtitle">
                  NIT/CI {{ e.cliente.nit_ci || '—' }}
                  @if (e.cliente.limite_credito !== null) { · Límite Bs {{ e.cliente.limite_credito | number: '1.2-2' }} · Disponible Bs {{ e.disponible | number: '1.2-2' }} }
                </p>
              </div>
              <button class="btn-secondary" (click)="cerrar()">Cerrar</button>
            </div>

            <div class="deuda-total">
              Deuda: <strong>Bs {{ e.deuda_total | number: '1.2-2' }}</strong>
              @if (e.vencido_total > 0) { <span class="badge badge-danger">Vencido Bs {{ e.vencido_total | number: '1.2-2' }}</span> }
            </div>

            <h4>Ventas pendientes</h4>
            @if (e.ventas.length === 0) {
              <p class="subtitle">Sin deudas pendientes.</p>
            } @else {
              <table class="tabla-detalle">
                <thead><tr><th>Documento</th><th>Fecha</th><th>Vence</th><th>Total</th><th>Abonado</th><th>Saldo</th></tr></thead>
                <tbody>
                  @for (v of e.ventas; track v.id) {
                    <tr [class.vencida]="v.vencida">
                      <td>{{ v.nro_documento }}</td>
                      <td>{{ v.fecha }}</td>
                      <td>{{ v.fecha_vencimiento || '—' }}@if (v.vencida) { <small> ({{ v.dias_atraso }} d)</small> }</td>
                      <td>{{ v.total | number: '1.2-2' }}</td>
                      <td>{{ v.abonado | number: '1.2-2' }}</td>
                      <td><strong>{{ v.saldo | number: '1.2-2' }}</strong></td>
                    </tr>
                  }
                </tbody>
              </table>

              <form class="form-abono" (ngSubmit)="abonar()">
                <h4>Registrar abono</h4>
                <div class="fila-abono">
                  <label>Aplicar a
                    <select [(ngModel)]="abono.pedido_id" name="pedido_id">
                      <option [ngValue]="null">Las más antiguas primero</option>
                      @for (v of e.ventas; track v.id) { <option [ngValue]="v.id">{{ v.nro_documento }} (saldo {{ v.saldo | number: '1.2-2' }})</option> }
                    </select>
                  </label>
                  <label>Monto (Bs)
                    <input type="number" min="0.01" step="0.01" [(ngModel)]="abono.monto" name="monto" required />
                  </label>
                  <label>Forma de pago
                    <select [(ngModel)]="abono.metodo_pago" name="metodo_pago">
                      <option value="efectivo">Efectivo</option>
                      <option value="qr">QR</option>
                      <option value="tarjeta">Tarjeta</option>
                    </select>
                  </label>
                </div>
                <label class="obs">Observaciones <span>(opcional)</span>
                  <input type="text" maxlength="255" [(ngModel)]="abono.observaciones" name="observaciones" />
                </label>
                <div class="acciones-abono">
                  <button type="button" class="btn-secondary" (click)="abono.monto = e.deuda_total">Pagar todo</button>
                  <button type="submit" class="btn-primary" [disabled]="guardando() || !abono.monto || abono.monto <= 0">
                    {{ guardando() ? 'Registrando…' : 'Registrar abono' }}
                  </button>
                </div>
                @if (errorModal()) { <p class="form-error">{{ errorModal() }}</p> }
              </form>
            }

            <h4>Abonos registrados</h4>
            @if (e.abonos.length === 0) {
              <p class="subtitle">Todavía no hay abonos.</p>
            } @else {
              <table class="tabla-detalle">
                <thead><tr><th>Fecha</th><th>Doc.</th><th>Pago</th><th>Atendió</th><th>Monto</th><th></th></tr></thead>
                <tbody>
                  @for (a of e.abonos; track a.id) {
                    <tr [class.anulado]="a.anulado">
                      <td>{{ a.fecha }}</td>
                      <td>{{ a.nro_documento }}</td>
                      <td>{{ a.metodo_pago }}</td>
                      <td>{{ a.vendedor || '—' }}</td>
                      <td>{{ a.monto | number: '1.2-2' }}@if (a.anulado) { <small> (anulado)</small> }</td>
                      <td>
                        @if (esAdmin && !a.anulado) {
                          <button class="link-danger" (click)="pedirAnulacion(a.id)">Anular</button>
                        }
                      </td>
                    </tr>
                    @if (anulandoId() === a.id) {
                      <tr>
                        <td colspan="6">
                          <div class="fila-anular">
                            <input type="text" maxlength="255" placeholder="Motivo de la anulación" [(ngModel)]="motivoAnulacion" name="motivo{{ a.id }}" />
                            <button class="link-danger" [disabled]="!motivoAnulacion.trim()" (click)="confirmarAnulacion(a.id)">Confirmar anulación</button>
                            <button class="link-action" (click)="anulandoId.set(null)">Cancelar</button>
                          </div>
                        </td>
                      </tr>
                    }
                  }
                </tbody>
              </table>
            }

            <div class="pie-modal">
              <button class="btn-secondary" [disabled]="descargando()" (click)="descargarEstado(e)">
                {{ descargando() ? 'Generando…' : '🧾 Estado de cuenta (PDF)' }}
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .acciones-cabecera { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .buscador { background: var(--papel); color: var(--tinta); border: 1px solid var(--papel-borde); border-radius: 8px; padding: 9px 12px; font-size: 14px; min-width: 220px; }
    .resumen-tarjetas { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; }
    .tarjeta { background: var(--superficie); border: var(--superficie-borde); border-radius: 12px; padding: 14px 16px; display: flex; flex-direction: column; gap: 4px; color: var(--papel); }
    .tarjeta span { font-size: 12px; opacity: 0.8; }
    .tarjeta strong { font-size: 22px; }
    .tarjeta.alerta strong { color: #ff9d9d; }
    .solo-vencidas { color: var(--papel); font-size: 13px; display: flex; gap: 8px; align-items: center; cursor: pointer; }
    .sub { display: block; font-size: 11px; opacity: 0.75; }
    .fila-activa { outline: 1px solid var(--cobre); }
    .modal-fondo { position: fixed; inset: 0; background: rgba(1, 0, 26, 0.75); display: flex; align-items: flex-start; justify-content: center; z-index: 50; padding: 24px 16px; overflow-y: auto; }
    .modal-panel { background: var(--papel); color: var(--tinta); border-radius: 14px; padding: 22px; max-width: 760px; width: 100%; }
    .modal-cabecera { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; }
    .modal-panel h3 { margin: 0 0 4px; }
    .modal-panel h4 { margin: 18px 0 6px; font-size: 14px; }
    .modal-panel .subtitle { color: #4b5470; margin: 0; }
    .deuda-total { font-size: 18px; margin-top: 10px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .tabla-detalle { width: 100%; border-collapse: collapse; }
    .tabla-detalle th, .tabla-detalle td { padding: 7px 6px; font-size: 13px; text-align: left; border-bottom: 1px dashed var(--papel-borde); color: var(--tinta); }
    .tabla-detalle th { color: #4b5470; font-weight: 600; }
    .tabla-detalle tr.vencida td { color: #a12626; }
    .tabla-detalle tr.anulado td { text-decoration: line-through; opacity: 0.6; }
    .form-abono { background: #fff; border: 1px solid var(--papel-borde); border-radius: 10px; padding: 12px 14px; margin-top: 12px; }
    .form-abono h4 { margin-top: 0; }
    .fila-abono { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 10px; }
    .form-abono label { display: flex; flex-direction: column; gap: 4px; font-size: 12px; font-weight: 600; }
    .form-abono input, .form-abono select { border: 1px solid var(--papel-borde); border-radius: 8px; padding: 8px 10px; font-size: 14px; background: #fff; color: var(--tinta); }
    .obs { margin-top: 10px; }
    .acciones-abono { display: flex; gap: 10px; justify-content: flex-end; margin-top: 12px; }
    .fila-anular { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .fila-anular input { flex: 1; min-width: 180px; border: 1px solid var(--papel-borde); border-radius: 8px; padding: 6px 8px; }
    .pie-modal { margin-top: 18px; display: flex; justify-content: flex-end; }
  `],
})
export class CuentasPorCobrarComponent implements OnInit {
  private service = inject(CuentasPorCobrarService);
  private auth = inject(AuthService);

  data = signal<RespuestaDeudores | null>(null);
  seleccionado = signal<EstadoCuentaCliente | null>(null);
  error = signal('');
  errorModal = signal('');
  mensajeOk = signal('');
  guardando = signal(false);
  exportando = signal(false);
  descargando = signal(false);
  anulandoId = signal<number | null>(null);

  buscar = '';
  soloVencidas = false;
  motivoAnulacion = '';
  abono: { pedido_id: number | null; monto: number | null; metodo_pago: 'efectivo' | 'qr' | 'tarjeta'; observaciones: string } = {
    pedido_id: null,
    monto: null,
    metodo_pago: 'efectivo',
    observaciones: '',
  };

  get esAdmin(): boolean {
    return this.auth.usuarioActual()?.rol === 'administrador';
  }

  ngOnInit(): void {
    this.cargar();
  }

  cargar(): void {
    this.service.deudores({ buscar: this.buscar.trim() || undefined, solo_vencidas: this.soloVencidas }).subscribe({
      next: (d) => this.data.set(d),
      error: () => this.error.set('No se pudo conectar con el servidor.'),
    });
  }

  abrir(c: DeudorResumen): void {
    this.errorModal.set('');
    this.mensajeOk.set('');
    this.anulandoId.set(null);
    this.abono = { pedido_id: null, monto: null, metodo_pago: 'efectivo', observaciones: '' };
    this.service.estadoCliente(c.cliente_id).subscribe({
      next: (e) => this.seleccionado.set(e),
      error: (err) => this.error.set(err?.error?.message || 'No se pudo cargar el cliente.'),
    });
  }

  cerrar(): void {
    this.seleccionado.set(null);
  }

  esSeleccionado(clienteId: number): boolean {
    return this.seleccionado()?.cliente.id === clienteId;
  }

  abonar(): void {
    const e = this.seleccionado();
    if (!e || !this.abono.monto || this.abono.monto <= 0) return;

    this.guardando.set(true);
    this.errorModal.set('');
    this.service
      .abonar({
        cliente_id: e.cliente.id,
        pedido_id: this.abono.pedido_id,
        monto: this.abono.monto,
        metodo_pago: this.abono.metodo_pago,
        observaciones: this.abono.observaciones.trim() || undefined,
      })
      .subscribe({
        next: (res) => {
          this.guardando.set(false);
          this.mensajeOk.set(res.message);
          this.abono = { pedido_id: null, monto: null, metodo_pago: this.abono.metodo_pago, observaciones: '' };
          this.seleccionado.set(res.estado);
          this.cargar();
        },
        error: (err) => {
          this.guardando.set(false);
          this.errorModal.set(err?.error?.message || 'No se pudo registrar el abono.');
        },
      });
  }

  pedirAnulacion(id: number): void {
    this.motivoAnulacion = '';
    this.anulandoId.set(id);
  }

  confirmarAnulacion(id: number): void {
    if (!this.motivoAnulacion.trim()) return;
    this.service.anularAbono(id, this.motivoAnulacion.trim()).subscribe({
      next: (res) => {
        this.anulandoId.set(null);
        this.mensajeOk.set(res.message);
        this.seleccionado.set(res.estado);
        this.cargar();
      },
      error: (err) => this.errorModal.set(err?.error?.message || 'No se pudo anular el abono.'),
    });
  }

  descargarEstado(e: EstadoCuentaCliente): void {
    this.descargando.set(true);
    this.service
      .descargarEstadoPdf(e.cliente.id, e.cliente.nombre)
      .catch(() => this.errorModal.set('No se pudo generar el estado de cuenta.'))
      .finally(() => this.descargando.set(false));
  }

  exportar(): void {
    this.exportando.set(true);
    this.service
      .descargarReporteExcel()
      .catch(() => this.error.set('No se pudo generar el reporte.'))
      .finally(() => this.exportando.set(false));
  }
}
