import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuditoriaService, FiltroAuditoria } from '../../core/services/auditoria.service';
import { PaginaAuditoria } from '../../core/models/paso4.model';
import { BASE_THEME } from '../../shared/theme/theme';

const ETIQUETA_CAMPO: Record<string, string> = {
  precio_venta: 'Precio de venta', precio_compra: 'Precio de compra', stock: 'Stock',
  stock_minimo: 'Stock mínimo', nombre: 'Nombre', categoria_id: 'Categoría', codigo: 'Código',
  codigo_barras: 'Código de barras', fecha_vencimiento: 'Vencimiento', activo: 'Activo',
  email: 'Correo', rol: 'Rol', password: 'Contraseña',
};

/** 4.4 — Auditoría: quién cambió precios, usuarios o inventario, y cuándo. */
@Component({
  selector: 'app-auditoria',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Administración &middot; Seguridad</div>
          <h1>Auditoría</h1>
          <p class="subtitle">Registro de cambios en productos (precios incluidos), usuarios e inventario, con el valor anterior y el nuevo.</p>
        </div>
      </header>

      <section class="panel">
        <div class="form-grid">
          <div class="field"><label>Qué cambió</label>
            <select [(ngModel)]="filtro.entidad" name="entidad">
              <option value="">Todo</option>
              <option value="producto">Productos y precios</option>
              <option value="usuario">Usuarios</option>
              <option value="inventario">Inventario</option>
            </select></div>
          <div class="field"><label>Desde</label><input type="date" [(ngModel)]="filtro.desde" name="desde" /></div>
          <div class="field"><label>Hasta</label><input type="date" [(ngModel)]="filtro.hasta" name="hasta" /></div>
          <div class="field"><label>Buscar</label><input type="text" placeholder="Producto o usuario…" [(ngModel)]="filtro.buscar" name="buscar" (keyup.enter)="buscar()" /></div>
          <div class="field-row" style="align-self:flex-end">
            <button class="btn-primary" (click)="buscar()" [disabled]="cargando()">Buscar</button>
            <button class="btn-secondary" (click)="limpiar()">Limpiar</button>
          </div>
        </div>
      </section>

      @if (error()) { <p class="form-error">{{ error() }}</p> }

      @if (cargando()) {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando…</p></div>
      } @else if (!pagina() || pagina()!.data.length === 0) {
        <div class="estado-vacio"><p>No hay registros para esos filtros.</p></div>
      } @else {
        <table>
          <thead><tr><th>Fecha</th><th>Quién</th><th>Qué</th><th>Campo</th><th>Antes</th><th>Después</th></tr></thead>
          <tbody>
            @for (r of pagina()!.data; track r.id) {
              <tr>
                <td data-label="Fecha">{{ fecha(r.created_at) }}</td>
                <td data-label="Quién">{{ r.usuario_nombre || '—' }}</td>
                <td data-label="Qué">
                  <span class="badge" [class.badge-ok]="r.accion === 'crear'" [class.badge-danger]="r.accion === 'eliminar'" [class.badge-info]="r.accion === 'actualizar'" [class.badge-warn]="r.accion === 'ajuste'">{{ r.accion }}</span>
                  {{ r.descripcion }}
                </td>
                <td data-label="Campo">{{ r.campo ? (etiqueta(r.campo)) : '—' }}</td>
                <td data-label="Antes">{{ r.valor_anterior ?? '—' }}</td>
                <td data-label="Después"><strong>{{ r.valor_nuevo ?? '—' }}</strong></td>
              </tr>
            }
          </tbody>
        </table>

        <div class="paginacion">
          <button class="btn-secondary" (click)="irA(pagina()!.current_page - 1)" [disabled]="pagina()!.current_page <= 1">← Anterior</button>
          <span>Página {{ pagina()!.current_page }} de {{ pagina()!.last_page }} · {{ pagina()!.total }} registros</span>
          <button class="btn-secondary" (click)="irA(pagina()!.current_page + 1)" [disabled]="pagina()!.current_page >= pagina()!.last_page">Siguiente →</button>
        </div>
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .paginacion { display: flex; gap: 14px; align-items: center; justify-content: center; margin-top: 14px; flex-wrap: wrap; font-size: 13px; }
  `],
})
export class AuditoriaComponent implements OnInit {
  private servicio = inject(AuditoriaService);

  filtro: FiltroAuditoria = { entidad: '', desde: '', hasta: '', buscar: '' };
  pagina = signal<PaginaAuditoria | null>(null);
  cargando = signal(true);
  error = signal('');

  ngOnInit(): void { this.buscar(); }

  buscar(page = 1): void {
    this.cargando.set(true);
    this.error.set('');
    this.servicio.listar({ ...this.filtro, page }).subscribe({
      next: (p) => { this.pagina.set(p); this.cargando.set(false); },
      error: () => { this.error.set('No se pudo cargar la auditoría.'); this.cargando.set(false); },
    });
  }

  irA(page: number): void { this.buscar(page); }

  limpiar(): void {
    this.filtro = { entidad: '', desde: '', hasta: '', buscar: '' };
    this.buscar();
  }

  etiqueta(campo: string): string { return ETIQUETA_CAMPO[campo] ?? campo; }

  fecha(iso: string): string {
    return new Date(iso).toLocaleString('es-BO', {
      day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'America/La_Paz',
    });
  }
}
