import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="login-wrap">
      <form class="login-card" (ngSubmit)="ingresar()">
        <div class="brand">
          <img src="brand/logo-al-paso.png" alt="Licorería Al Paso" height="46" />
        </div>
        <p class="subtitle">Ingresa con tu cuenta de la licorería para continuar.</p>

        <div class="field">
          <label for="email">Correo</label>
          <input id="email" type="email" [(ngModel)]="email" name="email" required autocomplete="username" />
        </div>
        <div class="field">
          <label for="password">Contraseña</label>
          <div class="password-input">
            <input
              [id]="'password'"
              [type]="mostrarPassword() ? 'text' : 'password'"
              [(ngModel)]="password"
              name="password"
              required
              autocomplete="current-password"
            />
            <button
              type="button"
              class="toggle-password"
              (click)="mostrarPassword.set(!mostrarPassword())"
              [attr.aria-label]="mostrarPassword() ? 'Ocultar contraseña' : 'Mostrar contraseña'"
              tabindex="-1"
            >
              @if (mostrarPassword()) {
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.6 18.6 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke-linecap="round" stroke-linejoin="round"/>
                  <line x1="1" y1="1" x2="23" y2="23" stroke-linecap="round"/>
                </svg>
              } @else {
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke-linecap="round" stroke-linejoin="round"/>
                  <circle cx="12" cy="12" r="3"/>
                </svg>
              }
            </button>
          </div>
          <a routerLink="/olvide-password" [queryParams]="{ tipo: 'usuario' }" class="olvide-link">¿Olvidaste tu contraseña?</a>
        </div>

        @if (error()) {
          <p class="error">{{ error() }}</p>
        }

        <button type="submit" class="btn-primary" [disabled]="cargando()">
          {{ cargando() ? 'Ingresando…' : 'Ingresar' }}
        </button>

        <p class="hint">Demo: admin&#64;licoreria.com / admin123</p>
      </form>
    </div>
  `,
  styles: [`
    :host {
      --verde-botella: #020024;
      --verde-botella-oscuro: #01001A;
      --cobre: #00D4FF;
      --cobre-claro: #00D4FF;
      --papel: #EAFBFF;
      --papel-borde: #00D4FF;
      --tinta: #020024;
      display: block;
      min-height: calc(100dvh - var(--altura-nav, 0px));
      background: var(--verde-botella-oscuro);
      font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
    }
    .login-wrap { display: flex; align-items: center; justify-content: center; min-height: calc(100dvh - var(--altura-nav, 0px)); padding: 24px; }
    .login-card {
      width: 100%; max-width: 360px;
      background: var(--papel);
      border: 1px solid var(--papel-borde);
      border-radius: 14px;
      padding: 32px 28px;
      box-shadow: 0 16px 40px rgba(0,0,0,0.35);
    }
    .brand { display: flex; align-items: center; margin-bottom: 6px; }
    .brand img { display: block; }
    .subtitle { font-size: 13px; color: #5a5140; margin: 0 0 22px; }
    .field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 16px; }
    .field label { font-size: 13px; font-weight: 600; color: var(--tinta); }
    .field input {
      border: 1px solid var(--papel-borde);
      border-radius: 8px;
      padding: 10px 12px;
      font-size: 14px;
      font-family: inherit;
      background: #fff;
      color: var(--tinta);
      width: 100%;
      box-sizing: border-box;
    }
    .field input::placeholder { color: #8a8578; }
    .field input:focus { outline: 2px solid var(--cobre-claro); outline-offset: 1px; }
    .password-input { position: relative; display: flex; align-items: center; }
    .password-input input { padding-right: 38px; }
    .toggle-password {
      position: absolute;
      right: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: none;
      border: none;
      padding: 4px;
      color: #8a7a56;
      cursor: pointer;
      border-radius: 6px;
    }
    .toggle-password:hover { color: var(--cobre); }
    .olvide-link {
      align-self: flex-end;
      font-size: 12px;
      color: var(--cobre);
      text-decoration: none;
      margin-top: 2px;
    }
    .olvide-link:hover { text-decoration: underline; }
    .error { color: #d64545; font-size: 13px; margin: -6px 0 14px; }
    .btn-primary {
      width: 100%;
      background: var(--cobre);
      color: #1a1409;
      border: none;
      border-radius: 8px;
      padding: 11px 20px;
      font-weight: 700;
      font-size: 14px;
      cursor: pointer;
    }
    .btn-primary:hover:not(:disabled) { background: var(--cobre-claro); }
    .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
    .hint { text-align: center; font-size: 12px; color: #8a7a56; margin: 16px 0 0; }
  `],
})
export class LoginComponent {
  private auth = inject(AuthService);
  private router = inject(Router);
  private ruta = inject(ActivatedRoute);

  email = '';
  password = '';
  cargando = signal(false);
  error = signal('');
  mostrarPassword = signal(false);

  // A donde volver despues de iniciar sesion (lo manda el guard / el
  // interceptor cuando la sesion vencio estando en una pagina privada).
  private returnUrl = '/catalogo';
  private hayReturnUrl = false;

  constructor() {
    const params = this.ruta.snapshot.queryParamMap;
    this.hayReturnUrl = !!params.get('returnUrl');
    this.returnUrl = params.get('returnUrl') || '/catalogo';
    if (params.get('expirada')) {
      this.error.set('Tu sesion vencio. Vuelve a iniciar sesion para continuar.');
    }
  }

  ingresar(): void {
    if (!this.email || !this.password) return;
    this.cargando.set(true);
    this.error.set('');

    this.auth.login(this.email, this.password).subscribe({
      next: () => {
        this.cargando.set(false);
        // 4.1: administrador y vendedor aterrizan en el mismo panel de inicio,
        // salvo que vengan de una página concreta.
        this.router.navigateByUrl(!this.hayReturnUrl ? '/dashboard' : this.returnUrl);
      },
      error: (err) => {
        this.cargando.set(false);
        this.error.set(err?.status === 401 ? 'Correo o contraseña incorrectos.' : 'No se pudo conectar con el servidor.');
      },
    });
  }
}
