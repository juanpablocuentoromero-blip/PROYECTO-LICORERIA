import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, OnInit, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { Pedido } from '../../core/models/pedido.model';
import { ClienteAuthService } from '../../core/services/cliente-auth.service';
import { PedidoClienteService } from '../../core/services/pedido-cliente.service';
import { ProductoService } from '../../core/services/producto.service';
import { Producto } from '../../core/models/producto.model';
import { Presentacion, enteroSeguro, factorDe, opcionesDe, textoCantidad } from '../../core/utils/presentacion';

@Component({
  selector: 'app-perfil-cliente',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page">
      <header class="cabecera">
        <a routerLink="/catalogo" class="volver">← Volver al catálogo</a>
        <h1>Mi cuenta</h1>
      </header>

      <div class="layout">
        <!-- ===== Datos de la cuenta ===== -->
        <section class="panel">
          <h2>Mis datos</h2>

          @if (cargandoPerfil()) {
            <p class="cargando-texto">Cargando…</p>
          } @else {
            <form (ngSubmit)="guardarPerfil()">
              <div class="campo">
                <label>Nombre</label>
                <input type="text" [(ngModel)]="formNombre" name="nombre" required />
              </div>
              <div class="campo">
                <label>Correo <span>(no editable)</span></label>
                <input type="email" [value]="cliente()?.email" disabled />
              </div>
              <div class="campo">
                <label>Teléfono</label>
                <input type="text" [(ngModel)]="formTelefono" name="telefono" placeholder="Ej. 75612345" />
              </div>
              <div class="campo">
                <label>Dirección</label>
                <input type="text" [(ngModel)]="formDireccion" name="direccion" placeholder="Tu dirección de entrega habitual" />
              </div>

              <details class="cambiar-password">
                <summary>Cambiar contraseña</summary>
                <div class="campo">
                  <label>Nueva contraseña</label>
                  <div class="password-input">
                    <input
                      [type]="mostrarPassword() ? 'text' : 'password'"
                      [(ngModel)]="formPassword"
                      name="password"
                      placeholder="Dejar en blanco para no cambiar"
                    />
                    <button type="button" class="toggle-password" (click)="mostrarPassword.set(!mostrarPassword())"
                      [attr.aria-label]="mostrarPassword() ? 'Ocultar contraseña' : 'Mostrar contraseña'" tabindex="-1">
                      @if (mostrarPassword()) {
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                          <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.6 18.6 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke-linecap="round" stroke-linejoin="round"/>
                          <line x1="1" y1="1" x2="23" y2="23" stroke-linecap="round"/>
                        </svg>
                      } @else {
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke-linecap="round" stroke-linejoin="round"/>
                          <circle cx="12" cy="12" r="3"/>
                        </svg>
                      }
                    </button>
                  </div>
                </div>
                <div class="campo">
                  <label>Confirmar contraseña</label>
                  <div class="password-input">
                    <input
                      [type]="mostrarPasswordConf() ? 'text' : 'password'"
                      [(ngModel)]="formPasswordConfirm"
                      name="passwordConfirm"
                    />
                    <button type="button" class="toggle-password" (click)="mostrarPasswordConf.set(!mostrarPasswordConf())"
                      [attr.aria-label]="mostrarPasswordConf() ? 'Ocultar contraseña' : 'Mostrar contraseña'" tabindex="-1">
                      @if (mostrarPasswordConf()) {
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                          <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.6 18.6 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke-linecap="round" stroke-linejoin="round"/>
                          <line x1="1" y1="1" x2="23" y2="23" stroke-linecap="round"/>
                        </svg>
                      } @else {
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke-linecap="round" stroke-linejoin="round"/>
                          <circle cx="12" cy="12" r="3"/>
                        </svg>
                      }
                    </button>
                  </div>
                </div>
              </details>

              @if (errorGuardar()) {
                <p class="mensaje-error">{{ errorGuardar() }}</p>
              }
              @if (guardadoOk()) {
                <p class="mensaje-ok">Datos actualizados.</p>
              }

              <button type="submit" class="btn-guardar" [disabled]="guardando()">
                {{ guardando() ? 'Guardando…' : 'Guardar cambios' }}
              </button>
            </form>
          }

          <button class="btn-salir" (click)="cerrarSesion()">Cerrar sesión</button>
        </section>

        <!-- ===== Historial de pedidos ===== -->
        <section class="panel panel-pedidos">
          <h2>Mis pedidos</h2>

          @if (cargandoPedidos()) {
            <p class="cargando-texto">Cargando pedidos…</p>
          } @else if (pedidos().length === 0) {
            <div class="sin-pedidos">
              <p>Todavía no hiciste ningún pedido.</p>
              <a routerLink="/catalogo" class="link-catalogo">Ir al catálogo →</a>
            </div>
          } @else {
            <div class="lista-pedidos">
              @for (pedido of pedidos(); track pedido.id) {
                <article class="pedido-card">
                  <div class="pedido-cabecera">
                    <div>
                      <strong>Pedido #{{ pedido.id }}</strong>
                      <span class="fecha">{{ pedido.created_at | date: 'd MMM y, HH:mm' }}</span>
                    </div>
                    <span class="estado-badge" [class]="'estado-' + pedido.estado">{{ etiquetaEstado(pedido.estado) }}</span>
                  </div>

                  <ul class="pedido-items">
                    @for (detalle of pedido.detalles; track detalle.id) {
                      <li>
                        @if (detalle.presentacion && detalle.presentacion !== 'unidad') {
                          {{ textoCant(detalle.presentacion, detalle.cantidad_presentacion) }} ({{ detalle.cantidad }} u.)
                        } @else { {{ detalle.cantidad }}× }
                        {{ detalle.producto?.nombre }}
                      </li>
                    }
                  </ul>

                  @if (puedeEditar(pedido)) {
                    @if (editandoId() !== pedido.id) {
                      <button type="button" class="btn-ver-qr" (click)="empezarEdicion(pedido)">✏️ Modificar productos</button>
                    } @else {
                      <div class="editor">
                        <p class="editor-ayuda">Cambiá las cantidades, quitá lo que no quieras o agregá más productos. Podés hacerlo hasta que el local confirme tu pedido.</p>
                        @for (l of lineasEdit(); track l.producto.id + l.presentacion) {
                          <div class="editor-fila">
                            <span class="editor-nombre">{{ l.producto.nombre }}<small>{{ nombrePres(l.presentacion) }}</small></span>
                            <input type="number" min="0" inputmode="numeric" [value]="l.cantidad"
                                   (change)="cambiarEdit(l, $any($event.target))" aria-label="Cantidad" />
                            <button type="button" class="editor-quitar" (click)="quitarEdit(l)" aria-label="Quitar">✕</button>
                          </div>
                        }
                        <div class="editor-agregar">
                          <select [ngModel]="selProducto()" (ngModelChange)="elegirProducto($event)" name="selProd{{ pedido.id }}">
                            <option [ngValue]="null">Agregar otro producto…</option>
                            @for (p of productosTienda(); track p.id) {
                              <option [ngValue]="p.id" [disabled]="p.stock + apartado(pedido, p.id) === 0">{{ p.nombre }} — Bs {{ p.precio_venta }}</option>
                            }
                          </select>
                          <select [ngModel]="selPres()" (ngModelChange)="selPres.set($event)" name="selPres{{ pedido.id }}">
                            @for (o of opcionesSel(); track o.valor) { <option [ngValue]="o.valor">{{ o.etiqueta }}</option> }
                          </select>
                          <input type="number" min="1" [ngModel]="selCant()" (ngModelChange)="selCant.set($event)" name="selCant{{ pedido.id }}" aria-label="Cantidad" />
                          <button type="button" class="editor-btn" (click)="agregarEdit(pedido)">Agregar</button>
                        </div>
                        @if (errorEdit()) { <p class="editor-error">{{ errorEdit() }}</p> }
                        <div class="editor-acciones">
                          <button type="button" class="editor-btn sec" (click)="cancelarEdicion()">Cancelar</button>
                          <button type="button" class="editor-btn" [disabled]="guardandoEdit()" (click)="guardarEdit(pedido)">
                            {{ guardandoEdit() ? 'Guardando…' : 'Guardar cambios' }}
                          </button>
                        </div>
                      </div>
                    }
                  }
                  @if (avisoEdit() && editadoId() === pedido.id) { <p class="editor-ok">{{ avisoEdit() }}</p> }

                  @if (pedido.tipo_entrega === 'delivery') {
                    <p class="pedido-entrega">
                      🛵 Delivery{{ pedido.zona_delivery ? ' · ' + pedido.zona_delivery.nombre : '' }}
                      @if (pedido.estado === 'en_camino' && pedido.repartidor) {
                        — <strong>En camino con {{ pedido.repartidor.nombre }}</strong>
                        @if (pedido.repartidor.telefono) { ({{ pedido.repartidor.telefono }}) }
                      }
                    </p>
                  } @else if (pedido.tipo_entrega === 'recojo') {
                    <p class="pedido-entrega">🏪 Recojo en la tienda</p>
                  }
                  @if (+(pedido.descuento ?? 0) > 0 || +(pedido.costo_envio ?? 0) > 0) {
                    <p class="pedido-entrega">
                      @if (+(pedido.descuento ?? 0) > 0) { Descuento: − Bs {{ pedido.descuento }} }
                      @if (+(pedido.costo_envio ?? 0) > 0) { · Envío: Bs {{ pedido.costo_envio }} }
                    </p>
                  }

                  <div class="pedido-footer">
                    <span class="total">Total: Bs {{ pedido.total }}</span>
                    <span class="pago-estado" [class.pagado]="pedido.pagado">
                      {{ pedido.pagado ? '✓ Pagado' : (pedido.metodo_pago === 'qr' ? 'Pendiente de pago (QR)' : 'Pago contra entrega') }}
                    </span>
                  </div>

                  @if (!pedido.pagado && pedido.metodo_pago === 'qr' && pedido.estado !== 'cancelado') {
                    <button class="btn-ver-qr" (click)="verQr(pedido)">
                      {{ qrAbiertoId() === pedido.id ? 'Ocultar QR' : 'Ver QR para pagar' }}
                    </button>
                  }

                  @if (qrAbiertoId() === pedido.id) {
                    <div class="qr-contenedor" [innerHTML]="qrSvg()"></div>
                  }
                </article>
              }
            </div>
          }
        </section>
      </div>
    </div>
  `,
  styles: [
    `
      :host {
        --verde-botella: #020024;
        --verde-botella-oscuro: #01001A;
        --cobre: #00D4FF;
        --cobre-claro: #00D4FF;
        --papel: #EAFBFF;
        --borde-claro: #00D4FF;
        --tinta: #020024;
        --rust: #d64545;
        --texto-suave: #5FB8CC;
        --fondo-alt: #E8FBFF;
        display: block;
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        color: var(--tinta);
        background: #fff;
        min-height: 100%;
      }

      .page { max-width: 1080px; margin: 0 auto; padding: 32px 32px 64px; }

      .cabecera { margin-bottom: 28px; }
      .volver {
        display: inline-block;
        color: var(--cobre);
        text-decoration: none;
        font-size: 13px;
        font-weight: 600;
        margin-bottom: 10px;
      }
      .volver:hover { text-decoration: underline; }
      h1 {
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        font-size: 32px;
        margin: 0;
        color: var(--verde-botella);
      }

      .layout {
        display: grid;
        grid-template-columns: 340px 1fr;
        gap: 28px;
        align-items: start;
      }

      .panel {
        background: #fff;
        border: 1px solid var(--borde-claro);
        border-radius: 14px;
        padding: 24px;
      }
      .panel h2 {
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        font-size: 19px;
        margin: 0 0 18px;
        color: var(--verde-botella);
      }

      .campo { display: flex; flex-direction: column; gap: 5px; margin-bottom: 14px; }
      .campo label { font-size: 12.5px; font-weight: 700; color: var(--tinta); }
      .campo label span { font-weight: 400; color: var(--texto-suave); }
      .campo input {
        border: 1px solid var(--borde-claro);
        border-radius: 8px;
        padding: 10px 12px;
        font-size: 14px;
        font-family: inherit;
        background: #fff;
        color: var(--tinta);
      }
      .campo input:disabled { background: var(--fondo-alt); color: var(--texto-suave); }
      .campo input:focus { outline: 2px solid var(--cobre-claro); outline-offset: 1px; }
      .password-input { position: relative; display: flex; align-items: center; }
      .password-input input { width: 100%; box-sizing: border-box; padding-right: 38px; }
      .toggle-password {
        position: absolute;
        right: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: none;
        border: none;
        padding: 4px;
        color: var(--texto-suave);
        cursor: pointer;
        border-radius: 6px;
      }
      .toggle-password:hover { color: var(--cobre); }

      .cambiar-password {
        margin: 4px 0 16px;
        border-top: 1px dashed var(--borde-claro);
        padding-top: 12px;
      }
      .cambiar-password summary {
        cursor: pointer;
        font-size: 13px;
        font-weight: 700;
        color: var(--cobre);
        margin-bottom: 10px;
      }

      .mensaje-error { color: var(--rust); font-size: 13px; margin: 0 0 12px; }
      .mensaje-ok { color: #2f6b46; font-size: 13px; margin: 0 0 12px; }

      .btn-guardar {
        width: 100%;
        background: var(--cobre);
        color: var(--tinta);
        border: none;
        border-radius: 8px;
        padding: 11px;
        font-weight: 700;
        font-size: 14px;
        cursor: pointer;
      }
      .btn-guardar:hover:not(:disabled) { background: var(--verde-botella); }
      .btn-guardar:disabled { opacity: 0.6; cursor: not-allowed; }

      .btn-salir {
        width: 100%;
        background: none;
        border: 1px solid var(--borde-claro);
        color: var(--rust);
        border-radius: 8px;
        padding: 10px;
        font-weight: 700;
        font-size: 13px;
        cursor: pointer;
        margin-top: 16px;
      }
      .btn-salir:hover { background: #fdf1ec; }

      .cargando-texto { color: var(--texto-suave); font-size: 14px; }

      .sin-pedidos { text-align: center; padding: 32px 0; color: var(--texto-suave); }
      .link-catalogo { color: var(--cobre); font-weight: 700; text-decoration: none; font-size: 13px; }

      .lista-pedidos { display: flex; flex-direction: column; gap: 16px; }
      .pedido-card {
        border: 1px solid var(--borde-claro);
        border-radius: 12px;
        padding: 16px 18px;
      }
      .pedido-cabecera {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 10px;
        margin-bottom: 10px;
      }
      .pedido-cabecera strong { font-size: 15px; }
      .fecha { display: block; font-size: 12px; color: var(--texto-suave); margin-top: 2px; }

      .estado-badge {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.03em;
        padding: 4px 10px;
        border-radius: 20px;
        white-space: nowrap;
      }
      .estado-pendiente { background: #fbe8c8; color: #8a5b12; }
      .estado-confirmado { background: #d6ecdc; color: #1f6b3a; }
      .estado-en_camino { background: #cfe8ff; color: #0b4a8a; }
      .pedido-entrega { font-size: 13px; color: var(--tinta); margin: 6px 0 0; }
      .estado-entregado { background: #DFF7FC; color: #006A80; }
      .estado-cancelado { background: #f6d9d2; color: #8a2f1f; }

      .pedido-items { margin: 0 0 12px; padding-left: 18px; font-size: 13.5px; color: var(--tinta); }
      .pedido-items li { margin-bottom: 2px; }

      .pedido-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-top: 1px dashed var(--borde-claro);
        padding-top: 10px;
        font-size: 13px;
      }
      .total { font-weight: 700; color: var(--verde-botella); }
      .pago-estado { color: var(--rust); font-weight: 600; }
      .pago-estado.pagado { color: #2f6b46; }

      .editor { background: #f1fafd; border: 1.5px solid #4a90b8; border-radius: 12px; padding: 12px; margin: 8px 0; color: #020024; }
      .editor-ayuda { font-size: 12.5px; color: #2d4a66; margin: 0 0 10px; }
      .editor-fila { display: flex; align-items: center; gap: 8px; padding: 6px 0; border-bottom: 1px dashed #b7d8e8; }
      .editor-nombre { flex: 1; font-size: 13.5px; font-weight: 600; color: #020024; min-width: 0; }
      .editor-nombre small { display: block; font-weight: 400; color: #4a6580; font-size: 11.5px; }
      .editor input, .editor select { background: #fff; color: #020024; border: 1.5px solid #4a90b8; border-radius: 8px; padding: 7px 8px; font-size: 13.5px; }
      .editor-fila input { width: 70px; text-align: center; }
      .editor-quitar { background: none; border: none; color: #b3261e; font-size: 16px; cursor: pointer; padding: 4px 8px; }
      .editor-agregar { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 10px; }
      .editor-agregar select:first-child { flex: 1 1 180px; min-width: 0; }
      .editor-agregar input { width: 70px; text-align: center; }
      .editor-acciones { display: flex; gap: 8px; justify-content: flex-end; margin-top: 12px; }
      .editor-btn { background: #020024; color: #fff; border: none; border-radius: 8px; padding: 8px 14px; font-weight: 700; font-size: 13px; cursor: pointer; }
      .editor-btn.sec { background: #fff; color: #020024; border: 1.5px solid #4a90b8; }
      .editor-btn:disabled { opacity: 0.5; cursor: not-allowed; }
      .editor-error { color: #b3261e; font-size: 13px; margin: 8px 0 0; font-weight: 600; }
      .editor-ok { color: #1f6b3a; font-size: 13px; margin: 6px 0 0; font-weight: 600; }
      .btn-ver-qr {
        margin-top: 12px;
        width: 100%;
        background: var(--fondo-alt);
        border: 1px solid var(--borde-claro);
        color: var(--verde-botella);
        border-radius: 8px;
        padding: 9px;
        font-weight: 700;
        font-size: 13px;
        cursor: pointer;
      }
      .btn-ver-qr:hover { border-color: var(--cobre-claro); }

      .qr-contenedor {
        margin-top: 14px;
        display: flex;
        justify-content: center;
        padding: 16px;
        background: var(--fondo-alt);
        border-radius: 10px;
      }

      @media (max-width: 780px) {
        .layout { grid-template-columns: 1fr; }
        .page { padding: 22px 18px 48px; }
      }
    `,
  ],
})
export class PerfilClienteComponent implements OnInit {
  private clienteAuth = inject(ClienteAuthService);
  private pedidoClienteService = inject(PedidoClienteService);
  private productoService = inject(ProductoService);
  private router = inject(Router);

  cliente = this.clienteAuth.clienteActual;

  cargandoPerfil = signal(true);
  guardando = signal(false);
  errorGuardar = signal<string | null>(null);
  guardadoOk = signal(false);

  formNombre = '';
  formTelefono = '';
  formDireccion = '';
  formPassword = '';
  formPasswordConfirm = '';
  mostrarPassword = signal(false);
  mostrarPasswordConf = signal(false);

  pedidos = signal<Pedido[]>([]);
  cargandoPedidos = signal(true);
  qrAbiertoId = signal<number | null>(null);
  qrSvg = signal<string>('');

  ngOnInit(): void {
    this.clienteAuth.obtenerPerfil().subscribe({
      next: (c) => {
        this.formNombre = c.nombre;
        this.formTelefono = c.telefono ?? '';
        this.formDireccion = c.direccion ?? '';
        this.cargandoPerfil.set(false);
      },
      error: () => this.cargandoPerfil.set(false),
    });

    this.pedidoClienteService.misPedidos().subscribe({
      next: (data) => {
        this.pedidos.set(data);
        this.cargandoPedidos.set(false);
      },
      error: () => this.cargandoPedidos.set(false),
    });
  }

  guardarPerfil(): void {
    this.errorGuardar.set(null);
    this.guardadoOk.set(false);

    if (this.formPassword && this.formPassword !== this.formPasswordConfirm) {
      this.errorGuardar.set('Las contraseñas no coinciden.');
      return;
    }

    this.guardando.set(true);
    const payload: any = {
      nombre: this.formNombre,
      telefono: this.formTelefono || null,
      direccion: this.formDireccion || null,
    };
    if (this.formPassword) {
      payload.password = this.formPassword;
      payload.password_confirmation = this.formPasswordConfirm;
    }

    this.clienteAuth.actualizarPerfil(payload).subscribe({
      next: () => {
        this.guardando.set(false);
        this.guardadoOk.set(true);
        this.formPassword = '';
        this.formPasswordConfirm = '';
      },
      error: (err) => {
        this.guardando.set(false);
        this.errorGuardar.set(err?.error?.message ?? 'No se pudo guardar. Intenta de nuevo.');
      },
    });
  }

  etiquetaEstado(estado: string): string {
    const mapa: Record<string, string> = {
      pendiente: 'Pendiente',
      confirmado: 'Confirmado',
      en_camino: 'En camino',
      entregado: 'Entregado',
      cancelado: 'Cancelado',
    };
    return mapa[estado] ?? estado;
  }

  verQr(pedido: Pedido): void {
    if (this.qrAbiertoId() === pedido.id) {
      this.qrAbiertoId.set(null);
      return;
    }
    this.qrAbiertoId.set(pedido.id);
    this.qrSvg.set('');
    this.pedidoClienteService.obtenerQr(pedido.id).subscribe({
      next: (svg) => this.qrSvg.set(svg),
      error: () => this.qrSvg.set('<p>No se pudo cargar el QR.</p>'),
    });
  }


  // ===== Modificar los productos de un pedido pendiente =====
  productosTienda = signal<Producto[]>([]);
  editandoId = signal<number | null>(null);
  editadoId = signal<number | null>(null);
  lineasEdit = signal<{ producto: Producto; presentacion: Presentacion; cantidad: number }[]>([]);
  selProducto = signal<number | null>(null);
  selPres = signal<Presentacion>('unidad');
  selCant = signal(1);
  errorEdit = signal('');
  avisoEdit = signal('');
  guardandoEdit = signal(false);

  textoCant(p: string | undefined, n: number | null | undefined): string { return textoCantidad(p, n ?? 0); }

  nombrePres(p: Presentacion): string { return p === 'caja' ? 'Caja' : p === 'paquete' ? 'Paquete' : 'Unidad'; }

  /** Solo se puede cambiar mientras nadie del local lo confirmó y no se pagó. */
  puedeEditar(p: Pedido): boolean { return p.estado === 'pendiente' && !p.pagado; }

  opcionesSel() {
    const p = this.productosTienda().find((x) => x.id === this.selProducto());
    return p ? opcionesDe(p) : opcionesDe({});
  }

  elegirProducto(id: number | null): void { this.selProducto.set(id); this.selPres.set('unidad'); }

  /** Lo que el pedido ya tiene apartado cuenta como disponible al editarlo. */
  apartado(pedido: Pedido, productoId: number): number {
    return (pedido.detalles ?? []).filter((d) => d.producto_id === productoId).reduce((s, d) => s + d.cantidad, 0);
  }

  empezarEdicion(pedido: Pedido): void {
    this.errorEdit.set('');
    this.avisoEdit.set('');
    this.productoService.listar().subscribe({
      next: (lista) => {
        this.productosTienda.set(lista);
        this.lineasEdit.set(
          (pedido.detalles ?? []).map((d) => {
            const pres = (d.presentacion ?? 'unidad') as Presentacion;
            const base = lista.find((x) => x.id === d.producto_id) ?? (d.producto as Producto);
            // El factor de la línea es el que tenía al pedirse.
            const factor = pres === 'unidad' ? 1 : Math.max(1, Math.round(d.cantidad / Math.max(1, d.cantidad_presentacion ?? 1)));
            const producto = { ...base, unidades_por_paquete: pres === 'paquete' ? factor : base.unidades_por_paquete, unidades_por_caja: pres === 'caja' ? factor : base.unidades_por_caja } as Producto;
            return { producto, presentacion: pres, cantidad: pres === 'unidad' ? d.cantidad : (d.cantidad_presentacion ?? d.cantidad) };
          }),
        );
        this.editandoId.set(pedido.id);
      },
      error: () => this.errorEdit.set('No se pudieron cargar los productos. Intentá de nuevo.'),
    });
  }

  cancelarEdicion(): void { this.editandoId.set(null); this.errorEdit.set(''); }

  private pedidoEnEdicion(): Pedido | undefined { return this.pedidos().find((p) => p.id === this.editandoId()); }

  /** Valida contra stock (en unidades) contando lo ya apartado por este pedido. */
  private cabe(producto: Producto, pres: Presentacion, cantidad: number, excluir?: { producto: Producto; presentacion: Presentacion }): string {
    const pedido = this.pedidoEnEdicion();
    const factor = factorDe(producto, pres);
    if (factor < 1) return `«${producto.nombre}» no se vende por ${pres}.`;
    const otras = this.lineasEdit()
      .filter((l) => l.producto.id === producto.id && !(excluir && l.presentacion === excluir.presentacion))
      .reduce((s, l) => s + (l.presentacion === pres ? 0 : l.cantidad * factorDe(l.producto, l.presentacion)), 0);
    const disponible = Number(producto.stock) + (pedido ? this.apartado(pedido, producto.id) : 0);
    return cantidad * factor + otras > disponible ? `No hay stock suficiente de «${producto.nombre}» (disponible: ${disponible} unidades).` : '';
  }

  cambiarEdit(l: { producto: Producto; presentacion: Presentacion; cantidad: number }, input: HTMLInputElement): void {
    const n = enteroSeguro(input.value);
    if (n < 1) { this.quitarEdit(l); return; }
    const error = this.cabe(l.producto, l.presentacion, n, l);
    if (error) { this.errorEdit.set(error); input.value = String(l.cantidad); return; }
    this.errorEdit.set('');
    this.lineasEdit.set(this.lineasEdit().map((x) => (x === l ? { ...x, cantidad: n } : x)));
  }

  quitarEdit(l: { producto: Producto; presentacion: Presentacion; cantidad: number }): void {
    this.lineasEdit.set(this.lineasEdit().filter((x) => x !== l));
  }

  agregarEdit(pedido: Pedido): void {
    const producto = this.productosTienda().find((p) => p.id === this.selProducto());
    const n = enteroSeguro(this.selCant());
    if (!producto || n < 1) return;
    const pres = this.selPres();
    const existente = this.lineasEdit().find((l) => l.producto.id === producto.id && l.presentacion === pres);
    const total = (existente?.cantidad ?? 0) + n;
    const error = this.cabe(producto, pres, total, existente);
    if (error) { this.errorEdit.set(error); return; }
    this.errorEdit.set('');
    this.lineasEdit.set(
      existente
        ? this.lineasEdit().map((l) => (l === existente ? { ...l, cantidad: total } : l))
        : [...this.lineasEdit(), { producto, presentacion: pres, cantidad: n }],
    );
    this.selProducto.set(null);
    this.selPres.set('unidad');
    this.selCant.set(1);
  }

  guardarEdit(pedido: Pedido): void {
    if (this.lineasEdit().length === 0) {
      this.errorEdit.set('Tu pedido debe tener al menos un producto. Si ya no lo querés, cancelalo desde el local.');
      return;
    }
    this.guardandoEdit.set(true);
    this.errorEdit.set('');
    this.pedidoClienteService
      .editarItems(pedido.id, this.lineasEdit().map((l) => ({ producto_id: l.producto.id, cantidad: l.cantidad, presentacion: l.presentacion })))
      .subscribe({
        next: (actualizado) => {
          this.pedidos.set(this.pedidos().map((p) => (p.id === pedido.id ? { ...p, ...actualizado } : p)));
          this.guardandoEdit.set(false);
          this.editandoId.set(null);
          this.editadoId.set(pedido.id);
          this.avisoEdit.set(`Pedido actualizado. Nuevo total: Bs ${actualizado.total}.${actualizado.aviso ? ' ' + actualizado.aviso : ''}`);
        },
        error: (err) => {
          this.errorEdit.set(err?.error?.message || 'No se pudo modificar el pedido.');
          this.guardandoEdit.set(false);
        },
      });
  }

  cerrarSesion(): void {
    this.clienteAuth.logout();
    this.router.navigate(['/catalogo']);
  }
}
