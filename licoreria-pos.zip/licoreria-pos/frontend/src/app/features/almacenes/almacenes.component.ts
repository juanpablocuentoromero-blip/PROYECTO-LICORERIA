import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AlmacenService } from '../../core/services/almacen.service';
import { Almacen } from '../../core/models/almacen.model';
import { AuthService } from '../../core/services/auth.service';
import { BASE_THEME } from '../../shared/theme/theme';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';

@Component({
  selector: 'app-almacenes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Inventario &middot; Almacenes</div>
          <h1>Almacenes</h1>
          <p class="subtitle">Depósitos o sucursales donde vive el stock. El Principal no se puede eliminar ni desactivar.</p>
        </div>
      </header>

      @if (!esAdmin()) {
        <div class="panel"><p class="form-error" style="margin:0">Solo un usuario con rol "administrador" puede crear, editar o eliminar almacenes.</p></div>
      }

      <section class="composer" [class.open]="formAbierto()">
        <button class="composer-toggle" [disabled]="!esAdmin()" (click)="toggleForm()">
          <span class="plus" [class.rotated]="formAbierto()">+</span>
          {{ editandoId() ? 'Editando almacén' : (formAbierto() ? 'Cerrar' : 'Nuevo almacén') }}
        </button>

        @if (formAbierto()) {
          <form class="composer-form" (ngSubmit)="guardar()">
            <div class="form-grid">
              <div class="field">
                <label>Nombre</label>
                <input type="text" [(ngModel)]="nombre" name="nombre" required autocomplete="off" />
              </div>
              <div class="field">
                <label>Dirección <span>(opcional)</span></label>
                <input type="text" [(ngModel)]="direccion" name="direccion" />
              </div>
            </div>

            <div class="field-row" style="margin-top:14px">
              <button type="submit" class="btn-primary" [disabled]="guardando() || !nombre.trim()">
                {{ guardando() ? 'Guardando…' : (editandoId() ? 'Guardar cambios' : 'Crear almacén') }}
              </button>
              @if (editandoId()) {
                <button type="button" class="btn-secondary" (click)="cancelarEdicion()">Cancelar edición</button>
              }
              @if (error()) { <span class="form-error">{{ error() }}</span> }
            </div>
          </form>
        }
      </section>

      @if (cargando()) {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando almacenes…</p></div>
      } @else if (almacenes().length === 0) {
        <div class="estado-vacio">
          <p>Todavía no hay almacenes registrados.</p>
        </div>
      } @else {
        <table>
          <thead><tr><th>Nombre</th><th>Dirección</th><th>Tipo</th><th>Estado</th><th></th></tr></thead>
          <tbody>
            @for (a of almacenes(); track a.id) {
              <tr>
                <td data-label="Nombre">{{ a.nombre }}</td>
                <td data-label="Dirección">{{ a.direccion || '—' }}</td>
                <td data-label="Tipo">
                  @if (a.es_principal) { <span class="badge">Principal</span> } @else { <span>Secundario</span> }
                </td>
                <td data-label="Estado">
                  <span class="badge" [class.badge-off]="!a.activo">{{ a.activo ? 'Activo' : 'Inactivo' }}</span>
                </td>
                <td data-label="Acciones">
                  <button class="link-action" [disabled]="!esAdmin()" (click)="editar(a)">Editar</button>
                  @if (!a.es_principal) {
                    <button class="link-danger" [disabled]="!esAdmin()" (click)="eliminar(a)">Eliminar</button>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .composer { background: var(--verde-botella); border: 1px solid #2c4536; border-radius: 14px; padding: 16px 20px; margin-bottom: 28px; }
    .composer-toggle { background: none; border: none; color: var(--cobre-claro); font-size: 15px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 10px; padding: 4px 0; }
    .composer-toggle:disabled { opacity: 0.5; cursor: not-allowed; }
    .plus { display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; border-radius: 50%; border: 1.5px solid var(--cobre-claro); font-size: 16px; line-height: 1; transition: transform 0.25s ease; }
    .plus.rotated { transform: rotate(45deg); }
    .composer-form { margin-top: 18px; }
  `],
})
export class AlmacenesComponent implements OnInit {
  private almacenService = inject(AlmacenService);
  private confirmDialog = inject(ConfirmDialogService);
  private auth = inject(AuthService);

  almacenes = signal<Almacen[]>([]);
  cargando = signal(true);
  guardando = signal(false);
  formAbierto = signal(false);
  error = signal('');
  editandoId = signal<number | null>(null);

  nombre = '';
  direccion = '';

  esAdmin(): boolean { return this.auth.usuarioActual()?.rol === 'administrador'; }

  ngOnInit(): void {
    this.cargar();
  }

  cargar(): void {
    this.cargando.set(true);
    this.almacenService.listar(true).subscribe({
      next: (data) => { this.almacenes.set(data); this.cargando.set(false); },
      error: () => { this.error.set('No se pudo conectar con el servidor.'); this.cargando.set(false); },
    });
  }

  toggleForm(): void {
    if (!this.esAdmin()) return;
    if (this.formAbierto() && this.editandoId()) {
      this.cancelarEdicion();
      return;
    }
    this.formAbierto.set(!this.formAbierto());
    this.error.set('');
  }

  private limpiarForm(): void {
    this.nombre = '';
    this.direccion = '';
  }

  editar(a: Almacen): void {
    if (!this.esAdmin()) return;
    this.editandoId.set(a.id);
    this.nombre = a.nombre;
    this.direccion = a.direccion ?? '';
    this.formAbierto.set(true);
    this.error.set('');
  }

  cancelarEdicion(): void {
    this.editandoId.set(null);
    this.limpiarForm();
    this.formAbierto.set(false);
    this.error.set('');
  }

  guardar(): void {
    if (!this.esAdmin() || !this.nombre.trim()) return;
    this.guardando.set(true);
    this.error.set('');

    const payload = {
      nombre: this.nombre.trim(),
      direccion: this.direccion.trim() || undefined,
    };

    const id = this.editandoId();
    const peticion = id ? this.almacenService.actualizar(id, payload) : this.almacenService.crear(payload);

    peticion.subscribe({
      next: (resultado) => {
        if (id) {
          this.almacenes.set(this.almacenes().map((a) => (a.id === id ? resultado : a)));
        } else {
          this.almacenes.set([...this.almacenes(), resultado]);
        }
        this.limpiarForm();
        this.editandoId.set(null);
        this.guardando.set(false);
        this.formAbierto.set(false);
      },
      error: (err) => {
        this.error.set(err?.error?.message || 'No se pudo guardar. Revisa los datos e intenta de nuevo.');
        this.guardando.set(false);
      },
    });
  }

  async eliminar(a: Almacen): Promise<void> {
    if (!this.esAdmin()) return;
    const ok = await this.confirmDialog.confirm({
      titulo: 'Eliminar almacén',
      mensaje: `¿Estás seguro de que quieres eliminar el almacén "${a.nombre}"?`,
      textoConfirmar: 'Sí, eliminar',
      peligroso: true,
    });
    if (!ok) return;

    this.almacenService.eliminar(a.id).subscribe({
      next: () => this.almacenes.set(this.almacenes().filter((x) => x.id !== a.id)),
      error: (err) => this.error.set(err?.error?.message || 'No se pudo eliminar el almacén.'),
    });
  }
}
