import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ReposicionService } from '../../core/services/reposicion.service';
import { RespuestaReposicion } from '../../core/models/paso4.model';
import { BASE_THEME } from '../../shared/theme/theme';

interface FilaRepo {
  producto_id: number;
  codigo: string;
  nombre: string;
  stock: number;
  stock_minimo: number;
  en_camino: number;
  ventas_por_semana: number;
  dias_stock: number | null;
  unidades_por_paquete: number;
  urgencia: 'urgente' | 'pronto' | 'normal';
  precio: number;
  cantidad: number;
  proveedor_id: number | null;
  elegida: boolean;
}

/** 4.3 — Sugerencia de reposición y borradores de pedido de compra. */
@Component({
  selector: 'app-reposicion',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Administración &middot; Compras</div>
          <h1>Sugerencia de reposición</h1>
          <p class="subtitle">Calcula, con lo que se vendió, cuántos días de stock quedan y cuánto conviene pedir. Los borradores se revisan en Compras antes de recibirlos.</p>
        </div>
      </header>

      <section class="panel">
        <div class="form-grid">
          <div class="field"><label>Ventas de los últimos (días)</label>
            <input type="number" min="7" max="180" [(ngModel)]="diasHistorial" name="dh" /></div>
          <div class="field"><label>Cubrir (días de venta)</label>
            <input type="number" min="1" max="90" [(ngModel)]="diasCobertura" name="dc" /></div>
          <div class="field"><label>Días que tarda el proveedor</label>
            <input type="number" min="0" max="30" [(ngModel)]="diasEntrega" name="de" /></div>
          <div class="field"><label>&nbsp;</label>
            <label class="chk"><input type="checkbox" [(ngModel)]="verTodos" name="vt" /> Mostrar también los que no necesitan pedido</label></div>
          <div class="field-row" style="align-self:flex-end">
            <button class="btn-primary" (click)="calcular()" [disabled]="cargando()">{{ cargando() ? 'Calculando…' : 'Calcular' }}</button>
          </div>
        </div>
      </section>

      @if (error()) { <p class="form-error">{{ error() }}</p> }
      @if (ok()) { <p class="form-ok">{{ ok() }}</p> }

      @if (cargando() && filas().length === 0) {
        <div class="estado-vacio"><div class="spinner"></div><p>Analizando ventas…</p></div>
      } @else if (datos()) {
        @if (filas().length === 0) {
          <div class="estado-vacio"><p>No hay productos que necesiten reposición con estos parámetros. 🎉</p></div>
        } @else {
          <div class="resumen">
            <div class="card-plain"><span class="lbl">Productos a pedir</span><strong>{{ seleccionadas().length }} de {{ filas().length }}</strong></div>
            <div class="card-plain"><span class="lbl">Urgentes</span><strong>{{ datos()!.resumen.urgentes }}</strong></div>
            <div class="card-plain"><span class="lbl">Costo estimado (selección)</span><strong>Bs {{ costoSeleccion().toFixed(2) }}</strong></div>
          </div>

          <div class="barra-gen">
            <div class="field" style="margin:0">
              <label>Proveedor para los que no tienen uno</label>
              <select [(ngModel)]="proveedorDefecto" name="pd">
                <option [ngValue]="null">— elegir —</option>
                @for (p of datos()!.proveedores; track p.id) { <option [ngValue]="p.id">{{ p.nombre }}</option> }
              </select>
            </div>
            <button class="btn-primary" (click)="generar()" [disabled]="generando() || seleccionadas().length === 0">
              {{ generando() ? 'Generando…' : 'Generar borrador(es) de compra' }}
            </button>
          </div>

          <table>
            <thead>
              <tr>
                <th><input type="checkbox" [checked]="todasElegidas()" (change)="alternarTodas($any($event.target).checked)" /></th>
                <th>Producto</th><th>Stock</th><th>Mín.</th><th>En camino</th><th>Ventas/sem.</th>
                <th>Días de stock</th><th>Pedir</th><th>P. compra</th><th>Proveedor</th>
              </tr>
            </thead>
            <tbody>
              @for (f of filas(); track f.producto_id) {
                <tr [class.fila-urgente]="f.urgencia === 'urgente'">
                  <td><input type="checkbox" [(ngModel)]="f.elegida" [name]="'e' + f.producto_id" /></td>
                  <td data-label="Producto">
                    {{ f.nombre }}
                    <span class="badge" [class.badge-danger]="f.urgencia === 'urgente'" [class.badge-warn]="f.urgencia === 'pronto'" [class.badge-info]="f.urgencia === 'normal'">{{ f.urgencia }}</span>
                  </td>
                  <td data-label="Stock">{{ f.stock }}</td>
                  <td data-label="Mín.">{{ f.stock_minimo }}</td>
                  <td data-label="En camino">{{ f.en_camino }}</td>
                  <td data-label="Ventas/sem.">{{ f.ventas_por_semana }}</td>
                  <td data-label="Días de stock">{{ f.dias_stock === null ? 'sin ventas' : f.dias_stock }}</td>
                  <td data-label="Pedir">
                    <input class="num" type="number" min="1" [step]="f.unidades_por_paquete || 1" [(ngModel)]="f.cantidad" [name]="'c' + f.producto_id" />
                    @if (f.unidades_por_paquete > 1) { <small>(caja de {{ f.unidades_por_paquete }})</small> }
                  </td>
                  <td data-label="P. compra">Bs {{ f.precio.toFixed(2) }}</td>
                  <td data-label="Proveedor">
                    <select [(ngModel)]="f.proveedor_id" [name]="'p' + f.producto_id">
                      <option [ngValue]="null">{{ proveedorDefecto ? '(el de arriba)' : '— elegir —' }}</option>
                      @for (p of datos()!.proveedores; track p.id) { <option [ngValue]="p.id">{{ p.nombre }}</option> }
                    </select>
                  </td>
                </tr>
              }
            </tbody>
          </table>
          <p class="nota">La cantidad sugerida cubre {{ datos()!.parametros.dias_cobertura }} días de venta + {{ datos()!.parametros.dias_entrega }} de entrega, nunca baja del stock mínimo y descuenta lo que ya está pedido y no llegó. El proveedor y el precio salen de la última compra de cada producto.</p>
        }
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .chk { display: flex; gap: 8px; align-items: center; font-size: 13px; text-transform: none; }
    .resumen { display: grid; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); gap: 12px; margin: 14px 0; }
    .lbl { display: block; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; opacity: 0.75; margin-bottom: 4px; }
    .barra-gen { display: flex; gap: 14px; align-items: flex-end; flex-wrap: wrap; margin-bottom: 14px; }
    .fila-urgente td { background: rgba(214, 69, 69, 0.08); }
    input.num { width: 84px; }
    small { opacity: 0.7; display: block; font-size: 11px; }
    .nota { font-size: 12px; opacity: 0.75; margin-top: 10px; }
  `],
})
export class ReposicionComponent implements OnInit {
  private servicio = inject(ReposicionService);
  private router = inject(Router);

  diasHistorial = 28;
  diasCobertura = 14;
  diasEntrega = 3;
  verTodos = false;
  proveedorDefecto: number | null = null;

  datos = signal<RespuestaReposicion | null>(null);
  filas = signal<FilaRepo[]>([]);
  cargando = signal(false);
  generando = signal(false);
  error = signal('');
  ok = signal('');

  seleccionadas = computed(() => this.filas().filter((f) => f.elegida && f.cantidad > 0));
  todasElegidas = computed(() => this.filas().length > 0 && this.filas().every((f) => f.elegida));

  ngOnInit(): void { this.calcular(); }

  costoSeleccion(): number {
    return this.seleccionadas().reduce((t, f) => t + f.cantidad * f.precio, 0);
  }

  calcular(): void {
    this.cargando.set(true);
    this.error.set('');
    this.ok.set('');
    this.servicio.sugerencias({
      dias_historial: this.diasHistorial, dias_cobertura: this.diasCobertura,
      dias_entrega: this.diasEntrega, todos: this.verTodos,
    }).subscribe({
      next: (r) => {
        this.datos.set(r);
        this.filas.set(r.items.map((i) => ({
          producto_id: i.producto_id, codigo: i.codigo, nombre: i.nombre, stock: i.stock,
          stock_minimo: i.stock_minimo, en_camino: i.en_camino, ventas_por_semana: i.ventas_por_semana,
          dias_stock: i.dias_stock, unidades_por_paquete: i.unidades_por_paquete, urgencia: i.urgencia,
          precio: i.precio_compra, cantidad: i.cantidad_sugerida, proveedor_id: i.proveedor_id,
          // Por defecto se marca lo que realmente hace falta.
          elegida: i.cantidad_sugerida > 0 && i.urgencia !== 'normal',
        })));
        this.cargando.set(false);
      },
      error: () => { this.error.set('No se pudo calcular la reposición.'); this.cargando.set(false); },
    });
  }

  alternarTodas(valor: boolean): void {
    this.filas.update((fs) => fs.map((f) => ({ ...f, elegida: valor })));
  }

  generar(): void {
    const items = this.seleccionadas().map((f) => ({
      producto_id: f.producto_id, cantidad: f.cantidad, precio_unitario: f.precio, proveedor_id: f.proveedor_id,
    }));

    this.generando.set(true);
    this.error.set('');
    this.ok.set('');

    this.servicio.generarBorradores(items, this.proveedorDefecto).subscribe({
      next: (r) => {
        this.generando.set(false);
        this.ok.set(r.message + ' Revísalos en Compras antes de enviarlos al proveedor.');
        // Recalcula: lo recién pedido pasa a "en camino" y baja la sugerencia.
        this.calcular();
        setTimeout(() => this.router.navigate(['/pedidos-compra']), 1800);
      },
      error: (err) => {
        this.generando.set(false);
        this.error.set(err?.error?.message ?? 'No se pudieron generar los borradores.');
      },
    });
  }
}
