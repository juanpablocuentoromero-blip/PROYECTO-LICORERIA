import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { PasswordRecuperacionService, TipoCuenta } from '../../core/services/password-recuperacion.service';

@Component({
  selector: 'app-olvide-password',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="wrap">
      <div class="card">
        <div class="brand">
          <img src="brand/logo-al-paso.png" alt="Licorería Al Paso" height="46" />
        </div>

        @if (!enviado()) {
          <p class="subtitle">
            Escribe el correo de tu cuenta {{ tipo() === 'usuario' ? 'de personal' : 'de cliente' }}
            y te mandamos un enlace para poner una contraseña nueva.
          </p>

          <form (ngSubmit)="enviar()">
            <div class="field">
              <label for="email">Correo</label>
              <input id="email" type="email" [(ngModel)]="email" name="email" required autocomplete="username" />
            </div>

            @if (error()) { <p class="error">{{ error() }}</p> }

            <button type="submit" class="btn-primary" [disabled]="cargando()">
              {{ cargando() ? 'Enviando…' : 'Enviar enlace' }}
            </button>
          </form>
        } @else {
          <p class="subtitle exito">
            Si <strong>{{ email }}</strong> está registrado, te llegará un correo con el enlace para
            restablecer tu contraseña. Revisa también la carpeta de spam.
          </p>
        }

        <p class="volver-hint">
          @if (tipo() === 'usuario') {
            <a routerLink="/login">← Volver a iniciar sesión</a>
          } @else {
            <a routerLink="/acceso">← Volver a iniciar sesión</a>
          }
        </p>
      </div>
    </div>
  `,
  styles: [`
    :host {
      --verde-botella-oscuro: #01001A;
      --cobre: #00D4FF;
      --cobre-claro: #00D4FF;
      --papel: #EAFBFF;
      --papel-borde: #00D4FF;
      --tinta: #020024;
      display: block;
      min-height: calc(100dvh - var(--altura-nav, 0px));
      background: var(--verde-botella-oscuro);
      font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
    }
    .wrap { display: flex; align-items: center; justify-content: center; min-height: calc(100dvh - var(--altura-nav, 0px)); padding: 24px; }
    .card {
      width: 100%; max-width: 380px;
      background: var(--papel);
      border: 1px solid var(--papel-borde);
      border-radius: 14px;
      padding: 32px 28px;
      box-shadow: 0 16px 40px rgba(0,0,0,0.35);
    }
    .brand { display: flex; align-items: center; margin-bottom: 6px; }
    .brand img { display: block; }
    .subtitle { font-size: 13px; color: #5a5140; margin: 0 0 20px; line-height: 1.5; }
    .subtitle.exito { color: #2c5a3f; }
    .field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 16px; }
    .field label { font-size: 13px; font-weight: 600; color: var(--tinta); }
    .field input {
      border: 1px solid var(--papel-borde);
      border-radius: 8px;
      padding: 10px 12px;
      font-size: 14px;
      font-family: inherit;
      background: #fff;
      color: var(--tinta);
      width: 100%;
      box-sizing: border-box;
    }
    .field input:focus { outline: 2px solid var(--cobre-claro); outline-offset: 1px; }
    .error { color: #d64545; font-size: 13px; margin: -6px 0 14px; }
    .btn-primary {
      width: 100%;
      background: var(--cobre);
      color: #1a1409;
      border: none;
      border-radius: 8px;
      padding: 11px 20px;
      font-weight: 700;
      font-size: 14px;
      cursor: pointer;
    }
    .btn-primary:hover:not(:disabled) { background: var(--cobre-claro); }
    .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
    .volver-hint { text-align: center; font-size: 12px; margin: 20px 0 0; }
    .volver-hint a { color: #8a7a56; text-decoration: none; }
    .volver-hint a:hover { text-decoration: underline; }
  `],
})
export class OlvidePasswordComponent {
  private recuperacion = inject(PasswordRecuperacionService);
  private route = inject(ActivatedRoute);

  tipo = signal<TipoCuenta>('cliente');
  email = '';
  cargando = signal(false);
  error = signal('');
  enviado = signal(false);

  constructor() {
    const tipoParam = this.route.snapshot.queryParamMap.get('tipo');
    if (tipoParam === 'usuario' || tipoParam === 'cliente') {
      this.tipo.set(tipoParam);
    }
  }

  enviar(): void {
    if (!this.email) return;
    this.cargando.set(true);
    this.error.set('');

    this.recuperacion.solicitar(this.email, this.tipo()).subscribe({
      next: () => {
        this.cargando.set(false);
        this.enviado.set(true);
      },
      error: () => {
        this.cargando.set(false);
        this.error.set('No se pudo enviar el enlace. Intenta de nuevo en un momento.');
      },
    });
  }
}
