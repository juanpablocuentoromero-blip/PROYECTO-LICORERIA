import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductoService } from '../../core/services/producto.service';
import { CategoriaService } from '../../core/services/categoria.service';
import { Producto, ProductoPayload } from '../../core/models/producto.model';
import { Categoria } from '../../core/models/categoria.model';
import { AuthService } from '../../core/services/auth.service';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';
import { BASE_THEME } from '../../shared/theme/theme';
import { AuditoriaService } from '../../core/services/auditoria.service';
import { HistorialPrecios } from '../../core/models/paso4.model';
import { PaginadorComponent } from '../../shared/paginador/paginador.component';

interface FormularioProducto {
  categoria_id: number | null;
  codigo: string;
  codigo_barras: string;
  unidades_por_paquete: number | null;
  unidades_por_caja: number | null;
  nombre: string;
  descripcion: string;
  imagen: string;
  precio_compra: number | null;
  precio_venta: number | null;
  margen_porcentaje: number | null;
  stock: number | null;
  stock_minimo: number | null;
  fecha_vencimiento: string;
  numero_lote: string;
  activo: boolean;
}

function formularioVacio(): FormularioProducto {
  return {
    categoria_id: null,
    codigo: '',
    codigo_barras: '',
    unidades_por_paquete: null,
    unidades_por_caja: null,
    nombre: '',
    descripcion: '',
    imagen: '',
    precio_compra: null,
    precio_venta: null,
    margen_porcentaje: null,
    stock: 0,
    stock_minimo: 0,
    fecha_vencimiento: '',
    numero_lote: '',
    activo: true,
  };
}

@Component({
  selector: 'app-productos',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginadorComponent],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Inventario &middot; Catálogo</div>
          <h1>Productos</h1>
          <p class="subtitle">Alta, edición y baja de productos. El catálogo público solo muestra lectura.</p>
        </div>
      </header>

      @if (!esAdmin()) {
        <div class="panel"><p class="form-error" style="margin:0">Solo un usuario con rol "administrador" puede crear, editar o eliminar productos.</p></div>
      }

      <section class="composer" [class.open]="formAbierto()">
        <button class="composer-toggle" [disabled]="!esAdmin()" (click)="toggleForm()">
          <span class="plus" [class.rotated]="formAbierto()">+</span>
          {{ editandoId() ? 'Editando producto' : (formAbierto() ? 'Cerrar' : 'Nuevo producto') }}
        </button>

        @if (formAbierto()) {
          <form class="composer-form" (ngSubmit)="guardar()">
            <div class="form-grid">
              <div class="field">
                <label>Categoría</label>
                <select [(ngModel)]="form.categoria_id" name="categoria_id" required>
                  <option [ngValue]="null">Selecciona…</option>
                  @for (c of categorias(); track c.id) { <option [ngValue]="c.id">{{ c.nombre }}</option> }
                </select>
              </div>
              <div class="field">
                <label>Código</label>
                <input type="text" [(ngModel)]="form.codigo" name="codigo" required autocomplete="off" />
              </div>
              <div class="field">
                <label>Código de barras <span>(opcional)</span></label>
                <input type="text" [(ngModel)]="form.codigo_barras" name="codigo_barras" autocomplete="off" />
              </div>
              <div class="field">
                <label>Unidades por paquete <span>(opcional, ej. 6)</span></label>
                <input type="number" min="1" [(ngModel)]="form.unidades_por_paquete" name="unidades_por_paquete" />
              </div>
              <div class="field">
                <label>Unidades por caja <span>(opcional, ej. 12)</span></label>
                <input type="number" min="1" [(ngModel)]="form.unidades_por_caja" name="unidades_por_caja" />
                <span class="hint">Con esto el cliente y el vendedor pueden pedir por unidad, paquete o caja.</span>
              </div>
              <div class="field" style="grid-column: 1 / -1;">
                <label>Nombre</label>
                <input type="text" [(ngModel)]="form.nombre" name="nombre" required autocomplete="off" />
              </div>
              <div class="field" style="grid-column: 1 / -1;">
                <label>Descripción <span>(opcional)</span></label>
                <textarea [(ngModel)]="form.descripcion" name="descripcion" rows="2"></textarea>
              </div>
              <div class="field">
                <label>Imagen (URL) <span>(opcional)</span></label>
                <input type="text" [(ngModel)]="form.imagen" name="imagen" placeholder="Deja vacío para usar la imagen por defecto" />
              </div>
              <div class="field">
                <label>Precio de compra (Bs)</label>
                <input type="number" min="0" step="0.01" [(ngModel)]="form.precio_compra" (ngModelChange)="recalcularPrecio()" name="precio_compra" required />
              </div>
              <div class="field">
                <label>Margen de ganancia (%) <span>(opcional, calcula el precio solo)</span></label>
                <input type="number" min="0" max="1000" step="0.1" [(ngModel)]="form.margen_porcentaje" (ngModelChange)="recalcularPrecio()" name="margen_porcentaje" placeholder="Ej. 40" />
              </div>
              <div class="field">
                <label>Precio de venta (Bs)</label>
                <input type="number" min="0" step="0.01" [(ngModel)]="form.precio_venta" name="precio_venta" required />
                @if (form.margen_porcentaje !== null && form.margen_porcentaje !== undefined) {
                  <small class="ayuda-margen">Con margen: al comprar a otro costo, el precio se recalcula solo.</small>
                }
              </div>
              <div class="field">
                <label>Stock inicial (almacén Principal)</label>
                <input type="number" min="0" [(ngModel)]="form.stock" name="stock" [disabled]="!!editandoId()" />
                @if (editandoId()) {
                  <span class="hint">Para corregir el stock usa Inventario &rarr; movimiento manual.</span>
                }
              </div>
              @if (!editandoId()) {
                <div class="field">
                  <label>N.º de lote <span>(opcional)</span></label>
                  <input type="text" maxlength="100" [(ngModel)]="form.numero_lote" name="numero_lote" placeholder="Ej. L-2410" />
                </div>
                <div class="field">
                  <label>Vencimiento del lote <span>(opcional)</span></label>
                  <input type="date" [(ngModel)]="form.fecha_vencimiento" name="fecha_vencimiento" />
                  <span class="hint">Una sola fecha para todo el lote (todas las unidades que entran juntas).</span>
                </div>
              } @else {
                <div class="field">
                  <label>Vencimiento</label>
                  <span class="hint">Se maneja por lote: registra nuevas entradas con su fecha en Inventario o Compras.</span>
                </div>
              }
              <div class="field">
                <label>Stock mínimo</label>
                <input type="number" min="0" [(ngModel)]="form.stock_minimo" name="stock_minimo" />
              </div>
              <div class="field field-checkbox">
                <label><input type="checkbox" [(ngModel)]="form.activo" name="activo" /> Activo</label>
              </div>
            </div>

            <div class="field-row" style="margin-top:14px">
              <button type="submit" class="btn-primary" [disabled]="guardando() || !formValido()">
                {{ guardando() ? 'Guardando…' : (editandoId() ? 'Guardar cambios' : 'Crear producto') }}
              </button>
              @if (editandoId()) {
                <button type="button" class="btn-secondary" (click)="cancelarEdicion()">Cancelar edición</button>
              }
              @if (error()) { <span class="form-error">{{ error() }}</span> }
            </div>
          </form>
        }
      </section>

      <section class="panel">
        <div class="field-row" style="margin-bottom:14px">
          <input type="text" [(ngModel)]="buscar" name="buscar" placeholder="Buscar por nombre o código…" (ngModelChange)="cargar()" />
        </div>

        @if (cargando()) {
          <div class="estado-vacio"><div class="spinner"></div><p>Cargando productos…</p></div>
        } @else if (productos().length === 0) {
          <div class="estado-vacio"><p>No se encontraron productos.</p></div>
        } @else {
          <table>
            <thead><tr><th>Código</th><th>Nombre</th><th>Categoría</th><th>Precio venta</th><th>Stock</th><th>Estado</th><th></th></tr></thead>
            <tbody>
              @for (p of productos(); track p.id) {
                <tr>
                  <td data-label="Código">{{ p.codigo }}</td>
                  <td data-label="Nombre">{{ p.nombre }}</td>
                  <td data-label="Categoría">{{ p.categoria?.nombre || '—' }}</td>
                  <td data-label="Precio venta">Bs {{ p.precio_venta }}</td>
                  <td data-label="Stock">
                    {{ p.stock }}
                    @if (p.stock <= p.stock_minimo) { <span class="badge badge-off">Bajo</span> }
                  </td>
                  <td data-label="Estado">
                    <span class="badge" [class.badge-off]="!p.activo">{{ p.activo ? 'Activo' : 'Inactivo' }}</span>
                  </td>
                  <td data-label="Acciones">
                    <button class="link-action" [disabled]="!esAdmin()" (click)="editar(p)">Editar</button>
                    @if (esAdmin()) { <button class="link-action" (click)="verHistorialPrecios(p)">Precios</button> }
                    <button class="link-danger" [disabled]="!esAdmin()" (click)="eliminar(p)">Eliminar</button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
          <app-paginador [actual]="paginaActual()" [ultima]="ultimaPagina()" [total]="totalRegistros()"
                         etiqueta="productos" (cambiar)="cargar($event)" />
        }
      </section>

      @if (historial() || cargandoHistorial()) {
        <div class="hp-fondo" (click)="cerrarHistorial()"></div>
        <section class="hp-modal" role="dialog" aria-label="Historial de precios">
          <header>
            <strong>Historial de precios{{ historial() ? ': ' + historial()!.producto.nombre : '' }}</strong>
            <button type="button" class="hp-x" (click)="cerrarHistorial()" aria-label="Cerrar">✕</button>
          </header>
          @if (cargandoHistorial()) {
            <div class="estado-vacio"><div class="spinner"></div></div>
          } @else if (historial(); as h) {
            <p class="hp-actual">
              Hoy: compra <strong>Bs {{ h.producto.precio_compra.toFixed(2) }}</strong> ·
              venta <strong>Bs {{ h.producto.precio_venta.toFixed(2) }}</strong>
            </p>
            @if (h.cambios.length === 0) {
              <p class="hp-vacio">Todavía no hay cambios de precio registrados (el registro empezó con la auditoría).</p>
            } @else {
              <table>
                <thead><tr><th>Fecha</th><th>Quién</th><th>Precio</th><th>Antes</th><th>Después</th></tr></thead>
                <tbody>
                  @for (c of h.cambios; track c.id) {
                    <tr>
                      <td data-label="Fecha">{{ fechaHora(c.created_at) }}</td>
                      <td data-label="Quién">{{ c.usuario_nombre || '—' }}</td>
                      <td data-label="Precio">{{ c.campo === 'precio_compra' ? 'Compra' : 'Venta' }}{{ c.accion === 'crear' ? ' (inicial)' : '' }}</td>
                      <td data-label="Antes">{{ c.valor_anterior ?? '—' }}</td>
                      <td data-label="Después"><strong>{{ c.valor_nuevo ?? '—' }}</strong></td>
                    </tr>
                  }
                </tbody>
              </table>
            }
          }
        </section>
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .ayuda-margen { color: #5FB8CC; font-size: 12px; margin-top: 4px; display: block; }
    .hp-fondo { position: fixed; inset: 0; background: rgba(0, 0, 0, 0.55); z-index: 1100; }
    .hp-modal { position: fixed; z-index: 1110; top: 50%; left: 50%; transform: translate(-50%, -50%); width: min(640px, calc(100vw - 24px)); max-height: 80vh; overflow: auto; background: #020024; color: #E8FBFF; border: 1px solid rgba(0, 212, 255, 0.45); border-radius: 12px; padding: 16px 18px; }
    .hp-modal header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
    .hp-x { background: transparent; border: 0; color: inherit; cursor: pointer; font-size: 16px; }
    .hp-actual { margin: 0 0 12px; font-size: 14px; }
    .hp-vacio { opacity: 0.8; font-size: 14px; }
    .composer { background: var(--verde-botella); border: 1px solid #2c4536; border-radius: 14px; padding: 16px 20px; margin-bottom: 28px; }
    .composer-toggle { background: none; border: none; color: var(--cobre-claro); font-size: 15px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 10px; padding: 4px 0; }
    .composer-toggle:disabled { opacity: 0.5; cursor: not-allowed; }
    .plus { display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; border-radius: 50%; border: 1.5px solid var(--cobre-claro); font-size: 16px; line-height: 1; transition: transform 0.25s ease; }
    .plus.rotated { transform: rotate(45deg); }
    .composer-form { margin-top: 18px; }
    .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; }
    .field { display: flex; flex-direction: column; gap: 6px; }
    .field label { font-size: 13px; font-weight: 600; color: #00D4FF; }
    .field label span { font-weight: 400; color: #5FB8CC; }
    .field input, .field select, .field textarea {
      background: var(--papel); border: 1px solid var(--papel-borde); border-radius: 8px;
      padding: 8px 10px; font-size: 14px; font-family: inherit; color: var(--tinta); resize: vertical;
    }
    .field input:disabled { opacity: 0.6; }
    .field-checkbox label { display: flex; align-items: center; gap: 8px; font-size: 14px; color: #00D4FF; }
    .hint { font-size: 12px; color: #8FD3E6; }
    .field-row { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; }
    .field-row input[type="text"] { min-width: 260px; }
  `],
})
export class ProductosComponent implements OnInit {
  private productoService = inject(ProductoService);
  private auditoriaService = inject(AuditoriaService);

  // 4.4 Historial de precios
  historial = signal<HistorialPrecios | null>(null);
  cargandoHistorial = signal(false);
  private categoriaService = inject(CategoriaService);
  private confirmDialog = inject(ConfirmDialogService);
  private auth = inject(AuthService);

  productos = signal<Producto[]>([]);
  categorias = signal<Categoria[]>([]);
  cargando = signal(true);
  guardando = signal(false);
  formAbierto = signal(false);
  error = signal('');
  editandoId = signal<number | null>(null);
  buscar = '';

  // 2.2 Paginación
  paginaActual = signal(1);
  ultimaPagina = signal(1);
  totalRegistros = signal(0);

  form: FormularioProducto = formularioVacio();

  formValido = computed(() => {
    return (
      !!this.form.categoria_id &&
      !!this.form.codigo.trim() &&
      !!this.form.nombre.trim() &&
      this.form.precio_compra !== null &&
      this.form.precio_venta !== null
    );
  });

  verHistorialPrecios(p: Producto): void {
    this.historial.set(null);
    this.cargandoHistorial.set(true);
    this.auditoriaService.historialPrecios(p.id).subscribe({
      next: (h) => { this.historial.set(h); this.cargandoHistorial.set(false); },
      error: () => { this.cargandoHistorial.set(false); this.error.set('No se pudo cargar el historial de precios.'); },
    });
  }

  cerrarHistorial(): void {
    this.historial.set(null);
    this.cargandoHistorial.set(false);
  }

  fechaHora(iso: string): string {
    return new Date(iso).toLocaleString('es-BO', {
      day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'America/La_Paz',
    });
  }

  esAdmin(): boolean {
    return this.auth.usuarioActual()?.rol === 'administrador';
  }

  ngOnInit(): void {
    this.categoriaService.listar().subscribe({ next: (data) => this.categorias.set(data) });
    this.cargar();
  }

  cargar(pagina = 1): void {
    this.cargando.set(true);
    this.productoService.listarPagina(pagina, { buscar: this.buscar || undefined }).subscribe({
      next: (res) => {
        // Si la página ya no existe (se borró el último de la última página), retrocede.
        if (pagina > res.last_page && res.last_page >= 1) { this.cargar(res.last_page); return; }
        this.productos.set(res.data);
        this.paginaActual.set(res.current_page);
        this.ultimaPagina.set(res.last_page);
        this.totalRegistros.set(res.total);
        this.cargando.set(false);
      },
      error: () => { this.error.set('No se pudo conectar con el servidor.'); this.cargando.set(false); },
    });
  }

  toggleForm(): void {
    if (!this.esAdmin()) return;
    if (this.formAbierto() && this.editandoId()) {
      this.cancelarEdicion();
      return;
    }
    this.formAbierto.set(!this.formAbierto());
    this.error.set('');
  }

  editar(p: Producto): void {
    if (!this.esAdmin()) return;
    this.editandoId.set(p.id);
    this.form = {
      categoria_id: p.categoria_id,
      codigo: p.codigo,
      codigo_barras: p.codigo_barras || '',
      unidades_por_paquete: p.unidades_por_paquete ?? null,
      unidades_por_caja: p.unidades_por_caja ?? null,
      nombre: p.nombre,
      descripcion: p.descripcion || '',
      imagen: p.imagen || '',
      precio_compra: p.precio_compra,
      precio_venta: p.precio_venta,
      margen_porcentaje: p.margen_porcentaje !== null && p.margen_porcentaje !== undefined && p.margen_porcentaje !== '' ? Number(p.margen_porcentaje) : null,
      stock: p.stock,
      stock_minimo: p.stock_minimo,
      fecha_vencimiento: '',
      numero_lote: '',
      activo: p.activo,
    };
    this.formAbierto.set(true);
    this.error.set('');
  }

  cancelarEdicion(): void {
    this.editandoId.set(null);
    this.form = formularioVacio();
    this.formAbierto.set(false);
    this.error.set('');
  }

  // Precio de venta automático: costo + margen (%). Solo actúa si hay margen
  // y costo; el precio se puede seguir corrigiendo a mano después.
  recalcularPrecio(): void {
    const costo = this.form.precio_compra;
    const margen = this.form.margen_porcentaje;
    if (costo === null || costo === undefined || margen === null || margen === undefined || isNaN(Number(costo)) || isNaN(Number(margen))) return;
    this.form.precio_venta = Math.round(Number(costo) * (1 + Number(margen) / 100) * 100) / 100;
  }

  private construirPayload(): ProductoPayload {
    const payload: ProductoPayload = {
      categoria_id: this.form.categoria_id as number,
      codigo: this.form.codigo.trim(),
      nombre: this.form.nombre.trim(),
      precio_compra: this.form.precio_compra as number,
      precio_venta: this.form.precio_venta as number,
      activo: this.form.activo,
      margen_porcentaje: this.form.margen_porcentaje !== null && this.form.margen_porcentaje !== undefined && String(this.form.margen_porcentaje) !== '' ? Number(this.form.margen_porcentaje) : null,
    };
    if (this.form.codigo_barras.trim()) payload.codigo_barras = this.form.codigo_barras.trim();
    payload.unidades_por_paquete = this.form.unidades_por_paquete || null;
    payload.unidades_por_caja = this.form.unidades_por_caja || null;
    if (this.form.descripcion.trim()) payload.descripcion = this.form.descripcion.trim();
    if (this.form.imagen.trim()) payload.imagen = this.form.imagen.trim();
    if (!this.editandoId()) {
      payload.stock = this.form.stock ?? 0;
      if (this.form.fecha_vencimiento) payload.fecha_vencimiento = this.form.fecha_vencimiento;
      if (this.form.numero_lote.trim()) payload.numero_lote = this.form.numero_lote.trim();
    }
    payload.stock_minimo = this.form.stock_minimo ?? 0;
    return payload;
  }

  guardar(): void {
    if (!this.esAdmin() || !this.formValido()) return;
    this.guardando.set(true);
    this.error.set('');

    const payload = this.construirPayload();
    const id = this.editandoId();
    const peticion = id ? this.productoService.actualizar(id, payload) : this.productoService.crear(payload);

    peticion.subscribe({
      next: () => {
        // Se recarga la página actual: con paginación ya no basta con tocar la lista local.
        this.cargar(this.paginaActual());
        this.cancelarEdicion();
        this.guardando.set(false);
      },
      error: (err) => {
        this.error.set(err?.error?.message || 'No se pudo guardar. Revisa los datos e intenta de nuevo.');
        this.guardando.set(false);
      },
    });
  }

  async eliminar(p: Producto): Promise<void> {
    if (!this.esAdmin()) return;
    const ok = await this.confirmDialog.confirm({
      titulo: 'Eliminar producto',
      mensaje: `¿Estás seguro de que quieres eliminar el producto "${p.nombre}"?`,
      textoConfirmar: 'Sí, eliminar',
      peligroso: true,
    });
    if (!ok) return;

    this.productoService.eliminar(p.id).subscribe({
      next: () => this.cargar(this.paginaActual()),
      error: (err: any) => this.error.set(err?.error?.message || 'No se pudo eliminar el producto.'),
    });
  }
}
