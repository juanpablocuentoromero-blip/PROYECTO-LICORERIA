import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AjusteInventarioService } from '../../core/services/ajuste-inventario.service';
import { LoteProducto } from '../../core/models/lote.model';
import { BASE_THEME } from '../../shared/theme/theme';

// Lotes con unidades en stock, ordenados por vencimiento (el que vence antes
// primero). Lo pueden consultar administrador y vendedor.
@Component({
  selector: 'app-lotes-vencimientos',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="panel">
      <div class="cabecera">
        <h3 class="panel-title">Lotes y vencimientos</h3>
        <div class="field filtro">
          <label>Mostrar</label>
          <select [ngModel]="filtro()" (ngModelChange)="cambiarFiltro($event)" name="filtroLotes">
            <option value="">Todos los lotes con stock</option>
            <option value="0">Ya vencidos</option>
            <option value="30">Vencen en 30 días o menos</option>
            <option value="60">Vencen en 60 días o menos</option>
            <option value="90">Vencen en 90 días o menos</option>
          </select>
        </div>
      </div>

      @if (cargando()) {
        <div class="estado-vacio"><div class="spinner"></div></div>
      } @else if (lotes().length === 0) {
        <div class="estado-vacio"><p>No hay lotes registrados con esos criterios.</p><span>Los lotes se crean al recibir una compra con vencimiento o al ajustar stock.</span></div>
      } @else {
        <table>
          <thead><tr><th>Producto</th><th>Lote</th><th>Vence</th><th>Disponible</th><th>Inicial</th><th>Costo unit.</th><th>Estado</th></tr></thead>
          <tbody>
            @for (l of lotes(); track l.id) {
              <tr>
                <td data-label="Producto">{{ l.producto?.nombre || '—' }}</td>
                <td data-label="Lote">{{ l.numero_lote || '—' }}</td>
                <td data-label="Vence">{{ l.fecha_vencimiento ? (l.fecha_vencimiento | slice:0:10) : 'sin fecha' }}</td>
                <td data-label="Disponible"><strong>{{ l.cantidad_disponible }}</strong></td>
                <td data-label="Inicial">{{ l.cantidad_inicial }}</td>
                <td data-label="Costo unit.">{{ l.costo_unitario }}</td>
                <td data-label="Estado">
                  @if (l.dias_para_vencer === null) { <span class="badge badge-off">sin vencimiento</span> }
                  @else if (l.vencido) { <span class="badge badge-danger">vencido hace {{ -l.dias_para_vencer }} d</span> }
                  @else if (l.dias_para_vencer <= 30) { <span class="badge badge-warn">vence en {{ l.dias_para_vencer }} d</span> }
                  @else { <span class="badge badge-ok">{{ l.dias_para_vencer }} d</span> }
                </td>
              </tr>
            }
          </tbody>
        </table>
      }
    </section>
  `,
  styles: [BASE_THEME, `
    .cabecera { display: flex; justify-content: space-between; align-items: flex-end; gap: 12px; flex-wrap: wrap; margin-bottom: 12px; }
    .panel-title { font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif; font-size: 20px; color: var(--papel); margin: 0; }
    .filtro { min-width: 240px; }
  `],
})
export class LotesVencimientosComponent implements OnInit {
  private ajusteService = inject(AjusteInventarioService);

  lotes = signal<LoteProducto[]>([]);
  cargando = signal(true);
  filtro = signal('');

  ngOnInit(): void {
    this.cargar();
  }

  cambiarFiltro(v: string): void {
    this.filtro.set(v);
    this.cargar();
  }

  cargar(): void {
    this.cargando.set(true);
    const dias = this.filtro();
    this.ajusteService.lotes(dias !== '' ? { vence_en_dias: Number(dias) } : undefined).subscribe({
      next: (d) => { this.lotes.set(d); this.cargando.set(false); },
      error: () => this.cargando.set(false),
    });
  }
}
