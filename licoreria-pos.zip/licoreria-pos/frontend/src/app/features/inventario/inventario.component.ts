import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MovimientoService } from '../../core/services/movimiento.service';
import { ProductoService } from '../../core/services/producto.service';
import { AuthService } from '../../core/services/auth.service';
import { MovimientoInventario } from '../../core/models/movimiento.model';
import { Producto } from '../../core/models/producto.model';
import { BASE_THEME } from '../../shared/theme/theme';
import { PaginadorComponent } from '../../shared/paginador/paginador.component';
import { AjusteInventarioComponent } from './ajuste-inventario.component';
import { LotesVencimientosComponent } from './lotes-vencimientos.component';

@Component({
  selector: 'app-inventario',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginadorComponent, AjusteInventarioComponent, LotesVencimientosComponent],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Inventario &middot; Movimientos</div>
          <h1>Inventario</h1>
          <p class="subtitle">Entradas, salidas y ajustes de stock, con trazabilidad completa.</p>
        </div>
      </header>

      @if (productosStockBajo().length > 0) {
        <div class="panel alerta">
          <strong>Stock bajo:</strong>
          {{ productosStockBajo().length }} producto(s) están en o por debajo de su stock mínimo —
          {{ nombresStockBajo() }}
        </div>
      }

      @if (!esAdmin()) {
        <div class="panel"><p class="form-error" style="margin:0">Puedes consultar el inventario y sus movimientos, pero solo un administrador puede registrar ajustes de stock.</p></div>
      }

      @if (esAdmin()) {
      <section class="panel">
        <h3 class="panel-title">Registrar movimiento manual</h3>
        <form class="form-grid" (ngSubmit)="registrar()">
          <div class="field">
            <label>Producto</label>
            <select [(ngModel)]="form.producto_id" name="producto_id" required>
              <option [ngValue]="null">Selecciona…</option>
              @for (p of productos(); track p.id) { <option [ngValue]="p.id">{{ p.nombre }} (stock: {{ p.stock }})</option> }
            </select>
          </div>
          <div class="field">
            <label>Tipo</label>
            <select [(ngModel)]="form.tipo" name="tipo">
              <option value="entrada">Entrada (compra/ajuste +)</option>
              <option value="salida">Salida (merma/ajuste -)</option>
            </select>
          </div>
          <div class="field">
            <label>Cantidad</label>
            <input type="number" min="1" [(ngModel)]="form.cantidad" name="cantidad" required />
          </div>
          @if (form.tipo === 'entrada') {
            <div class="field">
              <label>Vencimiento <span>(opcional, crea un lote)</span></label>
              <input type="date" [(ngModel)]="form.fecha_vencimiento" name="fecha_vencimiento" />
            </div>
            <div class="field">
              <label>N.º de lote <span>(opcional)</span></label>
              <input type="text" [(ngModel)]="form.numero_lote" name="numero_lote" maxlength="100" />
            </div>
          }
          <div class="field">
            <label>Motivo <span>(opcional)</span></label>
            <input type="text" [(ngModel)]="form.motivo" name="motivo" placeholder="Ej. Compra a proveedor, merma por rotura" />
          </div>
          <div class="field-row" style="grid-column: 1/-1">
            <button type="submit" class="btn-primary" [disabled]="guardando() || !form.producto_id">
              {{ guardando() ? 'Registrando…' : 'Registrar movimiento' }}
            </button>
            @if (error()) { <span class="form-error">{{ error() }}</span> }
          </div>
        </form>
      </section>
      }

      @if (esAdmin()) {
        <app-ajuste-inventario (aplicado)="alAjustar()" />
      }

      <app-lotes-vencimientos />

      <h3 class="panel-title" style="margin: 0">Historial de movimientos</h3>
      @if (cargando()) {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando movimientos…</p></div>
      } @else if (movimientos().length === 0) {
        <div class="estado-vacio"><p>Todavía no hay movimientos registrados.</p></div>
      } @else {
        <table>
          <thead><tr><th>Producto</th><th>Tipo</th><th>Cantidad</th><th>Stock resultante</th><th>Motivo</th><th>Usuario</th><th>Fecha</th></tr></thead>
          <tbody>
            @for (m of movimientos(); track m.id) {
              <tr>
                <td data-label="Producto">{{ m.producto?.nombre || '—' }}</td>
                <td data-label="Tipo"><span class="badge" [class.badge-ok]="m.tipo==='entrada'" [class.badge-danger]="m.tipo==='salida'">{{ m.tipo }}</span></td>
                <td data-label="Cantidad">{{ m.cantidad }}</td>
                <td data-label="Stock resultante">{{ m.stock_resultante }}</td>
                <td data-label="Motivo">{{ m.motivo || '—' }}@if (m.es_ajuste) { <span class="badge badge-info">ajuste</span> }</td>
                <td data-label="Usuario">{{ m.usuario?.nombre || '—' }}</td>
                <td data-label="Fecha">{{ m.created_at ? (m.created_at | slice:0:16) : '—' }}</td>
              </tr>
            }
          </tbody>
        </table>
        <app-paginador [actual]="paginaActual()" [ultima]="ultimaPagina()" [total]="totalRegistros()"
                       etiqueta="movimientos" (cambiar)="cargar($event)" />
      }

      <section class="panel">
        <h3 class="panel-title">Listado de productos</h3>
        <div class="field" style="max-width: 320px; margin-bottom: 14px;">
          <label>Buscar</label>
          <input type="text" [(ngModel)]="filtroProducto" name="filtroProducto" placeholder="Código, código de barras o nombre" />
        </div>
        @if (!esAdmin()) {
          <p class="form-error" style="margin: 0 0 12px">Solo un usuario con rol "administrador" puede editar productos.</p>
        }
        <table>
          <thead>
            <tr>
              <th>Código</th>
              <th>Código de barras</th>
              <th>Descripción</th>
              <th>Unid./Paq.</th>
              <th>Precio venta</th>
              <th>Saldo Stock</th>
              <th>Stock mínimo</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            @for (p of productosFiltrados(); track p.id) {
              @if (editandoProductoId() === p.id) {
                <tr class="fila-edicion">
                  <td data-label="Código">{{ p.codigo }}</td>
                  <td data-label="Código de barras">
                    <div class="field"><input type="text" [(ngModel)]="productoForm.codigo_barras" name="codigo_barras_{{p.id}}" /></div>
                  </td>
                  <td data-label="Descripción">
                    <div class="field"><input type="text" [(ngModel)]="productoForm.nombre" name="nombre_{{p.id}}" required /></div>
                  </td>
                  <td data-label="Unid./Paq.">
                    <div class="field"><input type="number" min="1" [(ngModel)]="productoForm.unidades_por_paquete" name="unidades_{{p.id}}" /></div>
                  </td>
                  <td data-label="Precio venta">
                    <div class="field"><input type="number" min="0" step="0.01" [(ngModel)]="productoForm.precio_venta" name="precio_venta_{{p.id}}" required /></div>
                  </td>
                  <td data-label="Saldo Stock">
                    <div class="field"><input type="number" min="0" [(ngModel)]="productoForm.stock" name="stock_{{p.id}}" required /></div>
                  </td>
                  <td data-label="Stock mínimo">
                    <div class="field"><input type="number" min="0" [(ngModel)]="productoForm.stock_minimo" name="stock_minimo_{{p.id}}" required /></div>
                  </td>
                  <td data-label="Acciones">
                    <button class="link-action" [disabled]="guardandoProducto()" (click)="guardarProducto(p)">
                      {{ guardandoProducto() ? 'Guardando…' : 'Guardar' }}
                    </button>
                    <button class="link-danger" [disabled]="guardandoProducto()" (click)="cancelarEdicionProducto()">Cancelar</button>
                    @if (errorProducto()) { <div class="form-error" style="margin-top:6px">{{ errorProducto() }}</div> }
                  </td>
                </tr>
              } @else {
                <tr [class.badge-danger]="p.stock <= p.stock_minimo">
                  <td data-label="Código">{{ p.codigo }}</td>
                  <td data-label="Código de barras">{{ p.codigo_barras || '—' }}</td>
                  <td data-label="Descripción">{{ p.nombre }}</td>
                  <td data-label="Unid./Paq.">{{ p.unidades_por_paquete || '—' }}</td>
                  <td data-label="Precio venta">{{ p.precio_venta | number:'1.2-2' }}</td>
                  <td data-label="Saldo Stock">{{ p.stock }}</td>
                  <td data-label="Stock mínimo">{{ p.stock_minimo }}</td>
                  <td data-label="Acciones">
                    <button class="link-action" [disabled]="!esAdmin()" (click)="editarProducto(p)">Editar</button>
                  </td>
                </tr>
              }
            }
          </tbody>
        </table>
      </section>
    </div>
  `,
  styles: [BASE_THEME, `
    .panel-title { font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif; font-size: 20px; color: var(--papel); margin: 0 0 14px; }
    .alerta { border-color: var(--rust); background: #2a1c17; color: #f2c39a; font-size: 14px; }
    .fila-edicion td { vertical-align: top; padding-top: 10px; }
    .fila-edicion .field { min-width: 90px; }
    .fila-edicion input { padding: 6px 8px; }
  `],
})
export class InventarioComponent implements OnInit {
  private movimientoService = inject(MovimientoService);
  private productoService = inject(ProductoService);
  private auth = inject(AuthService);

  movimientos = signal<MovimientoInventario[]>([]);
  productos = signal<Producto[]>([]);
  cargando = signal(true);

  // 2.2 Paginación del historial de movimientos
  paginaActual = signal(1);
  ultimaPagina = signal(1);
  totalRegistros = signal(0);
  guardando = signal(false);
  error = signal('');
  filtroProducto = '';

  editandoProductoId = signal<number | null>(null);
  guardandoProducto = signal(false);
  errorProducto = signal('');
  productoForm: {
    nombre: string;
    codigo_barras: string;
    unidades_por_paquete: number | null;
    precio_venta: number;
    stock: number;
    stock_minimo: number;
  } = { nombre: '', codigo_barras: '', unidades_por_paquete: null, precio_venta: 0, stock: 0, stock_minimo: 0 };

  form: {
    producto_id: number | null; tipo: string; cantidad: number; motivo: string;
    fecha_vencimiento: string; numero_lote: string;
  } = {
    producto_id: null,
    tipo: 'entrada',
    cantidad: 1,
    motivo: '',
    fecha_vencimiento: '',
    numero_lote: '',
  };

  // Tras un ajuste por conteo se refresca el historial y el listado de productos.
  alAjustar(): void {
    this.cargar(1);
    this.productoService.listar().subscribe({ next: (data) => this.productos.set(data) });
  }

  ngOnInit(): void {
    this.cargar();
    this.productoService.listar().subscribe({ next: (data) => this.productos.set(data) });
  }

  cargar(pagina = 1): void {
    this.cargando.set(true);
    this.movimientoService.listarPagina(pagina).subscribe({
      next: (res) => {
        if (pagina > res.last_page && res.last_page >= 1) { this.cargar(res.last_page); return; }
        this.movimientos.set(res.data);
        this.paginaActual.set(res.current_page);
        this.ultimaPagina.set(res.last_page);
        this.totalRegistros.set(res.total);
        this.cargando.set(false);
      },
      error: () => { this.error.set('No se pudo conectar con el servidor.'); this.cargando.set(false); },
    });
  }

  esAdmin(): boolean {
    return this.auth.usuarioActual()?.rol === 'administrador';
  }

  editarProducto(p: Producto): void {
    if (!this.esAdmin()) return;
    this.editandoProductoId.set(p.id);
    this.productoForm = {
      nombre: p.nombre,
      codigo_barras: p.codigo_barras || '',
      unidades_por_paquete: p.unidades_por_paquete ?? null,
      precio_venta: p.precio_venta,
      stock: p.stock,
      stock_minimo: p.stock_minimo,
    };
    this.errorProducto.set('');
  }

  cancelarEdicionProducto(): void {
    this.editandoProductoId.set(null);
    this.errorProducto.set('');
  }

  guardarProducto(p: Producto): void {
    if (!this.esAdmin()) return;

    if (!this.productoForm.nombre.trim()) {
      this.errorProducto.set('El nombre no puede estar vacío.');
      return;
    }

    this.guardandoProducto.set(true);
    this.errorProducto.set('');

    this.productoService
      .actualizar(p.id, {
        nombre: this.productoForm.nombre.trim(),
        codigo_barras: this.productoForm.codigo_barras.trim() || undefined,
        unidades_por_paquete: this.productoForm.unidades_por_paquete || undefined,
        precio_venta: this.productoForm.precio_venta,
        stock: this.productoForm.stock,
        stock_minimo: this.productoForm.stock_minimo,
      })
      .subscribe({
        next: (actualizado) => {
          this.productos.set(this.productos().map((x) => (x.id === p.id ? actualizado : x)));
          this.guardandoProducto.set(false);
          this.editandoProductoId.set(null);
        },
        error: (err) => {
          this.errorProducto.set(err?.error?.message || 'No se pudo guardar el producto.');
          this.guardandoProducto.set(false);
        },
      });
  }

  productosFiltrados(): Producto[] {
    const termino = this.filtroProducto.trim().toLowerCase();
    if (!termino) return this.productos();

    return this.productos().filter((p) =>
      p.codigo.toLowerCase().includes(termino) ||
      (p.codigo_barras || '').toLowerCase().includes(termino) ||
      p.nombre.toLowerCase().includes(termino)
    );
  }

  productosStockBajo(): Producto[] {
    return this.productos().filter((p) => p.stock <= p.stock_minimo);
  }

  nombresStockBajo(): string {
    return this.productosStockBajo().map((p) => p.nombre).join(', ');
  }

  registrar(): void {
    if (!this.esAdmin()) return;

    const usuario = this.auth.usuarioActual();
    if (!this.form.producto_id || !usuario || this.form.cantidad < 1) return;

    this.guardando.set(true);
    this.error.set('');

    this.movimientoService
      .crear({
        producto_id: this.form.producto_id,
        usuario_id: usuario.id,
        tipo: this.form.tipo,
        cantidad: this.form.cantidad,
        motivo: this.form.motivo.trim() || undefined,
        ...(this.form.tipo === 'entrada' && this.form.fecha_vencimiento ? { fecha_vencimiento: this.form.fecha_vencimiento } : {}),
        ...(this.form.tipo === 'entrada' && this.form.numero_lote.trim() ? { numero_lote: this.form.numero_lote.trim() } : {}),
      })
      .subscribe({
        next: () => {
          // El movimiento nuevo es el más reciente: se recarga desde la página 1.
          this.cargar(1);
          this.form = { producto_id: null, tipo: 'entrada', cantidad: 1, motivo: '', fecha_vencimiento: '', numero_lote: '' };
          this.guardando.set(false);
          this.productoService.listar().subscribe({ next: (data) => this.productos.set(data) });
        },
        error: (err) => {
          this.error.set(err?.error?.message || 'No se pudo registrar el movimiento.');
          this.guardando.set(false);
        },
      });
  }
}
