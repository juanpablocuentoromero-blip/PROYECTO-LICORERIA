import { Component, EventEmitter, OnInit, Output, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AjusteInventarioService } from '../../core/services/ajuste-inventario.service';
import { ProductoService } from '../../core/services/producto.service';
import { Producto } from '../../core/models/producto.model';
import { AjusteInventarioResultado } from '../../core/models/lote.model';
import { MovimientoInventario } from '../../core/models/movimiento.model';
import { BASE_THEME } from '../../shared/theme/theme';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';

interface LineaAjuste {
  producto: Producto;
  stock_sistema: number;
  stock_real: number;
  fecha_vencimiento: string;
  numero_lote: string;
}

const MOTIVOS = ['Conteo físico', 'Merma / rotura', 'Producto vencido', 'Robo o pérdida', 'Mercadería sin registrar', 'Corrección de error'];

// Ajuste de inventario por conteo físico (solo administrador): se escribe
// cuánto HAY realmente y el sistema calcula la diferencia.
@Component({
  selector: 'app-ajuste-inventario',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="panel">
      <h3 class="panel-title">Ajuste de inventario (conteo físico)</h3>
      <p class="ayuda">Cuenta lo que hay en el estante y escríbelo: el sistema calcula la diferencia contra su registro y deja constancia con tu nombre y el motivo.</p>

      <div class="agregar">
        <div class="field grande">
          <label>Producto</label>
          <input type="text" list="lista-ajuste" autocomplete="off" placeholder="Escribe el nombre o código…"
                 [ngModel]="texto()" (ngModelChange)="alEscribir($event)" name="ajusteProducto" (keydown.enter)="agregar($event)" />
          <datalist id="lista-ajuste">
            @for (p of productos(); track p.id) { <option [value]="etiqueta(p)"></option> }
          </datalist>
        </div>
        <button type="button" class="btn-secondary" [disabled]="!elegido()" (click)="agregar()">Agregar al conteo</button>
      </div>

      @if (lineas().length > 0) {
        <table class="tabla">
          <thead><tr><th>Producto</th><th>En sistema</th><th>Contado</th><th>Diferencia</th><th>Lote / Vence <small>(si sobra)</small></th><th></th></tr></thead>
          <tbody>
            @for (l of lineas(); track l.producto.id) {
              <tr>
                <td data-label="Producto">{{ l.producto.nombre }}</td>
                <td data-label="En sistema">{{ l.stock_sistema }}</td>
                <td data-label="Contado">
                  <input type="number" min="0" step="1" [(ngModel)]="l.stock_real" [name]="'real' + l.producto.id" style="width:90px" />
                </td>
                <td data-label="Diferencia">
                  <strong [class.neg]="diferencia(l) < 0" [class.pos]="diferencia(l) > 0">{{ diferencia(l) > 0 ? '+' : '' }}{{ diferencia(l) }}</strong>
                </td>
                <td data-label="Lote / Vence">
                  @if (diferencia(l) > 0) {
                    <input type="text" placeholder="Lote" [(ngModel)]="l.numero_lote" [name]="'lote' + l.producto.id" style="width:90px" />
                    <input type="date" [(ngModel)]="l.fecha_vencimiento" [name]="'venc' + l.producto.id" />
                  } @else { — }
                </td>
                <td><button class="link-danger" (click)="quitar(l.producto.id)">Quitar</button></td>
              </tr>
            }
          </tbody>
        </table>

        <div class="field-row" style="margin-top:14px; align-items:flex-end">
          <div class="field" style="min-width:240px">
            <label>Motivo del ajuste</label>
            <select [(ngModel)]="motivo" name="motivoAjuste">
              @for (m of motivos; track m) { <option [value]="m">{{ m }}</option> }
              <option value="__otro">Otro…</option>
            </select>
          </div>
          @if (motivo === '__otro') {
            <div class="field" style="min-width:240px">
              <label>Escribe el motivo</label>
              <input type="text" [(ngModel)]="motivoOtro" name="motivoOtro" maxlength="150" />
            </div>
          }
          <button class="btn-primary" [disabled]="guardando() || !puedeGuardar()" (click)="guardar()">
            {{ guardando() ? 'Aplicando…' : 'Aplicar ajuste' }}
          </button>
        </div>
        <p class="resumen">
          {{ conCambios() }} producto(s) con diferencia · valor estimado al costo:
          <strong [class.neg]="valorDiferencia() < 0" [class.pos]="valorDiferencia() > 0">Bs {{ valorDiferencia().toFixed(2) }}</strong>
        </p>
      }

      @if (error()) { <p class="form-error">{{ error() }}</p> }
      @if (resultado(); as r) {
        <p class="form-ok">{{ r.message }}@if (r.ajustes.length > 0) { Diferencia total al costo: Bs {{ r.valor_total_diferencia.toFixed(2) }}. }</p>
      }

      @if (historial().length > 0) {
        <h4>Últimos ajustes</h4>
        <table class="tabla">
          <thead><tr><th>Fecha</th><th>Producto</th><th>Tipo</th><th>Cantidad</th><th>Stock resultante</th><th>Motivo</th><th>Usuario</th></tr></thead>
          <tbody>
            @for (m of historial(); track m.id) {
              <tr>
                <td data-label="Fecha">{{ m.created_at ? (m.created_at | slice:0:16) : '—' }}</td>
                <td data-label="Producto">{{ m.producto?.nombre || '—' }}</td>
                <td data-label="Tipo"><span class="badge" [class.badge-ok]="m.tipo==='entrada'" [class.badge-danger]="m.tipo==='salida'">{{ m.tipo }}</span></td>
                <td data-label="Cantidad">{{ m.cantidad }}</td>
                <td data-label="Stock resultante">{{ m.stock_resultante }}</td>
                <td data-label="Motivo">{{ m.motivo || '—' }}</td>
                <td data-label="Usuario">{{ m.usuario?.nombre || '—' }}</td>
              </tr>
            }
          </tbody>
        </table>
      }
    </section>
  `,
  styles: [BASE_THEME, `
    .panel-title { font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif; font-size: 20px; color: var(--papel); margin: 0 0 8px; }
    .ayuda { margin: 0 0 14px; font-size: 13px; opacity: 0.8; }
    .agregar { display: flex; gap: 10px; align-items: flex-end; flex-wrap: wrap; }
    .field.grande { flex: 1; min-width: 260px; }
    .tabla { margin-top: 16px; width: 100%; }
    .neg { color: #d64545; }
    .pos { color: #3aa76d; }
    .resumen { margin: 12px 0 0; font-size: 14px; }
    h4 { margin: 20px 0 6px; color: var(--papel); font-size: 16px; }
  `],
})
export class AjusteInventarioComponent implements OnInit {
  /** Avisa al padre cuando se aplicó un ajuste (para refrescar stock e historial). */
  @Output() aplicado = new EventEmitter<void>();

  private ajusteService = inject(AjusteInventarioService);
  private productoService = inject(ProductoService);
  private confirmDialog = inject(ConfirmDialogService);

  motivos = MOTIVOS;
  productos = signal<Producto[]>([]);
  lineas = signal<LineaAjuste[]>([]);
  historial = signal<MovimientoInventario[]>([]);
  texto = signal('');
  elegido = signal<Producto | null>(null);
  guardando = signal(false);
  error = signal('');
  resultado = signal<AjusteInventarioResultado | null>(null);

  motivo = MOTIVOS[0];
  motivoOtro = '';

  conCambios = computed(() => this.lineas().filter((l) => this.diferencia(l) !== 0).length);

  ngOnInit(): void {
    this.cargarProductos();
    this.cargarHistorial();
  }

  private cargarProductos(): void {
    this.productoService.listar().subscribe({ next: (d) => this.productos.set(d) });
  }

  private cargarHistorial(): void {
    this.ajusteService.listarAjustes(1, 8).subscribe({ next: (r) => this.historial.set(r.data), error: () => {} });
  }

  etiqueta(p: Producto): string {
    return `${p.nombre} (${p.codigo})`;
  }

  private normalizar(t: string): string {
    return t.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  }

  alEscribir(t: string): void {
    this.texto.set(t ?? '');
    const q = this.normalizar(t ?? '');
    const lista = this.productos();
    const exacto = lista.find((p) => this.normalizar(this.etiqueta(p)) === q)
      ?? lista.find((p) => this.normalizar(p.codigo) === q || (p.codigo_barras && this.normalizar(p.codigo_barras) === q));
    this.elegido.set(exacto ?? null);
  }

  agregar(ev?: Event): void {
    ev?.preventDefault();
    const p = this.elegido();
    if (!p || this.lineas().some((l) => l.producto.id === p.id)) return;

    this.lineas.set([...this.lineas(), {
      producto: p, stock_sistema: p.stock, stock_real: p.stock, fecha_vencimiento: '', numero_lote: '',
    }]);
    this.texto.set('');
    this.elegido.set(null);
  }

  quitar(id: number): void {
    this.lineas.set(this.lineas().filter((l) => l.producto.id !== id));
  }

  diferencia(l: LineaAjuste): number {
    return (Number(l.stock_real) || 0) - l.stock_sistema;
  }

  valorDiferencia(): number {
    return this.lineas().reduce((acc, l) => acc + this.diferencia(l) * (Number(l.producto.precio_compra) || 0), 0);
  }

  private motivoFinal(): string {
    return (this.motivo === '__otro' ? this.motivoOtro : this.motivo).trim();
  }

  puedeGuardar(): boolean {
    return (
      this.lineas().length > 0 &&
      this.motivoFinal().length > 0 &&
      this.lineas().every((l) => Number.isInteger(Number(l.stock_real)) && Number(l.stock_real) >= 0)
    );
  }

  async guardar(): Promise<void> {
    if (!this.puedeGuardar()) return;

    const ok = await this.confirmDialog.confirm({
      titulo: 'Aplicar ajuste de inventario',
      mensaje: `Se ajustará el stock de ${this.conCambios()} producto(s) a lo contado. Quedará registrado en el historial con el motivo "${this.motivoFinal()}".`,
      textoConfirmar: 'Sí, aplicar ajuste',
    });
    if (!ok) return;

    this.guardando.set(true);
    this.error.set('');
    this.resultado.set(null);

    this.ajusteService
      .ajustar({
        motivo: this.motivoFinal(),
        items: this.lineas().map((l) => ({
          producto_id: l.producto.id,
          stock_real: Number(l.stock_real),
          ...(this.diferencia(l) > 0 && l.fecha_vencimiento ? { fecha_vencimiento: l.fecha_vencimiento } : {}),
          ...(this.diferencia(l) > 0 && l.numero_lote.trim() ? { numero_lote: l.numero_lote.trim() } : {}),
        })),
      })
      .subscribe({
        next: (r) => {
          this.resultado.set(r);
          this.lineas.set([]);
          this.guardando.set(false);
          this.cargarProductos();
          this.cargarHistorial();
          this.aplicado.emit();
        },
        error: (err) => {
          this.error.set(err?.error?.message || 'No se pudo aplicar el ajuste.');
          this.guardando.set(false);
        },
      });
  }
}
