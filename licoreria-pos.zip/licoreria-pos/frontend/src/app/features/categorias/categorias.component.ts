import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CategoriaService } from '../../core/services/categoria.service';
import { Categoria } from '../../core/models/categoria.model';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';

@Component({
  selector: 'app-categorias',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-header">
        <div class="eyebrow">Inventario &middot; Catálogo</div>
        <h1>Categorías</h1>
        <p class="subtitle">Los estantes de tu licorería, organizados por tipo.</p>
      </header>

      <section class="composer" [class.open]="formAbierto()">
        <button class="composer-toggle" (click)="toggleForm()">
          <span class="plus" [class.rotated]="formAbierto()">+</span>
          {{ formAbierto() ? 'Cerrar' : 'Nueva categoría' }}
        </button>

        @if (formAbierto()) {
          <form class="composer-form" (ngSubmit)="guardar()">
            @if (editandoId()) {
              <p class="subtitle" style="margin:0 0 4px">Editando categoría</p>
            }
            <div class="field">
              <label for="nombre">Nombre</label>
              <input
                id="nombre"
                type="text"
                [(ngModel)]="nombre"
                name="nombre"
                placeholder="Ej. Whiskies, Vinos, Cervezas"
                required
                autocomplete="off"
              />
            </div>
            <div class="field">
              <label for="descripcion">Descripción <span>(opcional)</span></label>
              <textarea
                id="descripcion"
                [(ngModel)]="descripcion"
                name="descripcion"
                rows="2"
                placeholder="Qué tipo de productos agrupa esta categoría"
              ></textarea>
            </div>
            <div class="field-row">
              <button type="submit" class="btn-primary" [disabled]="guardando() || !nombre.trim()">
                {{ guardando() ? 'Guardando…' : (editandoId() ? 'Guardar cambios' : 'Guardar categoría') }}
              </button>
              @if (editandoId()) {
                <button type="button" class="link-danger" (click)="cancelarEdicion()">Cancelar edición</button>
              }
              @if (error()) {
                <span class="form-error">{{ error() }}</span>
              }
            </div>
          </form>
        }
      </section>

      @if (cargando()) {
        <div class="estado-vacio">
          <div class="spinner"></div>
          <p>Cargando estantes…</p>
        </div>
      } @else if (categorias().length === 0) {
        <div class="estado-vacio">
          <div class="botella" aria-hidden="true">
            <svg width="40" height="64" viewBox="0 0 40 64" fill="none">
              <path d="M15 2H25V14L31 22V60C31 62.2 29.2 64 27 64H13C10.8 64 9 62.2 9 60V22L15 14V2Z"
                stroke="currentColor" stroke-width="2" fill="none"/>
              <line x1="9" y1="30" x2="31" y2="30" stroke="currentColor" stroke-width="2"/>
            </svg>
          </div>
          <p>Todavía no hay categorías registradas.</p>
          <span>Crea la primera para empezar a organizar tu catálogo.</span>
        </div>
      } @else {
        <div class="grid">
          @for (cat of categorias(); track cat.id) {
            <article class="label-card" [class.inactivo]="!cat.activo">
              <div class="label-stamp">{{ cat.id.toString().padStart(3, '0') }}</div>
              <h3>{{ cat.nombre }}</h3>
              <p class="desc">{{ cat.descripcion || 'Sin descripción registrada.' }}</p>
              <div class="label-footer">
                <span class="badge" [class.badge-off]="!cat.activo">
                  {{ cat.activo ? 'Activa' : 'Inactiva' }}
                </span>
                <div class="label-acciones">
                  <button class="link-action" (click)="editar(cat)">Editar</button>
                  <button class="link-danger" (click)="eliminar(cat)">Eliminar</button>
                </div>
              </div>
            </article>
          }
        </div>
      }
    </div>
  `,
  styles: [`
    :host {
      --verde-botella: #020024;
      --verde-botella-oscuro: #01001A;
      --cobre: #00D4FF;
      --cobre-claro: #00D4FF;
      --papel: #EAFBFF;
      --papel-borde: #00D4FF;
      --tinta: #020024;
      --rust: #d64545;
      display: block;
      font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
      color: var(--tinta);
      background:
        radial-gradient(1100px 480px at 100% -10%, rgba(0, 212, 255, 0.22), transparent 60%),
        radial-gradient(900px 420px at -10% 110%, rgba(0, 212, 255, 0.16), transparent 60%),
        var(--verde-botella);
      min-height: 100%;
      padding: 32px 32px 48px;
    }

    .page { max-width: 1180px; margin: 0 auto; display: flex; flex-direction: column; gap: 24px; min-width: 0; }

    .page-header { margin: 0; }
    .eyebrow {
      font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
      font-size: 12px;
      letter-spacing: 0.14em;
      text-transform: uppercase;
      color: var(--cobre-claro);
      margin-bottom: 10px;
    }
    h1 {
      font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
      font-size: 32px;
      font-weight: 700;
      color: var(--papel);
      margin: 0 0 6px;
      letter-spacing: -0.01em;
    }
    .subtitle { color: #8FE0F2; font-size: 15px; margin: 0; }

    .composer {
      background: linear-gradient(165deg, rgba(0, 212, 255, 0.14), rgba(2, 0, 36, 0.4));
      border: 1px solid rgba(0, 212, 255, 0.28);
      border-radius: 16px;
      padding: 16px 20px;
      margin: 0;
      box-shadow: 0 20px 44px rgba(0, 20, 45, 0.28);
      transition: background 0.2s ease;
    }
    .composer-toggle {
      background: none;
      border: none;
      color: var(--cobre-claro);
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 4px 0;
    }
    .plus {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 22px; height: 22px;
      border-radius: 50%;
      border: 1.5px solid var(--cobre-claro);
      font-size: 16px;
      line-height: 1;
      transition: transform 0.25s ease;
    }
    .plus.rotated { transform: rotate(45deg); }

    .composer-form { margin-top: 18px; display: flex; flex-direction: column; gap: 14px; }
    .field { display: flex; flex-direction: column; gap: 6px; }
    .field label { font-size: 13px; font-weight: 600; color: #00D4FF; }
    .field label span { font-weight: 400; color: #5FB8CC; }
    .field input, .field textarea {
      background: var(--papel);
      border: 1px solid var(--papel-borde);
      border-radius: 8px;
      padding: 10px 12px;
      font-size: 14px;
      font-family: inherit;
      color: var(--tinta);
      resize: vertical;
    }
    .field input:focus, .field textarea:focus {
      outline: 2px solid var(--cobre-claro);
      outline-offset: 1px;
    }
    .field-row { display: flex; align-items: center; gap: 14px; }

    .btn-primary {
      background: linear-gradient(120deg, var(--cobre), var(--cobre-claro));
      color: var(--tinta);
      border: none;
      border-radius: 12px;
      padding: 10px 20px;
      font-weight: 700;
      font-size: 14px;
      cursor: pointer;
      transition: background 0.15s ease, transform 0.1s ease;
    }
    .btn-primary:hover:not(:disabled) { filter: brightness(1.08); }
    .btn-primary:active:not(:disabled) { transform: scale(0.98); }
    .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }

    .form-error { color: #ff9d90; font-size: 13px; }

    .estado-vacio {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 48px 24px;
      background: linear-gradient(165deg, rgba(0, 212, 255, 0.14), rgba(2, 0, 36, 0.4));
      border: 1px solid rgba(0, 212, 255, 0.28);
      border-radius: 16px;
      color: #5FB8CC;
      text-align: center;
      gap: 8px;
    }
    .botella { color: var(--cobre-claro); opacity: 0.7; margin-bottom: 8px; }
    .estado-vacio p { font-size: 16px; font-weight: 600; color: #00D4FF; margin: 0; }
    .estado-vacio span { font-size: 13px; }

    .spinner {
      width: 28px; height: 28px;
      border: 3px solid rgba(0, 212, 255, 0.25);
      border-top-color: var(--cobre-claro);
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
      margin-bottom: 8px;
    }
    @keyframes spin { to { transform: rotate(360deg); } }

    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
      gap: 18px;
    }

    .label-card {
      position: relative;
      background: var(--papel);
      border: 1px solid var(--papel-borde);
      border-radius: 4px;
      padding: 20px 18px 16px;
      box-shadow: 0 6px 16px rgba(0,0,0,0.28);
      transition: transform 0.15s ease, box-shadow 0.15s ease;
    }
    .label-card::before {
      content: '';
      position: absolute;
      inset: 6px;
      border: 1px solid rgba(0, 212, 255, 0.28);
      border-radius: 2px;
      pointer-events: none;
    }
    .label-card:hover { transform: translateY(-3px); box-shadow: 0 10px 22px rgba(0,0,0,0.34); }
    .label-card.inactivo { opacity: 0.55; }

    .label-stamp {
      position: absolute;
      top: 14px; right: 16px;
      font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
      font-size: 11px;
      color: #5FB8CC;
      letter-spacing: 0.05em;
    }

    .label-card h3 {
      font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
      font-size: 21px;
      margin: 0 0 8px;
      padding-right: 36px;
      color: var(--tinta);
    }
    .desc {
      font-size: 13px;
      color: #5FB8CC;
      line-height: 1.5;
      min-height: 38px;
      margin: 0 0 16px;
    }

    .label-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-top: 1px dashed var(--papel-borde);
      padding-top: 12px;
    }
    .label-acciones { display: flex; align-items: center; gap: 10px; }
    .link-action {
      background: none;
      border: none;
      color: var(--cobre-claro);
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      padding: 0;
    }
    .link-action:hover { text-decoration: underline; }
    .badge {
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--verde-botella);
      background: #DFF7FC;
      padding: 4px 9px;
      border-radius: 20px;
    }
    .badge-off { color: #020024; background: #DFF7FC; }

    .link-danger {
      background: none;
      border: none;
      color: var(--rust);
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      padding: 0;
    }
    .link-danger:hover { text-decoration: underline; }

    @media (max-width: 560px) {
      :host { padding: 32px 18px 48px; }
      h1 { font-size: 32px; }
    }
  `],
})
export class CategoriasComponent implements OnInit {
  private categoriaService = inject(CategoriaService);
  private confirmDialog = inject(ConfirmDialogService);

  categorias = signal<Categoria[]>([]);
  cargando = signal(true);
  guardando = signal(false);
  formAbierto = signal(false);
  error = signal('');
  editandoId = signal<number | null>(null);

  nombre = '';
  descripcion = '';

  ngOnInit(): void {
    this.cargar();
  }

  cargar(): void {
    this.cargando.set(true);
    this.categoriaService.listar().subscribe({
      next: (data) => {
        this.categorias.set(data);
        this.cargando.set(false);
      },
      error: () => {
        this.error.set('No se pudo conectar con el servidor.');
        this.cargando.set(false);
      },
    });
  }

  toggleForm(): void {
    const abrir = !this.formAbierto();
    this.formAbierto.set(abrir);
    this.error.set('');
    if (!abrir) this.cancelarEdicion();
  }

  editar(cat: Categoria): void {
    this.editandoId.set(cat.id);
    this.nombre = cat.nombre;
    this.descripcion = cat.descripcion ?? '';
    this.error.set('');
    this.formAbierto.set(true);
  }

  cancelarEdicion(): void {
    this.editandoId.set(null);
    this.nombre = '';
    this.descripcion = '';
  }

  guardar(): void {
    if (!this.nombre.trim()) return;
    this.guardando.set(true);
    this.error.set('');

    const payload = { nombre: this.nombre.trim(), descripcion: this.descripcion.trim() || undefined };
    const id = this.editandoId();
    const peticion = id ? this.categoriaService.actualizar(id, payload) : this.categoriaService.crear(payload);

    peticion.subscribe({
      next: (guardada) => {
        this.categorias.set(
          id
            ? this.categorias().map((c) => (c.id === id ? guardada : c))
            : [guardada, ...this.categorias()],
        );
        this.cancelarEdicion();
        this.guardando.set(false);
        this.formAbierto.set(false);
      },
      error: () => {
        this.error.set('No se pudo guardar. Revisa el nombre e intenta de nuevo.');
        this.guardando.set(false);
      },
    });
  }

  async eliminar(cat: Categoria): Promise<void> {
    const ok = await this.confirmDialog.confirm({
      titulo: 'Eliminar categoría',
      mensaje: `¿Estás seguro de que quieres eliminar la categoría "${cat.nombre}"?`,
      textoConfirmar: 'Sí, eliminar',
      peligroso: true,
    });
    if (!ok) return;

    this.categoriaService.eliminar(cat.id).subscribe({
      next: () => this.categorias.set(this.categorias().filter((c) => c.id !== cat.id)),
      error: () => this.error.set('No se pudo eliminar la categoría.'),
    });
  }
}
