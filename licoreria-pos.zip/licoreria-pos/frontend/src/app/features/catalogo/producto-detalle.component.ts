import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Producto } from '../../core/models/producto.model';
import { ProductoService } from '../../core/services/producto.service';
import { Botella3dComponent } from '../../shared/botella-3d/botella-3d.component';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-producto-detalle',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, Botella3dComponent],
  template: `
    <div class="page">
      @if (cargando) {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando producto…</p></div>
      } @else if (!producto) {
        <div class="estado-vacio">
          <p>No se encontró este producto.</p>
          <a routerLink="/catalogo" class="volver">← Volver al catálogo</a>
        </div>
      } @else {
        <a routerLink="/catalogo" class="volver">← Volver al catálogo</a>

        <div class="detalle-grid">
          <div class="visor-grande">
            @if (producto.imagen) {
              <img class="foto-producto" [src]="producto.imagen" [alt]="producto.nombre" />
            } @else {
              <app-botella-3d [producto]="producto"></app-botella-3d>
            }
          </div>

          <div class="info">
            <span class="tag-categoria">{{ producto.categoria?.nombre || 'Sin categoría' }}</span>
            <h1>{{ producto.nombre }}</h1>
            <p class="codigo">Código: {{ producto.codigo }}</p>

            @if (producto.descripcion) {
              <p class="descripcion">{{ producto.descripcion }}</p>
            }

            <div class="precio-stock">
              <div>
                <span class="etiqueta">Precio de venta</span>
                <span class="precio">Bs {{ producto.precio_venta }}</span>
              </div>
              <div>
                <span class="etiqueta">Stock disponible</span>
                <span class="stock" [class.bajo]="producto.stock <= producto.stock_minimo">
                  {{ producto.stock }} unidades
                  @if (producto.stock <= producto.stock_minimo) { <span class="alerta">· stock bajo</span> }
                </span>
              </div>
            </div>

            <div class="ficha">
              <div class="fila"><span>Precio de compra</span><span>Bs {{ producto.precio_compra }}</span></div>
              <div class="fila"><span>Stock mínimo</span><span>{{ producto.stock_minimo }} unidades</span></div>
              @if (producto.fecha_vencimiento) {
                <div class="fila"><span>Vencimiento</span><span>{{ producto.fecha_vencimiento | date:'dd/MM/yyyy' }}</span></div>
              }
              <div class="fila"><span>Estado</span><span>{{ producto.activo ? 'Activo' : 'Inactivo' }}</span></div>
            </div>

            @if (auth.estaAutenticado()) {
              <div class="imagen-editor">
                <label>Foto del producto (ruta o URL)</label>
                <p class="ayuda">Pega la ruta de una foto de tu sistema (por ejemplo /productos/whiskies/johnnie-walker/red-label.webp) o un link https://. Si lo dejas vacío se usa la foto asignada automáticamente (si existe) o, si no, la botella 3D con el nombre.</p>
                <div class="imagen-form">
                  <input type="text" [(ngModel)]="imagenUrl" placeholder="https://..." />
                  <button class="btn-primary" [disabled]="guardandoImagen" (click)="guardarImagen()">
                    {{ guardandoImagen ? 'Guardando…' : 'Guardar' }}
                  </button>
                </div>
                @if (mensajeImagen) { <span class="ok">{{ mensajeImagen }}</span> }
                @if (errorImagen) { <span class="error">{{ errorImagen }}</span> }
              </div>
            }
          </div>
        </div>
      }
    </div>
  `,
  styles: [
    `
      :host {
        --verde-botella: #020024;
        --verde-botella-oscuro: #01001A;
        --cobre: #00D4FF;
        --cobre-claro: #00D4FF;
        --papel: #EAFBFF;
        --papel-borde: #00D4FF;
        --tinta: #020024;
        --rust: #d64545;
        display: block;
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        color: var(--tinta);
        min-height: 100%;
        padding: 40px 32px 64px;
      }

      .page { max-width: 980px; margin: 0 auto; }

      .volver {
        display: inline-block;
        color: var(--cobre-claro);
        text-decoration: none;
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        font-size: 13px;
        margin-bottom: 22px;
      }
      .volver:hover { text-decoration: underline; }

      .detalle-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 36px;
        align-items: start;
      }

      .visor-grande {
        height: 420px;
        border-radius: 16px;
        background:
          radial-gradient(160px 160px at 50% 30%, rgba(0, 212, 255, 0.18), transparent 70%),
          linear-gradient(180deg, #23392b 0%, #17281f 100%);
        overflow: hidden;
      }

      .foto-producto {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: contain;
        box-sizing: border-box;
        padding: 20px;
        background: #fff;
      }

      .info { color: var(--papel); }
      .tag-categoria {
        display: inline-block;
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        font-size: 11px;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        color: var(--verde-botella-oscuro);
        background: var(--cobre-claro);
        padding: 4px 10px;
        border-radius: 20px;
        margin-bottom: 12px;
      }
      h1 {
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        font-size: 34px;
        margin: 0 0 4px;
        line-height: 1.15;
      }
      .codigo { font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif; font-size: 12px; color: #5FB8CC; margin: 0 0 16px; }
      .descripcion { color: #00D4FF; font-size: 15px; margin: 0 0 20px; }

      .precio-stock {
        display: flex; gap: 32px; margin-bottom: 20px; flex-wrap: wrap;
      }
      .etiqueta { display: block; font-size: 11px; text-transform: uppercase; letter-spacing: 0.06em; color: #5FB8CC; margin-bottom: 4px; }
      .precio { font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif; font-size: 28px; font-weight: 700; color: var(--cobre-claro); }
      .stock { font-size: 16px; font-weight: 600; }
      .stock.bajo { color: var(--rust); }
      .alerta { font-size: 12px; font-weight: 500; }

      .ficha {
        background: rgba(255,255,255,0.04);
        border: 1px solid #2c4536;
        border-radius: 12px;
        padding: 6px 16px;
        margin-bottom: 24px;
      }
      .fila { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px dashed #2c4536; font-size: 14px; }
      .fila:last-child { border-bottom: none; }
      .fila span:first-child { color: #5FB8CC; }

      .imagen-editor {
        background: rgba(0, 212, 255, 0.08);
        border: 1px dashed var(--cobre-claro);
        border-radius: 12px;
        padding: 18px;
      }
      .imagen-editor label { display: block; font-weight: 600; margin-bottom: 4px; }
      .ayuda { font-size: 12.5px; color: #b9c9bd; margin: 0 0 12px; }
      .imagen-form { display: flex; gap: 8px; flex-wrap: wrap; }
      .imagen-form input {
        flex: 1; min-width: 200px;
        background: var(--papel); color: var(--tinta);
        border: 1px solid var(--papel-borde); border-radius: 8px;
        padding: 9px 12px; font-size: 14px;
      }
      .btn-primary {
        background: var(--cobre); color: var(--tinta); border: none;
        border-radius: 8px; padding: 9px 18px; font-weight: 600; cursor: pointer;
      }
      .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
      .ok { display: block; color: #9ed9ab; font-size: 13px; margin-top: 8px; }
      .error { display: block; color: var(--rust); font-size: 13px; margin-top: 8px; }

      .estado-vacio {
        display: flex; flex-direction: column; align-items: center; justify-content: center;
        padding: 100px 24px; color: #5FB8CC; text-align: center; gap: 12px;
      }
      .spinner {
        width: 28px; height: 28px; border: 3px solid #2c4536; border-top-color: var(--cobre-claro);
        border-radius: 50%; animation: spin 0.8s linear infinite;
      }
      @keyframes spin { to { transform: rotate(360deg); } }

      @media (max-width: 760px) {
        .detalle-grid { grid-template-columns: 1fr; }
        .visor-grande { height: 300px; }
      }
    `,
  ],
})
export class ProductoDetalleComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private productoService = inject(ProductoService);
  auth = inject(AuthService);

  producto: Producto | null = null;
  cargando = true;

  imagenUrl = '';
  guardandoImagen = false;
  mensajeImagen = '';
  errorImagen = '';

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!id) {
      this.cargando = false;
      return;
    }

    this.productoService.obtener(id).subscribe({
      next: (data) => {
        this.producto = data;
        this.imagenUrl = data.imagen && !data.imagen.includes('/api/imagen-generica/') ? data.imagen : '';
        this.cargando = false;
      },
      error: () => {
        this.cargando = false;
      },
    });
  }

  guardarImagen(): void {
    if (!this.producto) return;
    this.guardandoImagen = true;
    this.mensajeImagen = '';
    this.errorImagen = '';

    this.productoService.actualizar(this.producto.id, { imagen: this.imagenUrl.trim() }).subscribe({
      next: (actualizado) => {
        this.producto = actualizado;
        this.guardandoImagen = false;
        this.mensajeImagen = 'Imagen guardada.';
      },
      error: () => {
        this.guardandoImagen = false;
        this.errorImagen = 'No se pudo guardar la imagen.';
      },
    });
  }
}
