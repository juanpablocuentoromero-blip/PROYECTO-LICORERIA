import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { Producto } from '../../core/models/producto.model';
import { Categoria } from '../../core/models/categoria.model';
import { Pedido } from '../../core/models/pedido.model';
import { ProductoService } from '../../core/services/producto.service';
import { CategoriaService } from '../../core/services/categoria.service';
import { CarritoService } from '../../core/services/carrito.service';
import { ClienteAuthService } from '../../core/services/cliente-auth.service';
import { PedidoClienteService } from '../../core/services/pedido-cliente.service';
import { Botella3dComponent } from '../../shared/botella-3d/botella-3d.component';
import { DeliveryService } from '../../core/services/delivery.service';
import { PromocionService } from '../../core/services/promocion.service';
import { RespuestaCalculoPromo, ZonaDelivery } from '../../core/models/paso5.model';
import { Presentacion, enteroSeguro, factorDe, opcionesDe, textoCantidad } from '../../core/utils/presentacion';
import { ItemCarrito } from '../../core/models/carrito.model';

@Component({
  selector: 'app-catalogo',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, Botella3dComponent],
  template: `
    <div class="storefront">
      <!-- ===== Header claro: logo, buscador, cuenta, carrito ===== -->
      <header class="tienda-header">
        <div class="header-fila">
          <a class="marca" routerLink="/catalogo">
            <img src="brand/logo-al-paso.png" alt="Licorería Al Paso" height="34" />
          </a>

          <!-- ===== Categorías (mega-menú), junto al nombre de la tienda ===== -->
          <div class="cat-trigger-wrap" (mouseleave)="menuAbierto.set(false)">
            <button class="cat-trigger" [class.activo]="menuAbierto()" (click)="menuAbierto.set(!menuAbierto())" (mouseenter)="menuAbierto.set(true)">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <line x1="4" y1="7" x2="20" y2="7" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                <line x1="4" y1="12" x2="20" y2="12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                <line x1="4" y1="17" x2="20" y2="17" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
              </svg>
              Categorías
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true" class="chevron"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </button>

            @if (menuAbierto()) {
              <div class="mega-menu">
                <button
                  class="mega-item"
                  [class.activo]="categoriaSeleccionada() === null"
                  (click)="filtrarPorCategoria(null); menuAbierto.set(false)"
                >
                  Todas las categorías
                </button>
                @for (cat of categorias(); track cat.id) {
                  <button
                    class="mega-item"
                    [class.activo]="categoriaSeleccionada() === cat.id"
                    (click)="filtrarPorCategoria(cat.id); menuAbierto.set(false)"
                  >
                    {{ cat.nombre }}
                  </button>
                }
              </div>
            }
          </div>

          <div class="buscador">
            <input
              type="text"
              placeholder="¿Qué estás buscando?"
              [value]="textoBusqueda()"
              (input)="buscar($any($event.target).value)"
              (keyup.enter)="cargar()"
            />
            <button class="btn-buscar" (click)="cargar()" aria-label="Buscar">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <circle cx="11" cy="11" r="7" stroke="white" stroke-width="2.4"/>
                <line x1="21" y1="21" x2="16.65" y2="16.65" stroke="white" stroke-width="2.4" stroke-linecap="round"/>
              </svg>
            </button>
          </div>

          <div class="acciones-header">
            <button class="accion-carrito" (click)="carritoAbierto.set(true)" aria-label="Ver carrito">
              <svg width="21" height="21" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <circle cx="9" cy="21" r="1.4" fill="currentColor"/>
                <circle cx="18" cy="21" r="1.4" fill="currentColor"/>
                <path d="M2.5 3h2l2.2 12.2a1.8 1.8 0 0 0 1.78 1.5h8.44a1.8 1.8 0 0 0 1.77-1.47L21 8H6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              @if (carrito.totalUnidades() > 0) {
                <span class="badge-carrito">{{ carrito.totalUnidades() }}</span>
              }
            </button>
          </div>
        </div>
      </header>

      <div class="page">
        <!-- ===== Banner promocional ===== -->
        <section class="hero">
          <div class="hero-texto">
            <span class="hero-eyebrow">Entrega el mismo día</span>
            <h1>Tu licorería, a un clic de distancia</h1>
            <p>Cervezas frías, vinos, whiskies y más &mdash; elegí, agregá al carrito y listo.</p>
          </div>
          <div class="hero-ventajas">
            <div class="ventaja">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 12l6 6L21 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
              Productos verificados
            </div>
            <div class="ventaja">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2"/><path d="M12 7v5l3 3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
              Entrega rápida
            </div>
            <div class="ventaja">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="3" y="6" width="18" height="13" rx="2" stroke="currentColor" stroke-width="2"/><path d="M3 10h18" stroke="currentColor" stroke-width="2"/></svg>
              Pago contra entrega
            </div>
          </div>
        </section>

        @if (categoriaActivaNombre(); as nombreCat) {
          <div class="filtro-activo">
            Mostrando: <strong>{{ nombreCat }}</strong>
            <button (click)="filtrarPorCategoria(null)">Quitar filtro ✕</button>
          </div>
        }

        <!-- ===== Grid de productos ===== -->
        @if (cargando()) {
          <div class="estado-vacio">
            <div class="spinner"></div>
            <p>Cargando botellas…</p>
          </div>
        } @else if (productos().length === 0) {
          <div class="estado-vacio">
            <div class="botella" aria-hidden="true">
              <svg width="40" height="64" viewBox="0 0 40 64" fill="none">
                <path d="M15 2H25V14L31 22V60C31 62.2 29.2 64 27 64H13C10.8 64 9 62.2 9 60V22L15 14V2Z"
                  stroke="currentColor" stroke-width="2" fill="none"/>
                <line x1="9" y1="30" x2="31" y2="30" stroke="currentColor" stroke-width="2"/>
              </svg>
            </div>
            <p>No se encontraron productos.</p>
            <span>Prueba con otro término de búsqueda o categoría.</span>
          </div>
        } @else {
          <div class="conteo">{{ productos().length }} producto{{ productos().length === 1 ? '' : 's' }}</div>
          <div class="catalogo-grid">
            @for (producto of productos(); track producto.id) {
              <article class="producto-card">
                <a class="visor-3d" [routerLink]="['/catalogo', producto.id]">
                  @if (producto.imagen) {
                    <img class="foto-producto" [src]="producto.imagen" [alt]="producto.nombre" loading="lazy" />
                  } @else {
                    <app-botella-3d [producto]="producto"></app-botella-3d>
                  }
                  @if (producto.categoria?.nombre) {
                    <span class="tag-categoria">{{ producto.categoria?.nombre }}</span>
                  }
                  @if (producto.stock <= producto.stock_minimo) {
                    <span class="tag-stock-bajo">¡Últimas unidades!</span>
                  }
                </a>
                <div class="card-body">
                  <a class="titulo-link" [routerLink]="['/catalogo', producto.id]">
                    <h3>{{ producto.nombre }}</h3>
                  </a>
                  <p class="codigo">{{ producto.codigo }}</p>
                  <p class="stock-disp" [class.stock-agotado]="producto.stock === 0" [class.stock-poco]="producto.stock > 0 && producto.stock <= producto.stock_minimo">
                    @if (producto.stock === 0) {
                      Agotado
                    } @else {
                      {{ producto.stock }} disponible{{ producto.stock === 1 ? '' : 's' }}
                    }
                  </p>
                  <div class="card-footer">
                    <span class="precio">Bs {{ producto.precio_venta }} <small>c/u</small></span>
                  </div>

                  @if (producto.stock > 0) {
                    <div class="compra">
                      @if (opciones(producto).length > 1) {
                        <div class="pres-selector" role="radiogroup" aria-label="Presentación">
                          @for (o of opciones(producto); track o.valor) {
                            <button type="button" role="radio" class="pres-op"
                                    [attr.aria-checked]="presDe(producto) === o.valor"
                                    [class.activa]="presDe(producto) === o.valor"
                                    (click)="elegirPresentacion(producto, o.valor)">{{ o.etiqueta }}</button>
                          }
                        </div>
                      }
                      <div class="cantidad-fila">
                        <button type="button" class="qty-btn" aria-label="Menos"
                                (click)="cambiar(producto, presDe(producto), -1)">−</button>
                        <input type="number" class="qty-input" min="0" inputmode="numeric"
                               [attr.max]="carrito.maximoPara(producto, presDe(producto))"
                               [value]="carrito.cantidadDe(producto.id, presDe(producto))"
                               [attr.aria-label]="'Cantidad de ' + producto.nombre"
                               (change)="fijar(producto, presDe(producto), $any($event.target))"
                               (keyup.enter)="fijar(producto, presDe(producto), $any($event.target))"
                               (focus)="$any($event.target).select()" />
                        <button type="button" class="qty-btn" aria-label="Más"
                                [disabled]="carrito.maximoPara(producto, presDe(producto)) <= carrito.cantidadDe(producto.id, presDe(producto))"
                                (click)="cambiar(producto, presDe(producto), 1)">+</button>
                      </div>
                      @if (carrito.cantidadDe(producto.id, presDe(producto)) > 0) {
                        <small class="equiv">
                          {{ unidadesLinea(producto, presDe(producto)) }} u. · Bs {{ (unidadesLinea(producto, presDe(producto)) * +producto.precio_venta).toFixed(2) }}
                        </small>
                      } @else if (presDe(producto) !== 'unidad') {
                        <small class="equiv">{{ factor(producto, presDe(producto)) }} unidades por {{ presDe(producto) }}</small>
                      } @else {
                        <small class="equiv">Escribí la cantidad que querés</small>
                      }
                      @if (carrito.maximoPara(producto, presDe(producto)) === 0) {
                        <small class="equiv equiv-tope">No hay más stock para esta presentación.</small>
                      }
                    </div>
                  }
                </div>
              </article>
            }
          </div>
        }
      </div>
    </div>

    <!-- ===== Carrito deslizante ===== -->
    @if (carritoAbierto()) {
      <div class="carrito-backdrop" (click)="carritoAbierto.set(false)"></div>
    }
    <aside class="carrito-drawer" [class.abierto]="carritoAbierto()">
      <div class="drawer-header">
        <h2>Tu carrito</h2>
        <button class="cerrar" (click)="carritoAbierto.set(false)" aria-label="Cerrar carrito">✕</button>
      </div>

      @if (carrito.items().length === 0) {
        <div class="drawer-vacio">
          <p>Tu carrito está vacío.</p>
          <span>Agregá productos desde el catálogo.</span>
        </div>
      } @else {
        <div class="drawer-items">
          @for (item of carrito.items(); track item.producto.id + item.presentacion) {
            <div class="drawer-item">
              <div class="drawer-item-info">
                <strong>{{ item.producto.nombre }}</strong>
                <span>
                  {{ textoLinea(item) }} · Bs {{ item.producto.precio_venta }} c/u
                </span>
                <span>Subtotal: <b>Bs {{ carrito.subtotalDe(item).toFixed(2) }}</b></span>
              </div>
              <div class="drawer-item-controles">
                <div class="cantidad-fila chica">
                  <button type="button" class="qty-btn" aria-label="Menos" (click)="cambiar(item.producto, item.presentacion, -1)">−</button>
                  <input type="number" class="qty-input" min="0" inputmode="numeric"
                         [attr.max]="carrito.maximoPara(item.producto, item.presentacion)"
                         [value]="item.cantidad"
                         [attr.aria-label]="'Cantidad de ' + item.producto.nombre"
                         (change)="fijar(item.producto, item.presentacion, $any($event.target))"
                         (keyup.enter)="fijar(item.producto, item.presentacion, $any($event.target))"
                         (focus)="$any($event.target).select()" />
                  <button type="button" class="qty-btn" aria-label="Más"
                          [disabled]="carrito.maximoPara(item.producto, item.presentacion) <= item.cantidad"
                          (click)="cambiar(item.producto, item.presentacion, 1)">+</button>
                </div>
                <button class="quitar" (click)="carrito.quitar(item.producto.id, item.presentacion)">Quitar</button>
              </div>
            </div>
          }
        </div>

        <div class="drawer-footer">
          <div class="subtotal-fila">
            <span>Subtotal</span>
            <strong>Bs {{ carrito.totalMonto().toFixed(2) }}</strong>
          </div>
          <button class="btn-checkout" (click)="irACheckout()">Finalizar pedido</button>
          <p class="nota-checkout">El pago y la entrega se coordinan al confirmar tu pedido.</p>
        </div>
      }
    </aside>

    <!-- ===== Modal de checkout ===== -->
    @if (checkoutAbierto()) {
      <div class="carrito-backdrop checkout-backdrop" (click)="checkoutPaso() === 'formulario' ? cerrarCheckout() : null"></div>
      <div class="checkout-modal">
        @if (checkoutPaso() === 'formulario') {
          <div class="checkout-header">
            <h2>Confirmar pedido</h2>
            <button class="cerrar" (click)="cerrarCheckout()" aria-label="Cerrar">✕</button>
          </div>

          <div class="checkout-resumen">
            @for (item of carrito.items(); track item.producto.id + item.presentacion) {
              <div class="resumen-linea">
                <span>{{ textoLinea(item) }} — {{ item.producto.nombre }}</span>
                <span>Bs {{ carrito.subtotalDe(item).toFixed(2) }}</span>
              </div>
            }
            @if (descuentoPreview() > 0) {
              <div class="resumen-linea resumen-descuento">
                <span>Descuentos{{ promoCupon() ? ' (cupón ' + promoCupon() + ')' : '' }}</span>
                <span>− Bs {{ descuentoPreview().toFixed(2) }}</span>
              </div>
            }
            @if (tipoEntrega() === 'delivery' && zonaElegida()) {
              <div class="resumen-linea">
                <span>Envío · {{ zonaElegida()!.nombre }}</span>
                <span>Bs {{ costoEnvio().toFixed(2) }}</span>
              </div>
            }
            <div class="resumen-linea resumen-total">
              <span>Total</span>
              <span>Bs {{ totalFinal().toFixed(2) }}</span>
            </div>
          </div>

          <div class="campo">
            <label>¿Cómo lo recibes?</label>
            <div class="metodos-pago">
              <button class="metodo-btn" [class.activo]="tipoEntrega() === 'delivery'" (click)="tipoEntrega.set('delivery')">
                🛵 Delivery a mi dirección
              </button>
              <button class="metodo-btn" [class.activo]="tipoEntrega() === 'recojo'" (click)="tipoEntrega.set('recojo')">
                🏪 Recojo en la tienda
              </button>
            </div>
          </div>

          @if (tipoEntrega() === 'delivery') {
            <div class="campo">
              <label>Zona de entrega</label>
              @if (zonas().length > 0) {
                <select class="select-zona" [ngModel]="zonaId()" (ngModelChange)="zonaId.set($event)">
                  <option [ngValue]="null">Elige tu zona…</option>
                  @for (z of zonas(); track z.id) {
                    <option [ngValue]="z.id">{{ z.nombre }} — envío Bs {{ (+z.costo_envio).toFixed(2) }}</option>
                  }
                </select>
              } @else {
                <p class="checkout-aviso">El costo de envío se coordina contigo al confirmar el pedido.</p>
              }
            </div>

            <div class="campo">
              <label>Dirección de entrega</label>
              <input type="text" [(ngModel)]="direccionEntrega" placeholder="Calle, número, referencia..." />
            </div>
          }

          <div class="campo">
            <label>Cupón de descuento <span>(opcional)</span></label>
            <div class="fila-cupon">
              <input type="text" [(ngModel)]="cuponTexto" placeholder="CÓDIGO" (keydown.enter)="aplicarCupon()" />
              <button type="button" class="btn-cupon" [disabled]="calculandoPromo()" (click)="aplicarCupon()">
                {{ calculandoPromo() ? '…' : 'Aplicar' }}
              </button>
            </div>
            @if (cuponMensaje()) {
              <p class="cupon-msg" [class.cupon-error]="cuponMensajeError()">{{ cuponMensaje() }}</p>
            }
          </div>

          <div class="campo">
            <label>Método de pago</label>
            <div class="metodos-pago">
              <button
                class="metodo-btn"
                [class.activo]="metodoPago() === 'efectivo'"
                (click)="metodoPago.set('efectivo')"
              >
                💵 Efectivo contra entrega
              </button>
              <button
                class="metodo-btn"
                [class.activo]="metodoPago() === 'qr'"
                (click)="metodoPago.set('qr')"
              >
                📱 QR para transferir
              </button>
            </div>
          </div>

          <div class="campo">
            <label>Observaciones <span>(opcional)</span></label>
            <input type="text" [(ngModel)]="observaciones" placeholder="Ej. tocar timbre, dejar con portería..." />
          </div>

          <label class="check-edad">
            <input type="checkbox" [(ngModel)]="mayorEdad" />
            <span>Declaro que soy <strong>mayor de 18 años</strong>. Me pueden pedir mi documento al entregar el pedido.</span>
          </label>

          @if (checkoutError()) {
            <p class="checkout-error">{{ checkoutError() }}</p>
          }

          <button class="btn-confirmar-pedido" [disabled]="checkoutEnviando() || !mayorEdad" (click)="confirmarCheckout()">
            {{ checkoutEnviando() ? 'Enviando…' : 'Confirmar pedido' }}
          </button>
        } @else {
          <div class="checkout-header">
            <h2>¡Pedido registrado!</h2>
            <button class="cerrar" (click)="cerrarCheckout()" aria-label="Cerrar">✕</button>
          </div>

          <p class="checkout-confirmado-texto">
            Tu pedido <strong>#{{ pedidoCreado()?.id }}</strong> quedó pendiente de confirmación.
            @if (pedidoCreado()?.tipo_entrega === 'recojo') {
              Pásalo a recoger por la tienda.
            }
            @if (metodoPago() === 'efectivo') {
              Pagas en efectivo {{ pedidoCreado()?.tipo_entrega === 'recojo' ? 'al recogerlo' : 'cuando te lo entreguemos' }}.
            } @else {
              Escanea el QR para transferir el monto exacto.
            }
          </p>

          @if (metodoPago() === 'qr') {
            @if (qrSvg()) {
              <div class="qr-contenedor" [innerHTML]="qrSvg()"></div>
            } @else {
              <p class="cargando-texto">Generando código QR…</p>
            }
          }

          <a routerLink="/perfil" class="btn-ver-pedidos" (click)="cerrarCheckout()">Ver mis pedidos</a>
        }
      </div>
    }
  `,
  styles: [
    `
      :host {
        --verde-botella: #020024;
        --verde-botella-oscuro: #01001A;
        --cobre: #00D4FF;
        --cobre-claro: #00D4FF;
        --papel: #EAFBFF;
        --papel-borde: #00D4FF;
        --tinta: #020024;
        --rust: #d64545;
        --fondo: #EAFBFF;
        --fondo-alt: #E8FBFF;
        --borde-claro: #00D4FF;
        --texto-suave: #5FB8CC;
        display: block;
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        color: var(--tinta);
        background: var(--fondo);
      }

      /* ===== Header claro ===== */
      .tienda-header {
        position: sticky;
        top: var(--altura-nav, 0px);
        z-index: 40;
        background: #fff;
        border-bottom: 1px solid var(--borde-claro);
      }
      .header-fila {
        display: flex;
        align-items: center;
        gap: 24px;
        padding: 16px 32px;
        max-width: 1280px;
        margin: 0 auto;
      }
      .marca {
        display: flex;
        align-items: center;
        flex-shrink: 0;
        text-decoration: none;
      }
      .marca img { display: block; }

      .buscador {
        flex: 1;
        display: flex;
        align-items: stretch;
        max-width: 640px;
        border: 1.5px solid var(--borde-claro);
        border-radius: 8px;
        overflow: hidden;
      }
      .buscador input {
        flex: 1;
        border: none;
        outline: none;
        padding: 11px 16px;
        font-family: inherit;
        font-size: 14px;
        color: var(--tinta);
        background: #fff;
      }
      .buscador input::placeholder { color: #a39c8a; }
      .btn-buscar {
        background: var(--cobre);
        border: none;
        padding: 0 18px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .btn-buscar:hover { background: var(--verde-botella); }

      .acciones-header {
        display: flex;
        align-items: center;
        gap: 22px;
        flex-shrink: 0;
      }

      .accion-carrito {
        position: relative;
        background: none;
        border: none;
        color: var(--tinta);
        cursor: pointer;
        display: flex;
        align-items: center;
        padding: 2px;
      }
      .accion-carrito:hover { color: var(--cobre); }
      .badge-carrito {
        position: absolute;
        top: -7px;
        right: -9px;
        background: var(--rust);
        color: #fff;
        font-size: 10.5px;
        font-weight: 800;
        min-width: 18px;
        height: 18px;
        border-radius: 999px;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0 4px;
      }

      /* ===== Botón de categorías (mega-menú), junto a la marca ===== */
      .cat-trigger-wrap { position: relative; flex-shrink: 0; }
      .cat-trigger {
        display: flex;
        align-items: center;
        gap: 8px;
        background: var(--fondo-alt);
        border: 1px solid var(--borde-claro);
        color: var(--verde-botella);
        border-radius: 7px;
        padding: 8px 12px;
        font-size: 13.5px;
        font-weight: 700;
        cursor: pointer;
        white-space: nowrap;
      }
      .cat-trigger.activo, .cat-trigger:hover { background: var(--papel); border-color: var(--cobre-claro); }
      .chevron { margin-left: 2px; }

      .mega-menu {
        position: absolute;
        top: calc(100% + 8px);
        left: 0;
        width: 260px;
        max-height: 420px;
        overflow-y: auto;
        background: #fff;
        border: 1px solid var(--borde-claro);
        border-radius: 10px;
        box-shadow: 0 16px 36px rgba(36, 31, 24, 0.16);
        padding: 8px;
        z-index: 45;
      }
      .mega-item {
        display: block;
        width: 100%;
        text-align: left;
        background: none;
        border: none;
        padding: 10px 12px;
        border-radius: 7px;
        font-size: 13.5px;
        font-weight: 600;
        color: var(--tinta);
        cursor: pointer;
      }
      .mega-item:hover { background: var(--fondo-alt); color: var(--verde-botella); }
      .mega-item.activo { background: var(--papel); color: var(--verde-botella); }

      /* ===== Contenido ===== */
      .page { max-width: 1280px; margin: 0 auto; padding: 28px 32px 64px; }

      .hero {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 24px;
        flex-wrap: wrap;
        background: linear-gradient(120deg, var(--verde-botella) 0%, #274736 60%, var(--cobre) 160%);
        border-radius: 18px;
        padding: 38px 34px;
        margin-bottom: 30px;
        box-shadow: 0 14px 32px rgba(31, 54, 40, 0.18);
      }
      .hero-eyebrow {
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        font-size: 12px;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        color: var(--cobre-claro);
      }
      .hero-texto h1 {
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        font-size: 34px;
        color: var(--papel);
        margin: 8px 0 8px;
        max-width: 480px;
        line-height: 1.15;
      }
      .hero-texto p { color: #00D4FF; margin: 0; font-size: 15px; max-width: 420px; }
      .hero-ventajas { display: flex; flex-direction: column; gap: 12px; }
      .ventaja {
        display: flex;
        align-items: center;
        gap: 10px;
        color: var(--papel);
        font-size: 13.5px;
        font-weight: 600;
        background: rgba(0,0,0,0.18);
        padding: 9px 16px;
        border-radius: 10px;
      }
      .ventaja svg { color: var(--cobre-claro); flex-shrink: 0; }

      .filtro-activo {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 13px;
        color: var(--texto-suave);
        margin-bottom: 14px;
      }
      .filtro-activo strong { color: var(--tinta); }
      .filtro-activo button {
        background: none;
        border: 1px solid var(--borde-claro);
        color: var(--cobre);
        border-radius: 999px;
        padding: 4px 10px;
        font-size: 12px;
        cursor: pointer;
      }

      .conteo {
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        font-size: 12px;
        letter-spacing: 0.05em;
        color: var(--texto-suave);
        margin-bottom: 14px;
      }

      .catalogo-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
        gap: 22px;
      }

      .producto-card {
        background: #fff;
        border: 1px solid var(--borde-claro);
        border-radius: 14px;
        overflow: hidden;
        box-shadow: 0 4px 14px rgba(36, 31, 24, 0.06);
        transition: transform 0.18s ease, box-shadow 0.18s ease;
      }
      .producto-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 14px 28px rgba(36, 31, 24, 0.14);
      }

      .visor-3d {
        position: relative;
        display: block;
        width: 100%;
        height: 210px;
        background:
          radial-gradient(120px 120px at 50% 30%, rgba(0, 212, 255, 0.16), transparent 70%),
          linear-gradient(180deg, #23392b 0%, #17281f 100%);
      }
      .foto-producto {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        object-fit: contain;
        box-sizing: border-box;
        padding: 14px;
        background: #fff;
      }
      .tag-categoria {
        position: absolute;
        top: 10px;
        left: 10px;
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        font-size: 10px;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        color: var(--verde-botella-oscuro);
        background: var(--cobre-claro);
        padding: 4px 8px;
        border-radius: 20px;
      }
      .stock-disp { margin: 2px 0 8px; font-size: 12px; font-weight: 600; color: #1f6b3a; }
      .stock-disp.stock-poco { color: #b7791f; }
      .stock-disp.stock-agotado { color: var(--rust); }
      .tag-stock-bajo {
        position: absolute;
        top: 10px;
        right: 10px;
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
        color: #fff;
        background: var(--rust);
        padding: 4px 8px;
        border-radius: 20px;
      }

      .card-body { padding: 14px 16px 16px; }
      .titulo-link { text-decoration: none; color: inherit; }

      h3 {
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        font-size: 17px;
        font-weight: 600;
        margin: 0 0 2px;
        color: var(--tinta);
        line-height: 1.25;
      }
      .codigo {
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        font-size: 11px;
        color: #8a7a5a;
        margin: 0 0 14px;
        letter-spacing: 0.03em;
      }

      .card-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-top: 1px dashed var(--borde-claro);
        padding-top: 12px;
        gap: 8px;
      }
      .precio {
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        font-weight: 700;
        font-size: 17px;
        color: var(--verde-botella);
      }

      .btn-agregar {
        background: var(--verde-botella);
        color: var(--papel);
        border: none;
        border-radius: 8px;
        padding: 8px 12px;
        font-size: 12px;
        font-weight: 700;
        cursor: pointer;
        white-space: nowrap;
      }
      .btn-agregar:hover:not(:disabled) { background: var(--verde-botella-oscuro); }
      .btn-agregar:disabled { opacity: 0.4; cursor: not-allowed; }


      .precio small { font-size: 11px; font-weight: 600; color: var(--texto-suave); }
      .compra { display: flex; flex-direction: column; gap: 6px; margin-top: 8px; }
      .pres-selector { display: flex; gap: 4px; flex-wrap: wrap; }
      .pres-op {
        flex: 1 1 auto; min-width: 0; padding: 5px 8px; font-size: 11px; font-weight: 700;
        border-radius: 8px; cursor: pointer; white-space: nowrap;
        background: var(--fondo-alt); color: var(--tinta); border: 1px solid var(--borde-claro);
      }
      .pres-op.activa { background: var(--verde-botella); color: #fff; border-color: var(--verde-botella); }
      .cantidad-fila { display: flex; align-items: stretch; gap: 6px; }
      .qty-btn {
        width: 36px; min-height: 36px; border-radius: 8px; font-size: 18px; font-weight: 700; cursor: pointer;
        background: var(--fondo-alt); color: var(--verde-botella); border: 1px solid var(--borde-claro);
      }
      .qty-btn:disabled { opacity: 0.4; cursor: not-allowed; }
      .qty-input {
        flex: 1; min-width: 0; width: 100%; min-height: 36px; text-align: center; font-size: 15px; font-weight: 700;
        border-radius: 8px; border: 1.5px solid var(--borde-claro); background: #fff; color: var(--tinta);
        -moz-appearance: textfield;
      }
      .qty-input::-webkit-outer-spin-button, .qty-input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
      .qty-input:focus { outline: 2px solid var(--verde-botella); outline-offset: 1px; }
      .cantidad-fila.chica .qty-input { width: 56px; flex: none; }
      .cantidad-fila.chica .qty-btn { width: 30px; min-height: 32px; }
      .equiv { font-size: 12px; color: var(--texto-suave); }
      .equiv-tope { color: var(--rust); }

      .stepper {
        display: flex;
        align-items: center;
        gap: 10px;
        background: var(--fondo-alt);
        border: 1px solid var(--borde-claro);
        border-radius: 8px;
        padding: 4px 10px;
      }
      .stepper button {
        background: none;
        border: none;
        color: var(--cobre);
        font-size: 16px;
        font-weight: 700;
        cursor: pointer;
        width: 18px;
      }
      .stepper span { color: var(--tinta); font-weight: 700; font-size: 13px; min-width: 14px; text-align: center; }
      .stepper.chico { padding: 3px 8px; }

      .estado-vacio {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 80px 24px;
        color: var(--texto-suave);
        text-align: center;
        gap: 8px;
      }
      .botella { color: var(--cobre); opacity: 0.6; margin-bottom: 8px; }
      .estado-vacio p { font-size: 16px; font-weight: 600; color: var(--tinta); margin: 0; }
      .estado-vacio span { font-size: 13px; }

      .spinner {
        width: 28px; height: 28px;
        border: 3px solid var(--borde-claro);
        border-top-color: var(--cobre);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
        margin-bottom: 8px;
      }
      @keyframes spin { to { transform: rotate(360deg); } }

      /* ===== Carrito deslizante ===== */
      .carrito-backdrop {
        position: fixed;
        inset: 0;
        background: rgba(36, 31, 24, 0.4);
        z-index: 60;
      }
      .carrito-drawer {
        position: fixed;
        top: 0;
        right: -420px;
        width: 400px;
        max-width: 92vw;
        height: 100vh;
        background: #fff;
        border-left: 1px solid var(--borde-claro);
        z-index: 61;
        display: flex;
        flex-direction: column;
        transition: right 0.28s ease;
      }
      .carrito-drawer.abierto { right: 0; }

      .drawer-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 20px 22px;
        border-bottom: 1px solid var(--borde-claro);
      }
      .drawer-header h2 {
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        color: var(--verde-botella);
        font-size: 20px;
        margin: 0;
      }
      .cerrar {
        background: none;
        border: none;
        color: var(--texto-suave);
        font-size: 18px;
        cursor: pointer;
      }

      .drawer-vacio {
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        color: var(--texto-suave);
        gap: 6px;
        text-align: center;
        padding: 24px;
      }
      .drawer-vacio p { color: var(--tinta); font-weight: 600; margin: 0; }

      .drawer-items {
        flex: 1;
        overflow-y: auto;
        padding: 10px 22px;
      }
      .drawer-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 14px 0;
        border-bottom: 1px solid var(--borde-claro);
      }
      .drawer-item-info { display: flex; flex-direction: column; gap: 3px; }
      .drawer-item-info strong { color: var(--tinta); font-size: 14px; }
      .drawer-item-info span { color: var(--texto-suave); font-size: 12px; }
      .drawer-item-controles { display: flex; flex-direction: column; align-items: flex-end; gap: 6px; }
      .quitar {
        background: none;
        border: none;
        color: var(--rust);
        font-size: 11px;
        font-weight: 700;
        cursor: pointer;
        padding: 0;
      }

      .drawer-footer {
        padding: 18px 22px 24px;
        border-top: 1px solid var(--borde-claro);
      }
      .subtotal-fila {
        display: flex;
        align-items: center;
        justify-content: space-between;
        color: var(--tinta);
        font-size: 15px;
        margin-bottom: 14px;
      }
      .subtotal-fila strong { font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif; font-size: 20px; color: var(--cobre); }
      .btn-checkout {
        width: 100%;
        background: var(--cobre);
        color: var(--tinta);
        border: none;
        border-radius: 10px;
        padding: 13px;
        font-weight: 800;
        font-size: 14px;
        cursor: pointer;
      }
      .btn-checkout:hover { background: var(--verde-botella); }
      .nota-checkout { color: var(--texto-suave); font-size: 11px; text-align: center; margin: 10px 0 0; }

      .campo { display: flex; flex-direction: column; gap: 5px; margin-bottom: 14px; }
      .campo label { font-size: 12.5px; font-weight: 700; color: var(--tinta); }
      .campo label span { font-weight: 400; color: var(--texto-suave); }
      .campo input {
        border: 1px solid var(--borde-claro);
        border-radius: 8px;
        padding: 10px 12px;
        font-size: 14px;
        font-family: inherit;
        background: #fff;
        color: var(--tinta);
      }
      .campo input:focus { outline: 2px solid var(--cobre-claro); outline-offset: 1px; }

      /* ===== Modal de checkout ===== */
      .checkout-backdrop { z-index: 70; }
      .checkout-modal {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 440px;
        max-width: 92vw;
        max-height: 88vh;
        overflow-y: auto;
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 24px 60px rgba(36, 31, 24, 0.28);
        z-index: 71;
        padding: 22px 24px 26px;
      }
      .checkout-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px;
      }
      .checkout-header h2 {
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        color: var(--verde-botella);
        font-size: 20px;
        margin: 0;
      }

      .checkout-resumen {
        background: var(--fondo-alt);
        border-radius: 10px;
        padding: 14px 16px;
        margin-bottom: 16px;
      }
      .resumen-linea {
        display: flex;
        justify-content: space-between;
        font-size: 13px;
        color: var(--tinta);
        padding: 4px 0;
      }
      .resumen-total {
        border-top: 1px dashed var(--borde-claro);
        margin-top: 6px;
        padding-top: 8px;
        font-weight: 800;
        color: var(--verde-botella);
        font-size: 14.5px;
      }

      .metodos-pago { display: flex; flex-direction: column; gap: 8px; }
      .metodo-btn {
        text-align: left;
        background: #fff;
        border: 1.5px solid var(--borde-claro);
        border-radius: 9px;
        padding: 11px 14px;
        font-size: 13.5px;
        font-weight: 600;
        color: var(--tinta);
        cursor: pointer;
      }
      .metodo-btn.activo { border-color: var(--cobre); background: var(--papel); color: var(--verde-botella); }

      .checkout-error { color: var(--rust); font-size: 13px; margin: 4px 0 12px; }
      .resumen-descuento { color: #1f6b3a; }
      .select-zona {
        width: 100%; box-sizing: border-box; padding: 10px 12px; border-radius: 8px;
        border: 1px solid var(--papel-borde); background: #fff; color: var(--tinta); font-size: 14px; font-family: inherit;
      }
      .checkout-aviso { font-size: 12px; color: var(--rust); margin: 6px 0 0; }
      .fila-cupon { display: flex; gap: 8px; }
      .fila-cupon input { flex: 1; text-transform: uppercase; }
      .btn-cupon {
        border: 1px solid var(--verde-botella); background: transparent; color: var(--verde-botella);
        border-radius: 8px; padding: 0 16px; font-weight: 700; cursor: pointer; font-family: inherit;
      }
      .btn-cupon:hover:not(:disabled) { background: var(--verde-botella); color: #fff; }
      .cupon-msg { font-size: 12px; margin: 6px 0 0; color: #1f6b3a; }
      .cupon-msg.cupon-error { color: var(--rust); }
      .check-edad { display: flex; gap: 8px; align-items: flex-start; font-size: 13px; line-height: 1.4; margin: 4px 0 14px; cursor: pointer; color: var(--tinta); }
      .check-edad input { margin-top: 3px; width: 16px; height: 16px; flex: none; }

      .btn-confirmar-pedido {
        width: 100%;
        background: var(--cobre);
        color: var(--tinta);
        border: none;
        border-radius: 10px;
        padding: 13px;
        font-weight: 800;
        font-size: 14px;
        cursor: pointer;
        margin-top: 6px;
      }
      .btn-confirmar-pedido:hover:not(:disabled) { background: var(--verde-botella); }
      .btn-confirmar-pedido:disabled { opacity: 0.6; cursor: not-allowed; }

      .checkout-confirmado-texto { font-size: 14px; color: var(--tinta); line-height: 1.5; margin-bottom: 16px; }
      .qr-contenedor {
        display: flex;
        justify-content: center;
        padding: 16px;
        background: var(--fondo-alt);
        border-radius: 10px;
        margin-bottom: 16px;
      }
      .cargando-texto { color: var(--texto-suave); font-size: 13px; text-align: center; margin-bottom: 16px; }
      .btn-ver-pedidos {
        display: block;
        text-align: center;
        background: var(--verde-botella);
        color: #fff;
        text-decoration: none;
        border-radius: 10px;
        padding: 12px;
        font-weight: 700;
        font-size: 14px;
      }
      .btn-ver-pedidos:hover { background: var(--verde-botella-oscuro); }

      @media (max-width: 860px) {
        .header-fila { flex-wrap: wrap; padding: 12px 18px; }
        .marca { order: 1; }
        .cat-trigger-wrap { order: 2; }
        .acciones-header { order: 3; margin-left: auto; }
        .buscador { order: 4; flex-basis: 100%; max-width: none; }
        .page { padding: 22px 18px 48px; }
        .hero { padding: 26px 20px; }
        .hero-texto h1 { font-size: 26px; }
      }
    `,
  ],
})
export class CatalogoComponent implements OnInit {
  private productoService = inject(ProductoService);
  private categoriaService = inject(CategoriaService);
  clienteAuth = inject(ClienteAuthService);
  private pedidoClienteService = inject(PedidoClienteService);
  private deliveryService = inject(DeliveryService);
  private promocionService = inject(PromocionService);
  private router = inject(Router);
  carrito = inject(CarritoService);

  productos = signal<Producto[]>([]);
  categorias = signal<Categoria[]>([]);
  cargando = signal(true);
  textoBusqueda = signal('');
  categoriaSeleccionada = signal<number | null>(null);
  carritoAbierto = signal(false);
  menuAbierto = signal(false);

  // ===== Checkout =====
  checkoutAbierto = signal(false);
  checkoutPaso = signal<'formulario' | 'confirmado'>('formulario');
  checkoutEnviando = signal(false);
  checkoutError = signal<string | null>(null);
  direccionEntrega = '';
  observaciones = '';
  metodoPago = signal<'efectivo' | 'qr'>('efectivo');
  pedidoCreado = signal<Pedido | null>(null);
  qrSvg = signal<string>('');

  // 5.1 confirmación de edad (el servidor la exige)
  mayorEdad = false;

  // 5.2 delivery
  tipoEntrega = signal<'delivery' | 'recojo'>('delivery');
  zonas = signal<ZonaDelivery[]>([]);
  zonaId = signal<number | null>(null);
  zonaElegida = computed(() => this.zonas().find((z) => z.id === this.zonaId()) ?? null);
  costoEnvio = computed(() =>
    this.tipoEntrega() === 'delivery' ? Number(this.zonaElegida()?.costo_envio ?? 0) : 0,
  );

  // 5.4 promociones y cupón (vista previa; el servidor recalcula al confirmar)
  cuponTexto = '';
  calculandoPromo = signal(false);
  promoPreview = signal<RespuestaCalculoPromo | null>(null);
  cuponMensaje = signal('');
  cuponMensajeError = signal(false);
  descuentoPreview = computed(() => this.promoPreview()?.total_descuento ?? 0);
  promoCupon = computed(() => this.promoPreview()?.cupon?.codigo ?? '');

  totalFinal = computed(() =>
    Math.max(0, Math.round((this.carrito.totalMonto() - this.descuentoPreview() + this.costoEnvio()) * 100) / 100),
  );

  categoriaActivaNombre = computed(() => {
    const id = this.categoriaSeleccionada();
    if (id === null) return null;
    return this.categorias().find((c) => c.id === id)?.nombre ?? null;
  });

  ngOnInit(): void {
    this.categoriaService.listar().subscribe({
      next: (data) => this.categorias.set(data.filter((c) => c.activo)),
      error: () => this.categorias.set([]),
    });
    this.cargar();
  }

  cargar(): void {
    this.cargando.set(true);
    const filtro = this.textoBusqueda();
    const categoriaId = this.categoriaSeleccionada();
    this.productoService
      .listar({
        ...(filtro ? { buscar: filtro } : {}),
        ...(categoriaId ? { categoria_id: categoriaId } : {}),
      })
      .subscribe({
        next: (data) => {
          this.productos.set(data);
          this.cargando.set(false);
        },
        error: () => this.cargando.set(false),
      });
  }

  buscar(texto: string): void {
    this.textoBusqueda.set(texto);
  }

  filtrarPorCategoria(id: number | null): void {
    this.categoriaSeleccionada.set(id);
    this.cargar();
  }

  irACheckout(): void {
    if (!this.clienteAuth.estaAutenticado()) {
      this.carritoAbierto.set(false);
      this.router.navigate(['/acceso']);
      return;
    }
    this.checkoutError.set(null);
    this.checkoutPaso.set('formulario');
    this.direccionEntrega = this.clienteAuth.clienteActual()?.direccion ?? '';
    this.observaciones = '';
    this.metodoPago.set('efectivo');
    this.tipoEntrega.set('delivery');
    this.zonaId.set(null);
    this.mayorEdad = false;
    this.cuponTexto = '';
    this.cuponMensaje.set('');
    this.promoPreview.set(null);
    this.checkoutAbierto.set(true);

    this.deliveryService.zonas().subscribe({
      next: (zonas) => this.zonas.set(zonas),
      error: () => this.zonas.set([]),
    });
    this.recalcularPromos();
  }


  // ===== Presentaciones y cantidades (unidad / paquete / caja) =====
  private presElegida = signal<Record<number, Presentacion>>({});

  opciones(p: Producto) {
    return opcionesDe(p);
  }

  factor(p: Producto, pres: Presentacion): number {
    return factorDe(p, pres);
  }

  presDe(p: Producto): Presentacion {
    const elegida = this.presElegida()[p.id] ?? 'unidad';
    return factorDe(p, elegida) > 1 || elegida === 'unidad' ? elegida : 'unidad';
  }

  elegirPresentacion(p: Producto, pres: Presentacion): void {
    this.presElegida.update((m) => ({ ...m, [p.id]: pres }));
  }

  unidadesLinea(p: Producto, pres: Presentacion): number {
    return this.carrito.cantidadDe(p.id, pres) * factorDe(p, pres);
  }

  textoLinea(item: ItemCarrito): string {
    const unidades = this.carrito.unidadesDe(item);
    return item.presentacion === 'unidad'
      ? textoCantidad('unidad', item.cantidad)
      : `${textoCantidad(item.presentacion, item.cantidad)} (${unidades} u.)`;
  }

  /** Botones − / +. */
  cambiar(p: Producto, pres: Presentacion, delta: number): void {
    this.carrito.establecer(p, this.carrito.cantidadDe(p.id, pres) + delta, pres);
  }

  /** La persona escribió la cantidad directo: se aplica (recortada al stock) y el campo muestra lo que quedó. */
  fijar(p: Producto, pres: Presentacion, input: HTMLInputElement): void {
    const pedida = enteroSeguro(input.value);
    const final = this.carrito.establecer(p, pedida, pres);
    input.value = String(final);
  }

  private itemsPromo() {
    return this.carrito.items().map((i) => ({ producto_id: i.producto.id, cantidad: this.carrito.unidadesDe(i) }));
  }

  /** Pide al servidor los descuentos automáticos (y el cupón, si hay). */
  private recalcularPromos(cupon?: string): void {
    if (this.carrito.items().length === 0) return;
    this.calculandoPromo.set(true);
    this.promocionService.calcularTienda(this.itemsPromo(), cupon).subscribe({
      next: (res) => {
        this.promoPreview.set(res);
        this.calculandoPromo.set(false);
        if (cupon) {
          this.cuponMensajeError.set(!!res.cupon_error);
          this.cuponMensaje.set(
            res.cupon_error ?? `Cupón aplicado: ahorras Bs ${res.cupon?.descuento.toFixed(2)}.`,
          );
        }
      },
      error: () => {
        this.calculandoPromo.set(false);
        if (cupon) {
          this.cuponMensajeError.set(true);
          this.cuponMensaje.set('No se pudo validar el cupón. Intenta de nuevo.');
        }
      },
    });
  }

  aplicarCupon(): void {
    const codigo = this.cuponTexto.trim();
    if (!codigo) {
      this.cuponMensaje.set('');
      this.recalcularPromos();
      return;
    }
    this.recalcularPromos(codigo);
  }

  cerrarCheckout(): void {
    this.checkoutAbierto.set(false);
    this.checkoutPaso.set('formulario');
    this.pedidoCreado.set(null);
    this.qrSvg.set('');
  }

  confirmarCheckout(): void {
    this.checkoutError.set(null);

    if (this.tipoEntrega() === 'delivery') {
      if (this.zonas().length > 0 && !this.zonaId()) {
        this.checkoutError.set('Elige la zona de entrega.');
        return;
      }
      if (!this.direccionEntrega.trim()) {
        this.checkoutError.set('Ingresa una dirección de entrega.');
        return;
      }
    }
    if (!this.mayorEdad) {
      this.checkoutError.set('Debes confirmar que eres mayor de 18 años.');
      return;
    }
    if (this.carrito.items().length === 0) {
      this.checkoutError.set('Tu carrito está vacío.');
      return;
    }

    this.checkoutEnviando.set(true);
    this.pedidoClienteService
      .crear({
        metodo_pago: this.metodoPago(),
        tipo_entrega: this.tipoEntrega(),
        zona_delivery_id: this.tipoEntrega() === 'delivery' ? this.zonaId() : null,
        direccion_entrega: this.tipoEntrega() === 'delivery' ? this.direccionEntrega.trim() : undefined,
        observaciones: this.observaciones.trim() || undefined,
        cupon: this.cuponTexto.trim() || undefined,
        mayor_edad: this.mayorEdad,
        items: this.carrito.items().map((i) => ({ producto_id: i.producto.id, cantidad: i.cantidad, presentacion: i.presentacion })),
      })
      .subscribe({
        next: (pedido) => {
          this.checkoutEnviando.set(false);
          this.pedidoCreado.set(pedido);
          this.carrito.vaciar();
          this.carritoAbierto.set(false);
          this.checkoutPaso.set('confirmado');

          if (this.metodoPago() === 'qr') {
            this.pedidoClienteService.obtenerQr(pedido.id).subscribe({
              next: (svg) => this.qrSvg.set(svg),
              error: () => this.qrSvg.set('<p>No se pudo cargar el QR. Puedes verlo luego en "Mis pedidos".</p>'),
            });
          }

          // El catálogo pudo haber quedado con stock desactualizado en
          // pantalla tras la compra (el backend ya lo descontó).
          this.cargar();
        },
        error: (err) => {
          this.checkoutEnviando.set(false);
          this.checkoutError.set(err?.error?.message ?? 'No se pudo registrar el pedido. Intenta de nuevo.');
        },
      });
  }
}
