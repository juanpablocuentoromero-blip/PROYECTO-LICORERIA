import { DecimalPipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
  Component,
  ElementRef,
  HostListener,
  OnDestroy,
  OnInit,
  computed,
  effect,
  inject,
  signal,
  untracked,
  viewChild,
} from '@angular/core';
import { AuthService } from '../../core/services/auth.service';
import { VentaService } from '../../core/services/venta.service';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';
import { PromocionService } from '../../core/services/promocion.service';
import { FidelizacionService } from '../../core/services/fidelizacion.service';
import { ConfigFidelizacion } from '../../core/models/fidelizacion.model';
import { AnchoTicket, TicketService } from '../../core/services/ticket.service';
import { RespuestaCalculoPromo } from '../../core/models/paso5.model';
import {
  MetodoPago,
  ProductoPos,
  RespuestaRegistrarVenta,
  VentaPayload,
} from '../../core/models/punto-venta.model';

/** Una fila del carrito. `precio` y `stock` son la foto del momento del escaneo. */
export interface LineaVenta {
  producto_id: number;
  codigo: string;
  nombre: string;
  imagen?: string | null;
  es_combo: boolean;
  precio: number;
  stock: number;
  cantidad: number;
  /** Descuento de la línea en Bs. */
  descuento: number;
  /** Presentaciones del producto (null = no se vende así). */
  unidades_por_paquete?: number | null;
  unidades_por_caja?: number | null;
}

interface Aviso {
  tipo: 'ok' | 'error' | 'info';
  texto: string;
}

interface VentaCerrada {
  id: number;
  nroDocumento: string;
  total: number;
  recibido: number | null;
  cambio: number;
  metodo: MetodoPago;
  /** Fecha de vencimiento (solo ventas a crédito). */
  vence: string | null;
  /** Puntos que ganó el cliente con esta venta y su saldo resultante (6.4). */
  puntosGanados: number;
  puntosSaldo: number;
}

const SIN_NOMBRE = 'SIN NOMBRE';

// Los importes se redondean a 2 decimales en cada línea y luego se suman,
// igual que hace el backend, para que el TOTAL de la pantalla coincida
// siempre con el que guarda el servidor.
const redondear = (n: number): number => Math.round((n + Number.EPSILON) * 100) / 100;

// Acepta "2,5" y "2.5": el teclado numérico en Bolivia suele dar coma.
const aNumero = (texto: string): number => Number(texto.trim().replace(',', '.'));

const esNitGenerico = (nit: string): boolean => nit.trim() === '' || nit.trim() === '0';

@Component({
  selector: 'app-venta',
  standalone: true,
  imports: [DecimalPipe],
  templateUrl: './venta.component.html',
  styleUrl: './venta.component.css',
})
export class VentaComponent implements OnInit, OnDestroy {
  private ventaService = inject(VentaService);
  private confirmDialog = inject(ConfirmDialogService);
  private promocionService = inject(PromocionService);
  private fidelizacionService = inject(FidelizacionService);
  private ticketService = inject(TicketService);
  readonly auth = inject(AuthService);

  // ------------------------------------------------------------------
  // Referencias al DOM (para mantener el foco en el buscador)
  // ------------------------------------------------------------------
  private buscador = viewChild<ElementRef<HTMLInputElement>>('buscador');
  private campoRazon = viewChild<ElementRef<HTMLInputElement>>('campoRazon');

  // ------------------------------------------------------------------
  // Estado de la pantalla (todo en signals: la app no usa zone.js)
  // ------------------------------------------------------------------
  readonly fechaHoy = new Date().toLocaleDateString('es-BO', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });

  readonly almacen = signal('…');
  readonly cajaAbierta = signal(false);
  readonly cargandoContexto = signal(true);

  // Cliente de cabecera. Por defecto: NIT/CI 0 + SIN NOMBRE.
  readonly nitCi = signal('0');
  readonly razonSocial = signal(SIN_NOMBRE);
  readonly esClienteGenerico = computed(() => esNitGenerico(this.nitCi()));
  private nitConsultado: string | null = '0';

  // Buscador
  readonly codigo = signal('');
  readonly buscando = signal(false);
  readonly coincidencias = signal<ProductoPos[]>([]);
  readonly seleccion = signal(0);
  private textoDeLista = '';

  // Carrito
  readonly lineas = signal<LineaVenta[]>([]);
  readonly ultimoId = signal<number | null>(null);

  // 5.4 Promociones y cupón (vista previa; el servidor recalcula al cobrar)
  readonly cuponEscrito = signal('');
  readonly cuponVigente = signal('');
  readonly promo = signal<RespuestaCalculoPromo | null>(null);
  readonly cuponMensaje = signal<Aviso | null>(null);
  private secuenciaPromo = 0;
  private temporizadorPromo?: ReturnType<typeof setTimeout>;

  // 6.4 Fidelización: puntos del cliente identificado (vista previa; el servidor valida al cobrar)
  readonly fidelizacion = signal<ConfigFidelizacion | null>(null);
  readonly puntosSaldo = signal(0);
  readonly puntosCanje = signal(0);

  // 5.3 Venta a crédito (fiado)
  readonly diasCredito = signal(30);

  // 5.5 Ticket térmico
  readonly anchoTicket = signal<AnchoTicket>(this.ticketService.ancho());
  readonly autoImprimir = signal(localStorage.getItem('labodega_ticket_auto') === '1');
  readonly imprimiendo = signal(false);

  // Cobro
  readonly metodoPago = signal<MetodoPago>('efectivo');
  readonly recibido = signal<number | null>(null);
  readonly procesando = signal(false);

  // 4.6 Pagos mixtos: lo que se paga por QR y por tarjeta; el resto va en efectivo.
  readonly pagoQr = signal<number | null>(null);
  readonly pagoTarjeta = signal<number | null>(null);

  // Mensajes
  readonly aviso = signal<Aviso | null>(null);
  readonly ultimaVenta = signal<VentaCerrada | null>(null);
  readonly descargandoPdf = signal(false);
  private temporizadorAviso?: ReturnType<typeof setTimeout>;
  private audio?: AudioContext;

  // ------------------------------------------------------------------
  // Cálculos reactivos: se recalculan solos cada vez que cambia `lineas`
  // ------------------------------------------------------------------
  readonly subtotal = computed(() =>
    redondear(this.lineas().reduce((suma, l) => suma + this.importeBruto(l), 0)),
  );
  readonly descuentoTotal = computed(() =>
    redondear(this.lineas().reduce((suma, l) => suma + l.descuento, 0)),
  );
  /** Descuento por promociones/cupón (lo calcula el servidor). */
  readonly descuentoPromo = computed(() => this.promo()?.total_descuento ?? 0);
  /** Total después de descuentos y promociones, antes de canjear puntos. */
  readonly totalAntesDePuntos = computed(() =>
    Math.max(0, redondear(this.subtotal() - this.descuentoTotal() - this.descuentoPromo())),
  );

  /** Máximo de puntos canjeables ahora: saldo, tope por venta y mínimo del programa. */
  readonly maxPuntos = computed(() => {
    const cfg = this.fidelizacion();
    if (!cfg?.activo || cfg.valor_punto <= 0) return 0;
    if (this.esClienteGenerico() || this.metodoPago() === 'credito') return 0;
    const topeBs = redondear((this.totalAntesDePuntos() * cfg.tope_canje_pct) / 100);
    const max = Math.min(this.puntosSaldo(), Math.floor(topeBs / cfg.valor_punto));
    return max >= cfg.min_puntos_canje ? max : 0;
  });

  /** Puntos que realmente se canjearán (0 si lo escrito no cumple las reglas). */
  readonly puntosAplicados = computed(() => {
    const cfg = this.fidelizacion();
    const aplicados = Math.min(this.puntosCanje(), this.maxPuntos());
    return cfg && aplicados >= cfg.min_puntos_canje ? aplicados : 0;
  });

  readonly descuentoPuntos = computed(() =>
    redondear(this.puntosAplicados() * (this.fidelizacion()?.valor_punto ?? 0)),
  );

  /** Se muestra el bloque de puntos cuando el cliente está identificado y tiene saldo. */
  readonly mostrarPuntos = computed(
    () =>
      !!this.fidelizacion()?.activo &&
      !this.esClienteGenerico() &&
      this.puntosSaldo() > 0 &&
      this.metodoPago() !== 'credito',
  );

  readonly total = computed(() =>
    Math.max(0, redondear(this.totalAntesDePuntos() - this.descuentoPuntos())),
  );
  /** Promoción aplicada a una línea (para mostrarla bajo el producto). */
  readonly promoPorProducto = computed(() => {
    const mapa = new Map<number, { descuento: number; etiqueta: string }>();
    for (const l of this.promo()?.lineas ?? []) {
      if (l.descuento > 0 && l.etiqueta) mapa.set(l.producto_id, { descuento: l.descuento, etiqueta: l.etiqueta });
    }
    return mapa;
  });
  readonly cantidadArticulos = computed(() =>
    this.lineas().reduce((suma, l) => suma + l.cantidad, 0),
  );

  /** Pagado por QR + tarjeta en una venta mixta. */
  readonly sumaNoEfectivo = computed(() => redondear((this.pagoQr() ?? 0) + (this.pagoTarjeta() ?? 0)));

  /** Cuánto se cobra en efectivo: todo el total, o lo que quede después de QR/tarjeta (mixto). */
  readonly efectivoACobrar = computed(() => {
    const metodo = this.metodoPago();
    if (metodo === 'efectivo') return this.total();
    if (metodo === 'mixto') return Math.max(0, redondear(this.total() - this.sumaNoEfectivo()));
    return 0;
  });

  /** En una venta mixta, QR + tarjeta se pasaron del total. */
  readonly mixtoExcedido = computed(
    () => this.metodoPago() === 'mixto' && this.sumaNoEfectivo() > this.total(),
  );

  /** Vuelto a devolver (solo la parte en efectivo y solo si se digitó lo recibido). */
  readonly cambio = computed(() => {
    const recibido = this.recibido();
    if (this.efectivoACobrar() <= 0 || recibido === null) return 0;
    return Math.max(0, redondear(recibido - this.efectivoACobrar()));
  });

  /** Lo que falta para cubrir el efectivo, si lo recibido no alcanza. */
  readonly faltante = computed(() => {
    const recibido = this.recibido();
    if (this.efectivoACobrar() <= 0 || recibido === null) return 0;
    return Math.max(0, redondear(this.efectivoACobrar() - recibido));
  });

  readonly puedeCobrar = computed(
    () => this.lineas().length > 0 && this.cajaAbierta() && !this.procesando(),
  );

  constructor() {
    // Cada vez que cambia el carrito (productos, cantidades o descuento
    // manual) se vuelve a pedir al servidor el descuento por promociones.
    effect(() => {
      this.lineas();
      untracked(() => this.programarPromos());
    });
  }

  // ------------------------------------------------------------------
  // Ciclo de vida
  // ------------------------------------------------------------------
  ngOnInit(): void {
    this.cargarContexto();
    this.enfocar();
  }

  ngOnDestroy(): void {
    clearTimeout(this.temporizadorAviso);
    clearTimeout(this.temporizadorPromo);
    void this.audio?.close();
  }

  cargarContexto(): void {
    this.cargandoContexto.set(true);
    // Si no hay reglas de puntos (o falla), la venta sigue normal sin canje.
    this.fidelizacionService.configuracion().subscribe({
      next: (cfg) => this.fidelizacion.set(cfg),
      error: () => this.fidelizacion.set(null),
    });
    this.ventaService.contexto().subscribe({
      next: (ctx) => {
        this.almacen.set(ctx.almacen.nombre);
        this.cajaAbierta.set(ctx.caja_abierta);
        this.cargandoContexto.set(false);
      },
      error: (err) => {
        this.cargandoContexto.set(false);
        this.avisar('error', this.mensajeError(err));
      },
    });
  }

  // ------------------------------------------------------------------
  // ATAJOS DE TECLADO
  //   F2  → procesar y aceptar la venta al instante
  //   F4  → nueva venta (vacía el carrito, pide confirmación)
  //   Esc → cierra la lista de coincidencias y vuelve al buscador
  // ------------------------------------------------------------------
  @HostListener('document:keydown', ['$event'])
  alPresionarTecla(ev: KeyboardEvent): void {
    // Con un diálogo de confirmación abierto, las teclas son del diálogo.
    if (this.confirmDialog.solicitud()) return;

    switch (ev.key) {
      case 'F2':
        ev.preventDefault();
        // `repeat` = tecla mantenida: sin esto, dejar F2 apretado registraría varias ventas.
        if (!ev.repeat) this.cobrar();
        break;
      case 'F4':
        ev.preventDefault();
        if (!ev.repeat) void this.nuevaVenta(true);
        break;
      case 'Escape':
        this.coincidencias.set([]);
        this.enfocar();
        break;
    }
  }

  /** Clic en un espacio vacío de la pantalla: el foco vuelve al lector. */
  alHacerClic(ev: MouseEvent): void {
    const destino = ev.target as HTMLElement;
    if (destino.closest('input, select, textarea, button, a')) return;
    this.enfocar();
  }

  // ------------------------------------------------------------------
  // CLIENTE (cabecera)
  // ------------------------------------------------------------------
  alEscribirNit(ev: Event): void {
    const valor = this.texto(ev);
    this.nitCi.set(valor);
    this.nitConsultado = null;
    this.reiniciarPuntos();
    // Con NIT 0 el cliente es siempre SIN NOMBRE; con otro NIT la razón
    // social vieja ya no aplica hasta que se consulte.
    this.razonSocial.set(esNitGenerico(valor) ? SIN_NOMBRE : '');
  }

  /**
   * Busca el NIT/CI en la base. Si existe trae su razón social; si no, deja
   * escribirla y el cliente se registra al cobrar.
   * `moverFoco` es true cuando el cajero pulsó Enter (quiere seguir con el
   * lector) y false cuando solo salió del campo con el ratón.
   */
  consultarNit(moverFoco: boolean): void {
    const nit = this.nitCi().trim();

    if (esNitGenerico(nit)) {
      this.nitCi.set('0');
      this.razonSocial.set(SIN_NOMBRE);
      this.nitConsultado = '0';
      this.reiniciarPuntos();
      if (moverFoco) this.enfocar();
      return;
    }

    if (nit === this.nitConsultado) {
      if (moverFoco) this.enfocar();
      return;
    }

    this.ventaService.buscarCliente(nit).subscribe({
      next: (res) => {
        this.nitConsultado = nit;
        if (res.encontrado && res.cliente) {
          this.razonSocial.set(res.cliente.nombre);
          this.puntosSaldo.set(res.cliente.puntos_saldo ?? 0);
          if (moverFoco) this.enfocar();
        } else {
          this.avisar('info', 'Cliente nuevo: escriba la razón social. Se registrará al cobrar.');
          if (moverFoco) this.campoRazon()?.nativeElement.focus();
        }
      },
      error: (err) => this.avisar('error', this.mensajeError(err)),
    });
  }

  // ------------------------------------------------------------------
  // 6.4 PUNTOS
  // ------------------------------------------------------------------
  alEscribirPuntos(ev: Event): void {
    const n = Math.floor(aNumero(this.texto(ev)));
    this.puntosCanje.set(Number.isFinite(n) && n > 0 ? n : 0);
  }

  usarMaximoPuntos(): void {
    this.puntosCanje.set(this.maxPuntos());
  }

  quitarPuntos(): void {
    this.puntosCanje.set(0);
  }

  private reiniciarPuntos(): void {
    this.puntosSaldo.set(0);
    this.puntosCanje.set(0);
  }

  alEscribirRazon(ev: Event): void {
    this.razonSocial.set(this.texto(ev));
  }

  // ------------------------------------------------------------------
  // BUSCADOR (lector de código de barras)
  //
  // El lector escribe el código y pulsa Enter: (keydown.enter) → buscar().
  // ------------------------------------------------------------------
  alEscribirBuscador(ev: Event): void {
    const valor = this.texto(ev);
    this.codigo.set(valor);
    // Si cambia el texto, la lista de la búsqueda anterior ya no vale.
    if (valor.trim() !== this.textoDeLista) this.coincidencias.set([]);
  }

  alTeclaBuscador(ev: KeyboardEvent): void {
    const total = this.coincidencias().length;
    if (total === 0) return;

    if (ev.key === 'ArrowDown') {
      ev.preventDefault();
      this.seleccion.update((i) => Math.min(i + 1, total - 1));
    } else if (ev.key === 'ArrowUp') {
      ev.preventDefault();
      this.seleccion.update((i) => Math.max(i - 1, 0));
    }
  }

  buscar(): void {
    const texto = this.codigo().trim();
    if (!texto) return;

    // Lista abierta y el texto no cambió: Enter elige la fila resaltada.
    const lista = this.coincidencias();
    if (lista.length > 0 && texto === this.textoDeLista) {
      this.elegirCoincidencia(lista[this.seleccion()] ?? lista[0]);
      return;
    }

    this.buscando.set(true);
    this.ventaService.buscarProducto(texto).subscribe({
      next: (res) => {
        this.buscando.set(false);

        if (res.productos.length === 1) {
          // Lo normal con el lector: un código, un producto, directo al carrito.
          this.codigo.set('');
          this.coincidencias.set([]);
          this.agregarProducto(res.productos[0]);
        } else {
          // Búsqueda por nombre con varios resultados: que el cajero elija.
          this.textoDeLista = texto;
          this.seleccion.set(0);
          this.coincidencias.set(res.productos);
        }
      },
      error: (err: HttpErrorResponse) => {
        this.buscando.set(false);
        this.coincidencias.set([]);
        this.beep('error');
        this.avisar('error', this.mensajeError(err));
        // Se deja el código escrito pero seleccionado: el siguiente escaneo lo reemplaza.
        this.buscador()?.nativeElement.select();
      },
    });
  }

  elegirCoincidencia(producto: ProductoPos): void {
    this.codigo.set('');
    this.coincidencias.set([]);
    this.textoDeLista = '';
    this.agregarProducto(producto);
  }

  // ------------------------------------------------------------------
  // CARRITO
  // ------------------------------------------------------------------
  agregarProducto(p: ProductoPos): void {
    if (p.stock <= 0) {
      this.beep('error');
      this.avisar('error', `Sin stock: ${p.nombre}`);
      this.enfocar();
      return;
    }

    const existente = this.buscarLinea(p.id);

    if (existente) {
      if (existente.cantidad + 1 > p.stock) {
        this.beep('error');
        this.avisar('error', `Stock disponible de «${p.nombre}»: ${p.stock}`);
        this.enfocar();
        return;
      }
      // Al reescanear se refrescan precio y stock con lo último del servidor.
      this.actualizarLinea(p.id, (l) => ({
        ...l,
        precio: p.precio_venta,
        stock: p.stock,
        unidades_por_paquete: p.unidades_por_paquete ?? null,
        unidades_por_caja: p.unidades_por_caja ?? null,
        cantidad: l.cantidad + 1,
      }));
    } else {
      this.lineas.update((ls) => [
        ...ls,
        {
          producto_id: p.id,
          codigo: p.codigo,
          nombre: p.nombre,
          imagen: p.imagen ?? null,
          es_combo: p.es_combo,
          precio: p.precio_venta,
          stock: p.stock,
          unidades_por_paquete: p.unidades_por_paquete ?? null,
          unidades_por_caja: p.unidades_por_caja ?? null,
          cantidad: 1,
          descuento: 0,
        },
      ]);
    }

    this.ultimaVenta.set(null);
    this.ultimoId.set(p.id);
    this.beep('ok');
    this.enfocar();
    // Espera a que Angular pinte la fila y la deja a la vista.
    setTimeout(() =>
      document.getElementById(`fila-${p.id}`)?.scrollIntoView({ block: 'nearest' }),
    );
  }

  /** Botones − / + de la fila. */
  sumar(id: number, delta: number): void {
    const linea = this.buscarLinea(id);
    if (!linea) return;

    const nueva = linea.cantidad + delta;
    if (nueva < 1) return;
    if (nueva > linea.stock) {
      this.beep('error');
      this.avisar('error', `Stock disponible de «${linea.nombre}»: ${linea.stock}`);
      return;
    }
    this.actualizarLinea(id, (l) => this.conCantidad(l, nueva));
  }

  /** Cantidad escrita a mano: se recalcula con cada tecla. */
  alEscribirCantidad(id: number, ev: Event): void {
    const campo = ev.target as HTMLInputElement;
    const linea = this.buscarLinea(id);
    if (!linea) return;

    // Mientras escribe se tolera el campo vacío o "0"; se corrige al salir.
    if (!/^\d{1,4}$/.test(campo.value.trim())) return;
    const pedida = Number(campo.value);
    if (pedida < 1) return;

    const final = Math.min(pedida, linea.stock);
    if (final < pedida) {
      campo.value = String(final);
      this.beep('error');
      this.avisar('error', `Stock disponible de «${linea.nombre}»: ${linea.stock}`);
    }
    this.actualizarLinea(id, (l) => this.conCantidad(l, final));
  }

  /** Descuento en Bs escrito a mano: nunca puede superar el importe de la línea. */
  alEscribirDescuento(id: number, ev: Event): void {
    const campo = ev.target as HTMLInputElement;
    const linea = this.buscarLinea(id);
    if (!linea) return;

    const crudo = campo.value.trim().replace(',', '.');
    if (crudo === '') {
      this.actualizarLinea(id, (l) => ({ ...l, descuento: 0 }));
      return;
    }
    if (!/^\d*\.?\d{0,2}$/.test(crudo)) return;

    const pedido = Number(crudo);
    if (!Number.isFinite(pedido)) return;

    const maximo = this.importeBruto(linea);
    const final = Math.min(pedido, maximo);
    if (final < pedido) {
      campo.value = String(final);
      this.beep('error');
      this.avisar('error', `El descuento no puede superar Bs ${maximo.toFixed(2)}`);
    }
    this.actualizarLinea(id, (l) => ({ ...l, descuento: final }));
  }

  /** Al salir del campo, si quedó vacío o inválido, vuelve a mostrar el valor real. */
  restaurarCampo(id: number, campo: 'cantidad' | 'descuento', ev: Event): void {
    const linea = this.buscarLinea(id);
    if (!linea) return;
    (ev.target as HTMLInputElement).value = String(linea[campo]);
  }

  quitar(id: number): void {
    this.lineas.update((ls) => ls.filter((l) => l.producto_id !== id));
    this.enfocar();
  }

  async nuevaVenta(pedirConfirmacion: boolean): Promise<void> {
    if (this.procesando()) return;

    if (pedirConfirmacion && this.lineas().length > 0) {
      const ok = await this.confirmDialog.confirm({
        titulo: 'Nueva venta',
        mensaje: `Se descartarán ${this.lineas().length} producto(s) del carrito. ¿Continuar?`,
        textoConfirmar: 'Sí, vaciar',
        peligroso: true,
      });
      if (!ok) {
        this.enfocar();
        return;
      }
    }

    this.reiniciar();
    this.enfocar();
  }

  // ------------------------------------------------------------------
  // PROMOCIONES Y CUPÓN (5.4)
  // ------------------------------------------------------------------
  private programarPromos(): void {
    clearTimeout(this.temporizadorPromo);
    this.temporizadorPromo = setTimeout(() => this.recalcularPromos(), 250);
  }

  private recalcularPromos(mostrarMensajeCupon = false): void {
    const lineas = this.lineas();
    if (lineas.length === 0) {
      this.promo.set(null);
      return;
    }

    const secuencia = ++this.secuenciaPromo;
    this.promocionService
      .calcularPos(
        lineas.map((l) => ({ producto_id: l.producto_id, cantidad: l.cantidad, descuento: l.descuento })),
        this.cuponVigente() || undefined,
      )
      .subscribe({
        next: (res) => {
          // Una respuesta vieja nunca pisa a una más nueva.
          if (secuencia !== this.secuenciaPromo) return;
          this.promo.set(res);

          if (res.cupon_error) {
            // Un cupón inválido no se arrastra a la venta.
            this.cuponVigente.set('');
            this.cuponMensaje.set({ tipo: 'error', texto: res.cupon_error });
          } else if (res.cupon) {
            this.cuponMensaje.set({
              tipo: 'ok',
              texto: `Cupón ${res.cupon.codigo}: − Bs ${res.cupon.descuento.toFixed(2)}`,
            });
          } else if (mostrarMensajeCupon) {
            this.cuponMensaje.set(null);
          }
        },
        error: () => {
          if (secuencia !== this.secuenciaPromo) return;
          // Sin vista previa el cajero puede seguir: el servidor igual aplica las promociones al cobrar.
          this.promo.set(null);
        },
      });
  }

  alEscribirCupon(ev: Event): void {
    this.cuponEscrito.set(this.texto(ev).toUpperCase());
  }

  aplicarCupon(): void {
    const codigo = this.cuponEscrito().trim();
    if (this.lineas().length === 0) {
      this.cuponMensaje.set({ tipo: 'info', texto: 'Agregue productos antes de aplicar un cupón.' });
      return;
    }
    this.cuponVigente.set(codigo);
    if (!codigo) this.cuponMensaje.set(null);
    this.recalcularPromos(true);
  }

  quitarCupon(): void {
    this.cuponEscrito.set('');
    this.cuponVigente.set('');
    this.cuponMensaje.set(null);
    this.recalcularPromos(true);
    this.enfocar();
  }

  // ------------------------------------------------------------------
  // COBRO
  // ------------------------------------------------------------------
  cambiarMetodo(metodo: MetodoPago): void {
    this.metodoPago.set(metodo);
    if (metodo === 'credito') this.puntosCanje.set(0);
    if (metodo !== 'efectivo' && metodo !== 'mixto') this.recibido.set(null);
    if (metodo !== 'mixto') {
      this.pagoQr.set(null);
      this.pagoTarjeta.set(null);
    }
    this.enfocar();
  }

  alEscribirPagoQr(ev: Event): void { this.pagoQr.set(this.montoDe(ev)); }
  alEscribirPagoTarjeta(ev: Event): void { this.pagoTarjeta.set(this.montoDe(ev)); }

  private montoDe(ev: Event): number | null {
    const crudo = this.texto(ev);
    if (crudo.trim() === '') return null;
    const n = aNumero(crudo);
    return Number.isFinite(n) && n > 0 ? redondear(n) : null;
  }

  alEscribirDiasCredito(ev: Event): void {
    const n = Number(this.texto(ev));
    this.diasCredito.set(Number.isFinite(n) ? Math.min(365, Math.max(0, Math.trunc(n))) : 30);
  }

  alEscribirRecibido(ev: Event): void {
    const crudo = this.texto(ev);
    if (crudo.trim() === '') {
      this.recibido.set(null);
      return;
    }
    const n = aNumero(crudo);
    this.recibido.set(Number.isFinite(n) && n >= 0 ? n : null);
  }

  /** F2 / botón COBRAR. Valida en pantalla y manda la venta completa al servidor. */
  cobrar(): void {
    if (this.procesando()) return;

    if (this.lineas().length === 0) {
      this.beep('error');
      this.avisar('error', 'No hay productos en la venta. Escanee un código de barras.');
      this.enfocar();
      return;
    }
    if (!this.cajaAbierta()) {
      this.beep('error');
      this.avisar('error', 'La caja está cerrada. Pida al administrador que abra el turno.');
      return;
    }

    const generico = this.esClienteGenerico();
    if (!generico && this.razonSocial().trim() === '') {
      this.beep('error');
      this.avisar('error', 'Escriba la razón social del cliente (o use NIT/CI 0).');
      this.campoRazon()?.nativeElement.focus();
      return;
    }

    // La razón social escrita a mano vale siempre, tenga o no NIT/CI: solo
    // si el cajero la dejó vacía (venta genérica de mostrador) se usa
    // "SIN NOMBRE" por defecto.
    const razonFinal = this.razonSocial().trim() || SIN_NOMBRE;

    if (this.metodoPago() === 'mixto') {
      if (this.mixtoExcedido()) {
        this.beep('error');
        this.avisar('error', `QR + tarjeta (Bs ${this.sumaNoEfectivo().toFixed(2)}) superan el total (Bs ${this.total().toFixed(2)}).`);
        return;
      }
      if (this.sumaNoEfectivo() <= 0) {
        this.beep('error');
        this.avisar('error', 'En un pago mixto indique cuánto se paga con QR o tarjeta; el resto va en efectivo.');
        return;
      }
    }

    if (this.faltante() > 0) {
      this.beep('error');
      this.avisar('error', `Falta cobrar Bs ${this.faltante().toFixed(2)}.`);
      return;
    }

    // Fiado: el cliente tiene que estar identificado (el servidor además
    // verifica que tenga crédito habilitado y que no pase su límite).
    if (this.metodoPago() === 'credito' && generico) {
      this.beep('error');
      this.avisar('error', 'Para vender a crédito identifique al cliente con su NIT/CI.');
      return;
    }

    const payload: VentaPayload = {
      nit_ci: generico ? '0' : this.nitCi().trim(),
      razon_social: razonFinal,
      metodo_pago: this.metodoPago(),
      monto_recibido: this.efectivoACobrar() > 0 ? this.recibido() : null,
      pagos: this.metodoPago() === 'mixto' ? this.pagosMixtos() : undefined,
      cupon: this.cuponVigente() || undefined,
      puntos_canje: this.puntosAplicados() || undefined,
      dias_credito: this.metodoPago() === 'credito' ? this.diasCredito() : undefined,
      items: this.lineas().map((l) => ({
        producto_id: l.producto_id,
        cantidad: l.cantidad,
        descuento: l.descuento,
      })),
    };

    this.procesando.set(true);
    this.ventaService.registrar(payload).subscribe({
      next: (res) => this.alRegistrarVenta(res),
      error: (err) => {
        this.procesando.set(false);
        this.beep('error');
        this.avisar('error', this.mensajeError(err), 7000);
        this.enfocar();
      },
    });
  }

  /** Reparto del cobro mixto: QR y tarjeta como se digitaron, el resto en efectivo. */
  private pagosMixtos(): NonNullable<VentaPayload['pagos']> {
    const pagos: NonNullable<VentaPayload['pagos']> = [];
    if (this.efectivoACobrar() > 0) pagos.push({ metodo_pago: 'efectivo', monto: this.efectivoACobrar() });
    if ((this.pagoQr() ?? 0) > 0) pagos.push({ metodo_pago: 'qr', monto: this.pagoQr()! });
    if ((this.pagoTarjeta() ?? 0) > 0) pagos.push({ metodo_pago: 'tarjeta', monto: this.pagoTarjeta()! });
    return pagos;
  }

  private alRegistrarVenta(res: RespuestaRegistrarVenta): void {
    this.ultimaVenta.set({
      id: res.venta.id,
      nroDocumento: res.venta.nro_documento,
      total: res.venta.total,
      recibido: res.recibido,
      cambio: res.cambio,
      metodo: this.metodoPago(),
      vence: res.venta.fecha_vencimiento ?? null,
      puntosGanados: res.venta.puntos_ganados ?? 0,
      puntosSaldo: res.venta.puntos_saldo ?? 0,
    });
    if (this.autoImprimir()) void this.imprimirTicket();
    this.reiniciar();
    this.beep('ok');
    this.aviso.set(null);
    this.enfocar();
  }

  async descargarComprobante(): Promise<void> {
    const venta = this.ultimaVenta();
    if (!venta || this.descargandoPdf()) return;

    this.descargandoPdf.set(true);
    try {
      await this.ventaService.descargarPdf(venta.id, venta.nroDocumento);
    } catch {
      this.avisar('error', 'No se pudo descargar el comprobante.');
    } finally {
      this.descargandoPdf.set(false);
      this.enfocar();
    }
  }

  // ------------------------------------------------------------------
  // TICKET TÉRMICO (5.5)
  // ------------------------------------------------------------------
  async imprimirTicket(): Promise<void> {
    const venta = this.ultimaVenta();
    if (!venta || this.imprimiendo()) return;

    this.imprimiendo.set(true);
    try {
      await this.ticketService.imprimir(venta.id, this.anchoTicket());
    } catch {
      this.avisar('error', 'No se pudo generar el ticket.');
    } finally {
      this.imprimiendo.set(false);
    }
  }

  cambiarAnchoTicket(ev: Event): void {
    const ancho: AnchoTicket = this.texto(ev) === '58' ? 58 : 80;
    this.ticketService.guardarAncho(ancho);
    this.anchoTicket.set(ancho);
  }

  alternarAutoImprimir(): void {
    const nuevo = !this.autoImprimir();
    this.autoImprimir.set(nuevo);
    try {
      localStorage.setItem('labodega_ticket_auto', nuevo ? '1' : '0');
    } catch {
      /* sin almacenamiento: vale solo para esta sesión */
    }
  }

  cerrarResumen(): void {
    this.ultimaVenta.set(null);
    this.enfocar();
  }

  // ------------------------------------------------------------------
  // Utilidades
  // ------------------------------------------------------------------
  importeBruto(l: LineaVenta): number {
    return redondear(l.precio * l.cantidad);
  }

  subtotalLinea(l: LineaVenta): number {
    return redondear(this.importeBruto(l) - l.descuento);
  }

  get rolUsuario(): string {
    return this.auth.usuarioActual()?.rol === 'administrador' ? 'Administrador' : 'Vendedor';
  }

  /** Vuelve a dejar la pantalla lista para el siguiente cliente. */
  private reiniciar(): void {
    this.lineas.set([]);
    this.ultimoId.set(null);
    this.codigo.set('');
    this.coincidencias.set([]);
    this.recibido.set(null);
    this.pagoQr.set(null);
    this.pagoTarjeta.set(null);
    this.metodoPago.set('efectivo');
    this.cuponEscrito.set('');
    this.cuponVigente.set('');
    this.cuponMensaje.set(null);
    this.promo.set(null);
    this.diasCredito.set(30);
    this.nitCi.set('0');
    this.razonSocial.set(SIN_NOMBRE);
    this.nitConsultado = '0';
    this.reiniciarPuntos();
    this.procesando.set(false);
  }

  private buscarLinea(id: number): LineaVenta | undefined {
    return this.lineas().find((l) => l.producto_id === id);
  }

  private actualizarLinea(id: number, cambio: (l: LineaVenta) => LineaVenta): void {
    this.lineas.update((ls) => ls.map((l) => (l.producto_id === id ? cambio(l) : l)));
  }

  // Al bajar la cantidad, un descuento que ya no cabe se recorta al nuevo importe.
  private conCantidad(l: LineaVenta, cantidad: number): LineaVenta {
    return {
      ...l,
      cantidad,
      descuento: Math.min(l.descuento, redondear(l.precio * cantidad)),
    };
  }

  texto(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  seleccionarTexto(ev: Event): void {
    (ev.target as HTMLInputElement).select();
  }

  enfocar(): void {
    // Se espera al siguiente ciclo: el campo puede acabar de aparecer o de cambiar.
    setTimeout(() => this.buscador()?.nativeElement.focus());
  }

  avisar(tipo: Aviso['tipo'], texto: string, ms = 4500): void {
    clearTimeout(this.temporizadorAviso);
    this.aviso.set({ tipo, texto });
    this.temporizadorAviso = setTimeout(() => this.aviso.set(null), ms);
  }

  private mensajeError(err: unknown): string {
    if (err instanceof HttpErrorResponse) {
      if (err.status === 0) {
        return 'Sin conexión con el servidor. Verifique que el backend esté encendido.';
      }
      const mensaje = err.error?.message;
      if (typeof mensaje === 'string' && mensaje !== '') return mensaje;
    }
    return 'Ocurrió un error inesperado. Intente de nuevo.';
  }

  /** Pitido corto: el cajero escanea sin mirar la pantalla y necesita oír si entró. */
  private beep(tipo: 'ok' | 'error'): void {
    try {
      this.audio ??= new AudioContext();
      const oscilador = this.audio.createOscillator();
      const ganancia = this.audio.createGain();
      oscilador.type = 'square';
      oscilador.frequency.value = tipo === 'ok' ? 1250 : 240;
      ganancia.gain.value = 0.04;
      oscilador.connect(ganancia);
      ganancia.connect(this.audio.destination);
      oscilador.start();
      oscilador.stop(this.audio.currentTime + (tipo === 'ok' ? 0.07 : 0.28));
    } catch {
      // Sin audio disponible: la venta sigue funcionando igual.
    }
  }
}
