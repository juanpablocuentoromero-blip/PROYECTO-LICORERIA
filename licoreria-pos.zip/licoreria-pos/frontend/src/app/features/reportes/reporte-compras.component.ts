import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReporteService } from '../../core/services/reporte.service';
import { ProveedorService } from '../../core/services/proveedor.service';
import { ProductoService } from '../../core/services/producto.service';
import { Proveedor } from '../../core/models/proveedor.model';
import { Producto } from '../../core/models/producto.model';
import { AgruparCompras, ReporteCompras } from '../../core/models/reportes.model';
import { BASE_THEME } from '../../shared/theme/theme';
import { ATAJOS_RANGO, AtajoRango, rangoDe } from './rangos-fecha';

@Component({
  selector: 'app-reporte-compras',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="panel filtros">
      <div class="atajos">
        @for (a of atajos; track a.clave) {
          <button type="button" class="chip" (click)="aplicarAtajo(a.clave)">{{ a.etiqueta }}</button>
        }
      </div>

      <div class="form-grid">
        <div class="field"><label>Desde</label><input type="date" [(ngModel)]="desde" name="cDesde" /></div>
        <div class="field"><label>Hasta</label><input type="date" [(ngModel)]="hasta" name="cHasta" /></div>
        <div class="field">
          <label>Proveedor</label>
          <select [(ngModel)]="proveedorId" name="cProv">
            <option [ngValue]="null">Todos</option>
            @for (p of proveedores(); track p.id) { <option [ngValue]="p.id">{{ p.nombre }}</option> }
          </select>
        </div>
        <div class="field">
          <label>Producto</label>
          <select [(ngModel)]="productoId" name="cProd">
            <option [ngValue]="null">Todos</option>
            @for (p of productos(); track p.id) { <option [ngValue]="p.id">{{ p.nombre }}</option> }
          </select>
        </div>
        <div class="field">
          <label>Estado</label>
          <select [(ngModel)]="estado" name="cEstado">
            <option value="">Pendientes y recibidos</option>
            <option value="pendiente">Solo pendientes</option>
            <option value="recibido">Solo recibidos</option>
            <option value="cancelado">Solo cancelados</option>
          </select>
        </div>
        <div class="field">
          <label>Agrupar por</label>
          <select [(ngModel)]="agruparPor" name="cAgrupar">
            <option value="ninguno">Sin agrupar (por pedido)</option>
            <option value="proveedor">Proveedor</option>
            <option value="producto">Producto</option>
            <option value="dia">Día</option>
            <option value="mes">Mes</option>
          </select>
        </div>
      </div>

      <div class="field-row" style="margin-top:14px">
        <button class="btn-primary" [disabled]="cargando()" (click)="generar()">{{ cargando() ? 'Generando…' : 'Ver reporte' }}</button>
        <button class="btn-secondary" [disabled]="descargando()" (click)="descargarExcel()">{{ descargando() ? 'Generando…' : 'Descargar Excel' }}</button>
        @if (error()) { <span class="form-error">{{ error() }}</span> }
      </div>
    </section>

    @if (reporte(); as r) {
      <div class="tarjetas">
        <div class="tarjeta"><span>Pedidos</span><strong>{{ r.resumen.pedidos }}</strong></div>
        <div class="tarjeta"><span>Unidades compradas</span><strong>{{ r.resumen.unidades }}</strong></div>
        <div class="tarjeta"><span>Total comprado</span><strong>Bs {{ r.resumen.total.toFixed(2) }}</strong></div>
        <div class="tarjeta"><span>Recibido</span><strong>Bs {{ (r.resumen.por_estado['recibido'] || 0).toFixed(2) }}</strong></div>
        <div class="tarjeta"><span>Pendiente de llegar</span><strong>Bs {{ (r.resumen.por_estado['pendiente'] || 0).toFixed(2) }}</strong></div>
      </div>

      @if (r.pedidos.length === 0) {
        <div class="estado-vacio"><p>No hay compras en ese período con esos filtros.</p></div>
      } @else if (r.agrupar_por !== 'ninguno') {
        <table>
          <thead><tr><th>{{ etiquetaGrupo(r.agrupar_por) }}</th><th>Pedidos</th><th>Unidades</th><th>Total</th></tr></thead>
          <tbody>
            @for (g of r.grupos; track g.clave) {
              <tr>
                <td data-label="Grupo">{{ g.etiqueta }}</td>
                <td data-label="Pedidos">{{ g.pedidos }}</td>
                <td data-label="Unidades">{{ g.unidades }}</td>
                <td data-label="Total">Bs {{ g.total.toFixed(2) }}</td>
              </tr>
            }
          </tbody>
        </table>
      } @else {
        <table>
          <thead><tr><th>#</th><th>Fecha</th><th>Proveedor</th><th>Estado</th><th>Unidades</th><th>Total</th><th></th></tr></thead>
          <tbody>
            @for (p of r.pedidos; track p.id) {
              <tr>
                <td data-label="#">{{ p.id }}</td>
                <td data-label="Fecha">{{ p.fecha }}</td>
                <td data-label="Proveedor">{{ p.proveedor }}</td>
                <td data-label="Estado">
                  <span class="badge" [class.badge-info]="p.estado === 'pendiente'" [class.badge-ok]="p.estado === 'recibido'" [class.badge-danger]="p.estado === 'cancelado'">{{ p.estado }}</span>
                </td>
                <td data-label="Unidades">{{ p.unidades }}</td>
                <td data-label="Total">Bs {{ p.total.toFixed(2) }}</td>
                <td><button class="link-action" (click)="alternar(p.id)">{{ abierto() === p.id ? 'Ocultar' : 'Detalle' }}</button></td>
              </tr>
              @if (abierto() === p.id) {
                <tr class="fila-detalle">
                  <td colspan="7">
                    <table class="detalle">
                      <thead><tr><th>Producto</th><th>Cantidad</th><th>Costo unit.</th><th>Lote</th><th>Vence</th><th>Subtotal</th></tr></thead>
                      <tbody>
                        @for (it of p.items; track $index) {
                          <tr>
                            <td>{{ it.producto }}</td>
                            <td>@if (it.cantidad_paquetes) { {{ it.cantidad_paquetes }} paq × {{ it.unidades_por_paquete }} = {{ it.unidades }} u } @else { {{ it.unidades }} u }</td>
                            <td>Bs {{ it.costo_unitario.toFixed(2) }}</td>
                            <td>{{ it.numero_lote || '—' }}</td>
                            <td>{{ it.fecha_vencimiento || '—' }}</td>
                            <td>Bs {{ it.subtotal.toFixed(2) }}</td>
                          </tr>
                        }
                      </tbody>
                    </table>
                  </td>
                </tr>
              }
            }
          </tbody>
        </table>
      }
    }
  `,
  styles: [BASE_THEME, `
    .filtros { margin-bottom: 18px; }
    .atajos { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 14px; }
    .chip { background: transparent; color: var(--papel); border: 1px solid var(--papel-borde); border-radius: 999px; padding: 6px 12px; font-size: 13px; cursor: pointer; }
    .chip:hover { background: rgba(255,255,255,0.08); }
    .tarjetas { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 12px; margin-bottom: 18px; }
    .tarjeta { background: var(--papel); color: var(--tinta); border: 1px solid var(--papel-borde); border-radius: 12px; padding: 14px 16px; display: flex; flex-direction: column; gap: 4px; }
    .tarjeta span { font-size: 12px; opacity: 0.7; }
    .tarjeta strong { font-size: 20px; }
    .fila-detalle td { background: rgba(0,0,0,0.12); }
    .detalle { width: 100%; font-size: 13px; }
  `],
})
export class ReporteComprasComponent implements OnInit {
  private reporteService = inject(ReporteService);
  private proveedorService = inject(ProveedorService);
  private productoService = inject(ProductoService);

  atajos = ATAJOS_RANGO;
  proveedores = signal<Proveedor[]>([]);
  productos = signal<Producto[]>([]);
  reporte = signal<ReporteCompras | null>(null);
  cargando = signal(false);
  descargando = signal(false);
  error = signal('');
  abierto = signal<number | null>(null);

  desde = rangoDe('mes').desde;
  hasta = rangoDe('mes').hasta;
  proveedorId: number | null = null;
  productoId: number | null = null;
  estado: '' | 'pendiente' | 'recibido' | 'cancelado' = '';
  agruparPor: AgruparCompras = 'ninguno';

  ngOnInit(): void {
    this.proveedorService.listar().subscribe({ next: (d) => this.proveedores.set(d) });
    this.productoService.listar().subscribe({ next: (d) => this.productos.set(d) });
    this.generar();
  }

  aplicarAtajo(a: AtajoRango): void {
    const r = rangoDe(a);
    this.desde = r.desde;
    this.hasta = r.hasta;
    this.generar();
  }

  private filtros() {
    return {
      desde: this.desde,
      hasta: this.hasta,
      proveedor_id: this.proveedorId ?? undefined,
      producto_id: this.productoId ?? undefined,
      estado: this.estado,
      agrupar_por: this.agruparPor,
    };
  }

  etiquetaGrupo(a: AgruparCompras): string {
    return { ninguno: '', proveedor: 'Proveedor', producto: 'Producto', dia: 'Día', mes: 'Mes' }[a];
  }

  alternar(id: number): void {
    this.abierto.set(this.abierto() === id ? null : id);
  }

  generar(): void {
    this.cargando.set(true);
    this.error.set('');
    this.reporteService.compras(this.filtros()).subscribe({
      next: (r) => { this.reporte.set(r); this.cargando.set(false); },
      error: (err) => { this.error.set(err?.error?.message || 'No se pudo generar el reporte.'); this.cargando.set(false); },
    });
  }

  descargarExcel(): void {
    this.descargando.set(true);
    this.error.set('');
    const { agrupar_por, ...filtros } = this.filtros();
    this.reporteService
      .descargarExcel('compras-excel', filtros, 'reporte-compras')
      .catch(() => this.error.set('No se pudo descargar el Excel.'))
      .finally(() => this.descargando.set(false));
  }
}
