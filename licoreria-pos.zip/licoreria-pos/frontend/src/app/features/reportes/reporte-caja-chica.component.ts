import { Component, Input, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CajaChicaService } from '../../core/services/caja-chica.service';
import { UsuarioService } from '../../core/services/usuario.service';
import { Usuario } from '../../core/models/usuario.model';
import { CUENTAS_CAJA_CHICA } from '../../core/models/caja-chica.model';
import { FiltrosCajaChica, ReporteCajaChica } from '../../core/models/reportes.model';
import { BASE_THEME } from '../../shared/theme/theme';
import { ATAJOS_RANGO, AtajoRango, rangoDe } from './rangos-fecha';

// Reporte de caja chica. Lo usa el administrador (Reportes) y el cajero
// (pantalla de Caja): la API ya limita al vendedor a sus propios movimientos,
// así que acá solo se oculta el filtro por usuario cuando no es administrador.
@Component({
  selector: 'app-reporte-caja-chica',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="panel filtros">
      <div class="atajos">
        @for (a of atajos; track a.clave) {
          <button type="button" class="chip" (click)="aplicarAtajo(a.clave)">{{ a.etiqueta }}</button>
        }
      </div>

      <div class="form-grid">
        <div class="field"><label>Desde</label><input type="date" [(ngModel)]="desde" name="ccDesde" /></div>
        <div class="field"><label>Hasta</label><input type="date" [(ngModel)]="hasta" name="ccHasta" /></div>
        <div class="field">
          <label>Cuenta</label>
          <select [(ngModel)]="cuenta" name="ccCuenta">
            <option value="">Todas</option>
            @for (c of cuentas; track c) { <option [value]="c">{{ c }}</option> }
          </select>
        </div>
        <div class="field">
          <label>Tipo</label>
          <select [(ngModel)]="tipo" name="ccTipo">
            <option value="">Ingresos y egresos</option>
            <option value="ingreso">Solo ingresos</option>
            <option value="egreso">Solo egresos</option>
          </select>
        </div>
        <div class="field">
          <label>Método</label>
          <select [(ngModel)]="metodo" name="ccMetodo">
            <option value="">Efectivo y cheque</option>
            <option value="efectivo">Efectivo</option>
            <option value="cheque">Cheque</option>
          </select>
        </div>
        @if (esAdmin) {
          <div class="field">
            <label>Usuario</label>
            <select [(ngModel)]="usuarioId" name="ccUsuario">
              <option [ngValue]="null">Todos</option>
              @for (u of usuarios(); track u.id) { <option [ngValue]="u.id">{{ u.nombre }}</option> }
            </select>
          </div>
        }
      </div>

      <div class="field-row" style="margin-top:14px">
        <button class="btn-primary" [disabled]="cargando()" (click)="generar()">{{ cargando() ? 'Generando…' : 'Ver reporte' }}</button>
        <button class="btn-secondary" [disabled]="descargando()" (click)="descargarExcel()">{{ descargando() ? 'Generando…' : 'Descargar Excel' }}</button>
        <button class="btn-secondary" (click)="imprimir()">Imprimir</button>
        @if (error()) { <span class="form-error">{{ error() }}</span> }
      </div>
    </section>

    @if (reporte(); as r) {
      <div class="imprimible">
        <div class="tarjetas">
          <div class="tarjeta"><span>Movimientos</span><strong>{{ r.resumen.cantidad }}</strong></div>
          <div class="tarjeta ingreso"><span>Ingresos</span><strong>Bs {{ r.resumen.ingresos.toFixed(2) }}</strong></div>
          <div class="tarjeta egreso"><span>Egresos</span><strong>Bs {{ r.resumen.egresos.toFixed(2) }}</strong></div>
          <div class="tarjeta"><span>Saldo del período</span><strong>Bs {{ r.resumen.saldo.toFixed(2) }}</strong></div>
          <div class="tarjeta"><span>En efectivo (ing. / egr.)</span><strong>{{ r.resumen.ingresos_efectivo.toFixed(2) }} / {{ r.resumen.egresos_efectivo.toFixed(2) }}</strong></div>
          <div class="tarjeta"><span>En cheque (ing. / egr.)</span><strong>{{ r.resumen.ingresos_cheque.toFixed(2) }} / {{ r.resumen.egresos_cheque.toFixed(2) }}</strong></div>
        </div>

        @if (r.movimientos.length === 0) {
          <div class="estado-vacio"><p>No hay movimientos de caja chica en ese período con esos filtros.</p></div>
        } @else {
          <div class="dos-col">
            <div>
              <h4>Por cuenta</h4>
              <table>
                <thead><tr><th>Cuenta</th><th>Ingresos</th><th>Egresos</th><th>Saldo</th></tr></thead>
                <tbody>
                  @for (f of r.por_cuenta; track f.etiqueta) {
                    <tr><td data-label="Cuenta">{{ f.etiqueta }}</td><td data-label="Ingresos">{{ f.ingresos.toFixed(2) }}</td><td data-label="Egresos">{{ f.egresos.toFixed(2) }}</td><td data-label="Saldo">{{ f.saldo.toFixed(2) }}</td></tr>
                  }
                </tbody>
              </table>
            </div>
            <div>
              <h4>Por día</h4>
              <table>
                <thead><tr><th>Día</th><th>Ingresos</th><th>Egresos</th><th>Saldo</th></tr></thead>
                <tbody>
                  @for (f of r.por_dia; track f.etiqueta) {
                    <tr><td data-label="Día">{{ f.etiqueta }}</td><td data-label="Ingresos">{{ f.ingresos.toFixed(2) }}</td><td data-label="Egresos">{{ f.egresos.toFixed(2) }}</td><td data-label="Saldo">{{ f.saldo.toFixed(2) }}</td></tr>
                  }
                </tbody>
              </table>
            </div>
          </div>

          @if (r.por_usuario.length > 0) {
            <h4>Por usuario</h4>
            <table>
              <thead><tr><th>Usuario</th><th>Movimientos</th><th>Ingresos</th><th>Egresos</th><th>Saldo</th></tr></thead>
              <tbody>
                @for (f of r.por_usuario; track f.etiqueta) {
                  <tr><td data-label="Usuario">{{ f.etiqueta }}</td><td data-label="Movimientos">{{ f.cantidad }}</td><td data-label="Ingresos">{{ f.ingresos.toFixed(2) }}</td><td data-label="Egresos">{{ f.egresos.toFixed(2) }}</td><td data-label="Saldo">{{ f.saldo.toFixed(2) }}</td></tr>
                }
              </tbody>
            </table>
          }

          <h4>Detalle de movimientos</h4>
          <table>
            <thead><tr><th>Fecha</th><th>Caja</th><th>Cuenta</th><th>Concepto</th><th>Método</th><th>Ingreso</th><th>Egreso</th><th>Usuario</th></tr></thead>
            <tbody>
              @for (m of r.movimientos; track m.id) {
                <tr>
                  <td data-label="Fecha">{{ m.created_at | slice:0:16 }}</td>
                  <td data-label="Caja">#{{ m.caja_id }}</td>
                  <td data-label="Cuenta">{{ m.cuenta }}</td>
                  <td data-label="Concepto">{{ m.concepto }}@if (m.nro_documento) { <small> · doc. {{ m.nro_documento }}</small> }</td>
                  <td data-label="Método">{{ m.metodo_pago }}</td>
                  <td data-label="Ingreso">{{ m.tipo === 'ingreso' ? m.monto : '' }}</td>
                  <td data-label="Egreso">{{ m.tipo === 'egreso' ? m.monto : '' }}</td>
                  <td data-label="Usuario">{{ m.usuario?.nombre || '—' }}</td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>
    }
  `,
  styles: [BASE_THEME, `
    .filtros { margin-bottom: 18px; }
    .atajos { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 14px; }
    .chip { background: transparent; color: var(--papel); border: 1px solid var(--papel-borde); border-radius: 999px; padding: 6px 12px; font-size: 13px; cursor: pointer; }
    .chip:hover { background: rgba(255,255,255,0.08); }
    .tarjetas { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 12px; margin-bottom: 18px; }
    .tarjeta { background: var(--papel); color: var(--tinta); border: 1px solid var(--papel-borde); border-radius: 12px; padding: 14px 16px; display: flex; flex-direction: column; gap: 4px; }
    .tarjeta span { font-size: 12px; opacity: 0.7; }
    .tarjeta strong { font-size: 18px; }
    .tarjeta.ingreso strong { color: #1a7a3d; }
    .tarjeta.egreso strong { color: #b02020; }
    .dos-col { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 18px; }
    h4 { color: var(--papel); margin: 18px 0 8px; font-size: 16px; }
    @media print {
      :host { display: block; }
      .filtros { display: none !important; }
    }
  `],
})
export class ReporteCajaChicaComponent implements OnInit {
  /** Solo el administrador puede filtrar por usuario. */
  @Input() esAdmin = false;

  private cajaChicaService = inject(CajaChicaService);
  private usuarioService = inject(UsuarioService);

  atajos = ATAJOS_RANGO;
  cuentas = CUENTAS_CAJA_CHICA;
  usuarios = signal<Usuario[]>([]);
  reporte = signal<ReporteCajaChica | null>(null);
  cargando = signal(false);
  descargando = signal(false);
  error = signal('');

  desde = rangoDe('mes').desde;
  hasta = rangoDe('mes').hasta;
  cuenta = '';
  tipo: '' | 'ingreso' | 'egreso' = '';
  metodo: '' | 'efectivo' | 'cheque' = '';
  usuarioId: number | null = null;

  ngOnInit(): void {
    if (this.esAdmin) this.usuarioService.listar().subscribe({ next: (u) => this.usuarios.set(u) });
    this.generar();
  }

  aplicarAtajo(a: AtajoRango): void {
    const r = rangoDe(a);
    this.desde = r.desde;
    this.hasta = r.hasta;
    this.generar();
  }

  private filtros(): FiltrosCajaChica {
    return {
      desde: this.desde,
      hasta: this.hasta,
      cuenta: this.cuenta,
      tipo: this.tipo,
      metodo_pago: this.metodo,
      usuario_id: this.esAdmin ? (this.usuarioId ?? undefined) : undefined,
    };
  }

  generar(): void {
    this.cargando.set(true);
    this.error.set('');
    this.cajaChicaService.reporte(this.filtros()).subscribe({
      next: (r) => { this.reporte.set(r); this.cargando.set(false); },
      error: (err) => { this.error.set(err?.error?.message || 'No se pudo generar el reporte.'); this.cargando.set(false); },
    });
  }

  descargarExcel(): void {
    this.descargando.set(true);
    this.error.set('');
    this.cajaChicaService
      .descargarReporteExcel(this.filtros())
      .catch(() => this.error.set('No se pudo descargar el Excel.'))
      .finally(() => this.descargando.set(false));
  }

  imprimir(): void {
    window.print();
  }
}
