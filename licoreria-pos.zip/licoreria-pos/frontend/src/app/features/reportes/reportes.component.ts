import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReporteService, TipoReporte } from '../../core/services/reporte.service';
import { ReporteComprasComponent } from './reporte-compras.component';
import { ReporteCajaChicaComponent } from './reporte-caja-chica.component';
import { ReporteCajeroComponent } from './reporte-cajero.component';
import { ATAJOS_RANGO, AtajoRango, rangoDe } from './rangos-fecha';
import { BASE_THEME } from '../../shared/theme/theme';

interface TarjetaReporte {
  tipo: TipoReporte;
  titulo: string;
  descripcion: string;
  icono: string;
}

@Component({
  selector: 'app-reportes',
  standalone: true,
  imports: [CommonModule, FormsModule, ReporteComprasComponent, ReporteCajaChicaComponent, ReporteCajeroComponent],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Administración &middot; Reportes</div>
          <h1>Reportes</h1>
          <p class="subtitle">Mira los reportes en pantalla o descarga los datos en una hoja de cálculo (.xlsx).</p>
        </div>
      </header>

      <div class="tabs">
        <button type="button" [class.activo]="pestana() === 'excel'" (click)="pestana.set('excel')">Descargas Excel</button>
        <button type="button" [class.activo]="pestana() === 'compras'" (click)="pestana.set('compras')">Compras</button>
        <button type="button" [class.activo]="pestana() === 'caja'" (click)="pestana.set('caja')">Caja y cierres</button>
        <button type="button" [class.activo]="pestana() === 'caja-chica'" (click)="pestana.set('caja-chica')">Caja chica</button>
      </div>

      @if (pestana() === 'compras') {
        <app-reporte-compras />
      }
      @if (pestana() === 'caja') {
        <app-reporte-cajero [esAdmin]="true" />
      }
      @if (pestana() === 'caja-chica') {
        <app-reporte-caja-chica [esAdmin]="true" />
      }

      @if (pestana() === 'excel') {
      @if (error()) {
        <div class="panel" style="border-color:#d64545">
          <span class="form-error">{{ error() }}</span>
        </div>
      }

      <section class="panel filtros-fecha">
        <div class="field">
          <label>Desde <span>(opcional)</span></label>
          <input type="date" [(ngModel)]="desde" name="desde" />
        </div>
        <div class="field">
          <label>Hasta <span>(opcional)</span></label>
          <input type="date" [(ngModel)]="hasta" name="hasta" />
        </div>
        <div class="atajos">
          @for (a of atajos; track a.clave) {
            <button type="button" class="chip" (click)="aplicarAtajo(a.clave)">{{ a.etiqueta }}</button>
          }
          <button type="button" class="chip" (click)="limpiarFechas()">Todo el historial</button>
        </div>
        <p class="hint">Si no eliges fechas, cada reporte trae todos los registros.</p>
      </section>

      <div class="grid">
        @for (r of tarjetas; track r.tipo) {
          <article class="reporte-card">
            <div class="icono">{{ r.icono }}</div>
            <h3>{{ r.titulo }}</h3>
            <p>{{ r.descripcion }}</p>
            <button class="btn-primary" [disabled]="descargando() === r.tipo" (click)="descargar(r.tipo)">
              {{ descargando() === r.tipo ? 'Generando…' : 'Descargar .xlsx' }}
            </button>
          </article>
        }
      </div>
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .filtros-fecha { display: flex; align-items: flex-end; gap: 18px; flex-wrap: wrap; margin-bottom: 8px; }
    .filtros-fecha .field { display: flex; flex-direction: column; gap: 6px; }
    .filtros-fecha .field label { font-size: 13px; font-weight: 600; color: var(--tinta); }
    .filtros-fecha .field label span { font-weight: 400; color: #8a806a; }
    .filtros-fecha input {
      background: #fff; border: 1px solid var(--papel-borde); border-radius: 8px;
      padding: 8px 10px; font-size: 14px; color: var(--tinta);
    }
    .atajos { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
    .chip { background: transparent; color: var(--tinta); border: 1px solid var(--papel-borde); border-radius: 999px; padding: 6px 12px; font-size: 13px; cursor: pointer; }
    .chip:hover { background: rgba(0,0,0,0.06); }
    .tabs { display: flex; gap: 6px; margin-bottom: 22px; background: rgba(8,18,36,0.35); border-radius: 10px; padding: 4px; flex-wrap: wrap; }
    .tabs button { flex: 1; background: transparent; border: none; color: var(--papel); padding: 9px 14px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; white-space: nowrap; }
    .tabs button.activo { background: var(--papel); color: var(--tinta); }
    .filtros-fecha .hint { font-size: 12px; color: #8a806a; margin: 0 0 4px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); gap: 18px; }
    .reporte-card {
      background: var(--papel);
      border: 1px solid var(--papel-borde);
      border-radius: 12px;
      padding: 22px 20px;
      box-shadow: 0 6px 16px rgba(0,0,0,0.28);
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .icono { font-size: 28px; }
    .reporte-card h3 { font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif; font-size: 19px; margin: 0; color: var(--tinta); }
    .reporte-card p { font-size: 13px; color: #5a5140; line-height: 1.5; margin: 0 0 8px; min-height: 40px; }
    .reporte-card .btn-primary { width: 100%; }
  `],
})
export class ReportesComponent {
  private reporteService = inject(ReporteService);

  descargando = signal<TipoReporte | null>(null);
  error = signal('');

  desde = '';
  hasta = '';

  tarjetas: TarjetaReporte[] = [
    { tipo: 'rentabilidad', titulo: 'Rentabilidad', descripcion: 'Ganancia por producto vendido: ingreso, costo y margen, con total general.', icono: '💰' },
    { tipo: 'ventas', titulo: 'Ventas / Pedidos', descripcion: 'Cada pedido con cliente, vendedor, estado, método de pago y total.', icono: '🧾' },
    { tipo: 'inventario', titulo: 'Inventario actual', descripcion: 'Stock, precios y valor en inventario de cada producto.', icono: '📦' },
    { tipo: 'movimientos', titulo: 'Movimientos de inventario', descripcion: 'Historial de entradas y salidas de stock, con motivo y responsable.', icono: '🔄' },
    { tipo: 'clientes', titulo: 'Clientes', descripcion: 'Datos de contacto y cantidad de pedidos por cliente.', icono: '👥' },
    { tipo: 'compras-excel', titulo: 'Compras', descripcion: 'Cada producto comprado a proveedores: paquetes, costo, lote y vencimiento.', icono: '🛒' },
    { tipo: 'cajas-excel', titulo: 'Cierres de caja', descripcion: 'Cada turno de caja con lo esperado, lo contado y la diferencia.', icono: '🧮' },
  ];

  atajos = ATAJOS_RANGO;
  pestana = signal<'excel' | 'compras' | 'caja' | 'caja-chica'>('excel');

  aplicarAtajo(a: AtajoRango): void {
    const r = rangoDe(a);
    this.desde = r.desde;
    this.hasta = r.hasta;
  }

  limpiarFechas(): void {
    this.desde = '';
    this.hasta = '';
  }

  descargar(tipo: TipoReporte): void {
    this.error.set('');
    this.descargando.set(tipo);
    this.reporteService
      .descargar(tipo, this.desde || undefined, this.hasta || undefined)
      .catch(() => this.error.set('No se pudo generar el reporte. Verifica que el backend tenga instalado maatwebsite/excel.'))
      .finally(() => this.descargando.set(null));
  }
}
