// Atajos de rango de fechas compartidos por los reportes. Devuelven fechas
// YYYY-MM-DD en la hora local del navegador (la de Bolivia en el negocio).
export type AtajoRango = 'hoy' | 'ayer' | '7dias' | 'mes' | 'mes_anterior' | 'anio';

export const ATAJOS_RANGO: { clave: AtajoRango; etiqueta: string }[] = [
  { clave: 'hoy', etiqueta: 'Hoy' },
  { clave: 'ayer', etiqueta: 'Ayer' },
  { clave: '7dias', etiqueta: 'Últimos 7 días' },
  { clave: 'mes', etiqueta: 'Este mes' },
  { clave: 'mes_anterior', etiqueta: 'Mes anterior' },
  { clave: 'anio', etiqueta: 'Este año' },
];

function iso(d: Date): string {
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const dia = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${dia}`;
}

export function rangoDe(atajo: AtajoRango): { desde: string; hasta: string } {
  const hoy = new Date();
  const ini = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate());

  switch (atajo) {
    case 'hoy':
      return { desde: iso(ini), hasta: iso(ini) };
    case 'ayer': {
      const a = new Date(ini);
      a.setDate(a.getDate() - 1);
      return { desde: iso(a), hasta: iso(a) };
    }
    case '7dias': {
      const a = new Date(ini);
      a.setDate(a.getDate() - 6);
      return { desde: iso(a), hasta: iso(ini) };
    }
    case 'mes':
      return { desde: iso(new Date(ini.getFullYear(), ini.getMonth(), 1)), hasta: iso(ini) };
    case 'mes_anterior':
      return {
        desde: iso(new Date(ini.getFullYear(), ini.getMonth() - 1, 1)),
        hasta: iso(new Date(ini.getFullYear(), ini.getMonth(), 0)),
      };
    case 'anio':
      return { desde: iso(new Date(ini.getFullYear(), 0, 1)), hasta: iso(ini) };
  }
}
