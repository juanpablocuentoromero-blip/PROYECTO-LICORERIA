import { Component, Input, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CajaService } from '../../core/services/caja.service';
import { ReporteService } from '../../core/services/reporte.service';
import { UsuarioService } from '../../core/services/usuario.service';
import { Usuario } from '../../core/models/usuario.model';
import { ReporteCajero } from '../../core/models/reportes.model';
import { BASE_THEME } from '../../shared/theme/theme';
import { ATAJOS_RANGO, AtajoRango, rangoDe } from './rangos-fecha';

// Reporte de caja del cajero: sus ventas por día y método de pago, sus
// turnos y su caja chica. El vendedor solo ve lo suyo (la API lo fuerza);
// el administrador puede elegir un cajero o ver el total de todos.
@Component({
  selector: 'app-reporte-cajero',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="panel filtros">
      <div class="atajos">
        @for (a of atajos; track a.clave) {
          <button type="button" class="chip" (click)="aplicarAtajo(a.clave)">{{ a.etiqueta }}</button>
        }
      </div>
      <div class="form-grid">
        <div class="field"><label>Desde</label><input type="date" [(ngModel)]="desde" name="rcDesde" /></div>
        <div class="field"><label>Hasta</label><input type="date" [(ngModel)]="hasta" name="rcHasta" /></div>
        @if (esAdmin) {
          <div class="field">
            <label>Cajero</label>
            <select [(ngModel)]="usuarioId" name="rcUsuario">
              <option [ngValue]="null">Todos</option>
              @for (u of usuarios(); track u.id) { <option [ngValue]="u.id">{{ u.nombre }}</option> }
            </select>
          </div>
        }
      </div>
      <div class="field-row" style="margin-top:14px">
        <button class="btn-primary" [disabled]="cargando()" (click)="generar()">{{ cargando() ? 'Generando…' : 'Ver reporte' }}</button>
        @if (esAdmin) {
          <button class="btn-secondary" [disabled]="descargando()" (click)="descargarCierres()">{{ descargando() ? 'Generando…' : 'Descargar cierres (Excel)' }}</button>
        }
        <button class="btn-secondary" (click)="imprimir()">Imprimir</button>
        @if (error()) { <span class="form-error">{{ error() }}</span> }
      </div>
    </section>

    @if (reporte(); as r) {
      <div class="tarjetas">
        <div class="tarjeta"><span>Ventas cobradas</span><strong>{{ r.resumen.cantidad_ventas }}</strong></div>
        <div class="tarjeta"><span>Total vendido</span><strong>Bs {{ r.resumen.total.toFixed(2) }}</strong></div>
        <div class="tarjeta"><span>Efectivo</span><strong>Bs {{ r.resumen.efectivo.toFixed(2) }}</strong></div>
        <div class="tarjeta"><span>QR</span><strong>Bs {{ r.resumen.qr.toFixed(2) }}</strong></div>
        <div class="tarjeta"><span>Tarjeta</span><strong>Bs {{ r.resumen.tarjeta.toFixed(2) }}</strong></div>
        <div class="tarjeta"><span>Ticket promedio</span><strong>Bs {{ r.resumen.ticket_promedio.toFixed(2) }}</strong></div>
        <div class="tarjeta"><span>Ventas a crédito</span><strong>Bs {{ r.resumen.ventas_credito.toFixed(2) }}</strong></div>
        <div class="tarjeta"><span>Anuladas</span><strong>{{ r.resumen.cantidad_anuladas }} · Bs {{ r.resumen.monto_anulado.toFixed(2) }}</strong></div>
      </div>

      <h4>Ventas por día</h4>
      @if (r.por_dia.length === 0) {
        <div class="estado-vacio"><p>No hay ventas cobradas en este período.</p></div>
      } @else {
        <table>
          <thead><tr><th>Día</th><th>Ventas</th><th>Efectivo</th><th>QR</th><th>Tarjeta</th><th>Total</th></tr></thead>
          <tbody>
            @for (d of r.por_dia; track d.fecha) {
              <tr>
                <td data-label="Día">{{ d.fecha }}</td>
                <td data-label="Ventas">{{ d.cantidad }}</td>
                <td data-label="Efectivo">{{ d.efectivo.toFixed(2) }}</td>
                <td data-label="QR">{{ d.qr.toFixed(2) }}</td>
                <td data-label="Tarjeta">{{ d.tarjeta.toFixed(2) }}</td>
                <td data-label="Total"><strong>{{ d.total.toFixed(2) }}</strong></td>
              </tr>
            }
          </tbody>
        </table>
      }

      <h4>Turnos de caja</h4>
      @if (r.turnos.length === 0) {
        <div class="estado-vacio"><p>No hubo turnos de caja en este período.</p></div>
      } @else {
        <table>
          <thead>
            <tr>
              <th>#</th><th>Abierta</th><th>Cerrada</th><th>Apertura</th><th>Contado al cerrar</th>
              @if (esAdmin) { <th>Esperado</th><th>Diferencia</th> }
            </tr>
          </thead>
          <tbody>
            @for (t of r.turnos; track t.id) {
              <tr>
                <td data-label="#">{{ t.id }}</td>
                <td data-label="Abierta">{{ t.abierta_at | slice:0:16 }} <small>{{ t.abierta_por }}</small></td>
                <td data-label="Cerrada">@if (t.cerrada_at) { {{ t.cerrada_at | slice:0:16 }} <small>{{ t.cerrada_por }}</small> } @else { <span class="badge badge-info">abierta</span> }</td>
                <td data-label="Apertura">{{ t.monto_apertura.toFixed(2) }}</td>
                <td data-label="Contado">{{ t.monto_cierre_real !== null ? t.monto_cierre_real.toFixed(2) : '—' }}</td>
                @if (esAdmin) {
                  <td data-label="Esperado">{{ t.monto_cierre_esperado !== undefined ? t.monto_cierre_esperado.toFixed(2) : '—' }}</td>
                  <td data-label="Diferencia">
                    @if (t.diferencia !== undefined) {
                      <span [class.dif-neg]="t.diferencia < 0" [class.dif-pos]="t.diferencia > 0">{{ t.diferencia.toFixed(2) }}</span>
                    } @else { — }
                  </td>
                }
              </tr>
            }
          </tbody>
        </table>
      }

      <h4>Caja chica del período</h4>
      <div class="tarjetas">
        <div class="tarjeta"><span>Movimientos</span><strong>{{ r.caja_chica.movimientos }}</strong></div>
        <div class="tarjeta"><span>Ingresos</span><strong>Bs {{ r.caja_chica.ingresos.toFixed(2) }}</strong></div>
        <div class="tarjeta"><span>Egresos</span><strong>Bs {{ r.caja_chica.egresos.toFixed(2) }}</strong></div>
        <div class="tarjeta"><span>Saldo</span><strong>Bs {{ r.caja_chica.saldo.toFixed(2) }}</strong></div>
      </div>
    }
  `,
  styles: [BASE_THEME, `
    .filtros { margin-bottom: 18px; }
    .atajos { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 14px; }
    .chip { background: transparent; color: var(--papel); border: 1px solid var(--papel-borde); border-radius: 999px; padding: 6px 12px; font-size: 13px; cursor: pointer; }
    .chip:hover { background: rgba(255,255,255,0.08); }
    .tarjetas { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 12px; margin-bottom: 18px; }
    .tarjeta { background: var(--papel); color: var(--tinta); border: 1px solid var(--papel-borde); border-radius: 12px; padding: 14px 16px; display: flex; flex-direction: column; gap: 4px; }
    .tarjeta span { font-size: 12px; opacity: 0.7; }
    .tarjeta strong { font-size: 18px; }
    h4 { color: var(--papel); margin: 18px 0 8px; font-size: 16px; }
    .dif-neg { color: #d64545; font-weight: 600; }
    .dif-pos { color: #d6a545; font-weight: 600; }
    @media print { .filtros { display: none !important; } }
  `],
})
export class ReporteCajeroComponent implements OnInit {
  /** El administrador puede elegir cajero y ve esperado/diferencia de cada cierre. */
  @Input() esAdmin = false;

  private cajaService = inject(CajaService);
  private reporteService = inject(ReporteService);
  private usuarioService = inject(UsuarioService);

  atajos = ATAJOS_RANGO;
  usuarios = signal<Usuario[]>([]);
  reporte = signal<ReporteCajero | null>(null);
  cargando = signal(false);
  descargando = signal(false);
  error = signal('');

  // Por defecto, el día de hoy: es lo que un cajero revisa al cerrar su turno.
  desde = rangoDe('hoy').desde;
  hasta = rangoDe('hoy').hasta;
  usuarioId: number | null = null;

  ngOnInit(): void {
    if (this.esAdmin) this.usuarioService.listar().subscribe({ next: (u) => this.usuarios.set(u) });
    this.generar();
  }

  aplicarAtajo(a: AtajoRango): void {
    const r = rangoDe(a);
    this.desde = r.desde;
    this.hasta = r.hasta;
    this.generar();
  }

  generar(): void {
    this.cargando.set(true);
    this.error.set('');
    this.cajaService
      .miReporte({ desde: this.desde, hasta: this.hasta, usuario_id: this.esAdmin ? (this.usuarioId ?? undefined) : undefined })
      .subscribe({
        next: (r) => { this.reporte.set(r); this.cargando.set(false); },
        error: (err) => { this.error.set(err?.error?.message || 'No se pudo generar el reporte.'); this.cargando.set(false); },
      });
  }

  descargarCierres(): void {
    this.descargando.set(true);
    this.error.set('');
    this.reporteService
      .descargarExcel('cajas-excel', { desde: this.desde, hasta: this.hasta, usuario_id: this.usuarioId ?? undefined }, 'reporte-cajas')
      .catch(() => this.error.set('No se pudo descargar el Excel.'))
      .finally(() => this.descargando.set(false));
  }

  imprimir(): void {
    window.print();
  }
}
