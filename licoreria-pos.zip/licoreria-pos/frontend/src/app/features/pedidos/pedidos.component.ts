import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { PedidoService } from '../../core/services/pedido.service';
import { ProductoService } from '../../core/services/producto.service';
import { ClienteService } from '../../core/services/cliente.service';
import { AuthService } from '../../core/services/auth.service';
import { Pedido, DetallePedido } from '../../core/models/pedido.model';
import { Producto } from '../../core/models/producto.model';
import { Cliente } from '../../core/models/cliente.model';
import { BASE_THEME } from '../../shared/theme/theme';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';
import { TARJETA_ICONOS } from '../../shared/theme/tarjeta-iconos';
import { DeliveryService } from '../../core/services/delivery.service';
import { AnchoTicket, TicketService } from '../../core/services/ticket.service';
import { Repartidor } from '../../core/models/paso5.model';
import { PaginadorComponent } from '../../shared/paginador/paginador.component';
import { Presentacion, enteroSeguro, factorDe, opcionesDe, textoCantidad } from '../../core/utils/presentacion';

/** Línea de la venta que se está armando (o del pedido que se está editando). */
interface LineaCarrito {
  producto_id: number;
  /** Cuántas presentaciones (unidades, paquetes o cajas). */
  cantidad: number;
  presentacion: Presentacion;
  producto: Producto;
  /** Precio unitario con el que se cobra (el congelado en pedidos ya hechos). */
  precio: number;
}

@Component({
  selector: 'app-pedidos',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginadorComponent],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Ventas &middot; Pedidos</div>
          <h1>Pedidos y ventas</h1>
          <p class="subtitle">Arma el carrito, registra la venta y descuenta el stock automáticamente.</p>
        </div>
        <label class="ancho-ticket" title="Ancho del rollo de la impresora térmica de esta caja">
          Ticket térmico
          <select [ngModel]="anchoTicket()" (ngModelChange)="cambiarAnchoTicket($event)" name="anchoTicket">
            <option [ngValue]="80">80 mm</option>
            <option [ngValue]="58">58 mm</option>
          </select>
        </label>
      </header>

      <section class="panel">
        <h3 class="panel-title">Nueva venta</h3>

        <div class="form-grid">
          <div class="field">
            <label>Cliente <span>(escribe para buscar por nombre o NIT/CI)</span></label>
            <input type="text" list="lista-clientes" autocomplete="off" placeholder="Escribe el nombre del cliente…"
                   [ngModel]="clienteTexto()" (ngModelChange)="alEscribirCliente($event)" name="clienteTexto" />
            <datalist id="lista-clientes">
              @for (c of clientes(); track c.id) { <option [value]="etiquetaCliente(c)"></option> }
            </datalist>
            @if (clienteTexto() && !clienteId) {
              <small class="ayuda-cliente">Elige un cliente de la lista (o regístralo primero en Clientes).</small>
            }
          </div>
          <div class="field">
            <label>Teléfono <span class="obligatorio">(obligatorio)</span></label>
            <input type="tel" [(ngModel)]="telefono" name="telefono" maxlength="20" placeholder="Ej. 75612345" required />
          </div>
          <div class="field">
            <label>Método de pago</label>
            <select [(ngModel)]="metodoPago" name="metodoPago">
              <option value="efectivo">Efectivo</option>
              <option value="qr">QR</option>
              <option value="tarjeta">Tarjeta</option>
              <option value="credito">Crédito (fiado)</option>
            </select>
            @if (metodoPago === 'tarjeta') {
              <div class="tarjeta-iconos" [innerHTML]="tarjetaIconosHtml"></div>
            }
            @if (metodoPago === 'credito') {
              <small class="ayuda-cliente">
                Queda sin cobrar y se cobra después en <strong>Cuentas por cobrar</strong>. El cliente debe tener el
                crédito habilitado (Clientes) y NIT/CI.
              </small>
            }
          </div>
          @if (metodoPago === 'credito') {
            <div class="field">
              <label>Días para pagar</label>
              <input type="number" min="0" max="365" [(ngModel)]="diasCredito" name="diasCredito" />
            </div>
          }
          <div class="field">
            <label>Dirección de entrega <span>(opcional)</span></label>
            <input type="text" [(ngModel)]="direccion" name="direccion" />
          </div>
        </div>

        <div class="agregar-linea">
          <select [(ngModel)]="productoSeleccionado" (ngModelChange)="alElegirProducto()" name="productoSeleccionado">
            <option [ngValue]="null">Selecciona un producto…</option>
            @for (p of productos(); track p.id) {
              <option [ngValue]="p.id" [disabled]="p.stock === 0">{{ p.nombre }} — Bs {{ p.precio_venta }} (stock: {{ p.stock }} u.)</option>
            }
          </select>
          <select class="sel-pres" [(ngModel)]="presSeleccionada" name="presSeleccionada" aria-label="Presentación">
            @for (o of opcionesSeleccionado(); track o.valor) { <option [ngValue]="o.valor">{{ o.etiqueta }}</option> }
          </select>
          <input type="number" min="1" [(ngModel)]="cantidadSeleccionada" name="cantidadSeleccionada"
                 (keyup.enter)="agregarAlCarrito()" style="width:90px" aria-label="Cantidad" />
          <button type="button" class="btn-secondary" (click)="agregarAlCarrito()">Agregar</button>
        </div>

        @if (carrito().length > 0) {
          <table class="carrito-tabla">
            <thead><tr><th>Producto</th><th>Presentación</th><th>Cant.</th><th>Unidades</th><th>P. Unit.</th><th>Subtotal</th><th></th></tr></thead>
            <tbody>
              @for (linea of carrito(); track linea.producto_id + linea.presentacion) {
                <tr>
                  <td data-label="Producto">{{ linea.producto.nombre }}</td>
                  <td data-label="Presentación">{{ nombrePres(linea.presentacion) }}</td>
                  <td data-label="Cant.">
                    <input class="input-cant" type="number" min="1" [ngModel]="linea.cantidad"
                           (ngModelChange)="cambiarCantidadCarrito(linea, $event)" [name]="'c' + linea.producto_id + linea.presentacion" />
                  </td>
                  <td data-label="Unidades">{{ unidadesLinea(linea) }}</td>
                  <td data-label="P. Unit.">Bs {{ linea.precio }}</td>
                  <td data-label="Subtotal">Bs {{ subtotalLinea(linea).toFixed(2) }}</td>
                  <td><button class="link-danger" (click)="quitarDelCarrito(linea)">Quitar</button></td>
                </tr>
              }
            </tbody>
          </table>
          <div class="total-row">Total: <strong>Bs {{ totalCarrito().toFixed(2) }}</strong></div>
        }

        <div class="field-row" style="margin-top:14px">
          <button class="btn-primary" [disabled]="!puedeConfirmar() || guardando()" (click)="confirmarVenta()">
            {{ guardando() ? 'Registrando…' : 'Confirmar venta' }}
          </button>
          @if (error()) { <span class="form-error">{{ error() }}</span> }
          @if (mensajeOk()) { <span class="form-ok">{{ mensajeOk() }}</span> }
        </div>
      </section>

      <h3 class="panel-title" style="margin: 0">Historial de pedidos</h3>
      @if (cargandoPedidos()) {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando pedidos…</p></div>
      } @else if (pedidos().length === 0) {
        <div class="estado-vacio"><p>Todavía no hay pedidos registrados.</p></div>
      } @else {
        <table>
          <thead><tr><th>#</th><th>Cliente</th><th>Entrega</th><th>Total</th><th>Estado</th><th>Pago</th><th>Fecha</th><th></th></tr></thead>
          <tbody>
            @for (p of pedidos(); track p.id) {
              <tr>
                <td data-label="#">{{ p.id }}</td>
                <td data-label="Cliente">{{ p.cliente?.nombre || '—' }}</td>
                <td data-label="Entrega">
                  @if (p.tipo_entrega === 'delivery') {
                    <span class="badge badge-info">🛵 Delivery</span>
                    <small class="sub-entrega">{{ p.zona_delivery?.nombre || '' }}</small>
                    @if (p.repartidor) { <small class="sub-entrega">Repartidor: {{ p.repartidor.nombre }}</small> }
                  } @else if (p.origen === 'online') {
                    <span class="badge badge-off">🏪 Recojo</span>
                  } @else {
                    <span class="sub-entrega">Mostrador</span>
                  }
                </td>
                <td data-label="Total">Bs {{ p.total }}</td>
                <td data-label="Estado">
                  <span class="badge"
                    [class.badge-info]="p.estado === 'pendiente' || p.estado === 'en_camino'"
                    [class.badge-ok]="p.estado === 'entregado' || p.estado === 'confirmado'"
                    [class.badge-danger]="p.estado === 'cancelado'">{{ p.estado === 'en_camino' ? 'en camino' : p.estado }}</span>
                </td>
                <td data-label="Pago">
                  @if (p.metodo_pago === 'credito' && p.estado !== 'cancelado') {
                    <span class="badge" [class.badge-ok]="+(p.saldo_pendiente ?? 0) === 0" [class.badge-warn]="+(p.saldo_pendiente ?? 0) > 0">
                      {{ +(p.saldo_pendiente ?? 0) === 0 ? 'Crédito saldado' : 'Crédito · debe Bs ' + p.saldo_pendiente }}
                    </span>
                  } @else if (p.pagado) {
                    <span class="badge badge-ok">Pagado · {{ p.metodo_pago }}</span>
                  } @else if (p.estado !== 'cancelado') {
                    <div class="pago-acciones">
                      <button class="link-action" (click)="confirmarPago(p, 'efectivo')">💵 Efectivo</button>
                      <button class="link-action" (click)="mostrarQr(p)">📱 QR</button>
                      <button class="link-action tarjeta-btn" (click)="confirmarPago(p, 'tarjeta')">
                        <span [innerHTML]="tarjetaIconosHtml"></span> Tarjeta
                      </button>
                    </div>
                  } @else {
                    <span class="badge badge-danger">No pagado</span>
                  }
                </td>
                <td data-label="Fecha">{{ p.created_at ? (p.created_at | slice:0:10) : '—' }}</td>
                <td data-label="Acciones">
                  <button class="link-action" (click)="verDetalle(p)">🔍 Ver detalle</button>
                  @if (p.estado !== 'cancelado') {
                    <button class="link-action" (click)="abrirEdicion(p)">✏️ Editar</button>
                  }
                  @if (p.estado === 'pendiente') {
                    <button class="link-action" (click)="cambiarEstado(p, 'confirmado')">Confirmar</button>
                  }
                  @if (p.estado === 'confirmado' && p.tipo_entrega === 'delivery') {
                    <span class="repartidor-fila">
                      <select [ngModel]="repartidorElegido[p.id] ?? p.repartidor_id ?? null"
                              (ngModelChange)="repartidorElegido[p.id] = $event" name="rep{{ p.id }}">
                        <option [ngValue]="null">Repartidor…</option>
                        @for (r of repartidores(); track r.id) { <option [ngValue]="r.id">{{ r.nombre }}</option> }
                      </select>
                      <button class="link-action" (click)="salirARepartir(p)">🛵 En camino</button>
                    </span>
                  }
                  @if (p.estado === 'confirmado' && p.tipo_entrega !== 'delivery') {
                    <button class="link-action" (click)="cambiarEstado(p, 'entregado')">Entregar</button>
                  }
                  @if (p.estado === 'en_camino') {
                    <button class="link-action" (click)="cambiarEstado(p, 'entregado')">Entregar</button>
                  }
                  @if (p.estado !== 'cancelado') {
                    <button class="link-action" (click)="imprimirTicket(p)">🖨️ Ticket</button>
                  }
                  @if (p.pagado) {
                    <button class="link-action" [disabled]="descargando() === p.id" (click)="descargarFactura(p)">
                      {{ descargando() === p.id ? 'Generando…' : '🧾 Nota de venta' }}
                    </button>
                    <div class="reenvio-menu">
                      <button class="link-action" (click)="toggleReenvio(p.id)">↻ Reenviar</button>
                      @if (reenvioAbierto() === p.id) {
                        <div class="reenvio-opciones">
                          @if (p.cliente?.email) {
                            <button (click)="reenviar(p, 'correo')">📧 Por correo</button>
                          }
                          @if (p.cliente?.telefono) {
                            <button (click)="reenviar(p, 'whatsapp')">📱 Por WhatsApp</button>
                          }
                        </div>
                      }
                    </div>
                  }
                  @if (p.estado !== 'cancelado' && p.estado !== 'entregado') {
                    <button class="link-danger" (click)="cancelarPedido(p)">Cancelar</button>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
        <app-paginador [actual]="paginaActual()" [ultima]="ultimaPagina()" [total]="totalRegistros()"
                       etiqueta="pedidos" (cambiar)="cargarPedidos($event)" />
      }

      @if (pedidoEditando(); as pe) {
        <div class="modal-fondo" (click)="cerrarEdicion()">
          <div class="modal-panel modal-panel-ancho" (click)="$event.stopPropagation()">
            <h3>Editar pedido #{{ pe.id }}</h3>
            <p class="subtitle">
              @if (puedeEditarProductos()) {
                Corrige los datos y los productos (por ejemplo, quita lo que se acabó o agrega lo que faltó). El stock y el total se ajustan solos.
              } @else {
                Corrige los datos de contacto y entrega. Este pedido ya está cobrado o entregado: los productos no se pueden cambiar (usa una devolución).
              }
            </p>

            <div class="edit-grid">
              <div class="field">
                <label>Teléfono <span class="obligatorio">(obligatorio)</span></label>
                <input type="tel" [(ngModel)]="editTelefono" name="editTelefono" maxlength="20" />
              </div>
              <div class="field">
                <label>Dirección de entrega <span>(opcional)</span></label>
                <input type="text" [(ngModel)]="editDireccion" name="editDireccion" maxlength="255" />
              </div>
              <div class="field edit-obs">
                <label>Observaciones <span>(opcional)</span></label>
                <input type="text" [(ngModel)]="editObservaciones" name="editObservaciones" />
              </div>
            </div>

            @if (puedeEditarProductos()) {
              <h4 class="edit-sub">Productos del pedido</h4>
              <table class="tabla-detalle">
                <thead><tr><th>Producto</th><th>Presentación</th><th>Cant.</th><th>Unid.</th><th>Subtotal</th><th></th></tr></thead>
                <tbody>
                  @for (l of editLineas(); track l.producto_id + l.presentacion) {
                    <tr>
                      <td data-label="Producto">{{ l.producto.nombre }}</td>
                      <td data-label="Presentación">{{ nombrePres(l.presentacion) }}</td>
                      <td data-label="Cant.">
                        <input class="input-cant" type="number" min="1" [ngModel]="l.cantidad"
                               (ngModelChange)="cambiarCantidadEdicion(l, $event)" [name]="'e' + l.producto_id + l.presentacion" />
                      </td>
                      <td data-label="Unid.">{{ unidadesLinea(l) }}</td>
                      <td data-label="Subtotal">Bs {{ subtotalLinea(l).toFixed(2) }}</td>
                      <td><button type="button" class="link-danger" (click)="quitarLineaEdicion(l)">Quitar</button></td>
                    </tr>
                  }
                </tbody>
              </table>
              @if (editLineas().length === 0) {
                <p class="form-error">Sin productos. Agrega al menos uno para guardar.</p>
              }

              <div class="agregar-linea modal-agregar">
                <select [(ngModel)]="editProductoSel" (ngModelChange)="alElegirProductoEdicion()" name="editProductoSel">
                  <option [ngValue]="null">Agregar un producto…</option>
                  @for (p of productos(); track p.id) {
                    <option [ngValue]="p.id" [disabled]="p.stock + apartado(p.id) === 0">{{ p.nombre }} — Bs {{ p.precio_venta }}</option>
                  }
                </select>
                <select class="sel-pres" [(ngModel)]="editPresSel" name="editPresSel" aria-label="Presentación">
                  @for (o of opcionesEdicion(); track o.valor) { <option [ngValue]="o.valor">{{ o.etiqueta }}</option> }
                </select>
                <input type="number" min="1" [(ngModel)]="editCantSel" name="editCantSel" style="width:80px" aria-label="Cantidad" />
                <button type="button" class="btn-secondary btn-sobre-claro" (click)="agregarLineaEdicion()">Agregar</button>
              </div>

              <div class="total-row total-claro">
                Total: <strong>Bs {{ totalEdicion().toFixed(2) }}</strong>
                @if (+(pe.costo_envio ?? 0) > 0) { <small> + envío Bs {{ pe.costo_envio }}</small> }
              </div>
            }

            @if (errorEdicion()) { <p class="form-error error-claro">{{ errorEdicion() }}</p> }
            <div class="modal-acciones">
              <button class="btn-secondary btn-sobre-claro" (click)="cerrarEdicion()">Cancelar</button>
              <button class="btn-primary" [disabled]="guardandoEdicion() || !editTelefono.trim()" (click)="guardarEdicion()">
                {{ guardandoEdicion() ? 'Guardando…' : 'Guardar cambios' }}
              </button>
            </div>
          </div>
        </div>
      }

      @if (pedidoQrAbierto(); as pq) {
        <div class="modal-fondo" (click)="cerrarQr()">
          <div class="modal-panel" (click)="$event.stopPropagation()">
            <h3>Cobrar Pedido #{{ pq.id }} por QR</h3>
            <p class="subtitle">Bs {{ pq.total }} — el cliente escanea con su app bancaria.</p>
            @if (qrCargando()) {
              <div class="spinner"></div>
            } @else {
              <div class="qr-imagen" [innerHTML]="qrSvg()"></div>
            }
            <div class="modal-acciones">
              <button class="btn-secondary" (click)="cerrarQr()">Cerrar</button>
              <button class="btn-primary" (click)="confirmarPago(pq, 'qr')">Ya pagó — confirmar</button>
            </div>
          </div>
        </div>
      }

      @if (pedidoDetalleAbierto(); as pd) {
        <div class="modal-fondo" (click)="cerrarDetalle()">
          <div class="modal-panel modal-panel-ancho" (click)="$event.stopPropagation()">
            <h3>Detalle del pedido #{{ pd.id }}</h3>
            <p class="subtitle">{{ pd.cliente?.nombre || 'Cliente sin registrar' }} — {{ pd.created_at ? (pd.created_at | slice:0:10) : '—' }}</p>

            @if (!pd.detalles || pd.detalles.length === 0) {
              <p class="subtitle">Este pedido no tiene productos registrados.</p>
            } @else {
              <table class="tabla-detalle">
                <thead><tr><th>Producto</th><th>Cant.</th><th>P. Unit.</th><th>Subtotal</th></tr></thead>
                <tbody>
                  @for (d of pd.detalles; track d.id) {
                    <tr>
                      <td data-label="Producto">{{ d.producto?.nombre || 'Producto #' + d.producto_id }}</td>
                      <td data-label="Cant.">{{ textoDetalle(d) }}</td>
                      <td data-label="P. Unit.">Bs {{ d.precio_unitario }}</td>
                      <td data-label="Subtotal">Bs {{ d.subtotal }}</td>
                    </tr>
                  }
                </tbody>
              </table>
              @if (+(pd.descuento ?? 0) > 0) {
                <div class="total-row">Descuentos: − Bs {{ pd.descuento }}@if (pd.cupon_codigo) { (cupón {{ pd.cupon_codigo }}) }</div>
              }
              @if (+(pd.costo_envio ?? 0) > 0) {
                <div class="total-row">Envío: Bs {{ pd.costo_envio }}</div>
              }
              <div class="total-row">Total: <strong>Bs {{ pd.total }}</strong></div>
              @if (pd.tipo_entrega === 'delivery') {
                <p class="subtitle">🛵 {{ pd.zona_delivery?.nombre }} — {{ pd.direccion_entrega }}</p>
              }
            }

            <div class="modal-acciones">
              <button class="btn-secondary" (click)="cerrarDetalle()">Cerrar</button>
            </div>
          </div>
        </div>
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .obligatorio { color: #d64545; font-weight: 600; }
    .ayuda-cliente { color: #d6a545; font-size: 12px; margin-top: 4px; display: block; }
    .panel-title { font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif; font-size: 20px; color: var(--papel); margin: 0 0 14px; }
    .agregar-linea { display: flex; gap: 10px; align-items: center; margin-top: 16px; flex-wrap: wrap; }
    .pago-acciones { display: flex; gap: 6px; flex-wrap: wrap; }
    .pago-acciones .link-action { font-size: 12px; white-space: nowrap; }
    .modal-fondo {
      position: fixed; inset: 0; background: rgba(1, 0, 26, 0.72);
      display: flex; align-items: center; justify-content: center; z-index: 50; padding: 16px;
    }
    .modal-panel {
      background: var(--papel); color: var(--tinta); border-radius: 14px;
      padding: 24px; max-width: 340px; width: 100%; text-align: center;
    }
    .modal-panel-ancho { max-width: 760px; text-align: left; max-height: 92vh; overflow: auto; }
    /* Los modales son CLAROS: etiquetas, subtítulos y botones van oscuros (el
       cian del tema oscuro sobre blanco no se leía). */
    .modal-panel .field label { color: #0a2a52; font-weight: 700; }
    .modal-panel .field label span { color: #4a6580; }
    .modal-panel .field label span.obligatorio { color: #c0392b; }
    .modal-panel .field input, .modal-panel .field select { border-color: #4a90b8; color: #020024; background: #fff; }
    .edit-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; margin-bottom: 8px; }
    .edit-obs { grid-column: 1 / -1; }
    .edit-sub { margin: 14px 0 4px; color: #0a2a52; font-size: 15px; }
    .modal-agregar { margin-top: 10px; }
    .modal-agregar select, .modal-agregar input { background: #fff; color: #020024; border: 1.5px solid #4a90b8; }
    .btn-sobre-claro { color: #0a2a52; border-color: #4a90b8; background: #eaf6fb; }
    .btn-sobre-claro:hover { background: #d4ecf7; border-color: #0a2a52; }
    .total-claro { color: #0a2a52; }
    .error-claro { color: #b3261e; }
    .input-cant { width: 72px; text-align: center; background: #fff; color: #020024; border: 1.5px solid #4a90b8; border-radius: 8px; padding: 6px; font-size: 14px; }
    .sel-pres { max-width: 190px; min-width: 130px; flex: 0 1 auto !important; }
    .carrito-tabla .input-cant { background: var(--papel); }
    .modal-panel-ancho .subtitle { text-align: left; }
    .tabla-detalle { width: 100%; border-collapse: collapse; margin-top: 12px; }
    .tabla-detalle th, .tabla-detalle td { padding: 8px 6px; font-size: 13px; text-align: left; border-bottom: 1px dashed var(--papel-borde); }
    /* El modal tiene fondo claro (.modal-panel-ancho), así que aquí las letras
       van oscuras: el color claro que usa "tbody td" para las tablas normales
       (fondo oscuro) las volvía invisibles sobre este fondo claro. */
    .tabla-detalle th { color: #0a2a52; font-weight: 700; }
    .tabla-detalle td { color: var(--tinta); }
    .modal-panel h3 { font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif; margin: 0 0 4px; }
    .modal-panel .subtitle { color: #2d4a66; margin: 0 0 16px; }
    .qr-imagen { display: flex; justify-content: center; margin: 12px 0; }
    .qr-imagen svg { max-width: 100%; height: auto; }
    .modal-acciones { display: flex; gap: 10px; justify-content: center; margin-top: 16px; }
    .agregar-linea select { background: var(--papel); color: var(--tinta); border: 1px solid var(--papel-borde); border-radius: 8px; padding: 9px 12px; font-size: 14px; flex: 1; min-width: 220px; }
    .agregar-linea input { background: var(--papel); color: var(--tinta); border: 1px solid var(--papel-borde); border-radius: 8px; padding: 9px 12px; font-size: 14px; }
    .carrito-tabla { margin-top: 18px; }
    .total-row { text-align: right; color: var(--papel); font-size: 16px; margin-top: 10px; }
    .tarjeta-iconos { display: flex; gap: 6px; margin-top: 6px; }
    .tarjeta-btn { display: inline-flex; align-items: center; gap: 4px; }
    .tarjeta-btn span { display: inline-flex; }
    .ancho-ticket { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--papel); }
    .ancho-ticket select { background: var(--papel); color: var(--tinta); border: 1px solid var(--papel-borde); border-radius: 8px; padding: 7px 10px; font-size: 13px; }
    .sub-entrega { display: block; font-size: 11px; opacity: 0.8; margin-top: 2px; }
    .repartidor-fila { display: inline-flex; gap: 4px; align-items: center; }
    .repartidor-fila select { background: var(--papel); color: var(--tinta); border: 1px solid var(--papel-borde); border-radius: 6px; padding: 4px 6px; font-size: 12px; }
    .reenvio-menu { position: relative; display: inline-block; }
    .reenvio-opciones {
      position: absolute; top: 100%; left: 0; z-index: 20; margin-top: 4px;
      background: var(--papel); border: 1px solid var(--papel-borde); border-radius: 8px;
      padding: 6px; display: flex; flex-direction: column; min-width: 150px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.25);
    }
    .reenvio-opciones button {
      background: none; border: none; text-align: left; padding: 7px 8px; font-size: 12px;
      color: var(--tinta); cursor: pointer; border-radius: 5px; white-space: nowrap;
    }
    .reenvio-opciones button:hover { background: rgba(31, 54, 40, 0.08); }
  `],
})
export class PedidosComponent implements OnInit {
  private pedidoService = inject(PedidoService);
  private productoService = inject(ProductoService);
  private clienteService = inject(ClienteService);
  private auth = inject(AuthService);
  private sanitizer = inject(DomSanitizer);
  private confirmDialog = inject(ConfirmDialogService);
  private deliveryService = inject(DeliveryService);
  private ticketService = inject(TicketService);

  repartidores = signal<Repartidor[]>([]);
  repartidorElegido: Record<number, number | null> = {};
  anchoTicket = signal<AnchoTicket>(this.ticketService.ancho());

  tarjetaIconosHtml = this.sanitizer.bypassSecurityTrustHtml(TARJETA_ICONOS);
  descargando = signal<number | null>(null);
  reenvioAbierto = signal<number | null>(null);

  pedidos = signal<Pedido[]>([]);
  productos = signal<Producto[]>([]);
  clientes = signal<Cliente[]>([]);
  carrito = signal<LineaCarrito[]>([]);

  cargandoPedidos = signal(true);

  // 2.2 Paginación del listado de pedidos
  paginaActual = signal(1);
  ultimaPagina = signal(1);
  totalRegistros = signal(0);
  guardando = signal(false);
  error = signal('');
  mensajeOk = signal('');

  clienteId: number | null = null;
  clienteTexto = signal('');
  telefono = '';
  metodoPago = 'efectivo';
  direccion = '';

  // Edición de un pedido ya registrado (teléfono, dirección, observaciones).
  pedidoEditando = signal<Pedido | null>(null);
  guardandoEdicion = signal(false);
  errorEdicion = signal('');
  editTelefono = '';
  editDireccion = '';
  editObservaciones = '';
  productoSeleccionado: number | null = null;
  presSeleccionada: Presentacion = 'unidad';
  cantidadSeleccionada = 1;
  diasCredito = 30;

  // Edición de PRODUCTOS de un pedido ya registrado (quitar lo que se acabó, agregar lo que faltó).
  editLineas = signal<LineaCarrito[]>([]);
  editProductoSel: number | null = null;
  editPresSel: Presentacion = 'unidad';
  editCantSel = 1;
  puedeEditarProductos = signal(false);

  totalCarrito = computed(() => this.carrito().reduce((acc, l) => acc + this.subtotalLinea(l), 0));
  totalEdicion = computed(() => this.editLineas().reduce((acc, l) => acc + this.subtotalLinea(l), 0));

  nombrePres(p: Presentacion): string {
    return p === 'caja' ? 'Caja' : p === 'paquete' ? 'Paquete' : 'Unidad';
  }

  unidadesLinea(l: LineaCarrito): number {
    return l.cantidad * factorDe(l.producto, l.presentacion);
  }

  subtotalLinea(l: LineaCarrito): number {
    return this.unidadesLinea(l) * Number(l.precio);
  }

  opcionesSeleccionado() {
    const p = this.productos().find((x) => x.id === this.productoSeleccionado);
    return p ? opcionesDe(p) : opcionesDe({});
  }

  opcionesEdicion() {
    const p = this.productos().find((x) => x.id === this.editProductoSel);
    return p ? opcionesDe(p) : opcionesDe({});
  }

  alElegirProducto(): void {
    this.presSeleccionada = 'unidad';
  }

  alElegirProductoEdicion(): void {
    this.editPresSel = 'unidad';
  }

  ngOnInit(): void {
    this.cargarPedidos();
    this.productoService.listar().subscribe({ next: (data) => this.productos.set(data) });
    this.clienteService.listar().subscribe({ next: (data) => this.clientes.set(data) });
    this.deliveryService.repartidores().subscribe({ next: (data) => this.repartidores.set(data), error: () => {} });
  }

  cargarPedidos(pagina = 1): void {
    this.cargandoPedidos.set(true);
    this.pedidoService.listarPagina(pagina).subscribe({
      next: (res) => {
        if (pagina > res.last_page && res.last_page >= 1) { this.cargarPedidos(res.last_page); return; }
        this.pedidos.set(res.data);
        this.paginaActual.set(res.current_page);
        this.ultimaPagina.set(res.last_page);
        this.totalRegistros.set(res.total);
        this.cargandoPedidos.set(false);
      },
      error: () => { this.error.set('No se pudo conectar con el servidor.'); this.cargandoPedidos.set(false); },
    });
  }

  agregarAlCarrito(): void {
    const cantidad = enteroSeguro(this.cantidadSeleccionada);
    if (!this.productoSeleccionado || cantidad < 1) return;
    const producto = this.productos().find((p) => p.id === this.productoSeleccionado);
    if (!producto) return;
    this.error.set('');

    const resultado = this.sumarLinea(this.carrito(), producto, this.presSeleccionada, cantidad);
    if (resultado.error) { this.error.set(resultado.error); return; }
    this.carrito.set(resultado.lineas);
    this.productoSeleccionado = null;
    this.presSeleccionada = 'unidad';
    this.cantidadSeleccionada = 1;
  }

  /** Suma una línea validando contra el stock (en unidades, contando las otras líneas del mismo producto). */
  private sumarLinea(actuales: LineaCarrito[], producto: Producto, pres: Presentacion, cantidad: number, stockExtra = 0) {
    const factor = factorDe(producto, pres);
    if (factor < 1) return { lineas: actuales, error: `«${producto.nombre}» no se vende por ${pres}.` };

    const lineas = actuales.map((l) => ({ ...l }));
    const existente = lineas.find((l) => l.producto_id === producto.id && l.presentacion === pres);
    const otras = lineas
      .filter((l) => l.producto_id === producto.id && l !== existente)
      .reduce((s, l) => s + this.unidadesLinea(l), 0);
    const nueva = (existente?.cantidad ?? 0) + cantidad;
    const disponible = Number(producto.stock) + stockExtra;

    if ((nueva * factor) + otras > disponible) {
      return { lineas: actuales, error: `Stock insuficiente de «${producto.nombre}»: hay ${disponible} unidades.` };
    }

    if (existente) existente.cantidad = nueva;
    else lineas.push({ producto_id: producto.id, cantidad, presentacion: pres, producto, precio: Number(producto.precio_venta) });
    return { lineas, error: '' };
  }

  cambiarCantidadCarrito(linea: LineaCarrito, valor: unknown): void {
    const cantidad = enteroSeguro(valor);
    if (cantidad < 1) { this.quitarDelCarrito(linea); return; }
    const sin = this.carrito().filter((l) => l !== linea);
    const r = this.sumarLinea(sin, linea.producto, linea.presentacion, cantidad);
    if (r.error) { this.error.set(r.error); this.carrito.set([...this.carrito()]); return; }
    this.error.set('');
    this.carrito.set(this.conservarPrecio(r.lineas, linea));
  }

  quitarDelCarrito(linea: LineaCarrito): void {
    this.carrito.set(this.carrito().filter((l) => l !== linea));
  }

  // Texto con el que se muestra/busca un cliente en el campo escribible.
  etiquetaCliente(c: Cliente): string {
    const nit = c.nit_ci && c.nit_ci !== '0' ? ` — ${c.nit_ci}` : '';
    return `${c.nombre}${nit}`;
  }

  private normalizar(t: string): string {
    return t.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  }

  // Al escribir se intenta reconocer al cliente: coincidencia exacta con la
  // etiqueta de la lista, o con un único cliente cuyo nombre/NIT sea ese texto.
  alEscribirCliente(texto: string): void {
    this.clienteTexto.set(texto ?? '');
    const q = this.normalizar(texto ?? '');
    const lista = this.clientes();

    let elegido = lista.find((c) => this.normalizar(this.etiquetaCliente(c)) === q);
    if (!elegido) {
      const exactos = lista.filter((c) => this.normalizar(c.nombre) === q || (c.nit_ci && this.normalizar(c.nit_ci) === q));
      if (exactos.length === 1) elegido = exactos[0];
    }

    this.clienteId = elegido?.id ?? null;

    // Si el cliente ya tiene teléfono, se precarga (se puede cambiar).
    if (elegido?.telefono && !this.telefono.trim()) this.telefono = elegido.telefono;
  }

  puedeConfirmar(): boolean {
    return !!this.clienteId && this.telefono.trim().length >= 7 && this.carrito().length > 0;
  }

  abrirEdicion(p: Pedido): void {
    this.pedidoEditando.set(p);
    this.editTelefono = p.telefono_contacto || p.cliente?.telefono || '';
    this.editDireccion = p.direccion_entrega ?? '';
    this.editObservaciones = p.observaciones ?? '';
    this.errorEdicion.set('');

    // Los productos se pueden cambiar mientras el pedido no esté cobrado ni entregado.
    this.puedeEditarProductos.set(!p.pagado && p.estado !== 'entregado' && p.estado !== 'cancelado');
    this.editLineas.set(
      (p.detalles ?? []).map((d: DetallePedido) => {
        const pres = (d.presentacion ?? 'unidad') as Presentacion;
        const factor = pres === 'unidad' ? 1 : Math.max(1, Math.round(d.cantidad / Math.max(1, d.cantidad_presentacion ?? 1)));
        const producto = (d.producto ?? { id: d.producto_id, nombre: `Producto #${d.producto_id}`, stock: 0 }) as Producto;
        // El factor de la línea es el que tenía al pedirse (la ficha pudo cambiar después).
        const conFactor = { ...producto, unidades_por_paquete: pres === 'paquete' ? factor : producto.unidades_por_paquete, unidades_por_caja: pres === 'caja' ? factor : producto.unidades_por_caja } as Producto;
        return {
          producto_id: d.producto_id,
          cantidad: pres === 'unidad' ? d.cantidad : (d.cantidad_presentacion ?? d.cantidad),
          presentacion: pres,
          producto: conFactor,
          precio: Number(d.precio_unitario),
        };
      }),
    );
    this.editProductoSel = null;
    this.editPresSel = 'unidad';
    this.editCantSel = 1;
  }

  // Lo que ya está en el pedido tiene su stock "apartado": al editar, ese stock cuenta como disponible.
  apartado(productoId: number): number {
    return this.apartadoDe(productoId);
  }

  private apartadoDe(productoId: number): number {
    return (this.pedidoEditando()?.detalles ?? []).filter((d) => d.producto_id === productoId).reduce((s, d) => s + d.cantidad, 0);
  }

  agregarLineaEdicion(): void {
    const cantidad = enteroSeguro(this.editCantSel);
    const producto = this.productos().find((p) => p.id === this.editProductoSel);
    if (!producto || cantidad < 1) return;
    this.errorEdicion.set('');
    const r = this.sumarLinea(this.editLineas(), producto, this.editPresSel, cantidad, this.apartadoDe(producto.id));
    if (r.error) { this.errorEdicion.set(r.error); return; }
    this.editLineas.set(r.lineas);
    this.editProductoSel = null;
    this.editPresSel = 'unidad';
    this.editCantSel = 1;
  }

  cambiarCantidadEdicion(linea: LineaCarrito, valor: unknown): void {
    const cantidad = enteroSeguro(valor);
    if (cantidad < 1) { this.quitarLineaEdicion(linea); return; }
    const sin = this.editLineas().filter((l) => l !== linea);
    const r = this.sumarLinea(sin, linea.producto, linea.presentacion, cantidad, this.apartadoDe(linea.producto_id));
    if (r.error) { this.errorEdicion.set(r.error); this.editLineas.set([...this.editLineas()]); return; }
    this.errorEdicion.set('');
    this.editLineas.set(this.conservarPrecio(r.lineas, linea));
  }

  /** Al re-sumar una línea se perdía su precio congelado; se lo devolvemos y se mantiene su posición. */
  private conservarPrecio(lineas: LineaCarrito[], original: LineaCarrito): LineaCarrito[] {
    return lineas.map((l) => (l.producto_id === original.producto_id && l.presentacion === original.presentacion ? { ...l, precio: original.precio } : l));
  }

  quitarLineaEdicion(linea: LineaCarrito): void {
    this.editLineas.set(this.editLineas().filter((l) => l !== linea));
  }

  cerrarEdicion(): void {
    this.pedidoEditando.set(null);
  }

  guardarEdicion(): void {
    const p = this.pedidoEditando();
    if (!p || !this.editTelefono.trim()) return;
    if (this.puedeEditarProductos() && this.editLineas().length === 0) {
      this.errorEdicion.set('El pedido debe tener al menos un producto. Si no se puede atender, cancélalo.');
      return;
    }

    this.guardandoEdicion.set(true);
    this.errorEdicion.set('');

    const datos = {
      telefono_contacto: this.editTelefono.trim(),
      direccion_entrega: this.editDireccion.trim() || null,
      observaciones: this.editObservaciones.trim() || null,
    };

    const cambioProductos = this.puedeEditarProductos() && this.huboCambioProductos(p);

    // Primero los datos de contacto; después, si cambiaron, los productos (ajusta stock y total).
    this.pedidoService.editar(p.id, datos).subscribe({
      next: (actualizado) => {
        if (!cambioProductos) { this.terminarEdicion(p, actualizado); return; }
        this.pedidoService
          .editarItems(p.id, this.editLineas().map((l) => ({ producto_id: l.producto_id, cantidad: l.cantidad, presentacion: l.presentacion })))
          .subscribe({
            next: (conItems) => {
              this.terminarEdicion(p, conItems);
              this.productoService.listar().subscribe({ next: (data) => this.productos.set(data) });
            },
            error: (err) => this.falloEdicion(err),
          });
      },
      error: (err) => this.falloEdicion(err),
    });
  }

  private huboCambioProductos(p: Pedido): boolean {
    const antes = (p.detalles ?? []).map((d) => `${d.producto_id}|${d.presentacion ?? 'unidad'}|${d.cantidad_presentacion ?? d.cantidad}`).sort().join(',');
    const ahora = this.editLineas().map((l) => `${l.producto_id}|${l.presentacion}|${l.cantidad}`).sort().join(',');
    return antes !== ahora;
  }

  private terminarEdicion(p: Pedido, actualizado: Pedido): void {
    this.pedidos.set(this.pedidos().map((x) => (x.id === p.id ? actualizado : x)));
    this.guardandoEdicion.set(false);
    this.pedidoEditando.set(null);
    this.mensajeOk.set(`Pedido #${p.id} actualizado.${actualizado.aviso ? ' ' + actualizado.aviso : ''}`);
  }

  private falloEdicion(err: any): void {
    this.errorEdicion.set(err?.error?.message || 'No se pudo guardar. Revisa los datos e intenta de nuevo.');
    this.guardandoEdicion.set(false);
  }

  confirmarVenta(): void {
    const usuario = this.auth.usuarioActual();
    if (!this.clienteId || !usuario || this.carrito().length === 0) return;

    this.guardando.set(true);
    this.error.set('');
    this.mensajeOk.set('');

    this.pedidoService
      .crear({
        cliente_id: this.clienteId,
        usuario_id: usuario.id,
        metodo_pago: this.metodoPago,
        dias_credito: this.metodoPago === 'credito' ? enteroSeguro(this.diasCredito) : undefined,
        direccion_entrega: this.direccion.trim() || undefined,
        telefono: this.telefono.trim(),
        items: this.carrito().map((l) => ({ producto_id: l.producto_id, cantidad: l.cantidad, presentacion: l.presentacion })),
      })
      .subscribe({
        next: (pedido) => {
          // El pedido nuevo es el más reciente: se recarga desde la página 1.
          this.cargarPedidos(1);
          this.carrito.set([]);
          this.clienteId = null;
          this.clienteTexto.set('');
          this.telefono = '';
          this.direccion = '';
          this.guardando.set(false);
          this.mensajeOk.set(`Venta #${pedido.id} registrada.`);
          this.productoService.listar().subscribe({ next: (data) => this.productos.set(data) });
        },
        error: (err) => {
          this.error.set(err?.error?.message || 'No se pudo registrar la venta.');
          this.guardando.set(false);
        },
      });
  }

  cambiarEstado(p: Pedido, estado: string): void {
    this.pedidoService.cambiarEstado(p.id, estado).subscribe({
      next: (actualizado) => this.pedidos.set(this.pedidos().map((x) => (x.id === p.id ? actualizado : x))),
      error: (err) => this.error.set(err?.error?.message || 'No se pudo actualizar el estado del pedido.'),
    });
  }

  salirARepartir(p: Pedido): void {
    const repartidorId = this.repartidorElegido[p.id] ?? p.repartidor_id ?? null;
    if (!repartidorId) {
      this.error.set('Elige un repartidor antes de marcar el pedido en camino.');
      return;
    }
    this.error.set('');
    this.pedidoService.cambiarEstado(p.id, 'en_camino', repartidorId).subscribe({
      next: (actualizado) => {
        this.pedidos.set(this.pedidos().map((x) => (x.id === p.id ? actualizado : x)));
        this.mensajeOk.set(`Pedido #${p.id} en camino con ${actualizado.repartidor?.nombre ?? 'el repartidor'}.`);
      },
      error: (err) => this.error.set(err?.error?.message || 'No se pudo marcar el pedido en camino.'),
    });
  }

  cambiarAnchoTicket(ancho: AnchoTicket): void {
    this.ticketService.guardarAncho(ancho);
    this.anchoTicket.set(ancho);
  }

  imprimirTicket(p: Pedido): void {
    this.ticketService
      .imprimir(p.id, this.anchoTicket())
      .catch(() => this.error.set('No se pudo generar el ticket.'));
  }

  async cancelarPedido(p: Pedido): Promise<void> {
    const ok = await this.confirmDialog.confirm({
      titulo: 'Cancelar pedido',
      mensaje: `¿Cancelar el pedido #${p.id}? Esto restituye el stock automáticamente.`,
      textoConfirmar: 'Sí, cancelar',
      peligroso: true,
    });
    if (!ok) return;

    this.pedidoService.cancelar(p.id).subscribe({
      next: () => this.cargarPedidos(this.paginaActual()),
      error: () => this.error.set('No se pudo cancelar el pedido.'),
    });
  }

  descargarFactura(p: Pedido): void {
    this.descargando.set(p.id);
    this.pedidoService.descargarFactura(p.id)
      .catch(() => this.error.set('No se pudo generar la nota de venta.'))
      .finally(() => this.descargando.set(null));
  }

  toggleReenvio(id: number): void {
    this.reenvioAbierto.set(this.reenvioAbierto() === id ? null : id);
  }

  reenviar(p: Pedido, canal: 'correo' | 'whatsapp'): void {
    this.reenvioAbierto.set(null);
    this.pedidoService.reenviarFactura(p.id, canal).subscribe({
      next: () => this.mensajeOk.set(`La nota de venta se está enviando por ${canal === 'correo' ? 'correo' : 'WhatsApp'}.`),
      error: (err) => this.error.set(err?.error?.message || 'No se pudo reenviar la nota de venta.'),
    });
  }

  pedidoQrAbierto = signal<Pedido | null>(null);
  qrSvg = signal<SafeHtml | string>('');
  qrCargando = signal(false);

  mostrarQr(p: Pedido): void {
    this.pedidoQrAbierto.set(p);
    this.qrCargando.set(true);
    this.qrSvg.set('');
    this.pedidoService.obtenerQr(p.id).subscribe({
      next: (svg) => {
        this.qrSvg.set(this.sanitizer.bypassSecurityTrustHtml(svg));
        this.qrCargando.set(false);
      },
      error: () => {
        this.error.set('No se pudo generar el QR de pago.');
        this.qrCargando.set(false);
        this.cerrarQr();
      },
    });
  }

  cerrarQr(): void {
    this.pedidoQrAbierto.set(null);
  }

  pedidoDetalleAbierto = signal<Pedido | null>(null);

  verDetalle(p: Pedido): void {
    this.pedidoDetalleAbierto.set(p);
  }

  textoDetalle(d: DetallePedido): string {
    if (!d.presentacion || d.presentacion === 'unidad') return String(d.cantidad);
    return `${textoCantidad(d.presentacion, d.cantidad_presentacion ?? 0)} (${d.cantidad} u.)`;
  }

  cerrarDetalle(): void {
    this.pedidoDetalleAbierto.set(null);
  }

  confirmarPago(p: Pedido, metodo: 'efectivo' | 'qr' | 'tarjeta'): void {
    this.pedidoService.confirmarPago(p.id, metodo).subscribe({
      next: (actualizado) => {
        this.pedidos.set(this.pedidos().map((x) => (x.id === p.id ? actualizado : x)));
        this.mensajeOk.set(
          `Pago de #${p.id} confirmado. Se notificó al administrador y se envió la nota de venta al cliente.`
        );
        this.cerrarQr();
      },
      error: (err) => this.error.set(err?.error?.message || 'No se pudo confirmar el pago.'),
    });
  }
}
