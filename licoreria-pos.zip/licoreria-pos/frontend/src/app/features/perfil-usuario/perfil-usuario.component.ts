import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-perfil-usuario',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page">
      <header class="cabecera">
        <a routerLink="/catalogo" class="volver">← Volver</a>
        <h1>Mi perfil</h1>
        <span class="rol-badge" [class.admin]="esAdmin()">{{ esAdmin() ? 'Administrador' : 'Vendedor' }}</span>
      </header>

      <section class="panel">
        <form (ngSubmit)="guardar()">
          <div class="campo">
            <label>Nombre</label>
            <input type="text" [(ngModel)]="formNombre" name="nombre" required />
          </div>
          <div class="campo">
            <label>Correo <span>(no editable aquí)</span></label>
            <input type="email" [value]="auth.usuarioActual()?.email" disabled />
          </div>

          <details class="cambiar-password">
            <summary>Cambiar contraseña</summary>
            <div class="campo">
              <label>Nueva contraseña</label>
              <div class="password-input">
                <input
                  [type]="mostrarPassword() ? 'text' : 'password'"
                  [(ngModel)]="formPassword"
                  name="password"
                  placeholder="Dejar en blanco para no cambiar"
                />
                <button type="button" class="toggle-password" (click)="mostrarPassword.set(!mostrarPassword())"
                  [attr.aria-label]="mostrarPassword() ? 'Ocultar contraseña' : 'Mostrar contraseña'" tabindex="-1">
                  @if (mostrarPassword()) {
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.6 18.6 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke-linecap="round" stroke-linejoin="round"/>
                      <line x1="1" y1="1" x2="23" y2="23" stroke-linecap="round"/>
                    </svg>
                  } @else {
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke-linecap="round" stroke-linejoin="round"/>
                      <circle cx="12" cy="12" r="3"/>
                    </svg>
                  }
                </button>
              </div>
            </div>
            <div class="campo">
              <label>Confirmar contraseña</label>
              <div class="password-input">
                <input
                  [type]="mostrarPasswordConf() ? 'text' : 'password'"
                  [(ngModel)]="formPasswordConfirm"
                  name="passwordConfirm"
                />
                <button type="button" class="toggle-password" (click)="mostrarPasswordConf.set(!mostrarPasswordConf())"
                  [attr.aria-label]="mostrarPasswordConf() ? 'Ocultar contraseña' : 'Mostrar contraseña'" tabindex="-1">
                  @if (mostrarPasswordConf()) {
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.6 18.6 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke-linecap="round" stroke-linejoin="round"/>
                      <line x1="1" y1="1" x2="23" y2="23" stroke-linecap="round"/>
                    </svg>
                  } @else {
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke-linecap="round" stroke-linejoin="round"/>
                      <circle cx="12" cy="12" r="3"/>
                    </svg>
                  }
                </button>
              </div>
            </div>
          </details>

          @if (error()) {
            <p class="mensaje-error">{{ error() }}</p>
          }
          @if (guardadoOk()) {
            <p class="mensaje-ok">Datos actualizados.</p>
          }

          <button type="submit" class="btn-guardar" [disabled]="guardando()">
            {{ guardando() ? 'Guardando…' : 'Guardar cambios' }}
          </button>
        </form>

        <button class="btn-salir" (click)="cerrarSesion()">Cerrar sesión</button>
      </section>

      <section class="accesos">
        <a routerLink="/pedidos" class="acceso-card">
          <strong>Pedidos</strong>
          <span>Ver, confirmar pago y despachar</span>
        </a>
        <a routerLink="/clientes" class="acceso-card">
          <strong>Clientes</strong>
          <span>Fichas y contacto</span>
        </a>
        <a routerLink="/inventario" class="acceso-card">
          <strong>Inventario</strong>
          <span>Movimientos de stock</span>
        </a>
        @if (esAdmin()) {
          <a routerLink="/usuarios" class="acceso-card">
            <strong>Usuarios</strong>
            <span>Gestionar cuentas del personal</span>
          </a>
          <a routerLink="/categorias" class="acceso-card">
            <strong>Categorías</strong>
            <span>Estructura del catálogo</span>
          </a>
        }
      </section>
    </div>
  `,
  styles: [
    `
      :host {
        --verde-botella: #020024;
        --verde-botella-oscuro: #01001A;
        --cobre: #00D4FF;
        --cobre-claro: #00D4FF;
        --papel: #EAFBFF;
        --borde-claro: #00D4FF;
        --tinta: #020024;
        --rust: #d64545;
        --texto-suave: #5FB8CC;
        --fondo-alt: #E8FBFF;
        display: block;
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        color: var(--tinta);
        background: #fff;
        min-height: 100%;
      }

      .page { max-width: 760px; margin: 0 auto; padding: 32px 32px 64px; }

      .cabecera { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; margin-bottom: 24px; }
      .volver { color: var(--cobre); text-decoration: none; font-size: 13px; font-weight: 600; }
      .volver:hover { text-decoration: underline; }
      h1 {
        font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
        font-size: 28px;
        margin: 0;
        color: var(--verde-botella);
        flex: 1;
      }
      .rol-badge {
        font-size: 11px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        padding: 5px 12px;
        border-radius: 20px;
        background: var(--fondo-alt);
        color: var(--texto-suave);
      }
      .rol-badge.admin { background: var(--papel); color: var(--verde-botella); }

      .panel {
        background: #fff;
        border: 1px solid var(--borde-claro);
        border-radius: 14px;
        padding: 24px;
        margin-bottom: 24px;
      }

      .campo { display: flex; flex-direction: column; gap: 5px; margin-bottom: 14px; }
      .campo label { font-size: 12.5px; font-weight: 700; color: var(--tinta); }
      .campo label span { font-weight: 400; color: var(--texto-suave); }
      .campo input {
        border: 1px solid var(--borde-claro);
        border-radius: 8px;
        padding: 10px 12px;
        font-size: 14px;
        font-family: inherit;
        background: #fff;
        color: var(--tinta);
      }
      .campo input:disabled { background: var(--fondo-alt); color: var(--texto-suave); }
      .campo input:focus { outline: 2px solid var(--cobre-claro); outline-offset: 1px; }
      .password-input { position: relative; display: flex; align-items: center; }
      .password-input input { width: 100%; box-sizing: border-box; padding-right: 38px; }
      .toggle-password {
        position: absolute;
        right: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: none;
        border: none;
        padding: 4px;
        color: var(--texto-suave);
        cursor: pointer;
        border-radius: 6px;
      }
      .toggle-password:hover { color: var(--cobre); }

      .cambiar-password { margin: 4px 0 16px; border-top: 1px dashed var(--borde-claro); padding-top: 12px; }
      .cambiar-password summary { cursor: pointer; font-size: 13px; font-weight: 700; color: var(--cobre); margin-bottom: 10px; }

      .mensaje-error { color: var(--rust); font-size: 13px; margin: 0 0 12px; }
      .mensaje-ok { color: #2f6b46; font-size: 13px; margin: 0 0 12px; }

      .btn-guardar {
        width: 100%;
        background: var(--cobre);
        color: var(--tinta);
        border: none;
        border-radius: 8px;
        padding: 11px;
        font-weight: 700;
        font-size: 14px;
        cursor: pointer;
      }
      .btn-guardar:hover:not(:disabled) { background: var(--verde-botella); }
      .btn-guardar:disabled { opacity: 0.6; cursor: not-allowed; }

      .btn-salir {
        width: 100%;
        background: none;
        border: 1px solid var(--borde-claro);
        color: var(--rust);
        border-radius: 8px;
        padding: 10px;
        font-weight: 700;
        font-size: 13px;
        cursor: pointer;
        margin-top: 16px;
      }
      .btn-salir:hover { background: #fdf1ec; }

      .accesos {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
        gap: 14px;
      }
      .acceso-card {
        display: flex;
        flex-direction: column;
        gap: 4px;
        text-decoration: none;
        border: 1px solid var(--borde-claro);
        border-radius: 12px;
        padding: 16px;
      }
      .acceso-card:hover { border-color: var(--cobre-claro); background: var(--fondo-alt); }
      .acceso-card strong { color: var(--verde-botella); font-size: 14.5px; }
      .acceso-card span { color: var(--texto-suave); font-size: 12.5px; }

      @media (max-width: 600px) {
        .page { padding: 22px 18px 48px; }
      }
    `,
  ],
})
export class PerfilUsuarioComponent {
  auth = inject(AuthService);
  private router = inject(Router);

  formNombre = this.auth.usuarioActual()?.nombre ?? '';
  formPassword = '';
  formPasswordConfirm = '';
  mostrarPassword = signal(false);
  mostrarPasswordConf = signal(false);

  guardando = signal(false);
  error = signal<string | null>(null);
  guardadoOk = signal(false);

  esAdmin(): boolean {
    return this.auth.usuarioActual()?.rol === 'administrador';
  }

  guardar(): void {
    this.error.set(null);
    this.guardadoOk.set(false);

    if (this.formPassword && this.formPassword !== this.formPasswordConfirm) {
      this.error.set('Las contraseñas no coinciden.');
      return;
    }

    this.guardando.set(true);
    const payload: any = { nombre: this.formNombre };
    if (this.formPassword) {
      payload.password = this.formPassword;
      payload.password_confirmation = this.formPasswordConfirm;
    }

    this.auth.actualizarPerfil(payload).subscribe({
      next: () => {
        this.guardando.set(false);
        this.guardadoOk.set(true);
        this.formPassword = '';
        this.formPasswordConfirm = '';
      },
      error: (err) => {
        this.guardando.set(false);
        this.error.set(err?.error?.message ?? 'No se pudo guardar. Intenta de nuevo.');
      },
    });
  }

  cerrarSesion(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}
