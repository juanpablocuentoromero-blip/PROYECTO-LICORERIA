import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PedidoCompraService } from '../../core/services/pedido-compra.service';
import { ProveedorService } from '../../core/services/proveedor.service';
import { ProductoService } from '../../core/services/producto.service';
import { PedidoCompra, ItemCompra } from '../../core/models/pedido-compra.model';
import { Proveedor } from '../../core/models/proveedor.model';
import { Producto } from '../../core/models/producto.model';
import { BASE_THEME } from '../../shared/theme/theme';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';

// Una línea del pedido tal como se ve en pantalla. Se puede comprar por
// paquete/caja (los paquetes × unidades por paquete dan las unidades) o
// directamente por unidades; el stock siempre se cuenta en unidades.
interface LineaCompra {
  uid: number;
  producto: Producto;
  producto_id: number;
  modo: 'paquete' | 'unidad';
  cantidad: number;
  cantidad_paquetes?: number;
  unidades_por_paquete?: number;
  precio_paquete?: number;
  precio_unitario: number;
  subtotal: number;
  numero_lote: string;
  fecha_vencimiento: string;
}

@Component({
  selector: 'app-pedidos-compra',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Compras &middot; Reposición</div>
          <h1>Pedidos a proveedores</h1>
          <p class="subtitle">Arma el pedido por paquetes o unidades; el stock sube recién cuando marcas "Recibido".</p>
        </div>
      </header>

      <section class="panel">
        <h3 class="panel-title">
          {{ editandoId() ? 'Editando pedido de compra #' + editandoId() : 'Nuevo pedido de compra' }}
        </h3>

        <div class="form-grid">
          <div class="field">
            <label>Proveedor</label>
            <select [(ngModel)]="proveedorId" name="proveedorId">
              <option [ngValue]="null">Selecciona un proveedor…</option>
              @for (p of proveedores(); track p.id) { <option [ngValue]="p.id">{{ p.nombre }}</option> }
            </select>
          </div>
          <div class="field">
            <label>Observaciones <span>(opcional)</span></label>
            <input type="text" [(ngModel)]="observaciones" name="observaciones" />
          </div>
        </div>

        <div class="agregar-linea">
          <div class="buscador-producto">
            <input
              type="text"
              class="buscador-input"
              autocomplete="off"
              placeholder="Buscar producto por nombre o código…"
              [ngModel]="busqueda()"
              (ngModelChange)="alBuscar($event)"
              (focus)="listaAbierta.set(true)"
              (blur)="cerrarLista()"
              (keydown.enter)="elegirPrimero($event)"
              (keydown.escape)="listaAbierta.set(false)"
              name="busquedaProducto"
            />
            @if (listaAbierta()) {
              <ul class="resultados-producto">
                @for (p of productosFiltrados(); track p.id) {
                  <li (mousedown)="elegirProducto(p, $event)" [class.elegido]="p.id === productoSeleccionado">
                    <span>{{ p.nombre }} <small>{{ p.codigo }}</small></span>
                    <small>costo actual: Bs {{ p.precio_compra }}@if (p.unidades_por_paquete) { · {{ p.unidades_por_paquete }} u/paq }</small>
                  </li>
                } @empty {
                  <li class="sin-resultados">No hay productos que coincidan.</li>
                }
              </ul>
            }
          </div>

          <select [(ngModel)]="modo" name="modo" class="modo-select" title="Cómo compras este producto">
            <option value="paquete">Por paquete / caja</option>
            <option value="unidad">Por unidades</option>
          </select>
        </div>

        <div class="agregar-linea">
          @if (modo === 'paquete') {
            <label class="mini"><span>Paquetes</span>
              <input type="number" min="1" [(ngModel)]="paquetesSel" name="paquetesSel" style="width:90px" />
            </label>
            <label class="mini"><span>Unid. por paquete</span>
              <input type="number" min="1" [(ngModel)]="unidadesPorPaqueteSel" name="unidadesPorPaqueteSel" style="width:120px" />
            </label>
            <label class="mini"><span>Costo por paquete (Bs)</span>
              <input type="number" min="0" step="0.01" [(ngModel)]="costoPaqueteSel" name="costoPaqueteSel" style="width:140px" />
            </label>
          } @else {
            <label class="mini"><span>Cantidad</span>
              <input type="number" min="1" [(ngModel)]="cantidadSel" name="cantidadSel" style="width:90px" />
            </label>
            <label class="mini"><span>Costo unitario (Bs)</span>
              <input type="number" min="0" step="0.01" [(ngModel)]="costoUnitarioSel" name="costoUnitarioSel" style="width:140px" />
            </label>
          }
          <label class="mini"><span>Lote <em>(opcional)</em></span>
            <input type="text" [(ngModel)]="loteSel" name="loteSel" maxlength="100" style="width:110px" />
          </label>
          <label class="mini"><span>Vence <em>(opcional)</em></span>
            <input type="date" [(ngModel)]="vencimientoSel" name="vencimientoSel" />
          </label>
          <button type="button" class="btn-secondary" (click)="agregarLinea()" [disabled]="!lineaValida()">Agregar</button>
        </div>

        @if (previsualizacion(); as pv) {
          <p class="auto-calculo">
            = <strong>{{ pv.unidades }}</strong> unidades · costo por unidad <strong>Bs {{ pv.costoUnitario.toFixed(2) }}</strong>
            · subtotal <strong>Bs {{ pv.subtotal.toFixed(2) }}</strong>
          </p>
        }

        @if (lineas().length > 0) {
          <table class="carrito-tabla">
            <thead><tr><th>Producto</th><th>Cantidad</th><th>Costo unit.</th><th>Lote / Vence</th><th>Subtotal</th><th></th></tr></thead>
            <tbody>
              @for (linea of lineas(); track linea.uid) {
                <tr>
                  <td data-label="Producto">{{ linea.producto.nombre }}</td>
                  <td data-label="Cantidad">
                    @if (linea.modo === 'paquete') {
                      {{ linea.cantidad_paquetes }} paq × {{ linea.unidades_por_paquete }} = <strong>{{ linea.cantidad }}</strong> u
                    } @else {
                      {{ linea.cantidad }} u
                    }
                  </td>
                  <td data-label="Costo unit.">Bs {{ linea.precio_unitario.toFixed(2) }}</td>
                  <td data-label="Lote / Vence">
                    @if (linea.numero_lote || linea.fecha_vencimiento) {
                      {{ linea.numero_lote || '—' }} · {{ linea.fecha_vencimiento || 'sin fecha' }}
                    } @else { — }
                  </td>
                  <td data-label="Subtotal">Bs {{ linea.subtotal.toFixed(2) }}</td>
                  <td><button class="link-danger" (click)="quitarLinea(linea.uid)">Quitar</button></td>
                </tr>
              }
            </tbody>
          </table>
          <div class="total-row">Total: <strong>Bs {{ totalCompra().toFixed(2) }}</strong></div>
        }

        <div class="field-row" style="margin-top:14px">
          <button class="btn-primary" [disabled]="!puedeConfirmar() || guardando()" (click)="confirmarPedido()">
            {{ guardando() ? 'Guardando…' : (editandoId() ? 'Guardar cambios' : 'Registrar pedido de compra') }}
          </button>
          @if (editandoId()) {
            <button type="button" class="btn-secondary" (click)="cancelarEdicion()">Cancelar edición</button>
          }
          @if (error()) { <span class="form-error">{{ error() }}</span> }
          @if (mensajeOk()) { <span class="form-ok">{{ mensajeOk() }}</span> }
        </div>
      </section>

      <h3 class="panel-title" style="margin: 0">Historial de compras</h3>
      @if (cargandoPedidos()) {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando pedidos de compra…</p></div>
      } @else if (pedidosCompra().length === 0) {
        <div class="estado-vacio"><p>Todavía no hay pedidos de compra registrados.</p></div>
      } @else {
        <table>
          <thead><tr><th>#</th><th>Proveedor</th><th>Total</th><th>Estado</th><th>Fecha</th><th></th></tr></thead>
          <tbody>
            @for (pc of pedidosCompra(); track pc.id) {
              <tr>
                <td data-label="#">{{ pc.id }}</td>
                <td data-label="Proveedor">{{ pc.proveedor?.nombre || '—' }}</td>
                <td data-label="Total">Bs {{ pc.total }}</td>
                <td data-label="Estado">
                  <span class="badge"
                    [class.badge-info]="pc.estado === 'pendiente'"
                    [class.badge-ok]="pc.estado === 'recibido'"
                    [class.badge-danger]="pc.estado === 'cancelado'">{{ pc.estado }}</span>
                </td>
                <td data-label="Fecha">{{ pc.created_at ? (pc.created_at | slice:0:10) : '—' }}</td>
                <td data-label="Acciones">
                  <button class="link-action" (click)="alternarDetalle(pc.id)">{{ detalleAbierto() === pc.id ? 'Ocultar' : 'Ver detalle' }}</button>
                  @if (pc.estado === 'pendiente') {
                    <button class="link-action" (click)="editar(pc)">Editar</button>
                    <button class="link-action" (click)="recibir(pc)">✓ Marcar recibido</button>
                    <button class="link-danger" (click)="cancelar(pc)">Cancelar</button>
                  }
                </td>
              </tr>
              @if (detalleAbierto() === pc.id) {
                <tr class="fila-detalle">
                  <td colspan="6">
                    <table class="detalle-tabla">
                      <thead><tr><th>Producto</th><th>Cantidad</th><th>Costo unit.</th><th>Lote</th><th>Vence</th><th>Subtotal</th></tr></thead>
                      <tbody>
                        @for (d of pc.detalles ?? []; track d.id) {
                          <tr>
                            <td>{{ d.producto?.nombre || '—' }}</td>
                            <td>
                              @if (d.cantidad_paquetes) { {{ d.cantidad_paquetes }} paq × {{ d.unidades_por_paquete }} = {{ d.cantidad }} u }
                              @else { {{ d.cantidad }} u }
                            </td>
                            <td>Bs {{ d.precio_unitario }}</td>
                            <td>{{ d.numero_lote || '—' }}</td>
                            <td>{{ d.fecha_vencimiento ? (d.fecha_vencimiento | slice:0:10) : '—' }}</td>
                            <td>Bs {{ d.subtotal }}</td>
                          </tr>
                        }
                      </tbody>
                    </table>
                    @if (pc.observaciones) { <p class="obs">Obs.: {{ pc.observaciones }}</p> }
                  </td>
                </tr>
              }
            }
          </tbody>
        </table>
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .panel-title { font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif; font-size: 20px; color: var(--papel); margin: 0 0 14px; }
    .agregar-linea { display: flex; gap: 10px; align-items: flex-end; margin-top: 16px; flex-wrap: wrap; }
    .buscador-producto { position: relative; flex: 1; min-width: 240px; }
    .buscador-input { width: 100%; box-sizing: border-box; }
    .resultados-producto {
      position: absolute; z-index: 20; top: calc(100% + 4px); left: 0; right: 0;
      max-height: 280px; overflow-y: auto; margin: 0; padding: 4px; list-style: none;
      background: var(--papel); border: 1px solid var(--papel-borde); border-radius: 8px;
      box-shadow: 0 10px 24px rgba(0, 0, 0, 0.35);
    }
    .resultados-producto li { display: flex; justify-content: space-between; gap: 10px; padding: 8px 10px; border-radius: 6px; cursor: pointer; color: var(--tinta); font-size: 14px; }
    .resultados-producto li small { opacity: 0.7; font-size: 12px; white-space: nowrap; }
    .resultados-producto li:hover, .resultados-producto li.elegido { background: #cdeef7; }
    .resultados-producto li.sin-resultados { cursor: default; justify-content: center; }
    .resultados-producto li.sin-resultados:hover { background: transparent; }
    .agregar-linea select, .agregar-linea input { background: var(--papel); color: var(--tinta); border: 1px solid var(--papel-borde); border-radius: 8px; padding: 9px 12px; font-size: 14px; }
    .modo-select { min-width: 170px; }
    .mini { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--papel); }
    .mini em { font-style: normal; opacity: 0.65; }
    .auto-calculo { margin: 10px 0 0; font-size: 13px; color: var(--papel); }
    .carrito-tabla { margin-top: 18px; }
    .total-row { text-align: right; color: var(--papel); font-size: 16px; margin-top: 10px; }
    .fila-detalle td { background: rgba(0, 0, 0, 0.12); }
    .detalle-tabla { width: 100%; font-size: 13px; }
    .obs { margin: 8px 0 0; font-size: 13px; opacity: 0.8; }
  `],
})
export class PedidosCompraComponent implements OnInit {
  private pedidoCompraService = inject(PedidoCompraService);
  private confirmDialog = inject(ConfirmDialogService);
  private proveedorService = inject(ProveedorService);
  private productoService = inject(ProductoService);

  pedidosCompra = signal<PedidoCompra[]>([]);
  proveedores = signal<Proveedor[]>([]);
  productos = signal<Producto[]>([]);
  lineas = signal<LineaCompra[]>([]);

  cargandoPedidos = signal(true);
  guardando = signal(false);
  error = signal('');
  mensajeOk = signal('');
  editandoId = signal<number | null>(null);
  detalleAbierto = signal<number | null>(null);

  proveedorId: number | null = null;
  observaciones = '';

  // --- línea que se está armando ---
  productoSeleccionado: number | null = null;
  busqueda = signal('');
  listaAbierta = signal(false);
  modo: 'paquete' | 'unidad' = 'unidad';
  paquetesSel = 1;
  unidadesPorPaqueteSel: number | null = null;
  costoPaqueteSel: number | null = null;
  cantidadSel = 1;
  costoUnitarioSel: number | null = null;
  loteSel = '';
  vencimientoSel = '';

  private siguienteUid = 1;

  // Búsqueda sin distinguir mayúsculas ni tildes, por nombre o código.
  private normalizar(t: string): string {
    return t.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  }

  productosFiltrados = computed(() => {
    const q = this.normalizar(this.busqueda());
    const todos = this.productos();
    if (!q) return todos.slice(0, 50);
    const palabras = q.split(/\s+/);
    return todos
      .filter((p) => {
        const texto = this.normalizar(`${p.nombre} ${p.codigo ?? ''}`);
        return palabras.every((w) => texto.includes(w));
      })
      .slice(0, 50);
  });

  alBuscar(texto: string): void {
    this.busqueda.set(texto ?? '');
    // Si cambia el texto, la selección anterior ya no es válida.
    this.productoSeleccionado = null;
    this.listaAbierta.set(true);
  }

  // Al elegir un producto se precarga lo que ya se sabe de él: cómo viene
  // empaquetado y cuánto costó la última vez. Todo se puede cambiar.
  elegirProducto(p: Producto, ev?: Event): void {
    ev?.preventDefault();
    this.productoSeleccionado = p.id;
    this.busqueda.set(p.nombre);
    this.listaAbierta.set(false);

    const costo = Number(p.precio_compra) || 0;
    this.costoUnitarioSel = costo;
    this.unidadesPorPaqueteSel = p.unidades_por_paquete ?? null;
    this.costoPaqueteSel = p.unidades_por_paquete ? Math.round(costo * p.unidades_por_paquete * 100) / 100 : null;
    this.modo = p.unidades_por_paquete ? 'paquete' : 'unidad';
  }

  elegirPrimero(ev: Event): void {
    ev.preventDefault();
    const primero = this.productosFiltrados()[0];
    if (primero) this.elegirProducto(primero);
  }

  cerrarLista(): void {
    // Un instante después del blur, para no perder el clic en un resultado.
    setTimeout(() => this.listaAbierta.set(false), 120);
  }

  // Lo que va a resultar de la línea en construcción (unidades, costo por unidad, subtotal).
  previsualizacion(): { unidades: number; costoUnitario: number; subtotal: number } | null {
    if (!this.productoSeleccionado) return null;

    if (this.modo === 'paquete') {
      const paq = Number(this.paquetesSel);
      const por = Number(this.unidadesPorPaqueteSel);
      const costoPaq = Number(this.costoPaqueteSel);
      if (!(paq > 0) || !(por > 0) || this.costoPaqueteSel === null || isNaN(costoPaq)) return null;
      return { unidades: paq * por, costoUnitario: costoPaq / por, subtotal: costoPaq * paq };
    }

    const cant = Number(this.cantidadSel);
    const costo = Number(this.costoUnitarioSel);
    if (!(cant > 0) || this.costoUnitarioSel === null || isNaN(costo)) return null;
    return { unidades: cant, costoUnitario: costo, subtotal: costo * cant };
  }

  lineaValida(): boolean {
    return this.previsualizacion() !== null;
  }

  totalCompra = computed(() => this.lineas().reduce((acc, l) => acc + l.subtotal, 0));

  ngOnInit(): void {
    this.cargarPedidos();
    this.proveedorService.listar().subscribe({ next: (data) => this.proveedores.set(data.filter((p) => p.activo)) });
    this.productoService.listar().subscribe({ next: (data) => this.productos.set(data) });
  }

  cargarPedidos(): void {
    this.cargandoPedidos.set(true);
    this.pedidoCompraService.listar().subscribe({
      next: (data) => { this.pedidosCompra.set(data); this.cargandoPedidos.set(false); },
      error: () => { this.error.set('No se pudo conectar con el servidor.'); this.cargandoPedidos.set(false); },
    });
  }

  alternarDetalle(id: number): void {
    this.detalleAbierto.set(this.detalleAbierto() === id ? null : id);
  }

  agregarLinea(): void {
    const pv = this.previsualizacion();
    const producto = this.productos().find((p) => p.id === this.productoSeleccionado);
    if (!pv || !producto) return;

    const linea: LineaCompra = {
      uid: this.siguienteUid++,
      producto,
      producto_id: producto.id,
      modo: this.modo,
      cantidad: pv.unidades,
      precio_unitario: Math.round(pv.costoUnitario * 100) / 100,
      subtotal: Math.round(pv.subtotal * 100) / 100,
      numero_lote: this.loteSel.trim(),
      fecha_vencimiento: this.vencimientoSel,
    };

    if (this.modo === 'paquete') {
      linea.cantidad_paquetes = Number(this.paquetesSel);
      linea.unidades_por_paquete = Number(this.unidadesPorPaqueteSel);
      linea.precio_paquete = Number(this.costoPaqueteSel);
    }

    this.lineas.set([...this.lineas(), linea]);
    this.limpiarLinea();
  }

  private limpiarLinea(): void {
    this.productoSeleccionado = null;
    this.busqueda.set('');
    this.paquetesSel = 1;
    this.unidadesPorPaqueteSel = null;
    this.costoPaqueteSel = null;
    this.cantidadSel = 1;
    this.costoUnitarioSel = null;
    this.loteSel = '';
    this.vencimientoSel = '';
  }

  quitarLinea(uid: number): void {
    this.lineas.set(this.lineas().filter((l) => l.uid !== uid));
  }

  puedeConfirmar(): boolean {
    return !!this.proveedorId && this.lineas().length > 0;
  }

  // Convierte las líneas de la pantalla en lo que espera la API.
  private armarItems(): ItemCompra[] {
    return this.lineas().map((l) => {
      const base: ItemCompra = { producto_id: l.producto_id };
      if (l.numero_lote) base.numero_lote = l.numero_lote;
      if (l.fecha_vencimiento) base.fecha_vencimiento = l.fecha_vencimiento;

      if (l.modo === 'paquete') {
        return {
          ...base,
          cantidad_paquetes: l.cantidad_paquetes,
          unidades_por_paquete: l.unidades_por_paquete,
          precio_paquete: l.precio_paquete,
        };
      }
      return { ...base, cantidad: l.cantidad, precio_unitario: l.precio_unitario };
    });
  }

  // Carga un pedido pendiente en el formulario para corregirlo.
  editar(pc: PedidoCompra): void {
    this.editandoId.set(pc.id);
    this.proveedorId = pc.proveedor_id;
    this.observaciones = pc.observaciones ?? '';
    this.error.set('');
    this.mensajeOk.set('');
    this.limpiarLinea();

    this.lineas.set(
      (pc.detalles ?? []).map((d) => {
        const producto = this.productos().find((p) => p.id === d.producto_id) ?? (d.producto as Producto);
        const porPaquete = !!d.cantidad_paquetes;
        return {
          uid: this.siguienteUid++,
          producto,
          producto_id: d.producto_id,
          modo: porPaquete ? 'paquete' : 'unidad',
          cantidad: Number(d.cantidad),
          cantidad_paquetes: d.cantidad_paquetes ?? undefined,
          unidades_por_paquete: d.unidades_por_paquete ?? undefined,
          precio_paquete: d.precio_paquete != null ? Number(d.precio_paquete) : undefined,
          precio_unitario: Number(d.precio_unitario),
          subtotal: Number(d.subtotal),
          numero_lote: d.numero_lote ?? '',
          fecha_vencimiento: d.fecha_vencimiento ? String(d.fecha_vencimiento).slice(0, 10) : '',
        } as LineaCompra;
      }),
    );

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  cancelarEdicion(): void {
    this.editandoId.set(null);
    this.proveedorId = null;
    this.observaciones = '';
    this.lineas.set([]);
    this.limpiarLinea();
    this.error.set('');
  }

  confirmarPedido(): void {
    if (!this.proveedorId || this.lineas().length === 0) return;

    this.guardando.set(true);
    this.error.set('');
    this.mensajeOk.set('');

    const payload = {
      proveedor_id: this.proveedorId,
      observaciones: this.observaciones.trim() || undefined,
      items: this.armarItems(),
    };

    const id = this.editandoId();
    const peticion = id ? this.pedidoCompraService.actualizar(id, payload) : this.pedidoCompraService.crear(payload);

    peticion.subscribe({
      next: (pedido) => {
        if (id) {
          this.pedidosCompra.set(this.pedidosCompra().map((x) => (x.id === id ? pedido : x)));
          this.mensajeOk.set(`Pedido de compra #${pedido.id} actualizado.`);
        } else {
          this.pedidosCompra.set([pedido, ...this.pedidosCompra()]);
          this.mensajeOk.set(`Pedido de compra #${pedido.id} registrado. Márcalo "Recibido" cuando llegue la mercadería.`);
        }
        this.editandoId.set(null);
        this.lineas.set([]);
        this.proveedorId = null;
        this.observaciones = '';
        this.guardando.set(false);
      },
      error: (err) => {
        this.error.set(err?.error?.message || 'No se pudo guardar el pedido de compra.');
        this.guardando.set(false);
      },
    });
  }

  async recibir(pc: PedidoCompra): Promise<void> {
    const ok = await this.confirmDialog.confirm({
      titulo: 'Recibir mercadería',
      mensaje: `¿Confirmas que llegó la mercadería del pedido #${pc.id}? Esto sumará el stock, registrará los lotes con su vencimiento y actualizará el costo (y el precio de venta, si el producto tiene margen).`,
      textoConfirmar: 'Sí, ya llegó',
    });
    if (!ok) return;

    this.pedidoCompraService.recibir(pc.id).subscribe({
      next: (actualizado) => {
        this.pedidosCompra.set(this.pedidosCompra().map((x) => (x.id === pc.id ? actualizado : x)));
        this.mensajeOk.set(`Pedido #${pc.id} recibido. Stock y costos actualizados.`);
        if (this.editandoId() === pc.id) this.cancelarEdicion();
        this.productoService.listar().subscribe({ next: (data) => this.productos.set(data) });
      },
      error: (err) => this.error.set(err?.error?.message || 'No se pudo marcar como recibido.'),
    });
  }

  async cancelar(pc: PedidoCompra): Promise<void> {
    const ok = await this.confirmDialog.confirm({
      titulo: 'Cancelar pedido de compra',
      mensaje: `¿Cancelar el pedido de compra #${pc.id}? Esta acción no se puede deshacer.`,
      textoConfirmar: 'Sí, cancelar',
      peligroso: true,
    });
    if (!ok) return;

    this.pedidoCompraService.cancelar(pc.id).subscribe({
      next: () => { if (this.editandoId() === pc.id) this.cancelarEdicion(); this.cargarPedidos(); },
      error: (err) => this.error.set(err?.error?.message || 'No se pudo cancelar el pedido de compra.'),
    });
  }
}
