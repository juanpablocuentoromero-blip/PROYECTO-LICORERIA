import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PromocionService } from '../../core/services/promocion.service';
import { CategoriaService } from '../../core/services/categoria.service';
import { ProductoService } from '../../core/services/producto.service';
import { Categoria } from '../../core/models/categoria.model';
import { Producto } from '../../core/models/producto.model';
import { Promocion, PromocionPayload, TipoPromocion } from '../../core/models/paso5.model';
import { BASE_THEME } from '../../shared/theme/theme';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';
import { AuthService } from '../../core/services/auth.service';

const DIAS = [
  { n: 1, e: 'Lun' }, { n: 2, e: 'Mar' }, { n: 3, e: 'Mié' }, { n: 4, e: 'Jue' },
  { n: 5, e: 'Vie' }, { n: 6, e: 'Sáb' }, { n: 0, e: 'Dom' },
];

/**
 * Descuentos y promociones con reglas (5.4), solo administrador.
 * Los combos siguen siendo precios especiales aparte y no entran en estas reglas.
 */
@Component({
  selector: 'app-promociones',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Catálogo &middot; Promociones</div>
          <h1>Descuentos y promociones</h1>
          <p class="subtitle">Por volumen, por horario (happy hour) o con cupón. Los combos no entran en estas reglas.</p>
        </div>
      </header>

      @if (!puedeEditar()) {
        <p class="subtitle">Estás en modo consulta: aquí ves qué promociones y cupones están activos. Solo el administrador puede cambiarlos.</p>
      }

      @if (puedeEditar()) {
      <section class="panel">
        <button class="btn-secondary" (click)="toggleForm()">
          {{ formAbierto() ? 'Cerrar formulario' : (editandoId() ? 'Editar promoción' : '+ Nueva promoción') }}
        </button>

        @if (formAbierto()) {
          <form class="form-grid" style="margin-top:16px" (ngSubmit)="guardar()">
            <div class="field">
              <label>Nombre</label>
              <input type="text" [(ngModel)]="form.nombre" name="nombre" maxlength="120" required placeholder="Ej. Happy hour cervezas" />
            </div>
            <div class="field">
              <label>Tipo</label>
              <select [(ngModel)]="form.tipo" name="tipo">
                <option value="volumen">Por volumen (llevando N o más)</option>
                <option value="horario">Por horario (happy hour)</option>
                <option value="cupon">Con cupón</option>
              </select>
            </div>

            <div class="field">
              <label>Aplica a</label>
              <select [(ngModel)]="form.alcance" name="alcance">
                <option value="todo">Todos los productos</option>
                <option value="categoria">Una categoría</option>
                <option value="producto">Un producto</option>
              </select>
            </div>
            @if (form.alcance === 'categoria') {
              <div class="field">
                <label>Categoría</label>
                <select [(ngModel)]="form.categoria_id" name="categoria_id">
                  <option [ngValue]="null">Elige…</option>
                  @for (c of categorias(); track c.id) { <option [ngValue]="c.id">{{ c.nombre }}</option> }
                </select>
              </div>
            }
            @if (form.alcance === 'producto') {
              <div class="field">
                <label>Producto</label>
                <select [(ngModel)]="form.producto_id" name="producto_id">
                  <option [ngValue]="null">Elige…</option>
                  @for (p of productos(); track p.id) { <option [ngValue]="p.id">{{ p.nombre }}</option> }
                </select>
              </div>
            }

            <div class="field">
              <label>Descuento</label>
              <select [(ngModel)]="form.tipo_descuento" name="tipo_descuento">
                <option value="porcentaje">Porcentaje (%)</option>
                <option value="monto">Monto fijo (Bs, una sola vez)</option>
              </select>
            </div>
            <div class="field">
              <label>Valor {{ form.tipo_descuento === 'porcentaje' ? '(%)' : '(Bs)' }}</label>
              <input type="number" min="0.01" step="0.01" [(ngModel)]="form.valor" name="valor" required />
            </div>

            @if (form.tipo === 'volumen') {
              <div class="field">
                <label>Desde cuántas unidades</label>
                <input type="number" min="1" step="1" [(ngModel)]="form.cantidad_minima" name="cantidad_minima" />
              </div>
            }

            @if (form.tipo === 'horario') {
              <div class="field"><label>Desde las</label><input type="time" [(ngModel)]="form.hora_inicio" name="hora_inicio" /></div>
              <div class="field"><label>Hasta las</label><input type="time" [(ngModel)]="form.hora_fin" name="hora_fin" /></div>
              <div class="field" style="grid-column: 1/-1">
                <label>Días <span>(ninguno marcado = todos los días)</span></label>
                <div class="dias">
                  @for (d of dias; track d.n) {
                    <label class="dia"><input type="checkbox" [checked]="diaMarcado(d.n)" (change)="alternarDia(d.n)" /> {{ d.e }}</label>
                  }
                </div>
              </div>
            }

            @if (form.tipo === 'cupon') {
              <div class="field">
                <label>Código del cupón</label>
                <input type="text" [(ngModel)]="form.codigo" name="codigo" maxlength="40" placeholder="VERANO10" style="text-transform:uppercase" />
              </div>
              <div class="field">
                <label>Usos máximos <span>(vacío = ilimitado)</span></label>
                <input type="number" min="1" step="1" [(ngModel)]="form.usos_maximos" name="usos_maximos" />
              </div>
            }

            <div class="field"><label>Vigente desde <span>(opcional)</span></label><input type="date" [(ngModel)]="form.fecha_inicio" name="fecha_inicio" /></div>
            <div class="field"><label>Vigente hasta <span>(opcional)</span></label><input type="date" [(ngModel)]="form.fecha_fin" name="fecha_fin" /></div>
            <div class="field">
              <label class="check"><input type="checkbox" [(ngModel)]="form.activo" name="activo" /> Activa</label>
            </div>

            <div class="field-row" style="grid-column: 1/-1">
              <button type="submit" class="btn-primary" [disabled]="guardando() || !form.nombre.trim() || !form.valor">
                {{ guardando() ? 'Guardando…' : (editandoId() ? 'Actualizar' : 'Guardar promoción') }}
              </button>
              @if (error()) { <span class="form-error">{{ error() }}</span> }
            </div>
          </form>
        }
      </section>
      }

      @if (cargando()) {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando promociones…</p></div>
      } @else if (promociones().length === 0) {
        <div class="estado-vacio"><p>No hay promociones.</p><span>Crea la primera con el botón de arriba.</span></div>
      } @else {
        <table>
          <thead><tr><th>Nombre</th><th>Tipo</th><th>Aplica a</th><th>Descuento</th><th>Regla</th><th>Estado</th><th></th></tr></thead>
          <tbody>
            @for (p of promociones(); track p.id) {
              <tr>
                <td data-label="Nombre">{{ p.nombre }}</td>
                <td data-label="Tipo">{{ etiquetaTipo(p.tipo) }}</td>
                <td data-label="Aplica a">{{ aplicaA(p) }}</td>
                <td data-label="Descuento">{{ p.tipo_descuento === 'porcentaje' ? (+p.valor | number: '1.0-2') + ' %' : 'Bs ' + (+p.valor | number: '1.2-2') }}</td>
                <td data-label="Regla">{{ regla(p) }}</td>
                <td data-label="Estado"><span class="badge" [class.badge-ok]="p.activo" [class.badge-off]="!p.activo">{{ p.activo ? 'Activa' : 'Inactiva' }}</span></td>
                @if (puedeEditar()) {
                <td data-label="Acciones">
                  <button class="link-action" (click)="editar(p)">Editar</button>
                  <button class="link-action" (click)="alternarActiva(p)">{{ p.activo ? 'Desactivar' : 'Activar' }}</button>
                  <button class="link-danger" (click)="eliminar(p)">Eliminar</button>
                </td>
                }
              </tr>
            }
          </tbody>
        </table>
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .dias { display: flex; gap: 10px; flex-wrap: wrap; }
    .dia, .check { display: flex; gap: 6px; align-items: center; cursor: pointer; font-size: 13px; }
  `],
})
export class PromocionesComponent implements OnInit {
  private service = inject(PromocionService);
  private categoriaService = inject(CategoriaService);
  private productoService = inject(ProductoService);
  private confirmDialog = inject(ConfirmDialogService);
  private auth = inject(AuthService);
  /** Solo el administrador crea, edita o borra; el vendedor consulta. */
  puedeEditar = () => this.auth.usuarioActual()?.rol === 'administrador';

  readonly dias = DIAS;

  promociones = signal<Promocion[]>([]);
  categorias = signal<Categoria[]>([]);
  productos = signal<Producto[]>([]);
  cargando = signal(true);
  guardando = signal(false);
  formAbierto = signal(false);
  editandoId = signal<number | null>(null);
  error = signal('');

  form = this.formVacio();

  private formVacio() {
    return {
      nombre: '',
      tipo: 'volumen' as TipoPromocion,
      alcance: 'todo' as 'todo' | 'categoria' | 'producto',
      categoria_id: null as number | null,
      producto_id: null as number | null,
      tipo_descuento: 'porcentaje' as 'porcentaje' | 'monto',
      valor: null as number | null,
      cantidad_minima: null as number | null,
      hora_inicio: '',
      hora_fin: '',
      dias: [] as number[],
      codigo: '',
      usos_maximos: null as number | null,
      fecha_inicio: '',
      fecha_fin: '',
      activo: true,
    };
  }

  ngOnInit(): void {
    this.cargar();
    this.categoriaService.listar().subscribe({ next: (c) => this.categorias.set(c), error: () => {} });
    this.productoService.listar().subscribe({ next: (p) => this.productos.set(p), error: () => {} });
  }

  cargar(): void {
    this.cargando.set(true);
    this.service.listar().subscribe({
      next: (data) => { this.promociones.set(data); this.cargando.set(false); },
      error: () => { this.error.set('No se pudo conectar con el servidor.'); this.cargando.set(false); },
    });
  }

  toggleForm(): void {
    if (this.formAbierto()) {
      this.formAbierto.set(false);
      this.editandoId.set(null);
      this.form = this.formVacio();
      this.error.set('');
    } else {
      this.formAbierto.set(true);
    }
  }

  diaMarcado(n: number): boolean {
    return this.form.dias.includes(n);
  }

  alternarDia(n: number): void {
    this.form.dias = this.diaMarcado(n) ? this.form.dias.filter((d) => d !== n) : [...this.form.dias, n];
  }

  editar(p: Promocion): void {
    this.editandoId.set(p.id);
    this.form = {
      nombre: p.nombre,
      tipo: p.tipo,
      alcance: p.alcance,
      categoria_id: p.categoria_id,
      producto_id: p.producto_id,
      tipo_descuento: p.tipo_descuento,
      valor: Number(p.valor),
      cantidad_minima: p.cantidad_minima,
      hora_inicio: (p.hora_inicio ?? '').slice(0, 5),
      hora_fin: (p.hora_fin ?? '').slice(0, 5),
      dias: p.dias_semana ? p.dias_semana.split(',').map(Number) : [],
      codigo: p.codigo ?? '',
      usos_maximos: p.usos_maximos,
      fecha_inicio: p.fecha_inicio ?? '',
      fecha_fin: p.fecha_fin ?? '',
      activo: p.activo,
    };
    this.formAbierto.set(true);
    this.error.set('');
  }

  private aPayload(): PromocionPayload {
    const f = this.form;
    return {
      nombre: f.nombre.trim(),
      tipo: f.tipo,
      alcance: f.alcance,
      categoria_id: f.alcance === 'categoria' ? f.categoria_id : null,
      producto_id: f.alcance === 'producto' ? f.producto_id : null,
      tipo_descuento: f.tipo_descuento,
      valor: Number(f.valor),
      cantidad_minima: f.tipo === 'volumen' ? f.cantidad_minima : null,
      hora_inicio: f.tipo === 'horario' ? f.hora_inicio || null : null,
      hora_fin: f.tipo === 'horario' ? f.hora_fin || null : null,
      dias_semana: f.tipo === 'horario' && f.dias.length > 0 ? [...f.dias].sort().join(',') : null,
      codigo: f.tipo === 'cupon' ? f.codigo.trim().toUpperCase() || null : null,
      usos_maximos: f.tipo === 'cupon' ? f.usos_maximos : null,
      fecha_inicio: f.fecha_inicio || null,
      fecha_fin: f.fecha_fin || null,
      activo: f.activo,
    };
  }

  guardar(): void {
    this.guardando.set(true);
    this.error.set('');
    const id = this.editandoId();
    const payload = this.aPayload();
    const req = id ? this.service.actualizar(id, payload) : this.service.crear(payload);

    req.subscribe({
      next: () => {
        this.guardando.set(false);
        this.formAbierto.set(false);
        this.editandoId.set(null);
        this.form = this.formVacio();
        this.cargar();
      },
      error: (err) => {
        this.guardando.set(false);
        const errores = err?.error?.errors ? Object.values(err.error.errors).flat().join(' ') : '';
        this.error.set(errores || err?.error?.message || 'No se pudo guardar la promoción.');
      },
    });
  }

  alternarActiva(p: Promocion): void {
    const payload: PromocionPayload = {
      nombre: p.nombre, tipo: p.tipo, alcance: p.alcance,
      categoria_id: p.categoria_id, producto_id: p.producto_id,
      tipo_descuento: p.tipo_descuento, valor: Number(p.valor),
      cantidad_minima: p.cantidad_minima,
      hora_inicio: p.hora_inicio ? p.hora_inicio.slice(0, 5) : null,
      hora_fin: p.hora_fin ? p.hora_fin.slice(0, 5) : null,
      dias_semana: p.dias_semana, codigo: p.codigo, usos_maximos: p.usos_maximos,
      fecha_inicio: p.fecha_inicio, fecha_fin: p.fecha_fin,
      activo: !p.activo,
    };
    this.service.actualizar(p.id, payload).subscribe({
      next: () => this.cargar(),
      error: (err) => this.error.set(err?.error?.message || 'No se pudo cambiar el estado.'),
    });
  }

  async eliminar(p: Promocion): Promise<void> {
    const ok = await this.confirmDialog.confirm({
      titulo: 'Eliminar promoción',
      mensaje: `¿Eliminar «${p.nombre}»? Las ventas ya hechas conservan su descuento.`,
      textoConfirmar: 'Sí, eliminar',
      peligroso: true,
    });
    if (!ok) return;
    this.service.eliminar(p.id).subscribe({
      next: () => this.promociones.set(this.promociones().filter((x) => x.id !== p.id)),
      error: () => this.error.set('No se pudo eliminar la promoción.'),
    });
  }

  etiquetaTipo(t: TipoPromocion): string {
    return t === 'volumen' ? 'Volumen' : t === 'horario' ? 'Horario' : 'Cupón';
  }

  aplicaA(p: Promocion): string {
    if (p.alcance === 'categoria') return `Categoría: ${p.categoria?.nombre ?? '—'}`;
    if (p.alcance === 'producto') return `Producto: ${p.producto?.nombre ?? '—'}`;
    return 'Todo';
  }

  regla(p: Promocion): string {
    if (p.tipo === 'volumen') return `Desde ${p.cantidad_minima} unidades`;
    if (p.tipo === 'horario') {
      const dias = p.dias_semana
        ? p.dias_semana.split(',').map((d) => DIAS.find((x) => x.n === Number(d))?.e).join(' ')
        : 'todos los días';
      return `${(p.hora_inicio ?? '').slice(0, 5)}–${(p.hora_fin ?? '').slice(0, 5)} · ${dias}`;
    }
    const usos = p.usos_maximos ? `${p.usos_actuales}/${p.usos_maximos} usos` : `${p.usos_actuales} usos`;
    return `Código ${p.codigo} · ${usos}`;
  }
}
