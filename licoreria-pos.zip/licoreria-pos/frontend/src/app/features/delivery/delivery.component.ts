import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DeliveryService } from '../../core/services/delivery.service';
import { Repartidor, ZonaDelivery } from '../../core/models/paso5.model';
import { BASE_THEME } from '../../shared/theme/theme';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';
import { AuthService } from '../../core/services/auth.service';

/** Zonas de reparto (costo de envío) y repartidores (5.2). El administrador los gestiona; el vendedor los consulta. */
@Component({
  selector: 'app-delivery',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Ventas &middot; Delivery</div>
          <h1>Delivery</h1>
          <p class="subtitle">Zonas con su costo de envío y los repartidores que se asignan a los pedidos.</p>
        </div>
      </header>

      @if (error()) { <p class="form-error">{{ error() }}</p> }
      @if (!puedeEditar()) {
        <p class="subtitle">Modo consulta: puedes ver los costos de envío y el teléfono de cada repartidor. Solo el administrador puede cambiarlos.</p>
      }

      <section class="panel">
        <h3 class="panel-title">Zonas de reparto</h3>
        @if (puedeEditar()) {
        <form class="form-grid" (ngSubmit)="guardarZona()">
          <div class="field"><label>Nombre</label><input type="text" [(ngModel)]="zona.nombre" name="znombre" maxlength="100" required placeholder="Ej. Centro" /></div>
          <div class="field"><label>Costo de envío (Bs)</label><input type="number" min="0" step="0.5" [(ngModel)]="zona.costo_envio" name="zcosto" required /></div>
          <div class="field"><label>Descripción <span>(opcional)</span></label><input type="text" [(ngModel)]="zona.descripcion" name="zdesc" maxlength="255" /></div>
          <div class="field-row">
            <button type="submit" class="btn-primary" [disabled]="!zona.nombre.trim() || zona.costo_envio === null">
              {{ zonaEditando() ? 'Actualizar zona' : 'Agregar zona' }}
            </button>
            @if (zonaEditando()) { <button type="button" class="btn-secondary" (click)="cancelarZona()">Cancelar</button> }
          </div>
        </form>
        }

        @if (zonas().length > 0) {
          <table style="margin-top:16px">
            <thead><tr><th>Zona</th><th>Envío</th><th>Estado</th><th></th></tr></thead>
            <tbody>
              @for (z of zonas(); track z.id) {
                <tr>
                  <td data-label="Zona">{{ z.nombre }}@if (z.descripcion) { <small class="sub">{{ z.descripcion }}</small> }</td>
                  <td data-label="Envío">Bs {{ +z.costo_envio | number: '1.2-2' }}</td>
                  <td data-label="Estado"><span class="badge" [class.badge-ok]="z.activo" [class.badge-off]="!z.activo">{{ z.activo ? 'Activa' : 'Inactiva' }}</span></td>
                  @if (puedeEditar()) {
                  <td data-label="Acciones">
                    <button class="link-action" (click)="editarZona(z)">Editar</button>
                    <button class="link-action" (click)="alternarZona(z)">{{ z.activo ? 'Desactivar' : 'Activar' }}</button>
                    <button class="link-danger" (click)="eliminarZona(z)">Eliminar</button>
                  </td>
                  }
                </tr>
              }
            </tbody>
          </table>
        } @else {
          <p class="subtitle" style="margin-top:12px">Todavía no hay zonas. Sin zonas activas, la tienda solo ofrece recojo en tienda.</p>
        }
      </section>

      <section class="panel">
        <h3 class="panel-title">Repartidores</h3>
        @if (puedeEditar()) {
        <form class="form-grid" (ngSubmit)="guardarRepartidor()">
          <div class="field"><label>Nombre</label><input type="text" [(ngModel)]="rep.nombre" name="rnombre" maxlength="100" required /></div>
          <div class="field"><label>Teléfono</label><input type="text" [(ngModel)]="rep.telefono" name="rtel" maxlength="20" /></div>
          <div class="field-row">
            <button type="submit" class="btn-primary" [disabled]="!rep.nombre.trim()">{{ repEditando() ? 'Actualizar' : 'Agregar repartidor' }}</button>
            @if (repEditando()) { <button type="button" class="btn-secondary" (click)="cancelarRep()">Cancelar</button> }
          </div>
        </form>
        }

        @if (repartidores().length > 0) {
          <table style="margin-top:16px">
            <thead><tr><th>Nombre</th><th>Teléfono</th><th>Estado</th><th></th></tr></thead>
            <tbody>
              @for (r of repartidores(); track r.id) {
                <tr>
                  <td data-label="Nombre">{{ r.nombre }}</td>
                  <td data-label="Teléfono">{{ r.telefono || '—' }}</td>
                  <td data-label="Estado"><span class="badge" [class.badge-ok]="r.activo" [class.badge-off]="!r.activo">{{ r.activo ? 'Activo' : 'Inactivo' }}</span></td>
                  @if (puedeEditar()) {
                  <td data-label="Acciones">
                    <button class="link-action" (click)="editarRep(r)">Editar</button>
                    <button class="link-action" (click)="alternarRep(r)">{{ r.activo ? 'Desactivar' : 'Activar' }}</button>
                    <button class="link-danger" (click)="eliminarRep(r)">Eliminar</button>
                  </td>
                  }
                </tr>
              }
            </tbody>
          </table>
        }
      </section>
    </div>
  `,
  styles: [BASE_THEME, `.sub { display: block; font-size: 11px; opacity: 0.75; }`],
})
export class DeliveryComponent implements OnInit {
  private service = inject(DeliveryService);
  private confirmDialog = inject(ConfirmDialogService);
  private auth = inject(AuthService);
  puedeEditar = () => this.auth.usuarioActual()?.rol === 'administrador';

  zonas = signal<ZonaDelivery[]>([]);
  repartidores = signal<Repartidor[]>([]);
  error = signal('');
  zonaEditando = signal<number | null>(null);
  repEditando = signal<number | null>(null);

  zona: { nombre: string; costo_envio: number | null; descripcion: string } = { nombre: '', costo_envio: null, descripcion: '' };
  rep = { nombre: '', telefono: '' };

  ngOnInit(): void {
    this.cargar();
  }

  private msg(err: any, porDefecto: string): string {
    const errores = err?.error?.errors ? Object.values(err.error.errors).flat().join(' ') : '';
    return errores || err?.error?.message || porDefecto;
  }

  cargar(): void {
    this.service.zonas(true).subscribe({ next: (z) => this.zonas.set(z), error: () => this.error.set('No se pudo conectar con el servidor.') });
    this.service.repartidores(true).subscribe({ next: (r) => this.repartidores.set(r), error: () => {} });
  }

  // ---- Zonas
  guardarZona(): void {
    if (!this.zona.nombre.trim() || this.zona.costo_envio === null) return;
    this.error.set('');
    const payload = {
      nombre: this.zona.nombre.trim(),
      costo_envio: Number(this.zona.costo_envio),
      descripcion: this.zona.descripcion.trim() || undefined,
    };
    const id = this.zonaEditando();
    const req = id ? this.service.actualizarZona(id, payload) : this.service.crearZona({ ...payload, activo: true });
    req.subscribe({
      next: () => { this.cancelarZona(); this.cargar(); },
      error: (err) => this.error.set(this.msg(err, 'No se pudo guardar la zona.')),
    });
  }

  editarZona(z: ZonaDelivery): void {
    this.zonaEditando.set(z.id);
    this.zona = { nombre: z.nombre, costo_envio: Number(z.costo_envio), descripcion: z.descripcion ?? '' };
  }

  cancelarZona(): void {
    this.zonaEditando.set(null);
    this.zona = { nombre: '', costo_envio: null, descripcion: '' };
  }

  alternarZona(z: ZonaDelivery): void {
    this.service.actualizarZona(z.id, { activo: !z.activo }).subscribe({
      next: () => this.cargar(),
      error: (err) => this.error.set(this.msg(err, 'No se pudo cambiar el estado.')),
    });
  }

  async eliminarZona(z: ZonaDelivery): Promise<void> {
    const ok = await this.confirmDialog.confirm({ titulo: 'Eliminar zona', mensaje: `¿Eliminar la zona «${z.nombre}»?`, textoConfirmar: 'Sí, eliminar', peligroso: true });
    if (!ok) return;
    this.service.eliminarZona(z.id).subscribe({
      next: () => this.cargar(),
      error: (err) => this.error.set(this.msg(err, 'No se pudo eliminar la zona.')),
    });
  }

  // ---- Repartidores
  guardarRepartidor(): void {
    if (!this.rep.nombre.trim()) return;
    this.error.set('');
    const payload = { nombre: this.rep.nombre.trim(), telefono: this.rep.telefono.trim() || undefined };
    const id = this.repEditando();
    const req = id ? this.service.actualizarRepartidor(id, payload) : this.service.crearRepartidor({ ...payload, activo: true });
    req.subscribe({
      next: () => { this.cancelarRep(); this.cargar(); },
      error: (err) => this.error.set(this.msg(err, 'No se pudo guardar el repartidor.')),
    });
  }

  editarRep(r: Repartidor): void {
    this.repEditando.set(r.id);
    this.rep = { nombre: r.nombre, telefono: r.telefono ?? '' };
  }

  cancelarRep(): void {
    this.repEditando.set(null);
    this.rep = { nombre: '', telefono: '' };
  }

  alternarRep(r: Repartidor): void {
    this.service.actualizarRepartidor(r.id, { activo: !r.activo }).subscribe({
      next: () => this.cargar(),
      error: (err) => this.error.set(this.msg(err, 'No se pudo cambiar el estado.')),
    });
  }

  async eliminarRep(r: Repartidor): Promise<void> {
    const ok = await this.confirmDialog.confirm({ titulo: 'Eliminar repartidor', mensaje: `¿Eliminar a «${r.nombre}»?`, textoConfirmar: 'Sí, eliminar', peligroso: true });
    if (!ok) return;
    this.service.eliminarRepartidor(r.id).subscribe({
      next: () => this.cargar(),
      error: (err) => this.error.set(this.msg(err, 'No se pudo eliminar el repartidor.')),
    });
  }
}
