import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { DashboardService } from '../../core/services/dashboard.service';
import { Dashboard } from '../../core/models/paso4.model';
import { AuthService } from '../../core/services/auth.service';
import { BASE_THEME } from '../../shared/theme/theme';

/** 4.1 — Pantalla de inicio del administrador. */
@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">{{ esAdmin() ? 'Administración' : 'Ventas' }} &middot; Inicio</div>
          <h1>Panel del negocio</h1>
          <p class="subtitle">Cómo va el día: ventas, caja, pedidos y alertas.</p>
        </div>
        <div class="acciones">
          <input type="date" [(ngModel)]="fecha" name="fecha" (change)="cargar()" [max]="hoy" />
          <button class="btn-secondary" (click)="cargar()" [disabled]="cargando()">↻ Actualizar</button>
        </div>
      </header>

      @if (error()) { <p class="form-error">{{ error() }}</p> }

      @if (cargando() && !d()) {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando el panel…</p></div>
      } @else if (d(); as x) {
        <!-- Indicadores -->
        <div class="kpis">
          <div class="card-plain kpi">
            <span class="kpi-label">Ventas del día (neto)</span>
            <strong>Bs {{ bs(x.ventas.neto) }}</strong>
            @if (x.ventas.variacion_vs_ayer !== null) {
              <small [class.sube]="x.ventas.variacion_vs_ayer >= 0" [class.baja]="x.ventas.variacion_vs_ayer < 0">
                {{ x.ventas.variacion_vs_ayer >= 0 ? '▲' : '▼' }} {{ abs(x.ventas.variacion_vs_ayer) }}% vs ayer (Bs {{ bs(x.ventas.neto_ayer) }})
              </small>
            } @else {
              <small>Ayer: Bs {{ bs(x.ventas.neto_ayer) }}</small>
            }
            @if (x.ventas.devoluciones > 0) {
              <small class="baja">Incluye −Bs {{ bs(x.ventas.devoluciones) }} en devoluciones</small>
            }
          </div>
          <div class="card-plain kpi">
            <span class="kpi-label">Ventas realizadas</span>
            <strong>{{ x.ventas.cantidad }}</strong>
            <small>Ticket promedio: Bs {{ bs(x.ventas.ticket_promedio) }}</small>
          </div>
          <div class="card-plain kpi">
            <span class="kpi-label">Pedidos pendientes</span>
            <strong>{{ x.pedidos.pendientes }}</strong>
            <small>{{ x.pedidos.en_curso }} en curso (confirmados / en camino)</small>
          </div>
          <div class="card-plain kpi">
            <span class="kpi-label">Por cobrar (fiado)</span>
            <strong>Bs {{ bs(x.por_cobrar.total) }}</strong>
            <small [class.baja]="x.por_cobrar.vencido > 0">Vencido: Bs {{ bs(x.por_cobrar.vencido) }}</small>
          </div>
          <div class="card-plain kpi">
            <span class="kpi-label">Alertas de inventario</span>
            <strong [class.baja]="x.alertas.criticas > 0">{{ x.alertas.activas }}</strong>
            <small>{{ x.alertas.criticas }} crítica(s)@if (esAdmin()) { · <a routerLink="/reposicion">ver reposición</a> }</small>
          </div>
        </div>

        <div class="grid-2">
          <!-- Ventas por hora -->
          <section class="panel">
            <h3 class="panel-title">Ventas por hora</h3>
            @if (x.ventas.cantidad === 0) {
              <p class="vacio">Todavía no hay ventas en este día.</p>
            } @else {
              <div class="barras" role="img" aria-label="Ventas por hora">
                @for (h of x.ventas_por_hora; track h.hora) {
                  <div class="barra-col" [title]="h.hora + ':00 — Bs ' + bs(h.total) + ' (' + h.cantidad + ' ventas)'">
                    <div class="barra" [style.height.%]="pct(h.total, maxHora())" [class.pico]="h.total === maxHora() && h.total > 0"></div>
                    <span class="barra-et">{{ h.hora % 3 === 0 ? h.hora : '' }}</span>
                  </div>
                }
              </div>
              <p class="pie">Hora de Bolivia. Hora pico: {{ horaPico() }}</p>
            }
          </section>

          <!-- Últimos 7 días -->
          <section class="panel">
            <h3 class="panel-title">Últimos 7 días</h3>
            <div class="barras dias">
              @for (v of x.ultimos_7_dias; track v.fecha) {
                <div class="barra-col" [title]="v.fecha + ' — Bs ' + bs(v.total) + ' (' + v.cantidad + ' ventas)'">
                  <span class="barra-val">{{ v.total > 0 ? bs0(v.total) : '' }}</span>
                  <div class="barra" [style.height.%]="pct(v.total, maxDia())" [class.pico]="v.fecha === x.fecha"></div>
                  <span class="barra-et">{{ etiquetaDia(v.fecha) }}</span>
                </div>
              }
            </div>
          </section>
        </div>

        <div class="grid-2">
          <!-- Top productos -->
          <section class="panel">
            <div class="panel-cab">
              <h3 class="panel-title">Productos más vendidos</h3>
              <div class="seg">
                <button [class.on]="diasTop() === 1" (click)="cambiarTop(1)">Hoy</button>
                <button [class.on]="diasTop() === 7" (click)="cambiarTop(7)">7 días</button>
                <button [class.on]="diasTop() === 30" (click)="cambiarTop(30)">30 días</button>
              </div>
            </div>
            @if (x.top_productos.items.length === 0) {
              <p class="vacio">Sin ventas en el período.</p>
            } @else {
              <ol class="top">
                @for (t of x.top_productos.items; track t.producto_id) {
                  <li>
                    <div class="top-fila"><span>{{ t.nombre }}</span><strong>{{ t.unidades }} u.</strong></div>
                    <div class="top-barra"><div [style.width.%]="pct(t.unidades, maxTop())"></div></div>
                    <small>Bs {{ bs(t.importe) }}</small>
                  </li>
                }
              </ol>
            }
          </section>

          <!-- Caja + pedidos -->
          <section class="panel">
            <h3 class="panel-title">Caja</h3>
            @if (x.caja; as c) {
              <p><span class="badge badge-ok">Abierta</span> desde las {{ hora(c.abierta_at) }} por {{ c.abierta_por || '—' }}</p>
              @if (esAdmin()) {
                <div class="caja-grid">
                  <div><span>Apertura</span><strong>Bs {{ bs(c.monto_apertura) }}</strong></div>
                  <div><span>Ventas del turno</span><strong>Bs {{ bs(c.ventas_total) }}</strong></div>
                  <div><span>Efectivo</span><strong>Bs {{ bs(c.ventas_efectivo) }}</strong></div>
                  <div><span>QR</span><strong>Bs {{ bs(c.ventas_qr) }}</strong></div>
                  <div><span>Tarjeta</span><strong>Bs {{ bs(c.ventas_tarjeta) }}</strong></div>
                  <div><span>Efectivo esperado</span><strong>Bs {{ bs(c.saldo_esperado) }}</strong></div>
                </div>
              } @else {
                <p class="vacio">Los montos del turno solo los ve el administrador. Ya puedes vender.</p>
              }
              <a routerLink="/caja" class="link-action">Ir a caja →</a>
            } @else {
              <p><span class="badge badge-off">Cerrada</span> No hay un turno abierto. No se puede vender hasta abrir caja.</p>
              <a routerLink="/caja" class="link-action">Abrir caja →</a>
            }

            <h3 class="panel-title" style="margin-top:22px">Pedidos por atender</h3>
            @if (x.pedidos.lista.length === 0) {
              <p class="vacio">No hay pedidos pendientes. 🎉</p>
            } @else {
              <ul class="pedidos">
                @for (p of x.pedidos.lista; track p.id) {
                  <li><span>#{{ p.id }} · {{ p.cliente || 'Cliente' }}</span><strong>Bs {{ bs(p.total) }}</strong></li>
                }
              </ul>
              <a routerLink="/pedidos" class="link-action">Ver todos los pedidos →</a>
            }
          </section>
        </div>
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .acciones { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
    .kpis { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 12px; margin-bottom: 18px; }
    .kpi { display: flex; flex-direction: column; gap: 4px; }
    .kpi strong { font-size: 24px; }
    .kpi small { font-size: 12px; color: #2d4a66; opacity: 1; }
    .kpi-label { font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #2d4a66; font-weight: 700; }
    .kpi strong { color: #020024; }
    .kpi a { color: #0a5f80; font-weight: 700; }
    .barra-et, .barra-val, .pie { color: #B3E8F5; opacity: 1; }
    .top small, .caja-grid span { color: #B3E8F5; opacity: 1; }
    .sube { color: #0e7a4f !important; } .baja { color: #b3261e !important; }
    .grid-2 { display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 14px; margin-bottom: 14px; }
    .panel-cab { display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap; }
    .panel-title { margin: 0 0 12px; }
    .vacio { opacity: 0.85; font-size: 14px; color: #B3E8F5; }
    .barras { display: flex; align-items: flex-end; gap: 3px; height: 170px; padding-top: 18px; }
    .barras.dias { gap: 10px; }
    .barra-col { flex: 1; height: 100%; display: flex; flex-direction: column; justify-content: flex-end; align-items: center; min-width: 0; }
    .barra { width: 100%; min-height: 2px; background: rgba(0, 212, 255, 0.45); border-radius: 3px 3px 0 0; transition: height .3s; }
    .barra.pico { background: #00D4FF; }
    .barra-et { font-size: 10px; opacity: 0.7; height: 14px; margin-top: 3px; }
    .barra-val { font-size: 10px; opacity: 0.8; white-space: nowrap; }
    .pie { font-size: 12px; opacity: 0.7; margin: 8px 0 0; }
    .seg { display: inline-flex; border: 1px solid rgba(0, 212, 255, 0.35); border-radius: 8px; overflow: hidden; }
    .seg button { background: transparent; color: inherit; border: 0; padding: 5px 11px; font-size: 12px; cursor: pointer; }
    .seg button.on { background: #00D4FF; color: #020024; font-weight: 600; }
    .top { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 10px; }
    .top-fila { display: flex; justify-content: space-between; gap: 8px; font-size: 14px; }
    .top-barra { height: 6px; background: rgba(0, 212, 255, 0.15); border-radius: 3px; margin: 4px 0 2px; }
    .top-barra div { height: 100%; background: #00D4FF; border-radius: 3px; }
    .top small { opacity: 0.7; }
    .caja-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px; margin: 12px 0; }
    .caja-grid div { display: flex; flex-direction: column; gap: 2px; }
    .caja-grid span { font-size: 11px; opacity: 0.7; text-transform: uppercase; letter-spacing: 0.04em; }
    .pedidos { list-style: none; margin: 0 0 8px; padding: 0; }
    .pedidos li { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid rgba(0, 212, 255, 0.15); font-size: 14px; }
  `],
})
export class DashboardComponent implements OnInit {
  private servicio = inject(DashboardService);
  private auth = inject(AuthService);
  esAdmin = computed(() => this.auth.usuarioActual()?.rol === 'administrador');

  d = signal<Dashboard | null>(null);
  cargando = signal(true);
  error = signal('');
  diasTop = signal<1 | 7 | 30>(1);

  hoy = new Date().toISOString().slice(0, 10);
  fecha = this.hoy;

  maxHora = computed(() => Math.max(0, ...(this.d()?.ventas_por_hora.map((h) => h.total) ?? [0])));
  maxDia = computed(() => Math.max(0, ...(this.d()?.ultimos_7_dias.map((v) => v.total) ?? [0])));
  maxTop = computed(() => Math.max(0, ...(this.d()?.top_productos.items.map((t) => t.unidades) ?? [0])));
  horaPico = computed(() => {
    const horas = this.d()?.ventas_por_hora ?? [];
    const pico = horas.reduce((a, b) => (b.total > a.total ? b : a), horas[0]);
    return pico && pico.total > 0 ? `${pico.hora}:00 – ${pico.hora + 1}:00` : '—';
  });

  ngOnInit(): void { this.cargar(); }

  cargar(): void {
    this.cargando.set(true);
    this.error.set('');
    this.servicio.obtener(this.diasTop(), this.fecha || undefined).subscribe({
      next: (r) => { this.d.set(r); this.cargando.set(false); },
      error: () => { this.error.set('No se pudo cargar el panel.'); this.cargando.set(false); },
    });
  }

  cambiarTop(dias: 1 | 7 | 30): void {
    this.diasTop.set(dias);
    this.cargar();
  }

  bs(n: number): string { return (n ?? 0).toLocaleString('es-BO', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  bs0(n: number): string { return Math.round(n ?? 0).toLocaleString('es-BO'); }
  abs(n: number): number { return Math.abs(n); }
  pct(valor: number, max: number): number { return max > 0 ? Math.max(2, (valor / max) * 100) : 0; }

  hora(iso: string): string {
    return new Date(iso).toLocaleTimeString('es-BO', { hour: '2-digit', minute: '2-digit', timeZone: 'America/La_Paz' });
  }

  etiquetaDia(fecha: string): string {
    const d = new Date(fecha + 'T12:00:00');
    return d.toLocaleDateString('es-BO', { weekday: 'short', day: 'numeric' });
  }
}
