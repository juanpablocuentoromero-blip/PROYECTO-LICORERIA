import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReporteService, LibroVentas } from '../../core/services/reporte.service';
import { BASE_THEME } from '../../shared/theme/theme';

@Component({
  selector: 'app-libro-ventas',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Administración &middot; Libro de ventas</div>
          <h1>Libro de ventas</h1>
          <p class="subtitle">Todas las ventas confirmadas (pagadas) en el rango de fechas elegido.</p>
        </div>
      </header>

      <section class="panel">
        <div class="form-grid">
          <div class="field">
            <label>Desde</label>
            <input type="date" [(ngModel)]="desde" name="desde" (change)="cargar()" />
          </div>
          <div class="field">
            <label>Hasta</label>
            <input type="date" [(ngModel)]="hasta" name="hasta" (change)="cargar()" />
          </div>
          <div class="field-row" style="align-self:flex-end">
            <button class="btn-secondary" (click)="descargarExcel()">⬇ Exportar a Excel</button>
          </div>
        </div>
      </section>

      @if (cargando()) {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando el libro de ventas…</p></div>
      } @else if (datos(); as d) {
        <div class="resumen-grid">
          <div class="card-plain"><span class="card-label">Ventas en el periodo</span><strong>{{ d.cantidad_ventas }}</strong></div>
          <div class="card-plain"><span class="card-label">Total general</span><strong>Bs {{ d.total_general.toFixed(2) }}</strong></div>
          @if ((d.total_devuelto ?? 0) > 0) {
            <div class="card-plain"><span class="card-label">Devoluciones (notas de crédito)</span><strong>− Bs {{ (d.total_devuelto ?? 0).toFixed(2) }}</strong></div>
            <div class="card-plain"><span class="card-label">Total neto</span><strong>Bs {{ (d.total_neto ?? 0).toFixed(2) }}</strong></div>
          }
          @for (metodo of metodos(d.resumen_por_metodo); track metodo.nombre) {
            <div class="card-plain"><span class="card-label">Total {{ metodo.nombre }}</span><strong>Bs {{ metodo.valor.toFixed(2) }}</strong></div>
          }
        </div>

        @if (d.ventas.length === 0) {
          <div class="estado-vacio"><p>No hay ventas registradas en este rango de fechas.</p></div>
        } @else {
          <table>
            <thead><tr><th>#</th><th>Fecha de pago</th><th>Cliente</th><th>Vendedor</th><th>Método</th><th>Total</th></tr></thead>
            <tbody>
              @for (v of d.ventas; track v.id) {
                <tr>
                  <td data-label="#">{{ v.id }}</td>
                  <td data-label="Fecha de pago">{{ formatearFecha(v.pagado_at) }}</td>
                  <td data-label="Cliente">{{ v.cliente?.nombre || '—' }}</td>
                  <td data-label="Vendedor">{{ v.usuario?.nombre || '—' }}</td>
                  <td data-label="Método"><span class="badge badge-info">{{ v.metodo_pago }}</span></td>
                  <td data-label="Total">Bs {{ (+v.total).toFixed(2) }}</td>
                </tr>
              }
            </tbody>
          </table>
        }
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .resumen-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 12px; margin-top: 6px; }
    .card-label { display: block; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: #7d6f52; margin-bottom: 4px; }
  `],
})
export class LibroVentasComponent implements OnInit {
  private reporteService = inject(ReporteService);

  cargando = signal(true);
  datos = signal<LibroVentas | null>(null);

  desde = this.primerDiaDelMes();
  hasta = this.hoy();

  ngOnInit(): void { this.cargar(); }

  cargar(): void {
    this.cargando.set(true);
    this.reporteService.libroVentas(this.desde, this.hasta).subscribe({
      next: (d) => { this.datos.set(d); this.cargando.set(false); },
      error: () => { this.cargando.set(false); },
    });
  }

  descargarExcel(): void {
    this.reporteService.descargar('ventas');
  }

  metodos(resumen: Record<string, number>) {
    return Object.entries(resumen || {}).map(([nombre, valor]) => ({ nombre, valor }));
  }

  formatearFecha(iso?: string): string {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleString('es-BO', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }

  private hoy(): string { return new Date().toISOString().slice(0, 10); }
  private primerDiaDelMes(): string {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
  }
}
