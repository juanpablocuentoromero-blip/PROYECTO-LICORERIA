import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { CajaService } from '../../core/services/caja.service';
import { CajaChicaService } from '../../core/services/caja-chica.service';
import { AlmacenService } from '../../core/services/almacen.service';
import { Caja, MisVentasCajaActual, TotalesCajaActual } from '../../core/models/caja.model';
import { CUENTAS_CAJA_CHICA, MovimientoCajaChica, ResumenCajaChica } from '../../core/models/caja-chica.model';
import { Almacen } from '../../core/models/almacen.model';
import { AuthService } from '../../core/services/auth.service';
import { BASE_THEME } from '../../shared/theme/theme';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';
import { ReporteCajeroComponent } from '../reportes/reporte-cajero.component';
import { ReporteCajaChicaComponent } from '../reportes/reporte-caja-chica.component';

@Component({
  selector: 'app-caja',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, ReporteCajeroComponent, ReporteCajaChicaComponent],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Operación diaria &middot; Caja</div>
          <h1>Caja</h1>
          <p class="subtitle">Abre tu turno al empezar, registra los movimientos de caja chica y cierra con el arqueo al final del día.</p>
        </div>
      </header>

      <div class="tabs">
        <button type="button" [class.activo]="tab() === 'turno'" (click)="tab.set('turno')">Turno de caja</button>
        <button type="button" [class.activo]="tab() === 'caja-chica'" (click)="cambiarACajaChica()">Caja chica</button>
        <button type="button" [class.activo]="tab() === 'reporte-caja'" (click)="tab.set('reporte-caja')">Reporte de caja</button>
        <button type="button" [class.activo]="tab() === 'reporte-chica'" (click)="tab.set('reporte-chica')">Reporte caja chica</button>
      </div>

      @if (tab() === 'turno') {
        <!-- ===================== TURNO DE CAJA ===================== -->
        @if (cargandoCaja()) {
          <div class="estado-vacio"><div class="spinner"></div><p>Consultando el estado de la caja…</p></div>
        } @else if (!cajaActual()) {
          <!-- Administrador y vendedor pueden abrir el turno; la API ya
               permite POST /api/caja/abrir a cualquiera de los dos roles. -->
          <section class="panel">
            <h2 class="panel-title">No hay una caja abierta</h2>
            <p class="subtitle" style="margin-bottom:16px">Ingresa el monto con el que arrancas el turno para poder vender y registrar caja chica.</p>
            <form (ngSubmit)="abrirCaja()">
              <div class="form-grid">
                <div class="field">
                  <label>Monto de apertura (Bs)</label>
                  <input type="number" min="0" step="0.01" [(ngModel)]="montoApertura" name="montoApertura" required />
                </div>
                <div class="field">
                  <label>Observaciones <span>(opcional)</span></label>
                  <input type="text" [(ngModel)]="observacionesApertura" name="observacionesApertura" />
                </div>
              </div>
              <div class="field-row" style="margin-top:14px">
                <button type="submit" class="btn-primary" [disabled]="abriendo() || montoApertura === ''">
                  {{ abriendo() ? 'Abriendo…' : 'Abrir caja' }}
                </button>
                @if (errorTurno()) { <span class="form-error">{{ errorTurno() }}</span> }
              </div>
            </form>
          </section>
        } @else {
          <section class="panel">
            <div class="field-row" style="justify-content:space-between; margin-bottom: 18px">
              <div>
                <h2 class="panel-title" style="margin-bottom:4px">Turno abierto</h2>
                <p class="subtitle" style="margin:0">
                  Desde {{ cajaActual()!.abierta_at | date:'dd/MM/yyyy HH:mm' }} · {{ cajaActual()!.usuario_apertura?.nombre }}
                </p>
              </div>
              <span class="badge badge-ok">Abierta</span>
            </div>

            @if (esAdmin()) {
              <div class="resumen-grid">
                <div class="card-plain">
                  <span class="resumen-label">Apertura</span>
                  <span class="resumen-valor">Bs {{ cajaActual()!.monto_apertura | number:'1.2-2' }}</span>
                </div>
                <div class="card-plain">
                  <span class="resumen-label">Ventas en efectivo</span>
                  <span class="resumen-valor">Bs {{ (totales()?.ventas_efectivo ?? 0) | number:'1.2-2' }}</span>
                </div>
                <div class="card-plain">
                  <span class="resumen-label">Cobros de crédito (efectivo)</span>
                  <span class="resumen-valor">Bs {{ (totales()?.abonos_efectivo ?? 0) | number:'1.2-2' }}</span>
                </div>
                <div class="card-plain">
                  <span class="resumen-label">Caja chica (neto)</span>
                  <span class="resumen-valor">Bs {{ ((totales()?.ingresos_caja_chica ?? 0) - (totales()?.egresos_caja_chica ?? 0)) | number:'1.2-2' }}</span>
                </div>
                <div class="card-plain destacado">
                  <span class="resumen-label">Saldo esperado ahora</span>
                  <span class="resumen-valor">Bs {{ (totales()?.saldo_esperado_ahora ?? 0) | number:'1.2-2' }}</span>
                </div>
              </div>
            } @else {
              <!-- El vendedor ve solo lo que él vendió en este turno, nunca
                   el acumulado de todo el negocio (eso sigue siendo del
                   administrador). No es editable: es un resumen de lectura. -->
              <div class="resumen-grid">
                <div class="card-plain">
                  <span class="resumen-label">Tus ventas</span>
                  <span class="resumen-valor">{{ misVentas()?.cantidad ?? 0 }}</span>
                </div>
                <div class="card-plain destacado">
                  <span class="resumen-label">Total vendido por ti</span>
                  <span class="resumen-valor">Bs {{ (misVentas()?.total ?? 0) | number:'1.2-2' }}</span>
                </div>
              </div>
            }

            @if (!mostrarFormCierre()) {
              <div class="field-row" style="margin-top:20px">
                <button type="button" class="btn-primary" (click)="mostrarFormCierre.set(true)">Cerrar caja</button>
              </div>
            } @else {
              <form (ngSubmit)="cerrarCaja()" style="margin-top:20px; border-top: 1px solid rgba(140,193,233,0.2); padding-top:18px">
                <p class="subtitle" style="margin-bottom:12px">Cuenta el efectivo físico y anota lo que realmente hay en caja.</p>
                <div class="form-grid">
                  <div class="field">
                    <label>Monto contado (Bs)</label>
                    <input type="number" min="0" step="0.01" [(ngModel)]="montoCierreReal" name="montoCierreReal" required />
                  </div>
                  <div class="field">
                    <label>Observaciones <span>(opcional)</span></label>
                    <input type="text" [(ngModel)]="observacionesCierre" name="observacionesCierre" />
                  </div>
                </div>
                <div class="field-row" style="margin-top:14px">
                  <button type="submit" class="btn-primary" [disabled]="cerrando() || montoCierreReal === ''">
                    {{ cerrando() ? 'Cerrando…' : 'Confirmar cierre' }}
                  </button>
                  <button type="button" class="btn-secondary" (click)="mostrarFormCierre.set(false)">Cancelar</button>
                  @if (errorTurno()) { <span class="form-error">{{ errorTurno() }}</span> }
                </div>
              </form>
            }
          </section>
        }

        @if (esAdmin()) {
          <section class="panel">
            <div class="field-row" style="justify-content:space-between">
              <h2 class="panel-title" style="margin:0">Historial de cajas</h2>
              <button type="button" class="btn-secondary" (click)="toggleHistorial()">
                {{ historialAbierto() ? 'Ocultar' : 'Ver historial completo' }}
              </button>
            </div>

            @if (historialAbierto()) {
              @if (cargandoHistorial()) {
                <div class="estado-vacio" style="margin-top:16px"><div class="spinner"></div><p>Cargando historial…</p></div>
              } @else if (historial().length === 0) {
                <p class="subtitle" style="margin-top:16px">Todavía no hay cajas cerradas.</p>
              } @else {
                <table style="margin-top:16px">
                  <thead>
                    <tr>
                      <th>ID</th><th>Almacén</th><th>Abrió</th><th>Apertura</th>
                      <th>Cerró</th><th>Cierre</th><th>Estado</th><th>Diferencia</th><th></th>
                    </tr>
                  </thead>
                  <tbody>
                    @for (c of historial(); track c.id) {
                      <tr>
                        <td data-label="ID">#{{ c.id }}</td>
                        <td data-label="Almacén">{{ c.almacen?.nombre }}</td>
                        <td data-label="Abrió">{{ c.usuario_apertura?.nombre ?? '—' }}</td>
                        <td data-label="Apertura">{{ c.abierta_at | date:'dd/MM/yyyy HH:mm' }}</td>
                        <td data-label="Cerró">{{ c.cerrada_por_nombre ?? c.usuario_cierre?.nombre ?? '—' }}</td>
                        <td data-label="Cierre">{{ c.cerrada_at ? (c.cerrada_at | date:'dd/MM/yyyy HH:mm') : '—' }}</td>
                        <td data-label="Estado">
                          <span class="badge" [class.badge-ok]="c.estado === 'abierta'" [class.badge-off]="c.estado === 'cerrada'">
                            {{ c.estado === 'abierta' ? 'Abierta' : 'Cerrada' }}
                          </span>
                        </td>
                        <td data-label="Diferencia">
                          @if (c.diferencia !== undefined && c.diferencia !== null) {
                            <span [class.form-error]="c.diferencia != 0" [class.form-ok]="c.diferencia == 0">
                              Bs {{ c.diferencia | number:'1.2-2' }}
                            </span>
                          } @else { <span>—</span> }
                        </td>
                        <td data-label="Acciones">
                          @if (c.estado === 'cerrada') {
                            <button class="link-action" (click)="toggleDetalle(c.id)">
                              {{ detalleAbierto() === c.id ? 'Ocultar' : 'Detalle' }}
                            </button>
                            <button class="link-action" (click)="descargarArqueo(c)">Arqueo PDF</button>
                          }
                        </td>
                      </tr>
                      @if (detalleAbierto() === c.id) {
                        <tr>
                          <td colspan="9">
                            <p style="margin:6px 0">
                              <strong>Cerrada por:</strong> {{ c.cerrada_por_nombre ?? c.usuario_cierre?.nombre ?? '—' }}
                              · <strong>Ventas:</strong> {{ c.cantidad_ventas ?? 0 }}
                              · <strong>Efectivo:</strong> Bs {{ c.monto_ventas_efectivo ?? 0 | number:'1.2-2' }}
                              · <strong>QR:</strong> Bs {{ c.monto_ventas_qr ?? 0 | number:'1.2-2' }}
                              · <strong>Tarjeta:</strong> Bs {{ c.monto_ventas_tarjeta ?? 0 | number:'1.2-2' }}
                              · <strong>Anuladas:</strong> {{ c.cantidad_anuladas ?? 0 }} (Bs {{ c.monto_anulado ?? 0 | number:'1.2-2' }})
                            </p>
                            @if (c.observaciones) {
                              <p style="margin:4px 0"><strong>Obs. apertura:</strong> {{ c.observaciones }}</p>
                            }
                            @if (c.observaciones_cierre) {
                              <p style="margin:4px 0"><strong>Obs. cierre:</strong> {{ c.observaciones_cierre }}</p>
                            }
                            @if (c.detalle_vendedores?.length) {
                              <table style="margin-top:8px">
                                <thead>
                                  <tr><th>Vendedor</th><th>Ventas</th><th>Efectivo</th><th>QR</th><th>Tarjeta</th><th>Total</th></tr>
                                </thead>
                                <tbody>
                                  @for (v of (c.detalle_vendedores ?? []); track $index) {
                                    <tr>
                                      <td data-label="Vendedor">{{ v.nombre }}</td>
                                      <td data-label="Ventas">{{ v.cantidad }}</td>
                                      <td data-label="Efectivo">Bs {{ v.efectivo | number:'1.2-2' }}</td>
                                      <td data-label="QR">Bs {{ v.qr | number:'1.2-2' }}</td>
                                      <td data-label="Tarjeta">Bs {{ v.tarjeta | number:'1.2-2' }}</td>
                                      <td data-label="Total">Bs {{ v.total | number:'1.2-2' }}</td>
                                    </tr>
                                  }
                                </tbody>
                              </table>
                            }
                          </td>
                        </tr>
                      }
                    }
                  </tbody>
                </table>
              }
            }
          </section>
        }
      } @else if (tab() === 'reporte-caja') {
        <!-- ===================== REPORTE DE CAJA (cajero) ===================== -->
        <app-reporte-cajero [esAdmin]="esAdmin()" />
      } @else if (tab() === 'reporte-chica') {
        <!-- ===================== REPORTE DE CAJA CHICA ===================== -->
        <app-reporte-caja-chica [esAdmin]="esAdmin()" />
      } @else {
        <!-- ===================== CAJA CHICA ===================== -->
        @if (!cajaActual()) {
          <div class="panel"><p class="form-error" style="margin:0">Todavía no abriste la caja. Ve a la pestaña "Turno de caja" para abrirla antes de registrar movimientos.</p></div>
        }

        <section class="panel cc-cabecera">
          <div class="cc-titulo">
            <h2 class="panel-title" style="margin:0">Registro de ingresos y egresos</h2>
            <p class="subtitle" style="margin:2px 0 0">Movimientos manuales de caja chica: gastos e ingresos que no vienen de ventas ni compras.</p>
          </div>
          <div class="cc-acciones-rapidas">
            <button type="button" class="btn-chip" (click)="irAArqueo()">Arqueo de caja</button>
            <button type="button" class="btn-chip" [class.activo]="filtroMetodoPago === 'cheque'" (click)="verCheques()">Ver cheques</button>
            <button type="button" class="btn-chip" (click)="irAApertura()">Apertura caja</button>
            <a routerLink="/pedidos" class="btn-chip">Cobrar ticket</a>
          </div>
        </section>

        @if (resumen()) {
          <div class="resumen-grid">
            <div class="card-plain">
              <span class="resumen-label">Ingresos del turno</span>
              <span class="resumen-valor">Bs {{ resumen()!.ingresos | number:'1.2-2' }}</span>
            </div>
            <div class="card-plain">
              <span class="resumen-label">Egresos del turno</span>
              <span class="resumen-valor">Bs {{ resumen()!.egresos | number:'1.2-2' }}</span>
            </div>
            <div class="card-plain destacado">
              <span class="resumen-label">Saldo neto</span>
              <span class="resumen-valor">Bs {{ resumen()!.saldo | number:'1.2-2' }}</span>
            </div>
          </div>
        }

        @if (formAbierto()) {
          <section class="composer open">
            <p class="panel-title" style="margin:0 0 14px; font-size:16px">{{ editandoId() ? 'Editar movimiento' : 'Nuevo movimiento' }}</p>
            <form class="composer-form" style="margin-top:0" (ngSubmit)="guardarMovimiento()">
              <div class="form-grid">
                <div class="field">
                  <label>Cuenta</label>
                  <select [(ngModel)]="cuenta" name="cuenta" required>
                    @for (c of cuentas; track c) { <option [value]="c">{{ c }}</option> }
                  </select>
                </div>
                <div class="field">
                  <label>Tipo</label>
                  <select [(ngModel)]="mTipo" name="mTipo" required>
                    <option value="ingreso">Ingreso</option>
                    <option value="egreso">Egreso</option>
                  </select>
                </div>
                <div class="field">
                  <label>Método de pago</label>
                  <select [(ngModel)]="metodoPago" name="metodoPago" required>
                    <option value="efectivo">Efectivo</option>
                    <option value="cheque">Cheque</option>
                  </select>
                </div>
                <div class="field">
                  <label>Nro. documento <span>(opcional)</span></label>
                  <input type="text" [(ngModel)]="nroDocumento" name="nroDocumento" />
                </div>
                <div class="field" style="grid-column: 1 / -1">
                  <label>Concepto</label>
                  <input type="text" [(ngModel)]="concepto" name="concepto" required placeholder="Motivo del ingreso o egreso" />
                </div>
                <div class="field">
                  <label>Monto (Bs)</label>
                  <input type="number" min="0.01" step="0.01" [(ngModel)]="monto" name="monto" required />
                </div>
              </div>

              <div class="field-row" style="margin-top:14px">
                <button type="submit" class="btn-primary" [disabled]="guardandoMov() || !concepto.trim() || monto === ''">
                  {{ guardandoMov() ? 'Guardando…' : (editandoId() ? 'Guardar cambios' : 'Registrar movimiento') }}
                </button>
                <button type="button" class="btn-secondary" (click)="cancelarEdicion()">Cancelar</button>
                @if (errorMov()) { <span class="form-error">{{ errorMov() }}</span> }
              </div>
            </form>
          </section>
        }

        @if (filtrosVisibles()) {
          <section class="panel">
            <div class="filtros-row">
              <div class="field">
                <label>Desde</label>
                <input type="date" [(ngModel)]="filtroFechaDesde" name="filtroFechaDesde" (ngModelChange)="cargarMovimientos()" />
              </div>
              <div class="field">
                <label>Hasta</label>
                <input type="date" [(ngModel)]="filtroFechaHasta" name="filtroFechaHasta" (ngModelChange)="cargarMovimientos()" />
              </div>
              <div class="field">
                <label>Cuenta (detalle)</label>
                <select [(ngModel)]="filtroCuenta" name="filtroCuenta" (ngModelChange)="cargarMovimientos()">
                  <option value="">Todas</option>
                  @for (c of cuentas; track c) { <option [value]="c">{{ c }}</option> }
                </select>
              </div>
              <div class="field">
                <label>Tipo</label>
                <select [(ngModel)]="filtroTipo" name="filtroTipo" (ngModelChange)="cargarMovimientos()">
                  <option value="">Todos</option>
                  <option value="ingreso">Ingresos</option>
                  <option value="egreso">Egresos</option>
                </select>
              </div>
              <div class="field">
                <label>Método de pago</label>
                <select [(ngModel)]="filtroMetodoPago" name="filtroMetodoPago" (ngModelChange)="cargarMovimientos()">
                  <option value="">Todos</option>
                  <option value="efectivo">Efectivo</option>
                  <option value="cheque">Cheques</option>
                </select>
              </div>
            </div>
          </section>
        }

        <section class="panel cc-grid" id="cc-tabla-imprimible">
          @if (cargandoMovimientos()) {
            <div class="estado-vacio"><div class="spinner"></div><p>Cargando movimientos…</p></div>
          } @else if (movimientosFiltrados().length === 0) {
            <div class="estado-vacio"><p>No hay movimientos de caja chica con estos filtros.</p></div>
          } @else {
            <table>
              <thead>
                <tr>
                  <th>ID</th><th>Alm.</th><th>Usuario</th><th>Fecha</th><th>Hora</th>
                  <th>Cuenta</th><th>Nro. Doc.</th><th>Concepto</th><th>Entrada</th><th>Salida</th>
                </tr>
              </thead>
              <tbody>
                @for (m of movimientosPagina(); track m.id) {
                  <tr [class.fila-seleccionada]="seleccionadoId() === m.id" (click)="seleccionar(m)">
                    <td data-label="ID">#{{ m.id }}</td>
                    <td data-label="Alm.">{{ m.almacen?.nombre ?? '—' }}</td>
                    <td data-label="Usuario">{{ m.usuario?.nombre }}</td>
                    <td data-label="Fecha">{{ m.created_at | date:'dd/MM/yyyy' }}</td>
                    <td data-label="Hora">{{ m.created_at | date:'HH:mm' }}</td>
                    <td data-label="Cuenta">{{ m.cuenta }}</td>
                    <td data-label="Nro. Doc.">{{ m.nro_documento || '—' }}</td>
                    <td data-label="Concepto">{{ m.concepto }}</td>
                    <td data-label="Entrada">{{ m.tipo === 'ingreso' ? ('Bs ' + (m.monto | number:'1.2-2')) : '—' }}</td>
                    <td data-label="Salida">{{ m.tipo === 'egreso' ? ('Bs ' + (m.monto | number:'1.2-2')) : '—' }}</td>
                  </tr>
                }
              </tbody>
            </table>
          }
        </section>

        <section class="panel cc-toolbar">
          <div class="cc-toolbar-fila">
            <span class="cc-toolbar-label">Mantenimiento</span>
            <button type="button" class="btn-secondary" [disabled]="!cajaActual()" (click)="adicionar()">+ Adicionar</button>
            <button type="button" class="btn-secondary" [disabled]="!puedeEditarSeleccionado()" (click)="editarSeleccionado()">Editar</button>
            <button type="button" class="btn-secondary" [disabled]="!puedeEliminarSeleccionado()" (click)="eliminarSeleccionado()">Eliminar</button>
            <button type="button" class="btn-secondary" (click)="actualizar()">Actualizar</button>
            <button type="button" class="btn-secondary" (click)="imprimir()">Imprimir</button>
          </div>

          <div class="cc-toolbar-fila">
            <span class="cc-toolbar-label">Búsqueda</span>
            <input type="text" class="cc-buscar" placeholder="Buscar por concepto, nro. doc. o usuario…" [(ngModel)]="busqueda" name="busqueda" (ngModelChange)="paginaActual.set(1)" />
            <button type="button" class="btn-secondary" [class.activo]="filtrosVisibles()" (click)="toggleFiltros()">Filtrar</button>
            <select class="cc-orden-campo" [(ngModel)]="ordenCampo" name="ordenCampo">
              <option value="fecha">Ordenar por fecha</option>
              <option value="monto">Ordenar por monto</option>
              <option value="concepto">Ordenar por concepto</option>
            </select>
            <button type="button" class="btn-secondary" (click)="alternarOrden()">{{ ordenDir() === 'asc' ? '↑ Ascendente' : '↓ Descendente' }}</button>
          </div>

          <div class="cc-toolbar-fila cc-toolbar-fila--nav">
            <div class="cc-paginacion">
              <button type="button" class="btn-secondary" [disabled]="paginaActual() <= 1" (click)="paginaAnterior()">‹</button>
              <span class="cc-pagina-actual">Página {{ paginaActual() }} de {{ totalPaginas() }}</span>
              <button type="button" class="btn-secondary" [disabled]="paginaActual() >= totalPaginas()" (click)="paginaSiguiente()">›</button>
            </div>
            <div class="field cc-almacen">
              <label>Almacén activo</label>
              <select [(ngModel)]="filtroAlmacenId" name="filtroAlmacenId" (ngModelChange)="cargarMovimientos()">
                <option [ngValue]="''">GENERAL (todos)</option>
                @for (a of almacenes(); track a.id) { <option [ngValue]="a.id">{{ a.nombre }}</option> }
              </select>
            </div>
            <button type="button" class="btn-primary" [disabled]="!seleccionadoId()" (click)="verReciboSeleccionado()">Ver recibo de caja chica</button>
          </div>
          @if (errorMov()) { <p class="form-error" style="margin:10px 0 0">{{ errorMov() }}</p> }
        </section>
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .tabs { display: flex; gap: 6px; margin-bottom: 22px; background: rgba(8,18,36,0.35); border-radius: 10px; padding: 4px; max-width: 760px; flex-wrap: wrap; }
    .tabs button {
      flex: 1; border: none; background: transparent; padding: 10px 12px; border-radius: 8px;
      font-family: inherit; font-weight: 700; font-size: 13px; color: #a9c4de; cursor: pointer;
    }
    .tabs button.activo { background: var(--papel); color: var(--tinta); }

    .resumen-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 14px; margin-bottom: 22px; }
    .resumen-label { display: block; font-size: 12px; color: #6b5f45; font-weight: 600; margin-bottom: 6px; }
    .resumen-valor { display: block; font-size: 20px; font-weight: 800; color: var(--tinta); }
    .card-plain.destacado { border-color: var(--cobre); background: linear-gradient(120deg, rgba(0,85,160,0.08), var(--papel)); }

    .composer { background: var(--verde-botella); border: 1px solid #2c4536; border-radius: 14px; padding: 16px 20px; margin-bottom: 22px; }
    .composer-toggle { background: none; border: none; color: var(--cobre-claro); font-size: 15px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 10px; padding: 4px 0; }
    .composer-toggle:disabled { opacity: 0.5; cursor: not-allowed; }
    .plus { display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; border-radius: 50%; border: 1.5px solid var(--cobre-claro); font-size: 16px; line-height: 1; transition: transform 0.25s ease; }
    .plus.rotated { transform: rotate(45deg); }
    .composer-form { margin-top: 18px; }

    .filtros-row { display: flex; gap: 14px; flex-wrap: wrap; align-items: end; }
    .filtros-row .field { min-width: 160px; flex: 1; }

    /* --- Caja chica: cabecera con acciones rápidas --- */
    .cc-cabecera { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; flex-wrap: wrap; }
    .cc-acciones-rapidas { display: flex; gap: 8px; flex-wrap: wrap; }
    .btn-chip {
      display: inline-flex; align-items: center; justify-content: center; height: 34px; padding: 0 14px;
      border-radius: var(--radio-pill, 999px); font-size: 12.5px; font-weight: 700; white-space: nowrap;
      background: rgba(140, 193, 233, 0.1); color: var(--azul-claro); border: 1px solid rgba(140, 193, 233, 0.5);
      cursor: pointer; text-decoration: none; transition: background 0.15s ease, border-color 0.15s ease;
    }
    .btn-chip:hover { background: rgba(140, 193, 233, 0.2); border-color: var(--azul-claro); }
    .btn-chip.activo { background: var(--cobre); color: #fff; border-color: var(--cobre); }

    /* --- Grilla de movimientos: filas seleccionables como en un grid de escritorio --- */
    .cc-grid table tbody tr { cursor: pointer; }
    .cc-grid table tbody tr.fila-seleccionada { background: rgba(0, 85, 160, 0.22); }
    .cc-grid table tbody tr.fila-seleccionada td { color: #fff; }

    /* --- Barras inferiores: mantenimiento / búsqueda / navegación --- */
    .cc-toolbar { display: flex; flex-direction: column; gap: 14px; }
    .cc-toolbar-fila { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .cc-toolbar-fila--nav { justify-content: space-between; border-top: 1px solid rgba(140,193,233,0.2); padding-top: 14px; }
    .cc-toolbar-label { font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--azul-claro); min-width: 92px; }
    .cc-toolbar .btn-secondary.activo { background: rgba(140, 193, 233, 0.22); border-color: var(--azul-claro); }
    .cc-buscar {
      flex: 1; min-width: 220px; height: var(--alto-control); background: var(--papel); border: 1.5px solid var(--papel-borde);
      border-radius: var(--radio-md, 12px); padding: 0 var(--s-3, 12px); font-size: 14px; font-family: inherit; color: var(--tinta);
    }
    .cc-orden-campo {
      height: var(--alto-control); background: var(--papel); border: 1.5px solid var(--papel-borde);
      border-radius: var(--radio-md, 12px); padding: 0 var(--s-3, 12px); font-size: 13px; font-family: inherit; color: var(--tinta);
    }
    .cc-paginacion { display: flex; align-items: center; gap: 10px; }
    .cc-paginacion .btn-secondary { width: 38px; padding: 0; font-size: 16px; }
    .cc-pagina-actual { font-size: 13px; color: #cfe3f5; font-weight: 600; white-space: nowrap; }
    .cc-almacen { min-width: 200px; }

    @media print {
      .page-header, .tabs, .cc-cabecera, .resumen-grid, .composer, .cc-toolbar, .panel:not(.cc-grid) { display: none !important; }
    }
  `],
})
export class CajaComponent implements OnInit {
  private cajaService = inject(CajaService);
  private cajaChicaService = inject(CajaChicaService);
  private almacenService = inject(AlmacenService);
  private confirmDialog = inject(ConfirmDialogService);
  private auth = inject(AuthService);

  cuentas = CUENTAS_CAJA_CHICA;

  tab = signal<'turno' | 'caja-chica' | 'reporte-caja' | 'reporte-chica'>('turno');

  // --- Turno ---
  cajaActual = signal<Caja | null>(null);
  totales = signal<TotalesCajaActual | null>(null);
  misVentas = signal<MisVentasCajaActual | null>(null);
  cargandoCaja = signal(true);
  errorTurno = signal('');

  montoApertura: number | '' = '';
  observacionesApertura = '';
  abriendo = signal(false);

  mostrarFormCierre = signal(false);
  montoCierreReal: number | '' = '';
  observacionesCierre = '';
  cerrando = signal(false);

  historialAbierto = signal(false);
  detalleAbierto = signal<number | null>(null);
  cargandoHistorial = signal(false);
  historial = signal<Caja[]>([]);

  // --- Caja chica ---
  resumen = signal<ResumenCajaChica | null>(null);
  movimientos = signal<MovimientoCajaChica[]>([]);
  cargandoMovimientos = signal(true);
  almacenes = signal<Almacen[]>([]);

  filtroTipo = '';
  filtroMetodoPago = '';
  filtroCuenta = '';
  filtroFechaDesde = '';
  filtroFechaHasta = '';
  filtroAlmacenId: number | '' = '';
  filtrosVisibles = signal(false);

  // Búsqueda, orden y paginación son del lado del cliente: la lista ya
  // llega filtrada por fecha/cuenta/tipo/pago/almacén desde el backend.
  busqueda = '';
  ordenCampo: 'fecha' | 'monto' | 'concepto' = 'fecha';
  ordenDir = signal<'asc' | 'desc'>('desc');
  paginaActual = signal(1);
  porPagina = 12;
  seleccionadoId = signal<number | null>(null);

  movimientosFiltrados = computed(() => {
    const texto = this.busqueda.trim().toLowerCase();
    let lista = this.movimientos();
    if (texto) {
      lista = lista.filter((m) =>
        m.concepto.toLowerCase().includes(texto)
        || (m.nro_documento ?? '').toLowerCase().includes(texto)
        || (m.usuario?.nombre ?? '').toLowerCase().includes(texto));
    }
    const campo = this.ordenCampo;
    const dir = this.ordenDir() === 'asc' ? 1 : -1;
    return [...lista].sort((a, b) => {
      if (campo === 'monto') return (a.monto - b.monto) * dir;
      if (campo === 'concepto') return a.concepto.localeCompare(b.concepto) * dir;
      return (new Date(a.created_at ?? 0).getTime() - new Date(b.created_at ?? 0).getTime()) * dir;
    });
  });

  totalPaginas = computed(() => Math.max(1, Math.ceil(this.movimientosFiltrados().length / this.porPagina)));

  movimientosPagina = computed(() => {
    const pagina = Math.min(this.paginaActual(), this.totalPaginas());
    const inicio = (pagina - 1) * this.porPagina;
    return this.movimientosFiltrados().slice(inicio, inicio + this.porPagina);
  });

  seleccionado = computed(() => this.movimientos().find((m) => m.id === this.seleccionadoId()) ?? null);

  formAbierto = signal(false);
  editandoId = signal<number | null>(null);
  guardandoMov = signal(false);
  errorMov = signal('');

  cuenta: string = this.cuentas[0];
  mTipo: 'ingreso' | 'egreso' = 'ingreso';
  metodoPago: 'efectivo' | 'cheque' = 'efectivo';
  nroDocumento = '';
  concepto = '';
  monto: number | '' = '';

  esAdmin(): boolean { return this.auth.usuarioActual()?.rol === 'administrador'; }
  esPropio(m: MovimientoCajaChica): boolean { return m.usuario_id === this.auth.usuarioActual()?.id; }

  ngOnInit(): void {
    this.cargarCajaActual();
    this.almacenService.listar().subscribe({ next: (data) => this.almacenes.set(data), error: () => {} });
  }

  // ---------- Turno ----------
  cargarCajaActual(): void {
    this.cargandoCaja.set(true);
    this.cajaService.actual().subscribe({
      next: (res) => {
        this.cajaActual.set(res.caja);
        this.totales.set(res.totales ?? null);
        this.misVentas.set(res.mis_ventas ?? null);
        this.cargandoCaja.set(false);
      },
      error: () => {
        this.errorTurno.set('No se pudo consultar el estado de la caja.');
        this.cargandoCaja.set(false);
      },
    });
  }

  abrirCaja(): void {
    if (this.montoApertura === '') return;
    this.abriendo.set(true);
    this.errorTurno.set('');

    this.cajaService.abrir({
      monto_apertura: Number(this.montoApertura),
      observaciones: this.observacionesApertura.trim() || undefined,
    }).subscribe({
      next: () => {
        this.montoApertura = '';
        this.observacionesApertura = '';
        this.abriendo.set(false);
        this.cargarCajaActual();
      },
      error: (err) => {
        this.errorTurno.set(err?.error?.message || 'No se pudo abrir la caja.');
        this.abriendo.set(false);
      },
    });
  }

  cerrarCaja(): void {
    const caja = this.cajaActual();
    if (!caja || this.montoCierreReal === '') return;
    this.cerrando.set(true);
    this.errorTurno.set('');

    this.cajaService.cerrar(caja.id, {
      monto_cierre_real: Number(this.montoCierreReal),
      observaciones: this.observacionesCierre.trim() || undefined,
    }).subscribe({
      next: () => {
        this.montoCierreReal = '';
        this.observacionesCierre = '';
        this.mostrarFormCierre.set(false);
        this.cerrando.set(false);
        this.cargarCajaActual();
        if (this.historialAbierto()) this.cargarHistorial();
      },
      error: (err) => {
        this.errorTurno.set(err?.error?.message || 'No se pudo cerrar la caja.');
        this.cerrando.set(false);
      },
    });
  }

  toggleDetalle(id: number): void {
    this.detalleAbierto.set(this.detalleAbierto() === id ? null : id);
  }

  toggleHistorial(): void {
    this.historialAbierto.set(!this.historialAbierto());
    if (this.historialAbierto() && this.historial().length === 0) this.cargarHistorial();
  }

  cargarHistorial(): void {
    this.cargandoHistorial.set(true);
    this.cajaService.historial().subscribe({
      next: (data) => { this.historial.set(data); this.cargandoHistorial.set(false); },
      error: () => this.cargandoHistorial.set(false),
    });
  }

  async descargarArqueo(c: Caja): Promise<void> {
    try { await this.cajaService.descargarArqueoPdf(c.id); } catch { /* silencioso: falla de descarga puntual */ }
  }

  // ---------- Caja chica ----------
  cambiarACajaChica(): void {
    this.tab.set('caja-chica');
    this.cargarResumenCajaChica();
    this.cargarMovimientos();
  }

  cargarResumenCajaChica(): void {
    this.cajaChicaService.resumen().subscribe({ next: (r) => this.resumen.set(r), error: () => {} });
  }

  cargarMovimientos(): void {
    this.cargandoMovimientos.set(true);
    this.cajaChicaService.listar({
      tipo: this.filtroTipo || undefined,
      metodo_pago: this.filtroMetodoPago || undefined,
      cuenta: this.filtroCuenta || undefined,
      fecha_desde: this.filtroFechaDesde || undefined,
      fecha_hasta: this.filtroFechaHasta || undefined,
      almacen_id: this.filtroAlmacenId || undefined,
    }).subscribe({
      next: (data) => {
        this.movimientos.set(data);
        this.cargandoMovimientos.set(false);
        this.paginaActual.set(1);
        if (!data.some((m) => m.id === this.seleccionadoId())) this.seleccionadoId.set(null);
      },
      error: () => this.cargandoMovimientos.set(false),
    });
  }

  // ---------- Botones de operación rápida ----------
  irAArqueo(): void {
    this.tab.set('turno');
    if (this.cajaActual()) this.mostrarFormCierre.set(true);
  }

  irAApertura(): void {
    this.tab.set('turno');
    this.mostrarFormCierre.set(false);
  }

  verCheques(): void {
    this.filtroMetodoPago = this.filtroMetodoPago === 'cheque' ? '' : 'cheque';
    this.filtrosVisibles.set(true);
    this.cargarMovimientos();
  }

  toggleFiltros(): void {
    this.filtrosVisibles.set(!this.filtrosVisibles());
  }

  // ---------- Selección de fila (grilla estilo escritorio) ----------
  seleccionar(m: MovimientoCajaChica): void {
    this.seleccionadoId.set(this.seleccionadoId() === m.id ? null : m.id);
  }

  puedeEditarSeleccionado(): boolean {
    const m = this.seleccionado();
    return !!m && m.caja?.estado === 'abierta' && (this.esAdmin() || this.esPropio(m));
  }

  puedeEliminarSeleccionado(): boolean {
    const m = this.seleccionado();
    return !!m && m.caja?.estado === 'abierta' && this.esAdmin();
  }

  editarSeleccionado(): void {
    const m = this.seleccionado();
    if (m && this.puedeEditarSeleccionado()) this.editarMovimiento(m);
  }

  async eliminarSeleccionado(): Promise<void> {
    const m = this.seleccionado();
    if (m && this.puedeEliminarSeleccionado()) await this.eliminarMovimiento(m);
  }

  async verReciboSeleccionado(): Promise<void> {
    const m = this.seleccionado();
    if (m) await this.descargarRecibo(m);
  }

  actualizar(): void {
    this.cargarMovimientos();
    this.cargarResumenCajaChica();
  }

  imprimir(): void {
    window.print();
  }

  // ---------- Búsqueda, orden y paginación ----------
  alternarOrden(): void {
    this.ordenDir.set(this.ordenDir() === 'asc' ? 'desc' : 'asc');
  }

  paginaAnterior(): void {
    if (this.paginaActual() > 1) this.paginaActual.set(this.paginaActual() - 1);
  }

  paginaSiguiente(): void {
    if (this.paginaActual() < this.totalPaginas()) this.paginaActual.set(this.paginaActual() + 1);
  }

  adicionar(): void {
    if (!this.cajaActual()) return;
    this.editandoId.set(null);
    this.limpiarFormMov();
    this.formAbierto.set(true);
    this.errorMov.set('');
  }

  private limpiarFormMov(): void {
    this.cuenta = this.cuentas[0];
    this.mTipo = 'ingreso';
    this.metodoPago = 'efectivo';
    this.nroDocumento = '';
    this.concepto = '';
    this.monto = '';
  }

  editarMovimiento(m: MovimientoCajaChica): void {
    this.editandoId.set(m.id);
    this.cuenta = m.cuenta;
    this.mTipo = m.tipo;
    this.metodoPago = m.metodo_pago;
    this.nroDocumento = m.nro_documento ?? '';
    this.concepto = m.concepto;
    this.monto = m.monto;
    this.formAbierto.set(true);
    this.errorMov.set('');
  }

  cancelarEdicion(): void {
    this.editandoId.set(null);
    this.limpiarFormMov();
    this.formAbierto.set(false);
    this.errorMov.set('');
  }

  guardarMovimiento(): void {
    if (!this.concepto.trim() || this.monto === '') return;
    this.guardandoMov.set(true);
    this.errorMov.set('');

    const payload = {
      cuenta: this.cuenta,
      tipo: this.mTipo,
      metodo_pago: this.metodoPago,
      nro_documento: this.nroDocumento.trim() || undefined,
      concepto: this.concepto.trim(),
      monto: Number(this.monto),
    };

    const id = this.editandoId();
    const peticion = id ? this.cajaChicaService.actualizar(id, payload) : this.cajaChicaService.crear(payload);

    peticion.subscribe({
      next: () => {
        this.limpiarFormMov();
        this.editandoId.set(null);
        this.guardandoMov.set(false);
        this.formAbierto.set(false);
        this.cargarMovimientos();
        this.cargarResumenCajaChica();
        this.cargarCajaActual();
      },
      error: (err) => {
        this.errorMov.set(err?.error?.message || 'No se pudo guardar el movimiento.');
        this.guardandoMov.set(false);
      },
    });
  }

  async eliminarMovimiento(m: MovimientoCajaChica): Promise<void> {
    const ok = await this.confirmDialog.confirm({
      titulo: 'Eliminar movimiento',
      mensaje: `¿Eliminar el movimiento "${m.concepto}" por Bs ${m.monto}?`,
      textoConfirmar: 'Sí, eliminar',
      peligroso: true,
    });
    if (!ok) return;

    this.cajaChicaService.eliminar(m.id).subscribe({
      next: () => {
        this.movimientos.set(this.movimientos().filter((x) => x.id !== m.id));
        this.cargarResumenCajaChica();
        this.cargarCajaActual();
      },
      error: () => {},
    });
  }

  async descargarRecibo(m: MovimientoCajaChica): Promise<void> {
    try { await this.cajaChicaService.descargarReciboPdf(m.id); } catch { /* silencioso: falla de descarga puntual */ }
  }
}
