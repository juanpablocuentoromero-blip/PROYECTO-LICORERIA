import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UsuarioService } from '../../core/services/usuario.service';
import { Usuario } from '../../core/models/usuario.model';
import { AuthService } from '../../core/services/auth.service';
import { BASE_THEME } from '../../shared/theme/theme';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';

@Component({
  selector: 'app-usuarios',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Administración &middot; Personal</div>
          <h1>Usuarios</h1>
          <p class="subtitle">Cuentas del personal que opera el sistema (roles y accesos).</p>
        </div>
      </header>

      @if (!esAdmin()) {
        <div class="panel"><p class="form-error" style="margin:0">Solo un usuario con rol "administrador" puede gestionar usuarios.</p></div>
      }

      <section class="panel" [class.disabled]="!esAdmin()">
        <button class="btn-secondary" [disabled]="!esAdmin()" (click)="toggleForm()">
          {{ formAbierto() ? 'Cerrar formulario' : (editandoId() ? 'Editar usuario' : '+ Nuevo usuario') }}
        </button>

        @if (formAbierto()) {
          <form class="form-grid" style="margin-top:16px" (ngSubmit)="guardar()">
            <div class="field">
              <label>Nombre</label>
              <input type="text" [(ngModel)]="form.nombre" name="nombre" required />
            </div>
            <div class="field">
              <label>Email</label>
              <input type="email" [(ngModel)]="form.email" name="email" required />
            </div>
            <div class="field">
              <label>Contraseña <span>{{ editandoId() ? '(dejar vacío para no cambiar)' : '' }}</span></label>
              <input type="password" [(ngModel)]="form.password" name="password" [required]="!editandoId()" />
            </div>
            <div class="field">
              <label>Rol</label>
              <select [(ngModel)]="form.rol" name="rol">
                <option value="vendedor">Vendedor</option>
                <option value="administrador">Administrador</option>
              </select>
            </div>
            <div class="field-row" style="grid-column: 1/-1">
              <button type="submit" class="btn-primary" [disabled]="guardando()">
                {{ guardando() ? 'Guardando…' : (editandoId() ? 'Actualizar' : 'Guardar usuario') }}
              </button>
              @if (error()) { <span class="form-error">{{ error() }}</span> }
            </div>
          </form>
        }
      </section>

      @if (cargando()) {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando usuarios…</p></div>
      } @else {
        <table>
          <thead><tr><th>Nombre</th><th>Email</th><th>Rol</th><th>Estado</th><th></th></tr></thead>
          <tbody>
            @for (u of usuarios(); track u.id) {
              <tr>
                <td data-label="Nombre">{{ u.nombre }}</td>
                <td data-label="Email">{{ u.email }}</td>
                <td data-label="Rol"><span class="badge badge-info">{{ u.rol }}</span></td>
                <td data-label="Estado"><span class="badge" [class.badge-ok]="u.activo" [class.badge-off]="!u.activo">{{ u.activo ? 'Activo' : 'Inactivo' }}</span></td>
                <td data-label="Acciones">
                  <button class="link-action" [disabled]="!esAdmin()" (click)="editar(u)">Editar</button>
                  <button class="link-danger" [disabled]="!esAdmin()" (click)="eliminar(u)">Eliminar</button>
                </td>
              </tr>
            }
          </tbody>
        </table>
      }
    </div>
  `,
  styles: [BASE_THEME, `.disabled { opacity: 0.6; }`],
})
export class UsuariosComponent implements OnInit {
  private service = inject(UsuarioService);
  private confirmDialog = inject(ConfirmDialogService);
  private auth = inject(AuthService);

  usuarios = signal<Usuario[]>([]);
  cargando = signal(true);
  guardando = signal(false);
  formAbierto = signal(false);
  editandoId = signal<number | null>(null);
  error = signal('');

  form = { nombre: '', email: '', password: '', rol: 'vendedor' };

  esAdmin(): boolean { return this.auth.usuarioActual()?.rol === 'administrador'; }

  ngOnInit(): void { this.cargar(); }

  cargar(): void {
    this.cargando.set(true);
    this.service.listar().subscribe({
      next: (data) => { this.usuarios.set(data); this.cargando.set(false); },
      error: () => { this.error.set('No se pudo conectar con el servidor.'); this.cargando.set(false); },
    });
  }

  toggleForm(): void {
    this.formAbierto.set(!this.formAbierto());
    this.editandoId.set(null);
    this.resetForm();
  }

  editar(u: Usuario): void {
    this.editandoId.set(u.id);
    this.form = { nombre: u.nombre, email: u.email, password: '', rol: u.rol };
    this.formAbierto.set(true);
  }

  resetForm(): void { this.form = { nombre: '', email: '', password: '', rol: 'vendedor' }; }

  guardar(): void {
    if (!this.form.nombre.trim() || !this.form.email.trim()) return;
    this.guardando.set(true);
    this.error.set('');

    const payload: any = { nombre: this.form.nombre.trim(), email: this.form.email.trim(), rol: this.form.rol };
    if (this.form.password) payload.password = this.form.password;

    const id = this.editandoId();
    const req = id ? this.service.actualizar(id, payload) : this.service.crear(payload);

    req.subscribe({
      next: (res) => {
        if (id) this.usuarios.set(this.usuarios().map((u) => (u.id === id ? res : u)));
        else this.usuarios.set([res, ...this.usuarios()]);
        this.guardando.set(false);
        this.formAbierto.set(false);
        this.editandoId.set(null);
        this.resetForm();
      },
      error: (err) => {
        this.error.set(err?.error?.message || 'No se pudo guardar. Revisa los datos.');
        this.guardando.set(false);
      },
    });
  }

  async eliminar(u: Usuario): Promise<void> {
    const ok = await this.confirmDialog.confirm({
      titulo: 'Eliminar usuario',
      mensaje: `¿Estás seguro de que quieres eliminar al usuario "${u.nombre}"? Perderá acceso al sistema de inmediato.`,
      textoConfirmar: 'Sí, eliminar',
      peligroso: true,
    });
    if (!ok) return;

    this.service.eliminar(u.id).subscribe({
      next: () => this.usuarios.set(this.usuarios().filter((x) => x.id !== u.id)),
      error: () => this.error.set('No se pudo eliminar el usuario.'),
    });
  }
}
