import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { PasswordRecuperacionService, TipoCuenta } from '../../core/services/password-recuperacion.service';

@Component({
  selector: 'app-restablecer-password',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="wrap">
      <div class="card">
        <div class="brand">
          <img src="brand/logo-al-paso.png" alt="Licorería Al Paso" height="46" />
        </div>

        @if (!tokenValido()) {
          <p class="subtitle error">
            Este enlace no es válido o está incompleto. Solicita uno nuevo desde la pantalla de inicio de sesión.
          </p>
          <p class="volver-hint"><a routerLink="/acceso">← Volver a iniciar sesión</a></p>
        } @else if (exito()) {
          <p class="subtitle exito">Tu contraseña fue actualizada. Ya puedes iniciar sesión con ella.</p>
          <p class="volver-hint">
            @if (tipo === 'usuario') {
              <a routerLink="/login">Ir a iniciar sesión →</a>
            } @else {
              <a routerLink="/acceso">Ir a iniciar sesión →</a>
            }
          </p>
        } @else {
          <p class="subtitle">Escribe tu nueva contraseña para {{ email }}.</p>

          <form (ngSubmit)="restablecer()">
            <div class="field">
              <label for="password">Nueva contraseña</label>
              <div class="password-input">
                <input
                  id="password"
                  [type]="mostrarPassword() ? 'text' : 'password'"
                  [(ngModel)]="password"
                  name="password"
                  required
                  minlength="6"
                  autocomplete="new-password"
                />
                <button type="button" class="toggle-password" (click)="mostrarPassword.set(!mostrarPassword())"
                  [attr.aria-label]="mostrarPassword() ? 'Ocultar contraseña' : 'Mostrar contraseña'" tabindex="-1">
                  @if (mostrarPassword()) {
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.6 18.6 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke-linecap="round" stroke-linejoin="round"/>
                      <line x1="1" y1="1" x2="23" y2="23" stroke-linecap="round"/>
                    </svg>
                  } @else {
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke-linecap="round" stroke-linejoin="round"/>
                      <circle cx="12" cy="12" r="3"/>
                    </svg>
                  }
                </button>
              </div>
            </div>

            <div class="field">
              <label for="password-conf">Confirmar contraseña</label>
              <div class="password-input">
                <input
                  id="password-conf"
                  [type]="mostrarPasswordConf() ? 'text' : 'password'"
                  [(ngModel)]="passwordConfirmacion"
                  name="passwordConfirmacion"
                  required
                  autocomplete="new-password"
                />
                <button type="button" class="toggle-password" (click)="mostrarPasswordConf.set(!mostrarPasswordConf())"
                  [attr.aria-label]="mostrarPasswordConf() ? 'Ocultar contraseña' : 'Mostrar contraseña'" tabindex="-1">
                  @if (mostrarPasswordConf()) {
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.6 18.6 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke-linecap="round" stroke-linejoin="round"/>
                      <line x1="1" y1="1" x2="23" y2="23" stroke-linecap="round"/>
                    </svg>
                  } @else {
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke-linecap="round" stroke-linejoin="round"/>
                      <circle cx="12" cy="12" r="3"/>
                    </svg>
                  }
                </button>
              </div>
            </div>

            @if (error()) { <p class="error">{{ error() }}</p> }

            <button type="submit" class="btn-primary" [disabled]="cargando()">
              {{ cargando() ? 'Guardando…' : 'Guardar nueva contraseña' }}
            </button>
          </form>
        }
      </div>
    </div>
  `,
  styles: [`
    :host {
      --verde-botella-oscuro: #01001A;
      --cobre: #00D4FF;
      --cobre-claro: #00D4FF;
      --papel: #EAFBFF;
      --papel-borde: #00D4FF;
      --tinta: #020024;
      display: block;
      min-height: calc(100dvh - var(--altura-nav, 0px));
      background: var(--verde-botella-oscuro);
      font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
    }
    .wrap { display: flex; align-items: center; justify-content: center; min-height: calc(100dvh - var(--altura-nav, 0px)); padding: 24px; }
    .card {
      width: 100%; max-width: 380px;
      background: var(--papel);
      border: 1px solid var(--papel-borde);
      border-radius: 14px;
      padding: 32px 28px;
      box-shadow: 0 16px 40px rgba(0,0,0,0.35);
    }
    .brand { display: flex; align-items: center; margin-bottom: 6px; }
    .brand img { display: block; }
    .subtitle { font-size: 13px; color: #5a5140; margin: 0 0 20px; line-height: 1.5; }
    .subtitle.exito { color: #2c5a3f; }
    .subtitle.error { color: #d64545; }
    .field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 16px; }
    .field label { font-size: 13px; font-weight: 600; color: var(--tinta); }
    .field input {
      border: 1px solid var(--papel-borde);
      border-radius: 8px;
      padding: 10px 12px;
      font-size: 14px;
      font-family: inherit;
      background: #fff;
      color: var(--tinta);
      width: 100%;
      box-sizing: border-box;
    }
    .field input:focus { outline: 2px solid var(--cobre-claro); outline-offset: 1px; }
    .password-input { position: relative; display: flex; align-items: center; }
    .password-input input { padding-right: 38px; }
    .toggle-password {
      position: absolute;
      right: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: none;
      border: none;
      padding: 4px;
      color: #8a7a56;
      cursor: pointer;
      border-radius: 6px;
    }
    .toggle-password:hover { color: var(--cobre); }
    .error { color: #d64545; font-size: 13px; margin: -6px 0 14px; }
    .btn-primary {
      width: 100%;
      background: var(--cobre);
      color: #1a1409;
      border: none;
      border-radius: 8px;
      padding: 11px 20px;
      font-weight: 700;
      font-size: 14px;
      cursor: pointer;
    }
    .btn-primary:hover:not(:disabled) { background: var(--cobre-claro); }
    .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
    .volver-hint { text-align: center; font-size: 12px; margin: 20px 0 0; }
    .volver-hint a { color: #8a7a56; text-decoration: none; }
    .volver-hint a:hover { text-decoration: underline; }
  `],
})
export class RestablecerPasswordComponent {
  private recuperacion = inject(PasswordRecuperacionService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  tipo: TipoCuenta = 'cliente';
  email = '';
  token = '';
  tokenValido = signal(true);

  password = '';
  passwordConfirmacion = '';
  mostrarPassword = signal(false);
  mostrarPasswordConf = signal(false);
  cargando = signal(false);
  error = signal('');
  exito = signal(false);

  constructor() {
    const params = this.route.snapshot.queryParamMap;
    const tipoParam = params.get('tipo');
    const emailParam = params.get('email');
    const tokenParam = params.get('token');

    if ((tipoParam !== 'usuario' && tipoParam !== 'cliente') || !emailParam || !tokenParam) {
      this.tokenValido.set(false);
      return;
    }

    this.tipo = tipoParam;
    this.email = emailParam;
    this.token = tokenParam;
  }

  restablecer(): void {
    this.error.set('');

    if (this.password !== this.passwordConfirmacion) {
      this.error.set('Las contraseñas no coinciden.');
      return;
    }

    this.cargando.set(true);
    this.recuperacion
      .restablecer({
        email: this.email,
        tipo: this.tipo,
        token: this.token,
        password: this.password,
        password_confirmation: this.passwordConfirmacion,
      })
      .subscribe({
        next: () => {
          this.cargando.set(false);
          this.exito.set(true);
        },
        error: (err) => {
          this.cargando.set(false);
          this.error.set(err?.error?.message || 'No se pudo restablecer la contraseña.');
        },
      });
  }
}
