import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ClienteAuthService } from '../../core/services/cliente-auth.service';

@Component({
  selector: 'app-acceso-cliente',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="acceso-wrap">
      <div class="acceso-card">
        <a routerLink="/catalogo" class="volver">← Seguir viendo el catálogo</a>

        <div class="brand">
          <img src="brand/logo-al-paso.png" alt="Licorería Al Paso" height="46" />
        </div>

        <p class="subtitle">
          @if (modo() === 'login') {
            Inicia sesión para ver este producto y comprar.
          } @else {
            Crea tu cuenta gratis para ver productos y comprar.
          }
        </p>

        <div class="tabs">
          <button type="button" [class.activo]="modo() === 'login'" (click)="modo.set('login')">
            Iniciar sesión
          </button>
          <button type="button" [class.activo]="modo() === 'registro'" (click)="modo.set('registro')">
            Crear cuenta
          </button>
        </div>

        @if (modo() === 'login') {
          <form (ngSubmit)="iniciarSesion()">
            <div class="field">
              <label for="email">Correo</label>
              <input id="email" type="email" [(ngModel)]="email" name="email" required autocomplete="username" />
            </div>
            <div class="field">
              <label for="password">Contraseña</label>
              <div class="password-input">
                <input
                  id="password"
                  [type]="mostrarPassword() ? 'text' : 'password'"
                  [(ngModel)]="password"
                  name="password"
                  required
                  autocomplete="current-password"
                />
                <button type="button" class="toggle-password" (click)="mostrarPassword.set(!mostrarPassword())"
                  [attr.aria-label]="mostrarPassword() ? 'Ocultar contraseña' : 'Mostrar contraseña'" tabindex="-1">
                  <ng-container *ngTemplateOutlet="mostrarPassword() ? iconoOjoTachado : iconoOjo"></ng-container>
                </button>
              </div>
              <a routerLink="/olvide-password" [queryParams]="{ tipo: 'cliente' }" class="olvide-link">¿Olvidaste tu contraseña?</a>
            </div>

            @if (error()) { <p class="error">{{ error() }}</p> }

            <button type="submit" class="btn-primary" [disabled]="cargando()">
              {{ cargando() ? 'Ingresando…' : 'Ingresar' }}
            </button>
          </form>
        } @else {
          <form (ngSubmit)="registrarse()">
            <div class="field">
              <label for="nombre">Nombre completo</label>
              <input id="nombre" type="text" [(ngModel)]="nombre" name="nombre" required />
            </div>
            <div class="field">
              <label for="email-reg">Correo</label>
              <input id="email-reg" type="email" [(ngModel)]="email" name="email" required autocomplete="username" />
            </div>
            <div class="field">
              <label for="telefono">Teléfono (opcional)</label>
              <input id="telefono" type="tel" [(ngModel)]="telefono" name="telefono" />
            </div>
            <div class="field">
              <label for="password-reg">Contraseña</label>
              <div class="password-input">
                <input
                  id="password-reg"
                  [type]="mostrarPassword() ? 'text' : 'password'"
                  [(ngModel)]="password"
                  name="password"
                  required
                  minlength="6"
                  autocomplete="new-password"
                />
                <button type="button" class="toggle-password" (click)="mostrarPassword.set(!mostrarPassword())"
                  [attr.aria-label]="mostrarPassword() ? 'Ocultar contraseña' : 'Mostrar contraseña'" tabindex="-1">
                  <ng-container *ngTemplateOutlet="mostrarPassword() ? iconoOjoTachado : iconoOjo"></ng-container>
                </button>
              </div>
            </div>
            <div class="field">
              <label for="password-conf">Confirmar contraseña</label>
              <div class="password-input">
                <input
                  id="password-conf"
                  [type]="mostrarPasswordConf() ? 'text' : 'password'"
                  [(ngModel)]="passwordConfirmacion"
                  name="passwordConfirmacion"
                  required
                  autocomplete="new-password"
                />
                <button type="button" class="toggle-password" (click)="mostrarPasswordConf.set(!mostrarPasswordConf())"
                  [attr.aria-label]="mostrarPasswordConf() ? 'Ocultar contraseña' : 'Mostrar contraseña'" tabindex="-1">
                  <ng-container *ngTemplateOutlet="mostrarPasswordConf() ? iconoOjoTachado : iconoOjo"></ng-container>
                </button>
              </div>
            </div>

            <label class="check-edad">
              <input type="checkbox" [(ngModel)]="mayorEdad" name="mayorEdad" />
              <span>Declaro que soy <strong>mayor de 18 años</strong> y puedo comprar bebidas alcohólicas.</span>
            </label>

            @if (error()) { <p class="error">{{ error() }}</p> }

            <button type="submit" class="btn-primary" [disabled]="cargando() || !mayorEdad">
              {{ cargando() ? 'Creando cuenta…' : 'Crear cuenta' }}
            </button>
          </form>
        }

        <p class="staff-hint">¿Eres parte del equipo de la licorería? <a routerLink="/login">Ingresa aquí</a>.</p>
      </div>
    </div>

    <ng-template #iconoOjo>
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke-linecap="round" stroke-linejoin="round"/>
        <circle cx="12" cy="12" r="3"/>
      </svg>
    </ng-template>
    <ng-template #iconoOjoTachado>
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.6 18.6 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke-linecap="round" stroke-linejoin="round"/>
        <line x1="1" y1="1" x2="23" y2="23" stroke-linecap="round"/>
      </svg>
    </ng-template>
  `,
  styles: [`
    :host {
      --verde-botella: #020024;
      --verde-botella-oscuro: #01001A;
      --cobre: #00D4FF;
      --cobre-claro: #00D4FF;
      --papel: #EAFBFF;
      --papel-borde: #00D4FF;
      --tinta: #020024;
      --rust: #d64545;
      display: block;
      min-height: calc(100dvh - var(--altura-nav, 0px));
      background: var(--verde-botella-oscuro);
      font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
    }
    .acceso-wrap { display: flex; align-items: center; justify-content: center; min-height: calc(100dvh - var(--altura-nav, 0px)); padding: 24px; }
    .acceso-card {
      width: 100%; max-width: 400px;
      background: var(--papel);
      border: 1px solid var(--papel-borde);
      border-radius: 14px;
      padding: 28px 28px 32px;
      box-shadow: 0 16px 40px rgba(0,0,0,0.35);
    }
    .volver {
      display: inline-block;
      color: #8a7a56;
      text-decoration: none;
      font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
      font-size: 12px;
      margin-bottom: 18px;
    }
    .volver:hover { text-decoration: underline; }
    .brand { display: flex; align-items: center; margin-bottom: 6px; }
    .brand img { display: block; }
    .subtitle { font-size: 13px; color: #5a5140; margin: 0 0 18px; }
    .tabs { display: flex; gap: 6px; margin-bottom: 20px; background: #e7dcbf; border-radius: 8px; padding: 4px; }
    .tabs button {
      flex: 1; border: none; background: transparent; padding: 9px 10px; border-radius: 6px;
      font-family: inherit; font-weight: 600; font-size: 13px; color: #6b5f45; cursor: pointer;
    }
    .tabs button.activo { background: var(--papel); color: var(--tinta); box-shadow: 0 1px 3px rgba(0,0,0,0.15); }
    .field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px; }
    .field label { font-size: 13px; font-weight: 600; color: var(--tinta); }
    .field input {
      border: 1px solid var(--papel-borde);
      border-radius: 8px;
      padding: 10px 12px;
      font-size: 14px;
      font-family: inherit;
      background: #fff;
      color: var(--tinta);
      width: 100%;
      box-sizing: border-box;
    }
    .field input:focus { outline: 2px solid var(--cobre-claro); outline-offset: 1px; }
    .password-input { position: relative; display: flex; align-items: center; }
    .password-input input { padding-right: 38px; }
    .toggle-password {
      position: absolute;
      right: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: none;
      border: none;
      padding: 4px;
      color: #8a7a56;
      cursor: pointer;
      border-radius: 6px;
    }
    .toggle-password:hover { color: var(--cobre); }
    .olvide-link {
      align-self: flex-end;
      font-size: 12px;
      color: var(--cobre);
      text-decoration: none;
      margin-top: 2px;
    }
    .olvide-link:hover { text-decoration: underline; }
    .error { color: #d64545; font-size: 13px; margin: -6px 0 14px; }
    .check-edad { display: flex; gap: 8px; align-items: flex-start; font-size: 13px; color: var(--tinta); margin: 2px 0 16px; cursor: pointer; line-height: 1.4; }
    .check-edad input { margin-top: 3px; width: 16px; height: 16px; flex: none; }
    .btn-primary {
      width: 100%;
      background: var(--cobre);
      color: #1a1409;
      border: none;
      border-radius: 8px;
      padding: 11px 20px;
      font-weight: 700;
      font-size: 14px;
      cursor: pointer;
    }
    .btn-primary:hover:not(:disabled) { background: var(--cobre-claro); }
    .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
    .staff-hint { text-align: center; font-size: 12px; color: #8a7a56; margin: 18px 0 0; }
    .staff-hint a { color: var(--rust); font-weight: 600; text-decoration: none; }
    .staff-hint a:hover { text-decoration: underline; }
  `],
})
export class AccesoClienteComponent {
  private clienteAuth = inject(ClienteAuthService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);

  modo = signal<'login' | 'registro'>('login');
  cargando = signal(false);
  error = signal('');
  mostrarPassword = signal(false);
  mostrarPasswordConf = signal(false);

  email = '';
  password = '';
  nombre = '';
  telefono = '';
  passwordConfirmacion = '';
  mayorEdad = false;

  private returnUrl(): string {
    return this.route.snapshot.queryParamMap.get('returnUrl') || '/catalogo';
  }

  iniciarSesion(): void {
    this.error.set('');
    this.cargando.set(true);
    this.clienteAuth.login({ email: this.email, password: this.password }).subscribe({
      next: () => {
        this.cargando.set(false);
        this.router.navigateByUrl(this.returnUrl());
      },
      error: (err) => {
        this.cargando.set(false);
        this.error.set(err?.error?.message || 'No se pudo iniciar sesión.');
      },
    });
  }

  registrarse(): void {
    this.error.set('');

    if (this.password !== this.passwordConfirmacion) {
      this.error.set('Las contraseñas no coinciden.');
      return;
    }

    if (!this.mayorEdad) {
      this.error.set('Debes confirmar que eres mayor de 18 años para crear tu cuenta.');
      return;
    }

    this.cargando.set(true);
    this.clienteAuth
      .registro({
        nombre: this.nombre,
        email: this.email,
        telefono: this.telefono || undefined,
        password: this.password,
        password_confirmation: this.passwordConfirmacion,
        mayor_edad: this.mayorEdad,
      })
      .subscribe({
        next: () => {
          this.cargando.set(false);
          this.router.navigateByUrl(this.returnUrl());
        },
        error: (err) => {
          this.cargando.set(false);
          this.error.set(err?.error?.message || 'No se pudo crear la cuenta.');
        },
      });
  }
}
