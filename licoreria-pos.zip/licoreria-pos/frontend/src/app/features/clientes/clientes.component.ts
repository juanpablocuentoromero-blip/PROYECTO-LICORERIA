import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ClienteService } from '../../core/services/cliente.service';
import { Cliente } from '../../core/models/cliente.model';
import { BASE_THEME } from '../../shared/theme/theme';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';
import { AuthService } from '../../core/services/auth.service';
import { PaginadorComponent } from '../../shared/paginador/paginador.component';

@Component({
  selector: 'app-clientes',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginadorComponent],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Ventas &middot; Clientes</div>
          <h1>Clientes</h1>
          <p class="subtitle">Personas y negocios a los que atiende la licorería.</p>
        </div>
        <input class="buscador" type="text" placeholder="Buscar por nombre…" [(ngModel)]="buscar" (ngModelChange)="cargar()" />
      </header>

      <section class="panel">
        <button class="btn-secondary" (click)="toggleForm()">
          {{ formAbierto() ? 'Cerrar formulario' : (editandoId() ? 'Editar cliente' : '+ Nuevo cliente') }}
        </button>

        @if (formAbierto()) {
          <form class="form-grid" style="margin-top:16px" (ngSubmit)="guardar()">
            <div class="field">
              <label>Nombre</label>
              <input type="text" [(ngModel)]="form.nombre" name="nombre" required />
            </div>
            <div class="field">
              <label>NIT / CI</label>
              <input type="text" [(ngModel)]="form.nit_ci" name="nit_ci" maxlength="20" />
            </div>
            <div class="field">
              <label>Teléfono</label>
              <input type="text" [(ngModel)]="form.telefono" name="telefono" />
            </div>
            <div class="field">
              <label>Email</label>
              <input type="email" [(ngModel)]="form.email" name="email" />
            </div>
            <div class="field">
              <label>Dirección</label>
              <input type="text" [(ngModel)]="form.direccion" name="direccion" />
            </div>
            @if (esAdmin) {
              <div class="field credito-campo">
                <label class="check">
                  <input type="checkbox" [(ngModel)]="form.credito_habilitado" name="credito_habilitado" />
                  Permitir venta a crédito (fiado)
                </label>
                <small>Necesita NIT/CI. Solo el administrador puede habilitarlo.</small>
              </div>
              @if (form.credito_habilitado) {
                <div class="field">
                  <label>Límite de crédito (Bs) <span>(vacío = sin límite)</span></label>
                  <input type="number" min="0" step="0.01" [(ngModel)]="form.limite_credito" name="limite_credito" />
                </div>
              }
            }
            <div class="field-row" style="grid-column: 1/-1">
              <button type="submit" class="btn-primary" [disabled]="guardando() || !form.nombre.trim()">
                {{ guardando() ? 'Guardando…' : (editandoId() ? 'Actualizar' : 'Guardar cliente') }}
              </button>
              @if (error()) { <span class="form-error">{{ error() }}</span> }
            </div>
          </form>
        }
      </section>

      @if (cargando()) {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando clientes…</p></div>
      } @else if (clientes().length === 0) {
        <div class="estado-vacio"><p>No hay clientes registrados.</p><span>Agrega el primero con el botón de arriba.</span></div>
      } @else {
        <table>
          <thead><tr><th>Nombre</th><th>NIT/CI</th><th>Teléfono</th><th>Email</th><th>Dirección</th><th>Estado</th><th></th></tr></thead>
          <tbody>
            @for (c of clientes(); track c.id) {
              <tr>
                <td data-label="Nombre">{{ c.nombre }}</td>
                <td data-label="NIT/CI">{{ c.nit_ci || '—' }}</td>
                <td data-label="Teléfono">{{ c.telefono || '—' }}</td>
                <td data-label="Email">{{ c.email || '—' }}</td>
                <td data-label="Dirección">{{ c.direccion || '—' }}</td>
                <td data-label="Estado">
                  <span class="badge" [class.badge-ok]="c.activo" [class.badge-off]="!c.activo">{{ c.activo ? 'Activo' : 'Inactivo' }}</span>
                  @if (c.credito_habilitado) { <span class="badge badge-info">Fiado{{ c.limite_credito ? ' · Bs ' + c.limite_credito : '' }}</span> }
                </td>
                <td data-label="Acciones">
                  <button class="link-action" (click)="editar(c)">Editar</button>
                  <button class="link-danger" (click)="eliminar(c)">Eliminar</button>
                </td>
              </tr>
            }
          </tbody>
        </table>
        <app-paginador [actual]="paginaActual()" [ultima]="ultimaPagina()" [total]="totalRegistros()"
                       etiqueta="clientes" (cambiar)="cargar($event)" />
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .credito-campo small { font-size: 11px; opacity: 0.8; }
    .check { display: flex; gap: 8px; align-items: center; cursor: pointer; }
    .check input { width: 16px; height: 16px; }
    .buscador {
      background: var(--papel); color: var(--tinta); border: 1px solid var(--papel-borde); border-radius: 8px;
      padding: 9px 12px; font-size: 14px; min-width: 220px;
    }
  `],
})
export class ClientesComponent implements OnInit {
  private service = inject(ClienteService);
  private confirmDialog = inject(ConfirmDialogService);
  private auth = inject(AuthService);

  get esAdmin(): boolean {
    return this.auth.usuarioActual()?.rol === 'administrador';
  }

  clientes = signal<Cliente[]>([]);
  cargando = signal(true);
  guardando = signal(false);
  formAbierto = signal(false);
  editandoId = signal<number | null>(null);
  error = signal('');
  buscar = '';

  // 2.2 Paginación
  paginaActual = signal(1);
  ultimaPagina = signal(1);
  totalRegistros = signal(0);

  form = this.formVacio();

  private formVacio() {
    return {
      nombre: '', nit_ci: '', telefono: '', email: '', direccion: '',
      credito_habilitado: false, limite_credito: null as number | null,
    };
  }

  ngOnInit(): void { this.cargar(); }

  cargar(pagina = 1): void {
    this.cargando.set(true);
    this.service.listarPagina(this.buscar || undefined, pagina).subscribe({
      next: (res) => {
        // Si la página ya no existe (se borró el último de la última página), retrocede.
        if (pagina > res.last_page && res.last_page >= 1) { this.cargar(res.last_page); return; }
        this.clientes.set(res.data);
        this.paginaActual.set(res.current_page);
        this.ultimaPagina.set(res.last_page);
        this.totalRegistros.set(res.total);
        this.cargando.set(false);
      },
      error: () => { this.error.set('No se pudo conectar con el servidor.'); this.cargando.set(false); },
    });
  }

  toggleForm(): void {
    if (this.formAbierto()) {
      this.formAbierto.set(false);
      this.editandoId.set(null);
      this.resetForm();
    } else {
      this.formAbierto.set(true);
    }
  }

  editar(c: Cliente): void {
    this.editandoId.set(c.id);
    this.form = {
      nombre: c.nombre,
      nit_ci: c.nit_ci || '',
      telefono: c.telefono || '',
      email: c.email || '',
      direccion: c.direccion || '',
      credito_habilitado: !!c.credito_habilitado,
      limite_credito: c.limite_credito !== null && c.limite_credito !== undefined ? Number(c.limite_credito) : null,
    };
    this.formAbierto.set(true);
  }

  resetForm(): void { this.form = this.formVacio(); }

  guardar(): void {
    if (!this.form.nombre.trim()) return;
    this.guardando.set(true);
    this.error.set('');
    const payload = {
      nombre: this.form.nombre.trim(),
      telefono: this.form.telefono.trim() || undefined,
      email: this.form.email.trim() || undefined,
      direccion: this.form.direccion.trim() || undefined,
      nit_ci: this.form.nit_ci.trim() || null,
      // El servidor ignora estos dos si quien guarda no es administrador.
      ...(this.esAdmin
        ? {
            credito_habilitado: this.form.credito_habilitado,
            limite_credito: this.form.credito_habilitado ? this.form.limite_credito : null,
          }
        : {}),
    };

    const id = this.editandoId();
    const req = id ? this.service.actualizar(id, payload) : this.service.crear(payload);

    req.subscribe({
      next: () => {
        // Se recarga la página actual: con paginación ya no basta con tocar la lista local.
        this.cargar(this.paginaActual());
        this.guardando.set(false);
        this.formAbierto.set(false);
        this.editandoId.set(null);
        this.resetForm();
      },
      error: (err) => { this.error.set(err?.error?.message || 'No se pudo guardar. Revisa los datos.'); this.guardando.set(false); },
    });
  }

  async eliminar(c: Cliente): Promise<void> {
    const ok = await this.confirmDialog.confirm({
      titulo: 'Eliminar cliente',
      mensaje: `¿Estás seguro de que quieres eliminar a "${c.nombre}"? Esta acción no se puede deshacer.`,
      textoConfirmar: 'Sí, eliminar',
      peligroso: true,
    });
    if (!ok) return;

    this.service.eliminar(c.id).subscribe({
      next: () => this.cargar(this.paginaActual()),
      error: () => this.error.set('No se pudo eliminar el cliente.'),
    });
  }
}
