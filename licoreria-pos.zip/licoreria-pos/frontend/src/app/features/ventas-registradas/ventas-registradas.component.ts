import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VentaService } from '../../core/services/venta.service';
import { UsuarioService } from '../../core/services/usuario.service';
import { AuthService } from '../../core/services/auth.service';
import {
  DetalleVenta,
  FiltroVentas,
  ResumenVentas,
  VentaRegistrada,
} from '../../core/models/venta.model';
import { Usuario } from '../../core/models/usuario.model';
import { DevolucionResumen } from '../../core/models/paso4.model';
import { BASE_THEME } from '../../shared/theme/theme';
import { ConfirmDialogService } from '../../shared/confirm-dialog/confirm-dialog.service';
import { PaginadorComponent } from '../../shared/paginador/paginador.component';

@Component({
  selector: 'app-ventas-registradas',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginadorComponent],
  template: `
    <div class="page">
      <header class="page-header">
        <div>
          <div class="eyebrow">Ventas &middot; Historial</div>
          <h1>Ventas registradas</h1>
          <p class="subtitle">Historial y auditoría de todas las notas de venta y facturas emitidas.</p>
        </div>
      </header>

      <section class="panel">
        <div class="filtros">
          <div class="field">
            <label>Desde</label>
            <input type="date" [(ngModel)]="filtro.desde" name="desde" />
          </div>
          <div class="field">
            <label>Hasta</label>
            <input type="date" [(ngModel)]="filtro.hasta" name="hasta" />
          </div>
          <div class="field">
            <label>Cliente</label>
            <input type="text" placeholder="Nombre del cliente" [(ngModel)]="filtro.cliente" name="cliente" />
          </div>
          <div class="field">
            <label>Vendedor</label>
            <select [(ngModel)]="filtro.vendedor_id" name="vendedor">
              <option [ngValue]="null">Todos</option>
              @for (u of vendedores(); track u.id) { <option [ngValue]="u.id">{{ u.nombre }}</option> }
            </select>
          </div>
          <div class="field">
            <label>Estado</label>
            <select [(ngModel)]="filtro.estado" name="estado">
              <option value="todas">Todas</option>
              <option value="validas">Válidas</option>
              <option value="anuladas">Anuladas</option>
            </select>
          </div>
          <div class="field">
            <label>Tipo de venta</label>
            <select [(ngModel)]="filtro.tipo" name="tipo">
              <option value="todas">Todas</option>
              <option value="factura">Con factura</option>
              <option value="sin_factura">Sin factura</option>
            </select>
          </div>
          <div class="field">
            <label>Nro. documento</label>
            <input type="text" placeholder="0026-000002" [(ngModel)]="filtro.buscar" name="buscar" />
          </div>
          <div class="filtro-acciones">
            <button class="btn-primary" (click)="buscar()" [disabled]="cargando()">
              {{ cargando() ? 'Buscando…' : 'Buscar' }}
            </button>
            <button class="btn-secondary" (click)="limpiar()">Limpiar</button>
          </div>
        </div>

        @if (resumen(); as r) {
          <div class="resumen">
            <div class="resumen-item">
              <span class="resumen-label">Documentos</span>
              <strong>{{ r.cantidad }}</strong>
            </div>
            <div class="resumen-item">
              <span class="resumen-label">Total vendido</span>
              <strong>Bs {{ r.total.toFixed(2) }}</strong>
            </div>
            <div class="resumen-item">
              <span class="resumen-label">Cobrado</span>
              <strong>Bs {{ r.cobrado.toFixed(2) }}</strong>
            </div>
            <div class="resumen-item">
              <span class="resumen-label">Por cobrar</span>
              <strong>Bs {{ r.por_cobrar.toFixed(2) }}</strong>
            </div>
          </div>
          <p class="nota-resumen">Los totales excluyen las ventas anuladas.</p>
        }
      </section>

      @if (error()) { <p class="form-error">{{ error() }}</p> }
      @if (mensajeOk()) { <p class="form-ok">{{ mensajeOk() }}</p> }

      <h3 class="panel-title">Documentos emitidos</h3>
      @if (cargando()) {
        <div class="estado-vacio"><div class="spinner"></div><p>Cargando ventas…</p></div>
      } @else if (ventas().length === 0) {
        <div class="estado-vacio"><p>No hay ventas para los filtros seleccionados.</p></div>
      } @else {
        <table>
          <thead>
            <tr>
              <th>Nro. documento</th><th>Fecha</th><th>Hora</th><th>Cliente</th>
              <th>Vendedor</th><th>Total</th><th>Cobrado</th><th>Saldo</th><th>Estado</th><th></th>
            </tr>
          </thead>
          <tbody>
            @for (v of ventas(); track v.id) {
              <tr class="fila-venta" [class.fila-activa]="ventaSeleccionada()?.id === v.id"
                  [class.fila-anulada]="v.anulada" (click)="seleccionar(v)">
                <td data-label="Nro. documento">{{ v.nro_documento }}</td>
                <td data-label="Fecha">{{ v.fecha }}</td>
                <td data-label="Hora">{{ v.hora }}</td>
                <td data-label="Cliente">{{ v.cliente }}</td>
                <td data-label="Vendedor">{{ v.vendedor }}</td>
                <td data-label="Total">Bs {{ v.total.toFixed(2) }}</td>
                <td data-label="Cobrado">Bs {{ v.cobrado.toFixed(2) }}</td>
                <td data-label="Saldo">Bs {{ v.saldo.toFixed(2) }}</td>
                <td data-label="Estado">
                  <span class="badge"
                    [class.badge-danger]="v.anulada"
                    [class.badge-ok]="!v.anulada && v.pagado"
                    [class.badge-info]="!v.anulada && !v.pagado">
                    {{ v.anulada ? 'anulada' : (v.pagado ? 'cobrada' : 'pendiente') }}
                  </span>
                </td>
                <td>
                  <div class="fila-acciones">
                    <button class="link-action" (click)="descargarPdf(v, $event)"
                            [disabled]="descargando() === v.id">
                      {{ descargando() === v.id ? 'Generando…' : 'PDF' }}
                    </button>
                    @if (esAdministrador() && !v.anulada) {
                      <button class="link-danger" (click)="anular(v, $event)">Anular</button>
                    }
                  </div>
                </td>
              </tr>
            }
          </tbody>
        </table>
        <app-paginador [actual]="paginaActual()" [ultima]="ultimaPagina()" [total]="totalRegistros()"
                       etiqueta="ventas" (cambiar)="buscar($event)" />
      }

      @if (ventaSeleccionada(); as v) {
        <section class="panel detalle-panel">
          <h3 class="panel-title" style="margin:0 0 4px">Detalle de la venta {{ v.nro_documento }}</h3>
          <p class="subtitle">
            {{ v.cliente }} &middot; {{ v.fecha }} {{ v.hora }} &middot; pago por {{ v.metodo_pago }}
          </p>

          @if (v.anulada) {
            <p class="aviso-anulada">
              Anulada el {{ v.anulada_at }} por {{ v.anulada_por || '—' }}. Motivo: {{ v.motivo_anulacion }}
            </p>
          }

          @if (cargandoDetalle()) {
            <div class="estado-vacio"><div class="spinner"></div><p>Cargando detalle…</p></div>
          } @else {
            @if (v.pagos && v.pagos.length > 1) {
              <p class="pagos-mixtos">
                Pago mixto:
                @for (p of v.pagos; track p.metodo_pago) { <span class="badge badge-info">{{ p.metodo_pago }} Bs {{ p.monto.toFixed(2) }}</span> }
              </p>
            }

            <table>
              <thead>
                <tr>
                  <th>Código</th><th>Descripción</th><th>Cantidad</th><th>P. Unitario</th><th>Subtotal</th>
                  @if (devolviendo()) { <th>Devolver</th> }
                </tr>
              </thead>
              <tbody>
                @for (d of detalles(); track d.id) {
                  <tr>
                    <td data-label="Código">{{ d.codigo }}</td>
                    <td data-label="Descripción">
                      {{ d.descripcion }}
                      @if ((d.cantidad_devuelta ?? 0) > 0) {
                        <span class="badge badge-warn">devueltas {{ d.cantidad_devuelta }}</span>
                      }
                    </td>
                    <td data-label="Cantidad">{{ d.cantidad }}</td>
                    <td data-label="P. Unitario">Bs {{ d.precio_unitario.toFixed(2) }}</td>
                    <td data-label="Subtotal">Bs {{ d.subtotal.toFixed(2) }}</td>
                    @if (devolviendo()) {
                      <td data-label="Devolver">
                        @if (restante(d) > 0) {
                          <input class="num" type="number" min="0" [max]="restante(d)" step="1"
                                 [ngModel]="cantidadesDevolver()[d.id] ?? 0"
                                 (ngModelChange)="fijarCantidad(d.id, $event, restante(d))"
                                 [name]="'dev' + d.id" />
                          <small>de {{ restante(d) }}</small>
                        } @else { <small>—</small> }
                      </td>
                    }
                  </tr>
                }
              </tbody>
            </table>
            <div class="total-row">
              Total: <strong>Bs {{ v.total.toFixed(2) }}</strong>
              @if ((v.monto_devuelto ?? 0) > 0) {
                · Devuelto: <strong>− Bs {{ (v.monto_devuelto ?? 0).toFixed(2) }}</strong>
                · Neto: <strong>Bs {{ (v.total - (v.monto_devuelto ?? 0)).toFixed(2) }}</strong>
              }
            </div>

            @if (esAdministrador() && !v.anulada && (v.pagado || v.es_credito)) {
              @if (!devolviendo()) {
                @if (hayPorDevolver()) {
                  <button class="btn-secondary" (click)="iniciarDevolucion()">↩ Registrar devolución parcial</button>
                }
              } @else {
                <div class="form-devolucion">
                  <div class="field">
                    <label>Motivo de la devolución *</label>
                    <input type="text" maxlength="255" [(ngModel)]="motivoDevolucion" name="motivoDev" placeholder="Ej.: botella dañada, producto equivocado…" />
                  </div>
                  <div class="field">
                    <label>Devolver el dinero por</label>
                    <select [(ngModel)]="metodoReembolso" name="metodoReembolso">
                      <option value="">Mismo medio de pago</option>
                      <option value="efectivo">Efectivo (sale de caja)</option>
                      <option value="qr">QR / transferencia</option>
                      <option value="tarjeta">Tarjeta</option>
                    </select>
                  </div>
                  <p class="nota-resumen">
                    Se repone el stock y se emite una nota de crédito.
                    @if (v.es_credito) { En una venta a crédito, primero se descuenta de la deuda del cliente. }
                    El importe es proporcional a lo que se pagó por cada producto (con sus descuentos).
                  </p>
                  <div class="fila-acciones">
                    <button class="btn-primary" (click)="confirmarDevolucion()" [disabled]="enviandoDevolucion() || totalUnidadesDevolver() === 0">
                      {{ enviandoDevolucion() ? 'Registrando…' : 'Confirmar devolución (' + totalUnidadesDevolver() + ' u.)' }}
                    </button>
                    <button class="btn-secondary" (click)="cancelarDevolucion()">Cancelar</button>
                  </div>
                </div>
              }
            }

            @if (devoluciones().length > 0) {
              <h4 class="sub-titulo">Notas de crédito emitidas</h4>
              <table>
                <thead><tr><th>Nota</th><th>Fecha</th><th>Total</th><th>Devuelto por</th><th>Motivo</th><th>Registró</th><th></th></tr></thead>
                <tbody>
                  @for (n of devoluciones(); track n.id) {
                    <tr>
                      <td data-label="Nota">{{ n.nro_nota }}</td>
                      <td data-label="Fecha">{{ n.fecha }}</td>
                      <td data-label="Total">Bs {{ n.total.toFixed(2) }}</td>
                      <td data-label="Devuelto por">
                        @if (n.monto_reembolsado > 0) { {{ n.metodo_reembolso }} Bs {{ n.monto_reembolsado.toFixed(2) }} }
                        @if (n.aplicado_a_saldo > 0) { <br>descontado de la deuda Bs {{ n.aplicado_a_saldo.toFixed(2) }} }
                      </td>
                      <td data-label="Motivo">{{ n.motivo }}</td>
                      <td data-label="Registró">{{ n.usuario || '—' }}</td>
                      <td><button class="link-action" (click)="descargarNota(n)">PDF</button></td>
                    </tr>
                  }
                </tbody>
              </table>
            }
          }
        </section>
      }
    </div>
  `,
  styles: [BASE_THEME, `
    .panel-title { font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif; font-size: 20px; color: var(--papel); margin: 0 0 14px; }
    .filtros { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 12px; align-items: end; }
    .filtro-acciones { display: flex; gap: 8px; align-items: end; }
    .resumen { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px; margin-top: 18px; }
    .resumen-item { display: flex; flex-direction: column; gap: 2px; padding: 12px 14px; border: 1px solid var(--papel-borde); border-radius: 10px; }
    .resumen-label { font-size: 12px; color: #6b5f4a; }
    .resumen-item strong { font-size: 18px; color: var(--tinta); }
    .nota-resumen { font-size: 12px; color: #6b5f4a; margin: 8px 0 0; }
    .fila-venta { cursor: pointer; }
    .fila-activa { background: rgba(31, 54, 40, 0.10); }
    .fila-anulada td { opacity: 0.6; text-decoration: line-through; }
    .fila-anulada .badge, .fila-anulada .fila-acciones { text-decoration: none; opacity: 1; }
    .fila-acciones { display: flex; gap: 8px; flex-wrap: wrap; }
    .fila-acciones button { font-size: 12px; white-space: nowrap; }
    .detalle-panel { margin-top: 18px; }
    .total-row { text-align: right; color: var(--papel); font-size: 16px; margin-top: 10px; }
    input.num { width: 78px; }
    .detalle-panel small { opacity: 0.7; margin-left: 4px; }
    .pagos-mixtos { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; font-size: 13px; margin: 0 0 12px; }
    .form-devolucion { margin-top: 14px; padding: 14px; border: 1px dashed rgba(0, 212, 255, 0.45); border-radius: 10px; display: grid; gap: 10px; }
    .sub-titulo { margin: 20px 0 8px; font-size: 15px; }
    .aviso-anulada {
      background: rgba(176, 58, 46, 0.12); border: 1px solid rgba(176, 58, 46, 0.35);
      color: #b03a2e; border-radius: 8px; padding: 10px 12px; font-size: 13px; margin: 0 0 14px;
    }
  `],
})
export class VentasRegistradasComponent implements OnInit {
  private ventaService = inject(VentaService);
  private usuarioService = inject(UsuarioService);
  private auth = inject(AuthService);
  private confirmDialog = inject(ConfirmDialogService);

  ventas = signal<VentaRegistrada[]>([]);
  resumen = signal<ResumenVentas | null>(null);
  vendedores = signal<Usuario[]>([]);
  ventaSeleccionada = signal<VentaRegistrada | null>(null);
  detalles = signal<DetalleVenta[]>([]);

  cargando = signal(true);
  cargandoDetalle = signal(false);
  descargando = signal<number | null>(null);
  error = signal('');
  mensajeOk = signal('');

  // 4.5 Devoluciones parciales
  devoluciones = signal<DevolucionResumen[]>([]);
  devolviendo = signal(false);
  cantidadesDevolver = signal<Record<number, number>>({});
  enviandoDevolucion = signal(false);
  motivoDevolucion = '';
  metodoReembolso: '' | 'efectivo' | 'qr' | 'tarjeta' = '';

  // 2.2 Paginación: el resumen de arriba es de TODO lo filtrado, la tabla muestra una página.
  paginaActual = signal(1);
  ultimaPagina = signal(1);
  totalRegistros = signal(0);
  readonly porPagina = 25;

  filtro: FiltroVentas = { estado: 'todas', tipo: 'todas', vendedor_id: null };

  esAdministrador(): boolean {
    return this.auth.usuarioActual()?.rol === 'administrador';
  }

  ngOnInit(): void {
    this.buscar();
    this.cargarVendedores();
  }

  // El desplegable de vendedores solo lo puede llenar un administrador:
  // el endpoint de usuarios exige ese rol. Para el vendedor el filtro
  // queda con la única opción "Todos", que en su caso es suficiente.
  private cargarVendedores(): void {
    if (!this.esAdministrador()) return;

    this.usuarioService.listar().subscribe({
      next: (usuarios) => this.vendedores.set(usuarios),
      error: () => this.vendedores.set([]),
    });
  }

  buscar(pagina = 1): void {
    this.cargando.set(true);
    this.error.set('');

    this.ventaService.listar({ ...this.filtro, page: pagina, por_pagina: this.porPagina }).subscribe({
      next: (res) => {
        const pag = res.paginacion;

        // Si la página pedida ya no existe (p. ej. se anuló la última fila de
        // la última página), se vuelve a pedir la última que sí existe.
        if (pag && pagina > pag.last_page && pag.last_page >= 1) {
          this.buscar(pag.last_page);
          return;
        }

        this.ventas.set(res.ventas);
        this.resumen.set(res.resumen);
        this.paginaActual.set(pag?.current_page ?? 1);
        this.ultimaPagina.set(pag?.last_page ?? 1);
        this.totalRegistros.set(pag?.total ?? res.ventas.length);
        this.cargando.set(false);

        // Si la venta abierta abajo ya no entra en el filtro nuevo, se
        // cierra el detalle para no mostrar datos que no corresponden.
        const abierta = this.ventaSeleccionada();
        if (abierta && !res.ventas.some((v) => v.id === abierta.id)) {
          this.ventaSeleccionada.set(null);
          this.detalles.set([]);
        }
      },
      error: () => {
        this.error.set('No se pudieron cargar las ventas.');
        this.cargando.set(false);
      },
    });
  }

  limpiar(): void {
    this.filtro = { estado: 'todas', tipo: 'todas', vendedor_id: null };
    this.buscar();
  }

  seleccionar(venta: VentaRegistrada): void {
    // Segundo clic sobre la misma fila cierra el detalle.
    if (this.ventaSeleccionada()?.id === venta.id) {
      this.ventaSeleccionada.set(null);
      this.detalles.set([]);
      return;
    }

    this.ventaSeleccionada.set(venta);
    this.detalles.set([]);
    this.devoluciones.set([]);
    this.cancelarDevolucion();
    this.cargandoDetalle.set(true);

    this.ventaService.detalle(venta.id).subscribe({
      next: (res) => {
        this.ventaSeleccionada.set(res.venta);
        this.detalles.set(res.detalles);
        this.devoluciones.set(res.devoluciones ?? []);
        this.cargandoDetalle.set(false);
      },
      error: () => {
        this.error.set('No se pudo cargar el detalle de la venta.');
        this.cargandoDetalle.set(false);
      },
    });
  }

  async descargarPdf(venta: VentaRegistrada, evento: Event): Promise<void> {
    evento.stopPropagation();
    this.descargando.set(venta.id);
    this.error.set('');

    try {
      await this.ventaService.descargarPdf(venta.id, venta.nro_documento);
    } catch {
      this.error.set('No se pudo generar el PDF del comprobante.');
    } finally {
      this.descargando.set(null);
    }
  }

  async anular(venta: VentaRegistrada, evento: Event): Promise<void> {
    evento.stopPropagation();

    const confirmado = await this.confirmDialog.confirm({
      titulo: 'Anular venta',
      mensaje:
        `Se anulará el documento ${venta.nro_documento} por Bs ${venta.total.toFixed(2)} ` +
        'y la mercadería volverá al stock. Esta acción no se puede deshacer.',
      textoConfirmar: 'Anular',
      peligroso: true,
    });

    if (!confirmado) return;

    // El motivo es obligatorio en el backend y queda guardado con el
    // documento: es lo que justifica la anulación ante una auditoría.
    const motivo = window.prompt('Motivo de la anulación (obligatorio):')?.trim();
    if (!motivo) {
      this.error.set('La anulación necesita un motivo.');
      return;
    }

    this.error.set('');
    this.mensajeOk.set('');

    this.ventaService.anular(venta.id, motivo).subscribe({
      next: (res) => {
        this.mensajeOk.set(res.message);
        if (this.ventaSeleccionada()?.id === venta.id) {
          this.ventaSeleccionada.set(res.venta);
        }
        this.buscar(this.paginaActual());
      },
      error: (err) => {
        this.error.set(err?.error?.message ?? 'No se pudo anular la venta.');
      },
    });
  }

  // ---------------------------------------------------------------
  // 4.5 Devoluciones parciales / nota de crédito
  // ---------------------------------------------------------------
  restante(d: DetalleVenta): number {
    return Math.max(0, d.cantidad - (d.cantidad_devuelta ?? 0));
  }

  hayPorDevolver(): boolean {
    return this.detalles().some((d) => this.restante(d) > 0);
  }

  iniciarDevolucion(): void {
    this.cantidadesDevolver.set({});
    this.motivoDevolucion = '';
    this.metodoReembolso = '';
    this.error.set('');
    this.mensajeOk.set('');
    this.devolviendo.set(true);
  }

  cancelarDevolucion(): void {
    this.devolviendo.set(false);
    this.cantidadesDevolver.set({});
  }

  fijarCantidad(detalleId: number, valor: number | string | null, maximo: number): void {
    const n = Math.trunc(Number(valor));
    const limpio = Number.isFinite(n) ? Math.min(maximo, Math.max(0, n)) : 0;
    this.cantidadesDevolver.update((m) => ({ ...m, [detalleId]: limpio }));
  }

  totalUnidadesDevolver(): number {
    return Object.values(this.cantidadesDevolver()).reduce((t, n) => t + (n || 0), 0);
  }

  async confirmarDevolucion(): Promise<void> {
    const venta = this.ventaSeleccionada();
    if (!venta) return;

    const items = Object.entries(this.cantidadesDevolver())
      .filter(([, cantidad]) => cantidad > 0)
      .map(([id, cantidad]) => ({ detalle_id: Number(id), cantidad }));

    if (items.length === 0) {
      this.error.set('Indica cuántas unidades se devuelven.');
      return;
    }
    if (!this.motivoDevolucion.trim()) {
      this.error.set('La devolución necesita un motivo.');
      return;
    }

    const confirmado = await this.confirmDialog.confirm({
      titulo: 'Registrar devolución',
      mensaje:
        `Se devolverán ${this.totalUnidadesDevolver()} unidad(es) de la venta ${venta.nro_documento}: ` +
        'el stock vuelve al almacén y se emite una nota de crédito. Esta acción no se puede deshacer.',
      textoConfirmar: 'Devolver',
      peligroso: true,
    });
    if (!confirmado) return;

    this.enviandoDevolucion.set(true);
    this.error.set('');
    this.mensajeOk.set('');

    this.ventaService.devolver(venta.id, {
      motivo: this.motivoDevolucion.trim(),
      metodo_reembolso: this.metodoReembolso || null,
      items,
    }).subscribe({
      next: (res) => {
        this.enviandoDevolucion.set(false);
        this.mensajeOk.set(res.message);
        this.cancelarDevolucion();
        // Recarga el detalle (cantidades devueltas) y la lista.
        this.ventaSeleccionada.set(null);
        this.buscar(this.paginaActual());
        this.seleccionar(venta);
        void this.ventaService.descargarNotaCredito(res.devolucion.id, res.devolucion.nro_nota).catch(() => {
          this.error.set('La devolución se registró, pero no se pudo descargar la nota de crédito (puedes bajarla desde la lista).');
        });
      },
      error: (err) => {
        this.enviandoDevolucion.set(false);
        this.error.set(err?.error?.message ?? 'No se pudo registrar la devolución.');
      },
    });
  }

  async descargarNota(n: DevolucionResumen): Promise<void> {
    try {
      await this.ventaService.descargarNotaCredito(n.id, n.nro_nota);
    } catch {
      this.error.set('No se pudo descargar la nota de crédito.');
    }
  }
}
