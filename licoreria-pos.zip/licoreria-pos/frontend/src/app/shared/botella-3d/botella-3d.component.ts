import {
  AfterViewInit,
  Component,
  ElementRef,
  Input,
  OnChanges,
  OnDestroy,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { Producto } from '../../core/models/producto.model';

/**
 * Colores de vidrio por categoría. Ajustá los nombres para que
 * coincidan con tus categorías reales en la base de datos.
 */
const COLOR_POR_CATEGORIA: Record<string, number> = {
  singanis: 0xdad3b0,
  cervezas: 0xc9a227,
  'sodas y gaseosas locales': 0x8b1e2b,
  'sodas internacionales': 0x8b1e2b,
  'aguas embotelladas': 0x9fd8e0,
  whiskies: 0x8b5a2b,
  rones: 0x5c3a21,
  'tragos económicos': 0xb5651d,
  licores: 0x3a2e1e,
  vodkas: 0xd8e6ea,
  gins: 0xaad4c8,
  tequilas: 0xe8c774,
  'dulces y chicles': 0xe0a83e,
  'energizantes y rehidratantes': 0x2f8f4f,
  cigarrillos: 0xcfc7b0,
  snacks: 0xc17817,
  'espumantes y sidras': 0xe6d18a,
  'chichas, macerados y tragos tradicionales': 0x6b3f22,
  'complementos e insumos de barra': 0xb9c9bd,
  vinos: 0x4a0e2e,
  default: 0x2f6b4f,
};

@Component({
  selector: 'app-botella-3d',
  standalone: true,
  template: `<canvas #canvas class="botella-canvas"></canvas>`,
  styles: [
    `
      :host {
        display: block;
        width: 100%;
        height: 100%;
      }
      .botella-canvas {
        width: 100%;
        height: 100%;
        display: block;
        cursor: grab;
      }
      .botella-canvas:active {
        cursor: grabbing;
      }
    `,
  ],
})
export class Botella3dComponent implements AfterViewInit, OnChanges, OnDestroy {
  @Input({ required: true }) producto!: Producto;
  @Input() autoRotate = true;

  @ViewChild('canvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private controls!: OrbitControls;
  private bottleGroup!: THREE.Group;
  private resizeObserver?: ResizeObserver;
  private frameId?: number;
  private textureLoader = new THREE.TextureLoader();

  ngAfterViewInit(): void {
    this.initScene();
    this.buildBottle();
    this.animate();

    this.resizeObserver = new ResizeObserver(() => this.onResize());
    this.resizeObserver.observe(this.canvasRef.nativeElement.parentElement ?? this.canvasRef.nativeElement);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['producto'] && !changes['producto'].firstChange && this.scene) {
      this.buildBottle();
    }
  }

  ngOnDestroy(): void {
    if (this.frameId) cancelAnimationFrame(this.frameId);
    this.resizeObserver?.disconnect();
    this.renderer?.dispose();
    this.controls?.dispose();
  }

  private initScene(): void {
    const canvas = this.canvasRef.nativeElement;
    const { clientWidth, clientHeight } = canvas.parentElement ?? canvas;
    const width = clientWidth || 300;
    const height = clientHeight || 300;

    this.scene = new THREE.Scene();
    this.scene.background = null;

    this.camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    this.camera.position.set(0, 1.2, 6);

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    const luzAmbiente = new THREE.AmbientLight(0xffffff, 0.6);
    const luzPrincipal = new THREE.DirectionalLight(0xffffff, 1.2);
    luzPrincipal.position.set(3, 5, 4);
    const luzRelleno = new THREE.DirectionalLight(0xffffff, 0.4);
    luzRelleno.position.set(-4, 2, -3);
    this.scene.add(luzAmbiente, luzPrincipal, luzRelleno);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.minDistance = 3;
    this.controls.maxDistance = 10;
    this.controls.target.set(0, 1, 0);
  }

  /** Construye la geometría de la botella revolucionando un perfil 2D (silueta) sobre su eje. */
  private buildBottle(): void {
    if (this.bottleGroup) {
      this.scene.remove(this.bottleGroup);
      this.disposeGroup(this.bottleGroup);
    }

    this.bottleGroup = new THREE.Group();

    const perfil = [
      new THREE.Vector2(0, 0),
      new THREE.Vector2(0.55, 0),
      new THREE.Vector2(0.55, 0.15),
      new THREE.Vector2(0.5, 0.25),
      new THREE.Vector2(0.5, 1.6),
      new THREE.Vector2(0.42, 1.8),
      new THREE.Vector2(0.42, 2.05),
      new THREE.Vector2(0.16, 2.3),
      new THREE.Vector2(0.16, 2.65),
      new THREE.Vector2(0.2, 2.68),
    ];

    const nombreCategoria = (this.producto.categoria?.nombre ?? 'default').toLowerCase();
    const colorVidrio = COLOR_POR_CATEGORIA[nombreCategoria] ?? COLOR_POR_CATEGORIA['default'];

    const geometriaBotella = new THREE.LatheGeometry(perfil, 48);
    const materialVidrio = new THREE.MeshPhysicalMaterial({
      color: colorVidrio,
      roughness: 0.15,
      metalness: 0,
      transmission: 0.55,
      thickness: 0.6,
      transparent: true,
      opacity: 0.92,
      clearcoat: 0.4,
    });
    const botella = new THREE.Mesh(geometriaBotella, materialVidrio);
    botella.position.y = -1.3;

    const tapa = new THREE.Mesh(
      new THREE.CylinderGeometry(0.16, 0.18, 0.22, 24),
      new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.4, metalness: 0.3 })
    );
    tapa.position.y = -1.3 + 2.68 + 0.1;

    // Etiqueta: usa la imagen del producto si existe, si no genera una con el nombre.
    const etiqueta = new THREE.Mesh(
      new THREE.CylinderGeometry(0.505, 0.505, 0.9, 48, 1, true),
      new THREE.MeshStandardMaterial({
        map: this.crearTexturaEtiqueta(),
        transparent: true,
        side: THREE.DoubleSide,
        roughness: 0.6,
      })
    );
    etiqueta.position.y = -1.3 + 0.95;

    this.bottleGroup.add(botella, tapa, etiqueta);
    this.scene.add(this.bottleGroup);
  }

  private crearTexturaEtiqueta(): THREE.Texture {
    if (this.producto.imagen) {
      const textura = this.textureLoader.load(this.producto.imagen);
      textura.colorSpace = THREE.SRGBColorSpace;
      return textura;
    }

    // Fallback: genera una etiqueta con canvas mostrando el nombre del producto.
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#f5f1e8';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#2f2f2f';
    ctx.lineWidth = 6;
    ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);
    ctx.fillStyle = '#2f2f2f';
    ctx.textAlign = 'center';
    ctx.font = 'bold 36px sans-serif';
    ctx.fillText(this.producto.nombre, canvas.width / 2, 110, canvas.width - 60);
    ctx.font = '24px sans-serif';
    ctx.fillText(`Bs ${Number(this.producto.precio_venta).toFixed(2)}`, canvas.width / 2, 160);

    const textura = new THREE.CanvasTexture(canvas);
    textura.colorSpace = THREE.SRGBColorSpace;
    return textura;
  }

  private disposeGroup(group: THREE.Group): void {
    group.traverse((obj) => {
      if (obj instanceof THREE.Mesh) {
        obj.geometry.dispose();
        const materiales = Array.isArray(obj.material) ? obj.material : [obj.material];
        materiales.forEach((m) => m.dispose());
      }
    });
  }

  private animate = (): void => {
    this.frameId = requestAnimationFrame(this.animate);
    if (this.autoRotate) {
      this.bottleGroup.rotation.y += 0.006;
    }
    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  };

  private onResize(): void {
    const parent = this.canvasRef.nativeElement.parentElement ?? this.canvasRef.nativeElement;
    const { clientWidth, clientHeight } = parent;
    if (!clientWidth || !clientHeight) return;
    this.camera.aspect = clientWidth / clientHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(clientWidth, clientHeight);
  }
}
