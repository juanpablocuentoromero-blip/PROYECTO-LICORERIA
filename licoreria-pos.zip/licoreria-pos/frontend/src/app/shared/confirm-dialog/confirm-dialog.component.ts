import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfirmDialogService } from './confirm-dialog.service';

@Component({
  selector: 'app-confirm-dialog',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if (dialog.solicitud(); as s) {
      <div class="cd-fondo" (click)="cancelar()" role="presentation">
        <div class="cd-panel" (click)="$event.stopPropagation()" role="alertdialog" aria-modal="true">
          <div class="cd-icono" [class.cd-icono-peligro]="s.peligroso">
            @if (s.peligroso) {
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 9v4m0 4h.01M10.29 3.86l-8.18 14.18A2 2 0 0 0 4 21h16a2 2 0 0 0 1.89-2.96L13.71 3.86a2 2 0 0 0-3.42 0Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            } @else {
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 16v-4m0-4h.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            }
          </div>
          <h3>{{ s.titulo }}</h3>
          <p>{{ s.mensaje }}</p>
          <div class="cd-acciones">
            <button type="button" class="cd-btn-cancelar" (click)="cancelar()">{{ s.textoCancelar }}</button>
            <button type="button" class="cd-btn-confirmar" [class.cd-btn-peligro]="s.peligroso" (click)="confirmar()">{{ s.textoConfirmar }}</button>
          </div>
        </div>
      </div>
    }
  `,
  styles: [`
    .cd-fondo {
      position: fixed; inset: 0; background: rgba(1, 0, 26, 0.72);
      display: flex; align-items: center; justify-content: center; z-index: 200; padding: 16px;
      animation: cd-fade 0.12s ease;
    }
    .cd-panel {
      background: #EAFBFF; color: #020024; border-radius: 14px;
      padding: 26px 24px; max-width: 360px; width: 100%; text-align: center;
      box-shadow: 0 20px 50px rgba(0,0,0,0.35);
      animation: cd-pop 0.15s ease;
    }
    .cd-icono {
      width: 44px; height: 44px; border-radius: 50%; margin: 0 auto 14px;
      display: flex; align-items: center; justify-content: center;
      background: rgba(31, 54, 40, 0.12); color: #020024;
    }
    .cd-icono-peligro { background: rgba(166, 75, 42, 0.14); color: #d64545; }
    .cd-panel h3 { font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif; margin: 0 0 8px; font-size: 19px; }
    .cd-panel p { margin: 0 0 20px; color: #5a5040; font-size: 14px; line-height: 1.5; }
    .cd-acciones { display: flex; gap: 10px; justify-content: center; }
    .cd-acciones button {
      flex: 1; border-radius: 8px; padding: 10px 14px; font-size: 14px; font-weight: 700;
      cursor: pointer; border: none;
    }
    .cd-btn-cancelar { background: transparent; border: 1px solid #00D4FF !important; color: #5a5040; }
    .cd-btn-cancelar:hover { background: rgba(0,0,0,0.04); }
    .cd-btn-confirmar { background: #020024; color: #EAFBFF; }
    .cd-btn-confirmar:hover { background: #2c4536; }
    .cd-btn-peligro { background: #d64545; }
    .cd-btn-peligro:hover { background: #c1592f; }
    @keyframes cd-fade { from { opacity: 0; } to { opacity: 1; } }
    @keyframes cd-pop { from { transform: scale(0.94); opacity: 0; } to { transform: scale(1); opacity: 1; } }
  `],
})
export class ConfirmDialogComponent {
  dialog = inject(ConfirmDialogService);

  confirmar(): void { this.dialog.responder(true); }
  cancelar(): void { this.dialog.responder(false); }
}
