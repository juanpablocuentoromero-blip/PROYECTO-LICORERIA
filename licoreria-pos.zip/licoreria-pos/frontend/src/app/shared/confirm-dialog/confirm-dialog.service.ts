import { Injectable, signal } from '@angular/core';

export interface ConfirmOptions {
  titulo?: string;
  mensaje: string;
  textoConfirmar?: string;
  textoCancelar?: string;
  peligroso?: boolean; // pinta el botón de confirmar en rojo (acciones destructivas)
}

interface SolicitudConfirm extends Required<ConfirmOptions> {
  resolver: (valor: boolean) => void;
}

/**
 * Reemplazo del window.confirm() nativo del navegador (feo, no se puede
 * personalizar y en móvil se ve distinto en cada sistema). Se usa como:
 *
 *   const ok = await this.confirmDialog.confirm({ mensaje: '¿Eliminar a "Juan"?', peligroso: true });
 *   if (!ok) return;
 *
 * El modal en sí se renderiza una sola vez en el shell (app.html) mediante
 * <app-confirm-dialog />, que lee la señal `solicitud` de este servicio.
 */
@Injectable({ providedIn: 'root' })
export class ConfirmDialogService {
  solicitud = signal<SolicitudConfirm | null>(null);

  confirm(opciones: ConfirmOptions): Promise<boolean> {
    return new Promise((resolve) => {
      this.solicitud.set({
        titulo: opciones.titulo ?? '¿Estás seguro?',
        mensaje: opciones.mensaje,
        textoConfirmar: opciones.textoConfirmar ?? 'Sí, continuar',
        textoCancelar: opciones.textoCancelar ?? 'Cancelar',
        peligroso: opciones.peligroso ?? false,
        resolver: resolve,
      });
    });
  }

  responder(valor: boolean): void {
    const actual = this.solicitud();
    if (!actual) return;
    this.solicitud.set(null);
    actual.resolver(valor);
  }
}
