import { Component, input, output } from '@angular/core';

/** Barra Anterior / Página X de Y / Siguiente, reutilizable en todas las listas paginadas. */
@Component({
  selector: 'app-paginador',
  standalone: true,
  template: `
    @if (ultima() > 1) {
      <div class="paginacion">
        <button type="button" class="btn-secondary" (click)="cambiar.emit(actual() - 1)" [disabled]="actual() <= 1">← Anterior</button>
        <span>Página {{ actual() }} de {{ ultima() }} · {{ total() }} {{ etiqueta() }}</span>
        <button type="button" class="btn-secondary" (click)="cambiar.emit(actual() + 1)" [disabled]="actual() >= ultima()">Siguiente →</button>
      </div>
    }
  `,
  styles: [
    `
      .paginacion {
        display: flex;
        gap: 14px;
        align-items: center;
        justify-content: center;
        margin-top: 14px;
        flex-wrap: wrap;
        font-size: 13px;
      }
    `,
  ],
})
export class PaginadorComponent {
  actual = input.required<number>();
  ultima = input.required<number>();
  total = input<number>(0);
  etiqueta = input<string>('registros');
  cambiar = output<number>();
}
