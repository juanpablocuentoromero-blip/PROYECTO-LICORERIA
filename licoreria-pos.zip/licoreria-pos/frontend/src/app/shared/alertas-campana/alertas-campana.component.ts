import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AlertaService } from '../../core/services/alerta.service';
import { AuthService } from '../../core/services/auth.service';
import { Alerta } from '../../core/models/paso4.model';

/** 4.2 — Campana de alertas de stock mínimo y vencimiento (solo administrador). */
@Component({
  selector: 'app-alertas-campana',
  standalone: true,
  imports: [CommonModule],
  template: `
    <button type="button" class="campana" (click)="abrir()" [attr.aria-label]="'Alertas de inventario: ' + alertas.noLeidas() + ' sin leer'">
      <svg width="19" height="19" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M6 9a6 6 0 1 1 12 0c0 6 2.5 7.5 2.5 7.5h-17S6 15 6 9Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M10 20a2 2 0 0 0 4 0" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
      <span>Alertas</span>
      @if (alertas.noLeidas() > 0) { <span class="insignia">{{ alertas.noLeidas() }}</span> }
    </button>

    @if (abierto()) {
      <div class="fondo" (click)="cerrar()"></div>
      <section class="panel-alertas" role="dialog" aria-label="Alertas de inventario">
        <header>
          <strong>Alertas de inventario</strong>
          <button type="button" class="x" (click)="cerrar()" aria-label="Cerrar">✕</button>
        </header>

        <div class="barra">
          @if (esAdmin()) {
            <button type="button" (click)="revisar()" [disabled]="revisando()">{{ revisando() ? 'Revisando…' : '↻ Revisar ahora' }}</button>
          }
          @if (alertas.noLeidas() > 0) { <button type="button" (click)="alertas.leerTodas()">Marcar todas como leídas</button> }
        </div>
        @if (mensaje()) { <p class="msg">{{ mensaje() }}</p> }

        @if (alertas.alertas().length === 0) {
          <p class="vacio">Todo en orden: no hay productos bajo el mínimo ni por vencer.</p>
        } @else {
          <ul>
            @for (a of alertas.alertas(); track a.id) {
              <li [class.leida]="a.leida" [class.critica]="a.severidad === 'critica'">
                <span class="icono">{{ a.tipo === 'vencimiento' ? '⏳' : '📦' }}</span>
                <div class="cuerpo">
                  <strong>{{ a.titulo }}</strong>
                  <span>{{ a.mensaje }}</span>
                </div>
                @if (!a.leida) { <button type="button" class="leer" (click)="alertas.leer(a.id)" title="Marcar como leída">✓</button> }
              </li>
            }
          </ul>
        }

        @if (esAdmin()) {
          <footer><button type="button" (click)="irReposicion()">Ver sugerencia de reposición →</button></footer>
        } @else {
          <footer><span class="pie-vendedor">Avisa al administrador si falta algo por reponer.</span></footer>
        }
      </section>
    }
  `,
  styles: [`
    :host { display: block; }
    .campana { width: 100%; display: flex; align-items: center; gap: 10px; background: transparent; color: inherit; border: 0; padding: 10px 14px; cursor: pointer; font: inherit; text-align: left; border-radius: 8px; }
    .campana:hover { background: rgba(0, 212, 255, 0.1); }
    .insignia { margin-left: auto; background: #d64545; color: #fff; border-radius: 999px; font-size: 11px; padding: 1px 7px; font-weight: 700; }
    .fondo { position: fixed; inset: 0; z-index: 1190; }
    .panel-alertas { position: fixed; z-index: 1200; left: 16px; bottom: 96px; width: min(400px, calc(100vw - 32px)); max-height: 72vh; display: flex; flex-direction: column; background: #020024; color: #E8FBFF; border: 1px solid rgba(0, 212, 255, 0.45); border-radius: 12px; box-shadow: 0 12px 40px rgba(0, 0, 0, 0.55); }
    header { display: flex; justify-content: space-between; align-items: center; padding: 12px 14px; border-bottom: 1px solid rgba(0, 212, 255, 0.25); }
    .x { background: transparent; border: 0; color: inherit; cursor: pointer; font-size: 16px; }
    .barra { display: flex; gap: 8px; flex-wrap: wrap; padding: 10px 14px 0; }
    .barra button, footer button { background: rgba(0, 212, 255, 0.12); color: #66E5FF; border: 1px solid rgba(0, 212, 255, 0.35); border-radius: 7px; padding: 5px 10px; font-size: 12px; cursor: pointer; }
    .msg { margin: 8px 14px 0; font-size: 12px; color: #66E5FF; }
    .vacio { padding: 18px 14px; margin: 0; opacity: 0.8; font-size: 14px; }
    ul { list-style: none; margin: 10px 0 0; padding: 0 8px; overflow-y: auto; }
    li { display: flex; gap: 10px; align-items: flex-start; padding: 9px 8px; border-radius: 8px; border-left: 3px solid #e0a82e; margin-bottom: 6px; background: rgba(0, 212, 255, 0.06); }
    li.critica { border-left-color: #d64545; }
    li.leida { opacity: 0.55; }
    .cuerpo { display: flex; flex-direction: column; gap: 2px; font-size: 13px; flex: 1; min-width: 0; }
    .cuerpo span { opacity: 0.85; font-size: 12px; }
    .leer { background: transparent; border: 1px solid rgba(0, 212, 255, 0.4); color: #66E5FF; border-radius: 6px; cursor: pointer; width: 26px; height: 26px; }
    .pie-vendedor { font-size: 12px; color: #B3E8F5; }
    footer { padding: 10px 14px; border-top: 1px solid rgba(0, 212, 255, 0.25); }
  `],
})
export class AlertasCampanaComponent {
  alertas = inject(AlertaService);
  private router = inject(Router);
  private auth = inject(AuthService);
  esAdmin = () => this.auth.usuarioActual()?.rol === 'administrador';

  abierto = signal(false);
  revisando = signal(false);
  mensaje = signal('');

  abrir(): void {
    this.mensaje.set('');
    this.alertas.cargar();
    this.abierto.set(true);
  }

  cerrar(): void { this.abierto.set(false); }

  revisar(): void {
    this.revisando.set(true);
    this.alertas.revisar().subscribe({
      next: (r) => { this.mensaje.set(r.message); this.revisando.set(false); },
      error: () => { this.mensaje.set('No se pudo revisar.'); this.revisando.set(false); },
    });
  }

  irReposicion(): void {
    this.cerrar();
    this.router.navigate(['/reposicion']);
  }
}
