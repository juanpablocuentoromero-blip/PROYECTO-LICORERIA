import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { EdadService } from './edad.service';

@Component({
  selector: 'app-aviso-edad',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="edad-fondo" role="dialog" aria-modal="true" aria-labelledby="edad-titulo">
      <div class="edad-caja">
        <img class="logo" src="brand/logo-al-paso.png" alt="Licorería Al Paso" height="52" />

        @if (!edad.esMenor()) {
          <div class="sello">+18</div>
          <h2 id="edad-titulo">¿Eres mayor de 18 años?</h2>
          <p>
            Vendemos bebidas alcohólicas. Para ver la tienda debes ser mayor de edad.
            Al hacer tu pedido te pediremos confirmarlo otra vez y, al entregarlo,
            podemos pedirte tu documento.
          </p>
          <div class="botones">
            <button type="button" class="si" (click)="edad.confirmarMayor()">Sí, soy mayor de 18</button>
            <button type="button" class="no" (click)="edad.declararMenor()">No, soy menor</button>
          </div>
        } @else {
          <h2 id="edad-titulo">Lo sentimos</h2>
          <p>
            No podemos mostrarte esta tienda: la venta de bebidas alcohólicas está
            prohibida para menores de 18 años.
          </p>
          <div class="botones">
            <button type="button" class="no" (click)="edad.volverAPreguntar()">Me equivoqué, volver</button>
          </div>
        }

        <p class="staff">¿Eres parte del equipo? <a routerLink="/login">Ingresa aquí</a></p>
      </div>
    </div>
  `,
  styles: [`
    .edad-fondo {
      position: fixed; inset: 0; z-index: 2000;
      display: flex; align-items: center; justify-content: center; padding: 20px;
      background: radial-gradient(900px 500px at 50% 0%, rgba(0, 212, 255, 0.25), transparent 60%), #01001A;
    }
    .edad-caja {
      width: 100%; max-width: 420px; text-align: center;
      background: #EAFBFF; color: #020024; border: 1px solid #00D4FF; border-radius: 16px;
      padding: 28px 26px 24px; box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
      font-family: 'Open Sans', 'Segoe UI', system-ui, sans-serif;
    }
    .logo { display: block; margin: 0 auto 14px; }
    .sello {
      width: 64px; height: 64px; margin: 0 auto 10px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      background: #020024; color: #00D4FF; font-weight: 800; font-size: 22px;
      border: 3px solid #00D4FF;
    }
    h2 { margin: 0 0 8px; font-size: 22px; }
    p { margin: 0 0 18px; font-size: 14px; line-height: 1.5; color: #3b3f55; }
    .botones { display: flex; flex-direction: column; gap: 10px; }
    button {
      border: none; border-radius: 10px; padding: 12px 16px; font-size: 15px; font-weight: 700;
      cursor: pointer; font-family: inherit;
    }
    .si { background: #00D4FF; color: #020024; }
    .si:hover { filter: brightness(1.08); }
    .no { background: transparent; color: #020024; border: 1px solid #020024; }
    .no:hover { background: #DFF7FC; }
    .staff { margin: 18px 0 0; font-size: 12px; color: #6b6f85; }
    .staff a { color: #006A80; font-weight: 600; }
  `],
})
export class AvisoEdadComponent {
  edad = inject(EdadService);
}
