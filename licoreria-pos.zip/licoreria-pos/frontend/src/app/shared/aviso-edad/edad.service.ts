import { Injectable, signal } from '@angular/core';

const KEY = 'labodega_mayor_edad_ok';

/**
 * Aviso de +18 al entrar a la tienda (5.1).
 *
 * Es un aviso de cortesía/cumplimiento, no una verificación fuerte: guarda en
 * este navegador que el visitante declaró ser mayor de edad. La constancia
 * que sí queda en el sistema son las casillas obligatorias al crear la cuenta
 * y al hacer cada pedido (el servidor las exige).
 */
@Injectable({ providedIn: 'root' })
export class EdadService {
  confirmada = signal<boolean>(this.leer());
  /** true cuando el visitante dijo que es menor de edad. */
  esMenor = signal(false);

  private leer(): boolean {
    try {
      return localStorage.getItem(KEY) === '1';
    } catch {
      return false;
    }
  }

  confirmarMayor(): void {
    try {
      localStorage.setItem(KEY, '1');
    } catch {
      /* modo privado: queda solo en memoria */
    }
    this.esMenor.set(false);
    this.confirmada.set(true);
  }

  declararMenor(): void {
    this.esMenor.set(true);
  }

  volverAPreguntar(): void {
    this.esMenor.set(false);
  }
}
