// Estilos base compartidos por los módulos del panel administrativo.
// Se importan como string y se combinan con estilos propios de cada componente:
//   styles: [BASE_THEME, `/* estilos específicos */`]
//
// Sistema de diseño: neo-futurismo, paleta azul de marca.
// Los colores y la escala de espaciado viven en src/styles.css (:root);
// aquí solo se usan. Los valores después de la coma son respaldos por si
// una variable global no estuviera disponible.
export const BASE_THEME = `
  :host {
    /* Nombres de variable históricos apuntando al sistema de color actual,
       para que todo lo que ya usa var(--cobre) o var(--verde-botella)
       herede el color nuevo sin tocar cada componente uno por uno. */
    --verde-botella: var(--azul-marino, #020024);
    --verde-botella-oscuro: var(--azul-marino-oscuro, #01001A);
    --cobre: var(--azul-primario, #00D4FF);
    --cobre-claro: var(--azul-medio, #00D4FF);
    --papel: var(--crema, #EAFBFF);
    --papel-borde: var(--crema-borde, #00D4FF);
    --tinta: #020024;
    --rust: var(--peligro, #d64545);
    --verde-ok: var(--ok, #17a06b);
    --azul-claro: #66E5FF;

    /* Superficies reutilizadas por paneles, tablas y estados vacíos:
       una sola definición para que todo tenga el mismo material. */
    --superficie: linear-gradient(165deg, rgba(0, 212, 255, 0.14), rgba(2, 0, 36, 0.4));
    --superficie-borde: 1px solid rgba(0, 212, 255, 0.28);
    --alto-control: 38px;

    display: block;
    font-family: var(--fuente, 'Open Sans', 'Segoe UI', system-ui, sans-serif);
    color: var(--tinta);
    background:
      radial-gradient(1100px 480px at 100% -10%, rgba(0, 212, 255, 0.22), transparent 60%),
      radial-gradient(900px 420px at -10% 110%, rgba(0, 212, 255, 0.16), transparent 60%),
      var(--verde-botella);
    min-height: 100%;
    padding: var(--s-6, 32px) var(--s-6, 32px) var(--s-7, 48px);
  }

  /* El contenedor de la página reparte el espacio vertical con un único
     gap. Antes cada panel/título traía su propio margin y por eso las
     separaciones salían desparejas de una pantalla a otra. */
  .page {
    max-width: 1180px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    gap: var(--s-5, 24px);
    min-width: 0;
  }

  .page-header {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: var(--s-4, 16px);
    flex-wrap: wrap;
    margin: 0;
  }
  .eyebrow {
    font-size: 12px;
    letter-spacing: 0.16em;
    text-transform: uppercase;
    color: var(--azul-claro);
    margin-bottom: var(--s-2, 8px);
  }
  h1 {
    font-size: 32px;
    font-weight: 800;
    color: var(--papel);
    margin: 0 0 var(--s-1, 4px);
    letter-spacing: -0.02em;
  }
  .subtitle { color: #8FE0F2; font-size: 15px; margin: 0; }

  /* Título de sección dentro de un panel. Estaba repetido (con valores
     distintos) en varios componentes; aquí queda uno solo. */
  .panel-title {
    font-size: 19px;
    font-weight: 700;
    color: var(--papel);
    margin: 0 0 var(--s-4, 16px);
  }

  .panel {
    background: var(--superficie);
    border: var(--superficie-borde);
    border-radius: var(--radio-lg, 16px);
    padding: var(--s-5, 24px);
    margin: 0;
    box-shadow: var(--sombra-lg, 0 20px 44px rgba(0, 20, 45, 0.28));
    backdrop-filter: blur(6px);
    /* El host usa texto OSCURO (--tinta) pensado para tarjetas claras; los
       paneles son oscuros, así que su texto tiene que ser claro. Sin esto
       todo lo escrito dentro de un panel (gráficos, listas, caja) quedaba
       azul marino sobre azul marino. */
    color: var(--texto, #E8FBFF);
  }
  .panel p, .panel li, .panel span, .panel label, .panel small, .panel strong, .panel h4 { color: inherit; }
  .panel .form-error { color: #ff9d90; }
  .panel .form-ok { color: #7be0b0; }
  .panel a.link-action, .panel .link-action { color: var(--azul-claro); }

  /* --- Botones: todos con el mismo alto para que las filas de acciones
     queden alineadas y no escalonadas. --- */
  .btn-primary, .btn-secondary {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: var(--s-2, 8px);
    height: var(--alto-control);
    border-radius: var(--radio-md, 12px);
    font-weight: 700;
    cursor: pointer;
    white-space: nowrap;
  }
  .btn-primary {
    background: linear-gradient(120deg, var(--cobre), var(--cobre-claro));
    color: var(--tinta);
    border: none;
    padding: 0 var(--s-5, 24px);
    font-size: 14px;
    font-weight: 800;
    letter-spacing: 0.01em;
    box-shadow: 0 8px 20px rgba(0, 212, 255, 0.35);
    transition: box-shadow 0.15s ease, transform 0.1s ease, filter 0.15s ease;
  }
  .btn-primary:hover:not(:disabled) { filter: brightness(1.08); box-shadow: 0 10px 26px rgba(0, 212, 255, 0.5); }
  .btn-primary:active:not(:disabled) { transform: scale(0.98); }
  .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; box-shadow: none; }

  .btn-secondary {
    background: rgba(0, 212, 255, 0.08);
    color: var(--azul-claro);
    border: 1px solid rgba(0, 212, 255, 0.5);
    padding: 0 var(--s-4, 16px);
    font-size: 13px;
    font-weight: 600;
    transition: background 0.15s ease, border-color 0.15s ease;
  }
  .btn-secondary:hover { background: rgba(0, 212, 255, 0.16); border-color: var(--azul-claro); }

  /* --- Formularios --- */
  .field { display: flex; flex-direction: column; gap: var(--s-1, 4px); min-width: 0; }
  .field label { font-size: 13px; font-weight: 600; color: #00D4FF; }
  .field label span { font-weight: 400; color: #8FD3E6; }
  .field input, .field select, .field textarea {
    width: 100%;
    height: var(--alto-control);
    background: var(--papel);
    border: 1.5px solid var(--papel-borde);
    border-radius: var(--radio-md, 12px);
    padding: 0 var(--s-3, 12px);
    font-size: 14px;
    font-family: inherit;
    color: var(--tinta);
  }
  .field textarea {
    height: auto;
    min-height: 84px;
    padding: var(--s-2, 8px) var(--s-3, 12px);
    resize: vertical;
    line-height: 1.45;
  }
  .field input:focus, .field select:focus, .field textarea:focus {
    outline: 2px solid var(--cobre);
    outline-offset: 1px;
    border-color: var(--cobre);
  }
  .field-row { display: flex; align-items: center; gap: var(--s-3, 12px); flex-wrap: wrap; }
  .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: var(--s-4, 16px); align-items: end; }
  .form-error { color: #ff9d90; font-size: 13px; }
  .form-ok { color: #7be0b0; font-size: 13px; }

  /* --- Tablas ---
     Las listas se dibujaban sueltas sobre el fondo, mientras los
     formularios sí iban dentro de un panel. Ahora la tabla es una
     tarjeta con el mismo material que .panel, y las dos cosas se ven
     como parte del mismo sistema. */
  table { width: 100%; }
  /* Solo las tablas de listado (las que no traen clase propia) toman el
     aspecto de tarjeta. Las que sí la traen —.grid, .tabla-den,
     .carrito-tabla— tienen su propio diseño claro y no se tocan. */
  table:not([class]) {
    border-collapse: separate;
    border-spacing: 0;
    background: var(--superficie);
    border: var(--superficie-borde);
    border-radius: var(--radio-lg, 16px);
    box-shadow: var(--sombra-lg, 0 20px 44px rgba(0, 20, 45, 0.28));
    overflow: hidden;
  }
  thead th {
    text-align: left;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: var(--azul-claro);
    background: rgba(0, 0, 18, 0.35);
    padding: var(--s-3, 12px) var(--s-4, 16px);
    border-bottom: 1px solid rgba(0, 212, 255, 0.25);
    white-space: nowrap;
  }
  tbody td {
    padding: var(--s-3, 12px) var(--s-4, 16px);
    font-size: 14px;
    color: var(--papel);
    border-bottom: 1px solid rgba(0, 212, 255, 0.12);
    vertical-align: middle;
  }
  tbody tr:last-child td { border-bottom: none; }
  tbody tr { transition: background 0.12s ease; }
  tbody tr:hover { background: rgba(0, 212, 255, 0.07); }

  .badge {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    padding: 4px 10px;
    border-radius: var(--radio-pill, 999px);
    display: inline-block;
    white-space: nowrap;
  }
  .badge-ok { color: #0b3a26; background: #8fe6bd; }
  .badge-off { color: #020024; background: #DFF7FC; }
  .badge-warn { color: #4a2f0a; background: #f3c988; }
  .badge-danger { color: #fff; background: var(--rust); }
  .badge-info { color: #020024; background: var(--azul-claro); }

  .link-danger, .link-action {
    background: none;
    border: none;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    padding: 0;
    margin-right: var(--s-3, 12px);
    white-space: nowrap;
  }
  .link-danger { color: var(--rust); }
  .link-action { color: var(--azul-claro); }
  .link-danger:hover, .link-action:hover { text-decoration: underline; }

  /* Estado vacío / cargando: también como tarjeta, para que la pantalla
     no se vea "rota" cuando todavía no hay datos. */
  .estado-vacio {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: var(--s-7, 48px) var(--s-5, 24px);
    background: var(--superficie);
    border: var(--superficie-borde);
    border-radius: var(--radio-lg, 16px);
    color: #5FB8CC;
    text-align: center;
    gap: var(--s-2, 8px);
  }
  .estado-vacio p { font-size: 16px; font-weight: 600; color: #00D4FF; margin: 0; }
  .estado-vacio span { font-size: 13px; color: #8FE0F2; }

  .spinner {
    width: 28px; height: 28px;
    border: 3px solid rgba(0, 212, 255, 0.25);
    border-top-color: var(--azul-claro);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    margin-bottom: var(--s-2, 8px);
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  .card-plain {
    color: var(--tinta, #020024);
    background: var(--papel);
    border: 1.5px solid var(--papel-borde);
    border-radius: var(--radio-md, 12px);
    padding: var(--s-4, 16px);
  }

  @media (max-width: 900px) {
    :host { padding: var(--s-5, 24px) var(--s-5, 24px) var(--s-6, 32px); }
    h1 { font-size: 27px; }
  }

  @media (max-width: 560px) {
    :host { padding: var(--s-5, 24px) var(--s-4, 16px) var(--s-6, 32px); }
    .page { gap: var(--s-4, 16px); }
    .panel { padding: var(--s-4, 16px); }
    h1 { font-size: 24px; }

    /* Cada fila pasa a ser una tarjeta con su propia etiqueta al costado,
       en vez de una tabla imposible de leer en el celular. */
    table:not([class]) {
      display: block;
      background: none;
      border: none;
      box-shadow: none;
      border-radius: 0;
      overflow: visible;
    }
    table:not([class]) thead { display: none; }
    table:not([class]) tbody { display: block; }
    table:not([class]) tbody tr {
      display: block;
      margin-bottom: var(--s-3, 12px);
      background: var(--superficie);
      border: var(--superficie-borde);
      border-radius: var(--radio-md, 12px);
      overflow: hidden;
    }
    table:not([class]) tbody tr:last-child { margin-bottom: 0; }
    table:not([class]) tbody td {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: var(--s-3, 12px);
      padding: 10px var(--s-3, 12px);
      border-bottom: 1px solid rgba(0, 212, 255, 0.1);
      text-align: right;
    }
    table:not([class]) tbody tr td:last-child { border-bottom: none; }
    table:not([class]) tbody td::before {
      content: attr(data-label);
      font-weight: 600;
      font-size: 12px;
      color: var(--azul-claro);
      text-align: left;
      flex-shrink: 0;
    }
  }
`;
