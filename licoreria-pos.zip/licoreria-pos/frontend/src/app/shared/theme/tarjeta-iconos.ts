// Iconos SVG minimalistas de las marcas de tarjeta (no son los logos
// oficiales con derechos reservados, son una representación genérica de
// "dos círculos" / "VISA" para dar contexto visual junto al método de pago).
export const ICONO_MASTERCARD = `
<svg width="28" height="18" viewBox="0 0 28 18" xmlns="http://www.w3.org/2000/svg" aria-label="Mastercard">
  <rect width="28" height="18" rx="3" fill="#16233a"/>
  <circle cx="11.5" cy="9" r="5.4" fill="#eb001b"/>
  <circle cx="16.5" cy="9" r="5.4" fill="#f79e1b" fill-opacity="0.95"/>
  <path d="M14 4.4a5.4 5.4 0 0 1 0 9.2 5.4 5.4 0 0 1 0-9.2Z" fill="#ff5f00"/>
</svg>`;

export const ICONO_VISA = `
<svg width="28" height="18" viewBox="0 0 28 18" xmlns="http://www.w3.org/2000/svg" aria-label="Visa">
  <rect width="28" height="18" rx="3" fill="#1a1f71"/>
  <text x="14" y="12.5" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-size="8" font-style="italic" font-weight="700" fill="#ffffff">VISA</text>
</svg>`;

export const TARJETA_ICONOS = `${ICONO_MASTERCARD}${ICONO_VISA}`;
