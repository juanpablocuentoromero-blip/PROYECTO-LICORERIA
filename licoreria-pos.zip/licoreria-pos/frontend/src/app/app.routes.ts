import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { adminGuard } from './core/guards/admin.guard';
import { clienteOStaffGuard } from './core/guards/cliente-o-staff.guard';
import { clienteGuard } from './core/guards/cliente.guard';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./features/login/login.component').then((m) => m.LoginComponent),
  },
  {
    path: 'acceso',
    loadComponent: () =>
      import('./features/acceso-cliente/acceso-cliente.component').then((m) => m.AccesoClienteComponent),
  },
  {
    path: 'olvide-password',
    loadComponent: () =>
      import('./features/olvide-password/olvide-password.component').then((m) => m.OlvidePasswordComponent),
  },
  {
    path: 'restablecer-password',
    loadComponent: () =>
      import('./features/restablecer-password/restablecer-password.component').then(
        (m) => m.RestablecerPasswordComponent,
      ),
  },
  {
    // Público: cualquier visitante puede navegar el catálogo sin cuenta.
    path: 'catalogo',
    loadComponent: () =>
      import('./features/catalogo/catalogo.component').then((m) => m.CatalogoComponent),
  },
  {
    // Al abrir un producto puntual se exige sesión (cliente o staff);
    // si no hay ninguna, el guard manda a /acceso a crear cuenta o entrar.
    path: 'catalogo/:id',
    canActivate: [clienteOStaffGuard],
    loadComponent: () =>
      import('./features/catalogo/producto-detalle.component').then((m) => m.ProductoDetalleComponent),
  },
  {
    // Perfil del personal (vendedor o administrador): cualquiera de los dos
    // roles puede ver/editar sus propios datos, no hace falta ser admin.
    path: 'mi-perfil',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/perfil-usuario/perfil-usuario.component').then((m) => m.PerfilUsuarioComponent),
  },
  {
    // Solo el cliente dueño de la sesión ve su propio perfil/pedidos.
    path: 'perfil',
    canActivate: [clienteGuard],
    loadComponent: () =>
      import('./features/perfil-cliente/perfil-cliente.component').then((m) => m.PerfilClienteComponent),
  },
  {
    // Solo administrador: estructura del catálogo, no operación diaria.
    path: 'categorias',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./features/categorias/categorias.component').then((m) => m.CategoriasComponent),
  },
  {
    // Solo administrador: alta, edición y baja de productos del catálogo.
    path: 'productos',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./features/productos/productos.component').then((m) => m.ProductosComponent),
  },
  {
    path: 'clientes',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/clientes/clientes.component').then((m) => m.ClientesComponent),
  },
  {
    // Solo administrador: gestión de cuentas del personal.
    path: 'usuarios',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./features/usuarios/usuarios.component').then((m) => m.UsuariosComponent),
  },
  {
    // Punto de venta: escáner de código de barras + F2 para cobrar. Lo usan
    // administrador y vendedor (la API valida el resto).
    path: 'venta',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/venta/venta.component').then((m) => m.VentaComponent),
  },
  {
    path: 'pedidos',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/pedidos/pedidos.component').then((m) => m.PedidosComponent),
  },
  {
    // Administrador y vendedor pueden CONSULTAR inventario (stock,
    // historial de movimientos); registrar ajustes de stock sigue siendo
    // exclusivo de administrador (lo filtra el propio componente).
    path: 'inventario',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/inventario/inventario.component').then((m) => m.InventarioComponent),
  },
  {
    // Administrador y vendedor pueden CONSULTAR almacenes; crear/editar/
    // borrar sigue siendo exclusivo de administrador (lo filtra el propio
    // componente).
    path: 'almacenes',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/almacenes/almacenes.component').then((m) => m.AlmacenesComponent),
  },
  {
    // El vendedor entra a ver si la caja está abierta (sin montos, ver
    // CajaController::actual); abrir/cerrar turno e histórico son acciones
    // que la propia API ya restringe a administrador (blindaje de caja).
    path: 'caja',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/caja/caja.component').then((m) => m.CajaComponent),
  },
  {
    // Solo administrador: compras a proveedores/distribuidores.
    path: 'proveedores',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./features/proveedores/proveedores.component').then((m) => m.ProveedoresComponent),
  },
  {
    // Solo administrador: reponer stock vía pedidos de compra.
    path: 'pedidos-compra',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./features/pedidos-compra/pedidos-compra.component').then((m) => m.PedidosCompraComponent),
  },
  {
    // Solo administrador: histórico consolidado de todas las ventas pagadas.
    path: 'libro-ventas',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./features/libro-ventas/libro-ventas.component').then((m) => m.LibroVentasComponent),
  },
  {
    // Solo administrador: exporta datos sensibles del negocio.
    path: 'reportes',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./features/reportes/reportes.component').then((m) => m.ReportesComponent),
  },
  {
    // Fiado: administrador y vendedor ven deudas y registran abonos (el cobro
    // entra al arqueo de la caja abierta); anular un abono es solo admin
    // (lo valida la API).
    path: 'cuentas-por-cobrar',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/cuentas-por-cobrar/cuentas-por-cobrar.component').then(
        (m) => m.CuentasPorCobrarComponent,
      ),
  },
  {
    // Descuentos por volumen, horario y cupones: el administrador los gestiona;
    // el vendedor solo los consulta (la pantalla se muestra sin formularios).
    path: 'promociones',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/promociones/promociones.component').then((m) => m.PromocionesComponent),
  },
  {
    // Zonas de reparto y repartidores: el administrador las gestiona; el
    // vendedor las consulta (costo de envío y teléfono del repartidor).
    path: 'delivery',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/delivery/delivery.component').then((m) => m.DeliveryComponent),
  },
  {
    // Paso 4.1 — Inicio con los indicadores del día: administrador y vendedor
    // (al vendedor la API le oculta los montos de caja).
    path: 'dashboard',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/dashboard/dashboard.component').then((m) => m.DashboardComponent),
  },
  {
    // Paso 4.3 — Solo administrador: sugerencia de reposición y borradores de compra.
    path: 'reposicion',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./features/reposicion/reposicion.component').then((m) => m.ReposicionComponent),
  },
  {
    // Paso 4.4 — Solo administrador: quién cambió qué y cuándo.
    path: 'auditoria',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./features/auditoria/auditoria.component').then((m) => m.AuditoriaComponent),
  },
  {
    // Paso 4.5 — Solo administrador: historial de ventas, anulación y devoluciones.
    path: 'ventas-registradas',
    canActivate: [adminGuard],
    loadComponent: () =>
      import('./features/ventas-registradas/ventas-registradas.component').then(
        (m) => m.VentasRegistradasComponent,
      ),
  },
  { path: '', redirectTo: 'catalogo', pathMatch: 'full' },
  { path: '**', redirectTo: 'catalogo' },
];
