<?php

use App\Http\Controllers\AlertaController;
use App\Http\Controllers\AlmacenController;
use App\Http\Controllers\AuditoriaController;
use App\Http\Controllers\AuthClienteController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CajaController;
use App\Http\Controllers\CategoriaController;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\ComboController;
use App\Http\Controllers\CuentasPorCobrarController;
use App\Http\Controllers\FidelizacionController;
use App\Http\Controllers\InventarioAjusteController;
use App\Http\Controllers\LoteController;
use App\Http\Controllers\MovimientoCajaChicaController;
use App\Http\Controllers\MovimientoInventarioController;
use App\Http\Controllers\PedidoCompraController;
use App\Http\Controllers\PasswordRecuperacionController;
use App\Http\Controllers\PedidoController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\ProveedorController;
use App\Http\Controllers\PromocionController;
use App\Http\Controllers\ReposicionController;
use App\Http\Controllers\RepartidorController;
use App\Http\Controllers\ReporteController;
use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\VentaController;
use App\Http\Controllers\ZonaDeliveryController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Rutas públicas (sin sesión)
|--------------------------------------------------------------------------
| El catálogo (productos y categorías) es de lectura pública a propósito:
| cualquier visitante de la tienda puede ver qué hay y cuánto cuesta sin
| iniciar sesión. El SPA es quien exige login/registro cuando el visitante
| intenta entrar al detalle de un producto (ver AccesoClienteComponent /
| clienteGuard en el frontend); a nivel de API la lectura sigue abierta
| porque no expone nada sensible (precio y stock ya son públicos en el
| listado). Los combos también aparecen aquí: se venden como un producto
| más (ver Producto::combo() / ComboController).
*/
// throttle:5,1 = máximo 5 intentos por minuto, por IP+ruta (lo cuenta
// Laravel automáticamente). Al superarlo responde 429 "Too Many Attempts"
// en vez de dejar que sigan probando contraseñas sin límite.
Route::post('auth/login', [AuthController::class, 'login'])
    ->middleware('throttle:5,1');
Route::post('cliente/registro', [AuthClienteController::class, 'registro'])
    ->middleware('throttle:5,1');
Route::post('cliente/login', [AuthClienteController::class, 'login'])
    ->middleware('throttle:5,1');

// "Olvidé mi contraseña": sirve tanto para el staff (tipo=usuario) como
// para clientes de la tienda (tipo=cliente); ver PasswordRecuperacionController.
// También limitada: cada solicitud dispara un correo, así que sin esto se
// podría usar para bombardear de correos a cualquier email.
Route::post('password/olvide', [PasswordRecuperacionController::class, 'solicitar'])
    ->middleware('throttle:5,1');
Route::post('password/restablecer', [PasswordRecuperacionController::class, 'restablecer'])
    ->middleware('throttle:5,1');

Route::get('productos', [ProductoController::class, 'index']);
Route::get('productos/{producto}', [ProductoController::class, 'show']);
Route::get('categorias', [CategoriaController::class, 'index']);
Route::get('categorias/{categoria}', [CategoriaController::class, 'show']);

// Zonas de reparto activas (con su costo de envío): el checkout de la tienda
// las muestra antes de que el cliente confirme el pedido (5.2).
Route::get('zonas-delivery', [ZonaDeliveryController::class, 'index']);

// Ruta pública firmada: Twilio (WhatsApp) descarga la factura desde sus
// propios servidores, sin sesión de usuario, así que no puede pasar por el
// middleware auth.usuario. La "firma" (signed URL) es lo que evita que
// cualquiera adivine la URL de la factura de otro pedido.
Route::get('pedidos/{pedido}/factura-pdf', [PedidoController::class, 'facturaPdfPublica'])
    ->name('pedidos.factura-pdf-publica');

/*
|--------------------------------------------------------------------------
| Rutas del CLIENTE (cuenta propia en la tienda pública)
|--------------------------------------------------------------------------
*/
Route::middleware('auth.cliente')->prefix('cliente')->group(function () {
    Route::post('logout', [AuthClienteController::class, 'logout']);
    Route::get('me', [AuthClienteController::class, 'me']);
    Route::put('perfil', [AuthClienteController::class, 'actualizarPerfil']);
    Route::get('mis-pedidos', [PedidoController::class, 'misPedidos']);
    // 6.4: saldo y movimientos de puntos del cliente.
    Route::get('puntos', [FidelizacionController::class, 'misPuntos']);
    Route::post('pedidos', [PedidoController::class, 'crearComoCliente']);
    // Vista previa de descuentos/cupón del carrito (5.4); el pedido real recalcula todo.
    Route::post('promociones/calcular', [PromocionController::class, 'calcular']);
    Route::get('pedidos/{pedido}/qr', [PedidoController::class, 'qrCliente']);
    // El cliente corrige los productos de su pedido mientras siga «pendiente».
    Route::put('pedidos/{pedido}/items', [PedidoController::class, 'clienteEditarItems']);
});

/*
|--------------------------------------------------------------------------
| Rutas del STAFF (usuarios internos: administrador y vendedor)
|--------------------------------------------------------------------------
| Todo lo que sigue exige un token de "usuarios" válido (middleware
| auth.usuario). Dentro de este grupo:
|
| - El grupo "solo administrador" (middleware rol:administrador) es el
|   control total del negocio: inventarios, almacenes, compras a
|   proveedores, caja central (apertura/cierre/histórico/totales),
|   reportes, gestión de productos (incluye precios) y de usuarios,
|   combos/promociones y autorización de mermas (movimientos de
|   inventario tipo "salida").
|
| - El resto del grupo (sin rol:administrador) es el módulo de VENTA
|   DIRECTA, el único al que el vendedor tiene acceso: catálogo (lectura,
|   ya público arriba), datos del cliente para la factura, elegir método
|   de pago y cerrar la venta. El vendedor NO puede modificar precios, NI
|   ver el total acumulado de caja (blindaje, ver CajaController::actual),
|   NI tocar inventarios, compras a distribuidores o reportes.
*/
Route::middleware('auth.usuario')->group(function () {
    Route::post('auth/logout', [AuthController::class, 'logout']);
    Route::get('auth/me', [AuthController::class, 'me']);
    Route::put('auth/perfil', [AuthController::class, 'actualizarPerfil']);

    // ============================================================
    // SOLO ADMINISTRADOR — control total del sistema
    // ============================================================
    Route::middleware('rol:administrador')->group(function () {
        // Usuarios y categorías: configuración estructural.
        Route::apiResource('usuarios', UsuarioController::class);
        // 6.4: corregir/regalar puntos a mano (queda en auditoría y en el libro de puntos).
        Route::post('clientes/{cliente}/puntos/ajuste', [FidelizacionController::class, 'ajustar']);
        Route::post('categorias', [CategoriaController::class, 'store']);
        Route::put('categorias/{categoria}', [CategoriaController::class, 'update']);
        Route::patch('categorias/{categoria}', [CategoriaController::class, 'update']);
        Route::delete('categorias/{categoria}', [CategoriaController::class, 'destroy']);

        // Gestión de productos y precios: crear/editar/borrar. El vendedor
        // solo puede LEER el catálogo (rutas públicas de arriba) para
        // escanear/buscar al vender, nunca modificarlo.
        Route::post('productos', [ProductoController::class, 'store']);
        Route::put('productos/{producto}', [ProductoController::class, 'update']);
        Route::patch('productos/{producto}', [ProductoController::class, 'update']);
        Route::delete('productos/{producto}', [ProductoController::class, 'destroy']);

        // Combos/promociones (ej. "botella + hielo + gaseosa"): crearlos es
        // una decisión de negocio (afecta precios y stock), exclusiva del
        // administrador.
        Route::apiResource('combos', ComboController::class);

        // Descuentos y promociones con reglas (5.4), zonas y repartidores (5.2).
        // (index/show los ve también el vendedor: están más abajo, en el grupo compartido)
        Route::apiResource('promociones', PromocionController::class)->except(['index', 'show'])->parameters(['promociones' => 'promocion']);
        Route::post('zonas-delivery', [ZonaDeliveryController::class, 'store']);
        Route::put('zonas-delivery/{zona}', [ZonaDeliveryController::class, 'update']);
        Route::patch('zonas-delivery/{zona}', [ZonaDeliveryController::class, 'update']);
        Route::delete('zonas-delivery/{zona}', [ZonaDeliveryController::class, 'destroy']);
        Route::post('repartidores', [RepartidorController::class, 'store']);
        Route::put('repartidores/{repartidor}', [RepartidorController::class, 'update']);
        Route::patch('repartidores/{repartidor}', [RepartidorController::class, 'update']);
        Route::delete('repartidores/{repartidor}', [RepartidorController::class, 'destroy']);

        // Fiado (5.3): anular un abono y exportar el reporte son del administrador.
        Route::post('cuentas-por-cobrar/abonos/{abono}/anular', [CuentasPorCobrarController::class, 'anularAbono']);
        Route::get('reportes/cuentas-por-cobrar', [ReporteController::class, 'cuentasPorCobrar']);

        // Inventario: autorizar mermas (un movimiento tipo "salida" con
        // motivo, p.ej. botellas rotas) es exclusivo del administrador. Ver
        // el historial (index/show) es de lectura y vive en el grupo
        // compartido de abajo: el vendedor puede consultarlo, no tocarlo.
        Route::apiResource('movimientos-inventario', MovimientoInventarioController::class)
            ->only(['store']);

        // Ajustes de inventario por conteo físico (ve la diferencia, deja
        // movimiento marcado como ajuste + auditoría).
        Route::get('inventario/ajustes', [InventarioAjusteController::class, 'index']);
        Route::post('inventario/ajustes', [InventarioAjusteController::class, 'store']);

        // Almacenes: crear/editar/borrar es exclusivo del administrador.
        // Listar/ver (lectura) vive en el grupo compartido de abajo.
        Route::post('almacenes', [AlmacenController::class, 'store']);
        Route::put('almacenes/{almacen}', [AlmacenController::class, 'update']);
        Route::patch('almacenes/{almacen}', [AlmacenController::class, 'update']);
        Route::delete('almacenes/{almacen}', [AlmacenController::class, 'destroy']);

        // Proveedores y compras a distribuidores: registrar entrada de
        // mercancía es una acción especial exclusiva del administrador.
        Route::apiResource('proveedores', ProveedorController::class);
        Route::apiResource('pedidos-compra', PedidoCompraController::class)->parameters(['pedidos-compra' => 'pedido_compra']);
        Route::post('pedidos-compra/{pedidoCompra}/recibir', [PedidoCompraController::class, 'recibir']);

        // Reportes de ganancias/ventas/inventario/clientes: solo admin.
        Route::get('reportes/rentabilidad', [ReporteController::class, 'rentabilidad']);
        Route::get('reportes/ventas', [ReporteController::class, 'ventas']);
        Route::get('reportes/inventario', [ReporteController::class, 'inventario']);
        Route::get('reportes/movimientos', [ReporteController::class, 'movimientos']);
        Route::get('reportes/clientes', [ReporteController::class, 'clientes']);
        Route::get('reportes/libro-ventas', [ReporteController::class, 'libroVentas']);
        Route::get('reportes/compras', [ReporteController::class, 'compras']);
        Route::get('reportes/compras-excel', [ReporteController::class, 'comprasExcel']);
        Route::get('reportes/cajas-excel', [ReporteController::class, 'cajasExcel']);

        // ============================================================
        // PASO 4 — Funcionalidades nuevas (solo administrador)
        // ============================================================
        // 4.2 Alertas de stock mínimo y vencimiento (la campana del panel).
        // "Revisar ahora" avisa por correo/WhatsApp al dueño: solo administrador.
        // Ver y marcar como leídas las alertas lo hace también el vendedor (más abajo).
        Route::post('alertas/revisar', [AlertaController::class, 'revisar']);

        // 4.3 Sugerencia de reposición + borradores de pedido de compra.
        Route::get('reposicion/sugerencias', [ReposicionController::class, 'sugerencias']);
        Route::post('reposicion/generar-borradores', [ReposicionController::class, 'generarBorradores']);

        // 4.4 Auditoría e historial de precios.
        Route::get('auditoria', [AuditoriaController::class, 'index']);
        Route::get('productos/{producto}/historial-precios', [ProductoController::class, 'historialPrecios']);

        // 4.5 Devoluciones parciales / nota de crédito. Igual que anular una
        // venta, mueve dinero y stock: es del administrador.
        Route::get('ventas', [VentaController::class, 'index']);
        Route::get('ventas/{venta}', [VentaController::class, 'show'])->whereNumber('venta');
        Route::post('ventas/{venta}/anular', [VentaController::class, 'anular'])->whereNumber('venta');
        Route::post('ventas/{venta}/devolucion', [VentaController::class, 'devolver'])->whereNumber('venta');
        Route::get('devoluciones/{devolucion}/nota-pdf', [VentaController::class, 'notaCreditoPdf']);

        // Caja Central: histórico completo y arqueo en PDF de cualquier caja
        // pasada. Cerrar el turno se movió al grupo compartido de abajo: el
        // vendedor abre y cierra su propio turno igual que el administrador
        // (solo ve sus propias ventas al hacerlo, ver CajaController::actual).
        Route::get('caja', [CajaController::class, 'index']);
        Route::get('caja/{caja}/arqueo-pdf', [CajaController::class, 'arqueoPdf']);
    });

    // ============================================================
    // ADMINISTRADOR Y VENDEDOR — módulo de Venta Directa (caja) +
    // consulta de inventario/almacenes + abrir turno de caja
    // ============================================================
    // El vendedor: escanea productos (lectura, ya pública arriba), abre su
    // turno de caja, vende, ve pedidos/ventas (sin poder cancelarlos) y
    // consulta inventario/almacenes en solo lectura.

    // 4.1 Inicio (dashboard): lo ven administrador y vendedor. Para el
    // vendedor el controlador oculta los montos de caja (blindaje de caja).
    Route::get('reportes/dashboard', [ReporteController::class, 'dashboard']);

    // Clientes: dar de alta / actualizar datos (NIT/CI) para la factura.
    Route::apiResource('clientes', ClienteController::class)->except(['destroy']);

    // 6.4 Fidelización: el cajero consulta saldo y cuánto puede canjear.
    Route::get('fidelizacion/config', [FidelizacionController::class, 'configuracion']);
    Route::get('clientes/{cliente}/puntos', [FidelizacionController::class, 'puntos']);

    // Abrir y cerrar turno: cualquiera de los dos roles puede hacerlo (el que
    // llegue primero a trabajar abre la caja, y quien esté trabajando la
    // cierra al terminar su turno, sin depender de que el admin esté
    // presente). El detalle de totales de todo el negocio sigue reservado
    // al administrador (blindaje de caja, ver CajaController::actual).
    Route::post('caja/abrir', [CajaController::class, 'abrir']);
    Route::post('caja/{caja}/cerrar', [CajaController::class, 'cerrar']);

    // Caja chica (ingresos/egresos fuera de la venta): el vendedor la usa
    // para gastos/ingresos chicos del día a día (hielo, cambio, un
    // encargo) sin depender de que el administrador esté presente.
    // MovimientoCajaChicaController ya filtraba por usuario_id para el
    // vendedor (ver index()/autorizarPropio()); solo faltaba abrir estas
    // rutas, antes atrapadas en el grupo exclusivo de administrador de
    // arriba. Eliminar sigue siendo exclusivo de administrador.
    Route::get('caja-chica/resumen', [MovimientoCajaChicaController::class, 'resumen']);
    // Reporte de caja chica (el vendedor solo ve lo suyo): ANTES de caja-chica/{movimiento}.
    Route::get('caja-chica/reporte', [MovimientoCajaChicaController::class, 'reporte']);
    Route::get('caja-chica/reporte-excel', [MovimientoCajaChicaController::class, 'reporteExcel']);
    Route::get('caja-chica', [MovimientoCajaChicaController::class, 'index']);
    Route::get('caja-chica/{movimiento}', [MovimientoCajaChicaController::class, 'show']);
    Route::get('caja-chica/{movimiento}/recibo-pdf', [MovimientoCajaChicaController::class, 'reciboPdf']);
    Route::post('caja-chica', [MovimientoCajaChicaController::class, 'store']);
    Route::put('caja-chica/{movimiento}', [MovimientoCajaChicaController::class, 'update']);
    Route::patch('caja-chica/{movimiento}', [MovimientoCajaChicaController::class, 'update']);
    Route::delete('caja-chica/{movimiento}', [MovimientoCajaChicaController::class, 'destroy'])
        ->middleware('rol:administrador');

    // Inventario y almacenes: el vendedor puede CONSULTAR (ver stock,
    // historial de movimientos, almacenes) pero no crear/editar/borrar
    // nada de esto — esas rutas siguen exclusivas de administrador arriba.
    Route::get('movimientos-inventario', [MovimientoInventarioController::class, 'index']);
    Route::get('movimientos-inventario/{movimientos_inventario}', [MovimientoInventarioController::class, 'show']);
    Route::get('almacenes', [AlmacenController::class, 'index']);
    Route::get('almacenes/{almacen}', [AlmacenController::class, 'show']);

    // Alertas de stock mínimo y vencimiento (la campana): las ve y las marca
    // como leídas el administrador y el vendedor. Revisar/forzar avisos: solo admin.
    Route::get('alertas', [AlertaController::class, 'index']);
    Route::post('alertas/leer-todas', [AlertaController::class, 'leerTodas']);
    Route::post('alertas/{alerta}/leer', [AlertaController::class, 'leer']);

    // Promociones: el vendedor las CONSULTA (para decirle al cliente qué descuento
    // aplica); crear, editar o borrar sigue siendo solo del administrador.
    Route::get('promociones', [PromocionController::class, 'index']);
    Route::get('promociones/{promocion}', [PromocionController::class, 'show']);

    // Lotes (fecha de vencimiento por lote): consulta para admin y vendedor.
    Route::get('lotes', [LoteController::class, 'index']);

    // Punto de venta (pantalla de Venta): el lector de código de barras
    // consulta productos y clientes, y F2 registra la venta completa.
    // Estas rutas fijas van ANTES de cualquier ventas/{venta}.
    Route::get('repartidores', [RepartidorController::class, 'index']);
    Route::get('ventas/contexto', [VentaController::class, 'contexto']);
    Route::post('ventas/promociones', [PromocionController::class, 'calcular']);

    // Cuentas por cobrar / fiado (5.3): administrador y vendedor ven deudas y
    // registran abonos (el cobro entra al arqueo de la caja abierta).
    Route::get('cuentas-por-cobrar', [CuentasPorCobrarController::class, 'index']);
    Route::get('cuentas-por-cobrar/clientes/{cliente}', [CuentasPorCobrarController::class, 'cliente']);
    Route::get('cuentas-por-cobrar/clientes/{cliente}/estado-pdf', [CuentasPorCobrarController::class, 'estadoCuentaPdf']);
    Route::post('cuentas-por-cobrar/abonos', [CuentasPorCobrarController::class, 'abonar']);
    Route::get('ventas/buscar-producto', [VentaController::class, 'buscarProducto']);
    Route::get('ventas/cliente', [VentaController::class, 'buscarCliente']);
    Route::post('ventas', [VentaController::class, 'store']);

    // Ventas (pedidos generados desde caja): crear, listar, ver, y avanzar
    // el estado del pedido (confirmar/entregar, botones que usa cualquier
    // vendedor a diario) — todo eso pasa por update(), que solo toca
    // estado/dirección/método de pago/observaciones; nunca los productos,
    // cantidades o el total de la venta (eso no es editable por nadie,
    // ni siquiera el administrador, hoy en día). Cancelar (destroy, la
    // única acción que sí devuelve stock y reescribe el resultado de la
    // venta) sigue siendo exclusivo de administrador.
    // Notificación de pedidos nuevos de la tienda online (ver
    // PedidoNotificacionesService en el frontend, que la consulta cada
    // pocos segundos). Va ANTES del apiResource para que "nuevos" no se
    // intente resolver como {pedido}.
    Route::get('pedidos/nuevos', [PedidoController::class, 'nuevos']);
    Route::apiResource('pedidos', PedidoController::class)->except(['destroy']);
    // Cambiar los productos de un pedido aún no cobrado (quitar lo que se
    // acabó, agregar lo que faltó): ajusta stock y total.
    Route::put('pedidos/{pedido}/items', [PedidoController::class, 'editarItems']);
    Route::get('pedidos/{pedido}/qr', [PedidoController::class, 'qr']);
    Route::post('pedidos/{pedido}/confirmar-pago', [PedidoController::class, 'confirmarPago']);
    Route::get('pedidos/{pedido}/factura-pdf-descarga', [PedidoController::class, 'facturaPdfDescarga']);
    Route::post('pedidos/{pedido}/reenviar-factura', [PedidoController::class, 'reenviarFactura']);
    Route::get('pedidos/{pedido}/ticket', [PedidoController::class, 'ticketTermico']);
    Route::delete('pedidos/{pedido}', [PedidoController::class, 'destroy'])->middleware('rol:administrador');

    // Estado de la caja actual: el vendedor solo necesita saber si hay una
    // caja abierta para poder vender. Los montos/totales quedan filtrados
    // dentro del controlador según el rol (blindaje de caja).
    Route::get('caja/actual', [CajaController::class, 'actual']);
    // Reporte de caja del cajero (el vendedor solo ve lo suyo): ANTES de caja/{caja}.
    Route::get('caja/mi-reporte', [CajaController::class, 'miReporte']);
    Route::get('caja/{caja}', [CajaController::class, 'show'])->middleware('rol:administrador');
});
