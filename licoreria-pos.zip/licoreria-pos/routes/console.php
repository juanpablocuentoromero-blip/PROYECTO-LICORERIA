<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// Borra de la base los tokens de sesión (Sanctum) vencidos hace más de 24 h.
Schedule::command('sanctum:prune-expired --hours=24')->daily();

// 4.2 — Revisión diaria de stock mínimo y vencimientos (hora de Bolivia).
// Requiere el cron de Laravel:  * * * * * php artisan schedule:run
Schedule::command('alertas:revisar')
    ->dailyAt('07:00')
    ->timezone(config('services.licoreria.zona_horaria', 'America/La_Paz'))
    ->withoutOverlapping();

// 2.5 — Respaldo diario de la base de datos (copia local + copia fuera del servidor).
// Hora y destino en config/backup.php (.env: BACKUP_HORA, BACKUP_DISCO_EXTERNO...).
Schedule::command('backup:base-datos')
    ->dailyAt(config('backup.hora', '03:00'))
    ->timezone(config('services.licoreria.zona_horaria', 'America/La_Paz'))
    ->withoutOverlapping();
