<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: Arial, sans-serif; color: #241f18; padding: 16px;">
    <h2>🛎️ Nuevo pedido desde la tienda online</h2>
    <p><strong>Pedido:</strong> #{{ $pedido->id }}</p>
    <p><strong>Cliente:</strong> {{ $pedido->cliente->nombre }}</p>
    @if ($pedido->tipo_entrega === 'delivery')
        <p><strong>Entrega:</strong> Delivery — zona {{ $pedido->zonaDelivery?->nombre ?? '—' }} (envío Bs {{ number_format((float) $pedido->costo_envio, 2) }})</p>
        <p><strong>Dirección de entrega:</strong> {{ $pedido->direccion_entrega }}</p>
    @else
        <p><strong>Entrega:</strong> Recojo en tienda</p>
    @endif
    <p><strong>Método de pago:</strong> {{ ucfirst($pedido->metodo_pago) }}</p>
    @if ((float) $pedido->descuento > 0)
        <p><strong>Descuento aplicado:</strong> Bs {{ number_format((float) $pedido->descuento, 2) }}@if ($pedido->cupon_codigo) (cupón {{ $pedido->cupon_codigo }})@endif</p>
    @endif
    <p><strong>Mayoría de edad confirmada:</strong> {{ $pedido->mayor_edad_confirmada ? 'Sí' : 'No' }} — verificar al entregar.</p>
    <p><strong>Total:</strong> Bs {{ number_format((float) $pedido->total, 2) }}</p>
    @if($pedido->observaciones)
        <p><strong>Observaciones:</strong> {{ $pedido->observaciones }}</p>
    @endif

    <table style="width:100%; border-collapse: collapse; margin-top: 12px;">
        <thead>
            <tr>
                <th style="text-align:left; border-bottom:1px solid #ccc;">Producto</th>
                <th style="text-align:right; border-bottom:1px solid #ccc;">Cant.</th>
                <th style="text-align:right; border-bottom:1px solid #ccc;">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            @foreach($pedido->detalles as $detalle)
            <tr>
                <td>{{ $detalle->producto->nombre }}</td>
                <td style="text-align:right;">{{ $detalle->cantidad }}</td>
                <td style="text-align:right;">Bs {{ number_format((float) $detalle->subtotal, 2) }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <p style="margin-top:16px; color:#666;">Todavía no está pagado — pídele al cliente que confirme el pago (efectivo/QR) y regístralo desde la pantalla de Pedidos.</p>
</body>
</html>
