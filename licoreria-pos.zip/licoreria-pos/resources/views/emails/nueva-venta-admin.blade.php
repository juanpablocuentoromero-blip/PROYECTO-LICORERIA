<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: Arial, sans-serif; color: #241f18; padding: 16px;">
    <h2>Nueva venta confirmada</h2>
    <p><strong>Pedido:</strong> #{{ $pedido->id }}</p>
    <p><strong>Cliente:</strong> {{ $pedido->cliente->nombre }}</p>
    <p><strong>Vendedor:</strong> {{ $pedido->usuario->nombre }}</p>
    <p><strong>Método de pago:</strong> {{ ucfirst($pedido->metodo_pago) }}</p>
    <p><strong>Total:</strong> Bs {{ number_format((float) $pedido->total, 2) }}</p>
    <p><strong>Fecha:</strong> {{ $pedido->pagado_at?->format('d/m/Y H:i') }}</p>

    <table style="width:100%; border-collapse: collapse; margin-top: 12px;">
        <thead>
            <tr>
                <th style="text-align:left; border-bottom:1px solid #ccc;">Producto</th>
                <th style="text-align:right; border-bottom:1px solid #ccc;">Cant.</th>
                <th style="text-align:right; border-bottom:1px solid #ccc;">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            @foreach($pedido->detalles as $detalle)
            <tr>
                <td>{{ $detalle->producto->nombre }}</td>
                <td style="text-align:right;">{{ $detalle->cantidad }}</td>
                <td style="text-align:right;">Bs {{ number_format((float) $detalle->subtotal, 2) }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
