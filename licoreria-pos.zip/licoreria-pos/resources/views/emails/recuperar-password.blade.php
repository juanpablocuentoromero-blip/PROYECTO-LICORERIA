<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: Arial, sans-serif; color: #241f18; background:#f2ead8; padding: 24px;">
    <div style="max-width: 520px; margin: 0 auto; background:#fff; border-radius: 12px; overflow: hidden; border: 1px solid #ddccA6;">
        <div style="background:#1f3628; padding: 24px; text-align:center;">
            <h1 style="color:#e0a83e; margin:0; font-size:22px; font-family: Georgia, serif;">Licorería Al Paso</h1>
        </div>
        <div style="padding: 24px;">
            <p>Hola {{ $nombre }},</p>
            <p>Recibimos una solicitud para restablecer tu contraseña. Si fuiste tú, haz clic en el siguiente botón:</p>

            <p style="text-align:center; margin: 28px 0;">
                <a href="{{ $enlace }}"
                   style="background:#c17817; color:#1a1409; text-decoration:none; font-weight:bold; padding: 12px 24px; border-radius: 8px; display:inline-block;">
                    Restablecer contraseña
                </a>
            </p>

            <p style="font-size:13px; color:#7d9186;">
                Este enlace vence en 60 minutos. Si no solicitaste este cambio, puedes ignorar este correo:
                tu contraseña actual seguirá funcionando.
            </p>

            <p style="font-size:12px; color:#b0a888; word-break:break-all; margin-top:18px;">
                Si el botón no funciona, copia y pega este enlace en tu navegador:<br>{{ $enlace }}
            </p>
        </div>
    </div>
</body>
</html>
