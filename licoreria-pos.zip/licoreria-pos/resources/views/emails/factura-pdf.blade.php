{{--
    Nota de venta en PDF (DomPDF).
    - El logo va en la cabecera y, además, repetido como marca de agua al
      centro de cada página (elemento con position: fixed, que DomPDF
      dibuja en todas las hojas).
    - Las imágenes se referencian con public_path() porque DomPDF lee el
      archivo del disco, no por HTTP.
--}}
@php
    $logo = public_path('brand/logo-al-paso.png');
    $marcaAgua = public_path('brand/logo-marca-agua.png');
@endphp
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page { margin: 34px 38px; }
        body { font-family: Helvetica, Arial, sans-serif; font-size: 12px; color: #12284B; }
        h1 { font-size: 18px; margin: 0; color: #12284B; }
        .muted { color: #6b7f96; }

        /* Marca de agua: centrada y fija, se repite en cada página.
           La imagen ya viene atenuada desde el archivo, así no depende
           del soporte de opacidad del motor de PDF. */
        .marca-agua {
            position: fixed;
            top: 300px;
            left: 0;
            right: 0;
            text-align: center;
            z-index: -100;
        }
        .marca-agua img { width: 380px; }

        .cabecera { width: 100%; border-bottom: 2px solid #0055A0; padding-bottom: 10px; }
        .cabecera td { vertical-align: middle; border: none; padding: 0; }
        .cabecera .logo { width: 170px; }
        .cabecera .logo img { width: 160px; }
        .cabecera .titulo { text-align: right; }

        table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        th, td { padding: 6px 8px; border-bottom: 1px solid #cfe3f5; text-align: left; }
        th { background: #eaf2fa; color: #12284B; }
        .totales td { border: none; }
        .text-right { text-align: right; }
        .pie { margin-top: 32px; font-size: 11px; }
    </style>
</head>
<body>
    @if (is_file($marcaAgua))
        <div class="marca-agua">
            <img src="{{ $marcaAgua }}" alt="">
        </div>
    @endif

    <table class="cabecera">
        <tr>
            <td class="logo">
                @if (is_file($logo))
                    <img src="{{ $logo }}" alt="Licorería Al Paso">
                @endif
            </td>
            <td class="titulo">
                <h1>Nota de venta</h1>
                <p class="muted">Licorería Al Paso<br>Riberalta, Beni — Bolivia</p>
            </td>
        </tr>
    </table>

    <table class="totales">
        <tr>
            <td><strong>Pedido:</strong> #{{ $pedido->id }}</td>
            <td class="text-right"><strong>Fecha:</strong> {{ $pedido->created_at->format('d/m/Y H:i') }}</td>
        </tr>
        <tr>
            <td><strong>Cliente:</strong> {{ $pedido->cliente->nombre }}</td>
            <td class="text-right"><strong>Método de pago:</strong> {{ ucfirst($pedido->metodo_pago) }}</td>
        </tr>
        @if($pedido->referencia_pago)
        <tr>
            <td colspan="2"><strong>Referencia de pago:</strong> {{ $pedido->referencia_pago }}</td>
        </tr>
        @endif
    </table>

    <table>
        <thead>
            <tr>
                <th>Producto</th>
                <th class="text-right">Cantidad</th>
                <th class="text-right">Precio unit.</th>
                <th class="text-right">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            @foreach($pedido->detalles as $detalle)
            <tr>
                <td>{{ $detalle->producto->nombre }}</td>
                <td class="text-right">{{ $detalle->cantidad }}</td>
                <td class="text-right">Bs {{ number_format((float) $detalle->precio_unitario, 2) }}</td>
                <td class="text-right">Bs {{ number_format((float) $detalle->subtotal, 2) }}</td>
            </tr>
            @if ((float) $detalle->descuento > 0)
            <tr>
                <td colspan="3" class="muted" style="font-size: 10px;">
                    ↳ {{ $detalle->promocion_aplicada ?: 'Descuento' }}
                </td>
                <td class="text-right muted" style="font-size: 10px;">- Bs {{ number_format((float) $detalle->descuento, 2) }}</td>
            </tr>
            @endif
            @endforeach
        </tbody>
    </table>

    <table class="totales" style="margin-top: 8px;">
        @if ((float) $pedido->descuento > 0)
        <tr>
            <td></td>
            <td class="text-right" style="width: 120px;">Descuentos:</td>
            <td class="text-right" style="width: 100px;">- Bs {{ number_format((float) $pedido->descuento, 2) }}</td>
        </tr>
        @endif
        @if ((float) $pedido->costo_envio > 0)
        <tr>
            <td></td>
            <td class="text-right" style="width: 120px;">Envío (delivery):</td>
            <td class="text-right" style="width: 100px;">Bs {{ number_format((float) $pedido->costo_envio, 2) }}</td>
        </tr>
        @endif
        <tr>
            <td></td>
            <td class="text-right" style="width: 120px;"><strong>Total:</strong></td>
            <td class="text-right" style="width: 100px;"><strong>Bs {{ number_format((float) $pedido->total, 2) }}</strong></td>
        </tr>
    </table>

    <p class="muted pie">Gracias por su compra.</p>
</body>
</html>
