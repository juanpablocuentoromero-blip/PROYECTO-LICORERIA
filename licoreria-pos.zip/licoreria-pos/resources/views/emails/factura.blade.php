<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: Arial, sans-serif; color: #241f18; background:#f2ead8; padding: 24px;">
    <div style="max-width: 520px; margin: 0 auto; background:#fff; border-radius: 12px; overflow: hidden; border: 1px solid #ddccA6;">
        <div style="background:#1f3628; padding: 24px; text-align:center;">
            <h1 style="color:#f2ead8; margin:0; font-size:22px;">Licorería Al Paso</h1>
        </div>
        <div style="padding: 24px;">
            <p>Hola {{ $pedido->cliente->nombre }},</p>
            <p>Gracias por tu compra. Tu pedido <strong>#{{ $pedido->id }}</strong> fue confirmado y adjuntamos tu nota de venta en PDF.</p>

            <table style="width:100%; border-collapse: collapse; margin-top: 16px;">
                <tr>
                    <td style="padding:6px 0; color:#7d9186;">Método de pago</td>
                    <td style="padding:6px 0; text-align:right; text-transform:capitalize;">{{ $pedido->metodo_pago }}</td>
                </tr>
                <tr>
                    <td style="padding:6px 0; color:#7d9186;">Total pagado</td>
                    <td style="padding:6px 0; text-align:right; font-weight:bold;">Bs {{ number_format((float) $pedido->total, 2) }}</td>
                </tr>
            </table>

            <p style="margin-top:24px; font-size:13px; color:#7d9186;">
                Si tienes alguna consulta sobre tu pedido, responde a este correo o contáctanos directamente.
            </p>
        </div>
    </div>
</body>
</html>
