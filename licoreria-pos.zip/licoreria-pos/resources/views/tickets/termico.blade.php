{{--
    Ticket para impresora térmica (tarea 5.5), 58 mm u 80 mm.

    Una sola plantilla sirve para dos salidas:
      - HTML  ($pdf = false): el panel lo abre en un marco oculto y llama a
        print(). @page fija el ancho del rollo, así el navegador manda el
        ticket a la térmica sin márgenes ni A4.
      - PDF   ($pdf = true): DomPDF con papel del mismo ancho (descarga).
    Solo tablas y estilos simples: DomPDF no soporta flex ni grid.

    Variables: $pedido (con cliente, usuario, detalles.producto, zonaDelivery),
               $ancho (58|80), $pdf (bool).
--}}
@php
    $mm = (int) $ancho === 58 ? 58 : 80;
    // Caracteres que caben por línea en fuente monoespaciada 8-9 pt.
    $fs = $mm === 58 ? 9 : 10;
    $bs = fn ($n) => number_format((float) $n, 2);
    $local = fn ($f) => $f ? $f->copy()->setTimezone(config('services.licoreria.zona_horaria', 'America/La_Paz')) : null;
    $fecha = $local($pedido->created_at);
    $esCredito = $pedido->esCredito();
@endphp
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Ticket {{ $pedido->nroDocumento() }}</title>
    <style>
        @page { size: {{ $mm }}mm auto; margin: 0; }
        * { box-sizing: border-box; }
        html, body { margin: 0; padding: 0; }
        body {
            width: {{ $mm === 58 ? '48mm' : '72mm' }};
            margin: 0 auto;
            padding: 3mm 0 6mm;
            font-family: 'Courier New', Courier, monospace;
            font-size: {{ $fs }}px;
            line-height: 1.25;
            color: #000;
        }
        .c { text-align: center; }
        .r { text-align: right; }
        .b { font-weight: bold; }
        .g { font-size: {{ $fs + 3 }}px; }
        .sep { border-top: 1px dashed #000; margin: 4px 0; height: 0; }
        table { width: 100%; border-collapse: collapse; }
        td { padding: 1px 0; vertical-align: top; }
        .anulada { border: 1px solid #000; padding: 2px; margin: 4px 0; font-weight: bold; text-align: center; }
    </style>
</head>
<body>
    <div class="c b g">LICORERÍA AL PASO</div>
    <div class="c">Riberalta, Beni — Bolivia</div>
    <div class="sep"></div>

    <div class="c b">{{ $pedido->nro_factura ? 'FACTURA' : 'NOTA DE VENTA' }}</div>
    <div class="c">{{ $pedido->nroDocumento() }}</div>

    @if ($pedido->anulada)
        <div class="anulada">*** ANULADA ***</div>
    @endif

    <div class="sep"></div>
    <div>Fecha: {{ $fecha?->format('d/m/Y H:i') }}</div>
    <div>Cliente: {{ $pedido->cliente?->nombre ?? 'SIN NOMBRE' }}</div>
    @if ($pedido->cliente?->nit_ci && $pedido->cliente->nit_ci !== '0')
        <div>NIT/CI: {{ $pedido->cliente->nit_ci }}</div>
    @endif
    @if ($pedido->usuario && $pedido->origen !== 'online')
        <div>Atendió: {{ $pedido->usuario->nombre }}</div>
    @endif
    @if ($pedido->tipo_entrega === 'delivery')
        <div>Delivery: {{ $pedido->zonaDelivery?->nombre }}</div>
        @if ($pedido->direccion_entrega)
            <div>Dir.: {{ $pedido->direccion_entrega }}</div>
        @endif
    @endif

    <div class="sep"></div>
    <table>
        @foreach ($pedido->detalles as $d)
            <tr>
                <td colspan="2" class="b">{{ $d->producto?->nombre ?? 'Producto eliminado' }}</td>
            </tr>
            <tr>
                <td>{{ $d->cantidad }} x {{ $bs($d->precio_unitario) }}</td>
                <td class="r">{{ $bs((float) $d->cantidad * (float) $d->precio_unitario) }}</td>
            </tr>
            @if ((float) $d->descuento > 0)
                <tr>
                    <td>@if ($d->promocion_aplicada) {{ $d->promocion_aplicada }} @else Descuento @endif</td>
                    <td class="r">-{{ $bs($d->descuento) }}</td>
                </tr>
            @endif
        @endforeach
    </table>
    <div class="sep"></div>

    <table>
        <tr><td>Subtotal</td><td class="r">{{ $bs($pedido->subtotal) }}</td></tr>
        @if ((float) $pedido->descuento > 0)
            <tr><td>Descuentos</td><td class="r">-{{ $bs($pedido->descuento) }}</td></tr>
        @endif
        @if ((float) $pedido->costo_envio > 0)
            <tr><td>Envío</td><td class="r">{{ $bs($pedido->costo_envio) }}</td></tr>
        @endif
        <tr class="b g"><td>TOTAL Bs</td><td class="r">{{ $bs($pedido->total) }}</td></tr>
    </table>

    <div class="sep"></div>
    @if ($esCredito)
        <div class="b">VENTA A CRÉDITO</div>
        <table>
            <tr><td>Abonado</td><td class="r">{{ $bs((float) $pedido->total - (float) $pedido->saldo_pendiente) }}</td></tr>
            <tr class="b"><td>Saldo</td><td class="r">{{ $bs($pedido->saldo_pendiente) }}</td></tr>
        </table>
        @if ($pedido->fecha_vencimiento_credito)
            <div>Vence: {{ $pedido->fecha_vencimiento_credito->format('d/m/Y') }}</div>
        @endif
        <div style="margin-top: 14px;">Firma: ______________</div>
    @else
        <div>Pago: {{ strtoupper($pedido->metodo_pago) }}{{ $pedido->pagado ? '' : ' (pendiente)' }}</div>
    @endif

    <div class="sep"></div>
    <div class="c">¡Gracias por su compra!</div>
    <div class="c">Beba con moderación.</div>
    <div class="c">Prohibida la venta a menores de 18 años.</div>

    @unless ($pdf)
        <script>
            window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 150); });
        </script>
    @endunless
</body>
</html>
