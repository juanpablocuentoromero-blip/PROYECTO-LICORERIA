{{--
    Recibo individual de un movimiento de caja chica (DomPDF). Formato
    chico, pensado para imprimir como comprobante de un solo gasto/ingreso.
--}}
@php
    $logo = public_path('brand/logo-al-paso.png');
@endphp
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page { margin: 30px 36px; }
        body { font-family: Helvetica, Arial, sans-serif; font-size: 12px; color: #12284B; }
        h1 { font-size: 16px; margin: 0; color: #12284B; }
        .muted { color: #6b7f96; }

        .cabecera { width: 100%; border-bottom: 2px solid #0055A0; padding-bottom: 10px; margin-bottom: 14px; }
        .cabecera td { vertical-align: middle; border: none; padding: 0; }
        .cabecera .logo { width: 150px; }
        .cabecera .logo img { width: 140px; }
        .cabecera .titulo { text-align: right; }

        table.datos { width: 100%; border-collapse: collapse; margin-top: 6px; }
        table.datos td { padding: 7px 8px; border-bottom: 1px solid #cfe3f5; }
        table.datos td:first-child { color: #6b7f96; width: 40%; }

        .monto { margin-top: 20px; text-align: center; }
        .monto .valor { font-size: 26px; font-weight: bold; }
        .monto .tipo-ingreso { color: #1a7a3d; }
        .monto .tipo-egreso { color: #b02020; }

        .firma { margin-top: 60px; width: 100%; }
        .firma td { text-align: center; padding-top: 6px; border-top: 1px solid #12284B; font-size: 11px; }
    </style>
</head>
<body>
    <table class="cabecera">
        <tr>
            <td class="logo">
                @if (is_file($logo))
                    <img src="{{ $logo }}" alt="Licorería Al Paso">
                @endif
            </td>
            <td class="titulo">
                <h1>Recibo de caja chica</h1>
                <p class="muted">Comprobante #{{ $movimiento->id }}</p>
            </td>
        </tr>
    </table>

    <table class="datos">
        <tr><td>Fecha y hora</td><td>{{ $movimiento->created_at->format('d/m/Y H:i') }}</td></tr>
        <tr><td>Almacén</td><td>{{ $movimiento->almacen->nombre }}</td></tr>
        <tr><td>Registrado por</td><td>{{ $movimiento->usuario->nombre }}</td></tr>
        <tr><td>Cuenta</td><td>{{ $movimiento->cuenta }}</td></tr>
        <tr><td>Concepto</td><td>{{ $movimiento->concepto }}</td></tr>
        <tr><td>Método de pago</td><td>{{ ucfirst($movimiento->metodo_pago) }}</td></tr>
        @if ($movimiento->nro_documento)
            <tr><td>Nro. documento</td><td>{{ $movimiento->nro_documento }}</td></tr>
        @endif
    </table>

    <div class="monto">
        <p class="muted">{{ $movimiento->tipo === 'ingreso' ? 'Monto recibido' : 'Monto entregado' }}</p>
        <p class="valor {{ $movimiento->tipo === 'ingreso' ? 'tipo-ingreso' : 'tipo-egreso' }}">
            Bs {{ number_format($movimiento->monto, 2) }}
        </p>
    </div>

    <table class="firma">
        <tr>
            <td style="width:45%">Entregado por</td>
            <td style="width:10%; border:none"></td>
            <td style="width:45%">Recibido por</td>
        </tr>
    </table>
</body>
</html>
