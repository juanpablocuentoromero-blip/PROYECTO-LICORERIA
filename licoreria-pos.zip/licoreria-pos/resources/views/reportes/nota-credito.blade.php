{{--
    Nota de crédito de una devolución parcial (DomPDF).
--}}
@php
    $logo = public_path('brand/logo-al-paso.png');
    $venta = $devolucion->pedido;
@endphp
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page { margin: 30px 36px; }
        body { font-family: DejaVu Sans, Helvetica, Arial, sans-serif; font-size: 11px; color: #12284B; }
        h1 { font-size: 16px; margin: 0; }
        .muted { color: #6b7f96; }
        .cabecera { width: 100%; border-bottom: 2px solid #0055A0; padding-bottom: 10px; margin-bottom: 14px; }
        .cabecera td { vertical-align: middle; border: none; padding: 0; }
        .cabecera .logo img { width: 140px; }
        .cabecera .titulo { text-align: right; }
        table.datos { width: 100%; border-collapse: collapse; margin-bottom: 12px; }
        table.datos td { padding: 5px 8px; border-bottom: 1px solid #cfe3f5; }
        table.datos td:first-child { color: #6b7f96; width: 32%; }
        table.items { width: 100%; border-collapse: collapse; }
        table.items th { background: #12284B; color: #fff; text-align: left; padding: 6px 8px; }
        table.items td { padding: 6px 8px; border-bottom: 1px solid #cfe3f5; }
        .r { text-align: right; }
        .total td { font-weight: bold; font-size: 13px; border-top: 2px solid #12284B; }
        .firma { margin-top: 60px; width: 100%; }
        .firma td { text-align: center; padding-top: 6px; border-top: 1px solid #12284B; font-size: 10px; }
    </style>
</head>
<body>
    <table class="cabecera">
        <tr>
            <td class="logo">@if (is_file($logo))<img src="{{ $logo }}" alt="Licorería Al Paso">@endif</td>
            <td class="titulo">
                <h1>Nota de crédito</h1>
                <p class="muted">{{ $devolucion->nroNota() }}</p>
            </td>
        </tr>
    </table>

    <table class="datos">
        <tr><td>Fecha y hora</td><td>{{ $devolucion->created_at->format('d/m/Y H:i') }}</td></tr>
        <tr><td>Venta original</td><td>{{ $venta->nroDocumento() }} ({{ $venta->created_at->format('d/m/Y') }})</td></tr>
        <tr><td>Cliente</td><td>{{ $venta->cliente?->nombre ?? 'SIN NOMBRE' }} @if($venta->cliente?->nit_ci) — NIT/CI {{ $venta->cliente->nit_ci }} @endif</td></tr>
        <tr><td>Motivo</td><td>{{ $devolucion->motivo }}</td></tr>
        <tr><td>Registrada por</td><td>{{ $devolucion->usuario?->nombre ?? '—' }}</td></tr>
    </table>

    <table class="items">
        <thead><tr><th>Producto</th><th class="r">Cantidad</th><th class="r">Importe (Bs)</th></tr></thead>
        <tbody>
            @foreach ($devolucion->detalles as $d)
                <tr>
                    <td>{{ $d->producto?->nombre ?? 'Producto eliminado' }}</td>
                    <td class="r">{{ $d->cantidad }}</td>
                    <td class="r">{{ number_format($d->monto, 2) }}</td>
                </tr>
            @endforeach
            <tr class="total"><td colspan="2">Total devuelto</td><td class="r">Bs {{ number_format($devolucion->total, 2) }}</td></tr>
        </tbody>
    </table>

    <p style="margin-top:14px">
        @if ($devolucion->aplicado_a_saldo > 0)
            Descontado de la deuda del cliente: <strong>Bs {{ number_format($devolucion->aplicado_a_saldo, 2) }}</strong><br>
        @endif
        @if ($devolucion->monto_reembolsado > 0)
            Devuelto al cliente: <strong>Bs {{ number_format($devolucion->monto_reembolsado, 2) }}</strong> ({{ ucfirst($devolucion->metodo_reembolso) }})
        @endif
    </p>

    <table class="firma"><tr><td>Firma del cliente</td><td style="width:40px;border:none"></td><td>Firma de la licorería</td></tr></table>
</body>
</html>
