{{--
    Arqueo de caja (DomPDF). Sigue el mismo estilo visual que la factura
    (emails/factura-pdf.blade.php): logo, cabecera azul, tablas con
    encabezado claro. Solo lo descarga el administrador (ver rutas).
--}}
@php
    $logo = public_path('brand/logo-al-paso.png');
@endphp
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page { margin: 34px 38px; }
        body { font-family: Helvetica, Arial, sans-serif; font-size: 12px; color: #12284B; }
        h1 { font-size: 18px; margin: 0; color: #12284B; }
        h2 { font-size: 14px; margin: 24px 0 8px; color: #12284B; }
        .muted { color: #6b7f96; }

        .cabecera { width: 100%; border-bottom: 2px solid #0055A0; padding-bottom: 10px; }
        .cabecera td { vertical-align: middle; border: none; padding: 0; }
        .cabecera .logo { width: 170px; }
        .cabecera .logo img { width: 160px; }
        .cabecera .titulo { text-align: right; }

        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 6px 8px; border-bottom: 1px solid #cfe3f5; text-align: left; }
        th { background: #eaf2fa; color: #12284B; }
        .datos td { border: none; padding: 3px 8px; }
        .text-right { text-align: right; }

        .resumen { margin-top: 10px; }
        .resumen td { border: none; padding: 4px 8px; }
        .resumen .total-row td { border-top: 1.5px solid #0055A0; font-weight: bold; }
        .diferencia-ok { color: #1a7a3d; font-weight: bold; }
        .diferencia-mal { color: #b02020; font-weight: bold; }
    </style>
</head>
<body>
    <table class="cabecera">
        <tr>
            <td class="logo">
                @if (is_file($logo))
                    <img src="{{ $logo }}" alt="Licorería Al Paso">
                @endif
            </td>
            <td class="titulo">
                <h1>Arqueo de caja</h1>
                <p class="muted">Licorería Al Paso<br>Riberalta, Beni — Bolivia</p>
            </td>
        </tr>
    </table>

    <table class="datos">
        <tr>
            <td><strong>Caja #:</strong> {{ $caja->id }}</td>
            <td class="text-right"><strong>Almacén:</strong> {{ $caja->almacen->nombre }}</td>
        </tr>
        <tr>
            <td><strong>Apertura:</strong> {{ $caja->abierta_at->format('d/m/Y H:i') }} — {{ $caja->usuarioApertura->nombre }}</td>
            <td class="text-right">
                <strong>Cierre:</strong>
                {{ $caja->cerrada_at ? $caja->cerrada_at->format('d/m/Y H:i') : 'Turno todavía abierto' }}
                @if ($caja->cerrada_at)
                    <br><strong>Cerrada por:</strong> {{ $caja->cerrada_por_nombre ?? $caja->usuarioCierre?->nombre ?? '—' }}
                @endif
            </td>
        </tr>
    </table>

    <h2>Resumen del turno</h2>
    <table class="resumen">
        <tr><td>Monto de apertura</td><td class="text-right">Bs {{ number_format($caja->monto_apertura, 2) }}</td></tr>
        <tr><td>+ Ventas en efectivo</td><td class="text-right">Bs {{ number_format($totales['ventas_efectivo'], 2) }}</td></tr>
        <tr><td>+ Cobros de crédito en efectivo (abonos)</td><td class="text-right">Bs {{ number_format($totales['abonos_efectivo'] ?? 0, 2) }}</td></tr>
        <tr><td>+ Ingresos de caja chica (efectivo)</td><td class="text-right">Bs {{ number_format($totales['ingresos_caja_chica'], 2) }}</td></tr>
        <tr><td>− Egresos de caja chica (efectivo)</td><td class="text-right">Bs {{ number_format($totales['egresos_caja_chica'], 2) }}</td></tr>
        @if (($totales['devoluciones_efectivo'] ?? 0) > 0)
        <tr><td>− Devoluciones a clientes en efectivo (notas de crédito)</td><td class="text-right">Bs {{ number_format($totales['devoluciones_efectivo'], 2) }}</td></tr>
        @endif
        <tr class="total-row">
            <td>Saldo esperado en caja</td>
            <td class="text-right">Bs {{ number_format($caja->monto_cierre_esperado ?? ($caja->monto_apertura + $totales['ventas_efectivo'] + ($totales['abonos_efectivo'] ?? 0) + $totales['ingresos_caja_chica'] - $totales['egresos_caja_chica'] - ($totales['devoluciones_efectivo'] ?? 0)), 2) }}</td>
        </tr>
        @if ($caja->estado === 'cerrada')
            <tr><td>Monto contado (real)</td><td class="text-right">Bs {{ number_format($caja->monto_cierre_real, 2) }}</td></tr>
            <tr class="total-row">
                <td>Diferencia</td>
                <td class="text-right {{ $caja->diferencia == 0 ? 'diferencia-ok' : 'diferencia-mal' }}">
                    Bs {{ number_format($caja->diferencia, 2) }}
                    {{ $caja->diferencia == 0 ? '(cuadra)' : ($caja->diferencia > 0 ? '(sobrante)' : '(faltante)') }}
                </td>
            </tr>
        @endif
    </table>

    <h2>Ventas del turno</h2>
    <table class="resumen">
        <tr><td>Cantidad de ventas</td><td class="text-right">{{ $totales['cantidad_ventas'] }}</td></tr>
        <tr><td>Efectivo</td><td class="text-right">Bs {{ number_format($totales['ventas_efectivo'], 2) }}</td></tr>
        <tr><td>QR</td><td class="text-right">Bs {{ number_format($totales['ventas_qr'], 2) }}</td></tr>
        <tr><td>Tarjeta</td><td class="text-right">Bs {{ number_format($totales['ventas_tarjeta'], 2) }}</td></tr>
        <tr class="total-row"><td>Total vendido</td><td class="text-right">Bs {{ number_format($totales['ventas_total'], 2) }}</td></tr>
        <tr><td>Ventas anuladas ({{ $totales['cantidad_anuladas'] }})</td><td class="text-right">Bs {{ number_format($totales['monto_anulado'], 2) }}</td></tr>
    </table>

    @if (($totales['ventas_credito'] ?? 0) > 0 || ($totales['abonos_efectivo'] ?? 0) + ($totales['abonos_qr'] ?? 0) + ($totales['abonos_tarjeta'] ?? 0) > 0)
        <h2>Crédito (fiado) del turno</h2>
        <table class="resumen">
            <tr><td>Vendido a crédito (no entra a caja)</td><td class="text-right">Bs {{ number_format($totales['ventas_credito'] ?? 0, 2) }}</td></tr>
            <tr><td>Cobrado en abonos · efectivo</td><td class="text-right">Bs {{ number_format($totales['abonos_efectivo'] ?? 0, 2) }}</td></tr>
            <tr><td>Cobrado en abonos · QR</td><td class="text-right">Bs {{ number_format($totales['abonos_qr'] ?? 0, 2) }}</td></tr>
            <tr><td>Cobrado en abonos · tarjeta</td><td class="text-right">Bs {{ number_format($totales['abonos_tarjeta'] ?? 0, 2) }}</td></tr>
        </table>
    @endif

    <h2>Detalle por vendedor</h2>
    @if (empty($totales['por_vendedor']))
        <p class="muted">No hubo ventas en este turno.</p>
    @else
        <table>
            <thead>
                <tr>
                    <th>Vendedor</th><th class="text-right">Ventas</th><th class="text-right">Efectivo</th>
                    <th class="text-right">QR</th><th class="text-right">Tarjeta</th><th class="text-right">Total</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($totales['por_vendedor'] as $v)
                    <tr>
                        <td>{{ $v['nombre'] }}</td>
                        <td class="text-right">{{ $v['cantidad'] }}</td>
                        <td class="text-right">{{ number_format($v['efectivo'], 2) }}</td>
                        <td class="text-right">{{ number_format($v['qr'], 2) }}</td>
                        <td class="text-right">{{ number_format($v['tarjeta'], 2) }}</td>
                        <td class="text-right">{{ number_format($v['total'], 2) }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif

    @if ($caja->observaciones)
        <h2>Observaciones de apertura</h2>
        <p>{{ $caja->observaciones }}</p>
    @endif
    @if ($caja->observaciones_cierre)
        <h2>Observaciones de cierre</h2>
        <p>{{ $caja->observaciones_cierre }}</p>
    @endif

    <h2>Movimientos de caja chica del turno</h2>
    @if ($caja->movimientosCajaChica->isEmpty())
        <p class="muted">No se registraron movimientos de caja chica en este turno.</p>
    @else
        <table>
            <thead>
                <tr>
                    <th>Fecha</th><th>Usuario</th><th>Cuenta</th><th>Concepto</th><th>Pago</th>
                    <th class="text-right">Entrada</th><th class="text-right">Salida</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($caja->movimientosCajaChica as $m)
                    <tr>
                        <td>{{ $m->created_at->format('d/m/Y H:i') }}</td>
                        <td>{{ $m->usuario->nombre }}</td>
                        <td>{{ $m->cuenta }}</td>
                        <td>{{ $m->concepto }}</td>
                        <td>{{ ucfirst($m->metodo_pago) }}</td>
                        <td class="text-right">{{ $m->tipo === 'ingreso' ? number_format($m->monto, 2) : '' }}</td>
                        <td class="text-right">{{ $m->tipo === 'egreso' ? number_format($m->monto, 2) : '' }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</body>
</html>
