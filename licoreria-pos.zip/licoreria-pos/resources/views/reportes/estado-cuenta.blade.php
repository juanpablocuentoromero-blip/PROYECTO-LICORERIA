{{--
    Estado de cuenta de un cliente con crédito (fiado). DomPDF, mismo estilo
    que el arqueo de caja y la nota de venta.
--}}
@php
    $logo = public_path('brand/logo-al-paso.png');
    $c = $estado['cliente'];
@endphp
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page { margin: 34px 38px; }
        body { font-family: Helvetica, Arial, sans-serif; font-size: 12px; color: #12284B; }
        h1 { font-size: 18px; margin: 0; color: #12284B; }
        h2 { font-size: 14px; margin: 22px 0 8px; color: #12284B; }
        .muted { color: #6b7f96; }
        .cabecera { width: 100%; border-bottom: 2px solid #0055A0; padding-bottom: 10px; }
        .cabecera td { vertical-align: middle; border: none; padding: 0; }
        .cabecera .logo { width: 170px; }
        .cabecera .logo img { width: 160px; }
        .cabecera .titulo { text-align: right; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 6px 8px; border-bottom: 1px solid #cfe3f5; text-align: left; }
        th { background: #eaf2fa; color: #12284B; }
        .datos td { border: none; padding: 3px 8px; }
        .text-right { text-align: right; }
        .vencida { color: #b02020; font-weight: bold; }
        .anulado { color: #8a94a3; text-decoration: line-through; }
        .total-row td { border-top: 1.5px solid #0055A0; font-weight: bold; }
    </style>
</head>
<body>
    <table class="cabecera">
        <tr>
            <td class="logo">
                @if (is_file($logo))
                    <img src="{{ $logo }}" alt="Licorería Al Paso">
                @endif
            </td>
            <td class="titulo">
                <h1>Estado de cuenta</h1>
                <p class="muted">Licorería Al Paso<br>Riberalta, Beni — Bolivia</p>
            </td>
        </tr>
    </table>

    <table class="datos">
        <tr>
            <td><strong>Cliente:</strong> {{ $c['nombre'] }}</td>
            <td class="text-right"><strong>Generado:</strong> {{ $generado }}</td>
        </tr>
        <tr>
            <td><strong>NIT/CI:</strong> {{ $c['nit_ci'] ?: '—' }}</td>
            <td class="text-right"><strong>Teléfono:</strong> {{ $c['telefono'] ?: '—' }}</td>
        </tr>
        @if ($c['limite_credito'] !== null)
            <tr>
                <td><strong>Límite de crédito:</strong> Bs {{ number_format($c['limite_credito'], 2) }}</td>
                <td class="text-right"><strong>Disponible:</strong> Bs {{ number_format($estado['disponible'], 2) }}</td>
            </tr>
        @endif
    </table>

    <h2>Ventas pendientes de pago</h2>
    @if (count($estado['ventas']) === 0)
        <p class="muted">No tiene deudas pendientes.</p>
    @else
        <table>
            <thead>
                <tr>
                    <th>Documento</th><th>Fecha</th><th>Vence</th>
                    <th class="text-right">Total</th><th class="text-right">Abonado</th><th class="text-right">Saldo</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($estado['ventas'] as $v)
                    <tr>
                        <td>{{ $v['nro_documento'] }}</td>
                        <td>{{ $v['fecha'] }}</td>
                        <td class="{{ $v['vencida'] ? 'vencida' : '' }}">
                            {{ $v['fecha_vencimiento'] ?? '—' }}
                            @if ($v['vencida']) ({{ $v['dias_atraso'] }} d de atraso) @endif
                        </td>
                        <td class="text-right">{{ number_format($v['total'], 2) }}</td>
                        <td class="text-right">{{ number_format($v['abonado'], 2) }}</td>
                        <td class="text-right">{{ number_format($v['saldo'], 2) }}</td>
                    </tr>
                @endforeach
                <tr class="total-row">
                    <td colspan="5">Total adeudado</td>
                    <td class="text-right">Bs {{ number_format($estado['deuda_total'], 2) }}</td>
                </tr>
                @if ($estado['vencido_total'] > 0)
                    <tr>
                        <td colspan="5" class="vencida">De lo cual ya vencido</td>
                        <td class="text-right vencida">Bs {{ number_format($estado['vencido_total'], 2) }}</td>
                    </tr>
                @endif
            </tbody>
        </table>
    @endif

    <h2>Abonos registrados</h2>
    @if (count($estado['abonos']) === 0)
        <p class="muted">Todavía no hay abonos.</p>
    @else
        <table>
            <thead>
                <tr><th>Fecha</th><th>Documento</th><th>Pago</th><th>Atendió</th><th class="text-right">Monto</th></tr>
            </thead>
            <tbody>
                @foreach ($estado['abonos'] as $a)
                    <tr class="{{ $a['anulado'] ? 'anulado' : '' }}">
                        <td>{{ $a['fecha'] }}</td>
                        <td>{{ $a['nro_documento'] }}</td>
                        <td>{{ ucfirst($a['metodo_pago']) }}@if ($a['anulado']) (anulado) @endif</td>
                        <td>{{ $a['vendedor'] ?? '—' }}</td>
                        <td class="text-right">{{ number_format($a['monto'], 2) }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</body>
</html>
