<?php

namespace Tests\Feature\Fidelizacion;

use App\Models\Cliente;
use App\Models\Pedido;
use App\Models\PuntosMovimiento;
use App\Models\Usuario;
use App\Services\FidelizacionService;
use Tests\TestCase;

/**
 * 6.4 — Programa de puntos: 1 punto por cada Bs 10 pagados, 1 punto = Bs 0.50,
 * canje hasta el 20 % de la venta y desde 10 puntos (valores por defecto).
 */
class FidelizacionTest extends TestCase
{
    private Usuario $admin;

    private Usuario $vendedor;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = $this->crearAdmin();
        $this->vendedor = $this->crearVendedor();
        $this->abrirCaja(100, $this->admin);
    }

    private function cliente(string $nit = '5551234', int $puntos = 0): Cliente
    {
        $cliente = Cliente::create(['nombre' => 'Cliente Frecuente', 'nit_ci' => $nit, 'activo' => true]);

        if ($puntos !== 0) {
            app(FidelizacionService::class)->ajustar($cliente, $puntos, 'Saldo inicial de prueba', $this->admin->id);
        }

        return $cliente->fresh();
    }

    private function saldo(Cliente $cliente): int
    {
        return (int) Cliente::findOrFail($cliente->id)->puntos_saldo;
    }

    /** Vende como vendedor. $cliente null = SIN NOMBRE. */
    private function vender(array $items, ?Cliente $cliente = null, array $extra = [])
    {
        $this->comoUsuario($this->vendedor);

        $datos = $cliente
            ? ['nit_ci' => $cliente->nit_ci, 'razon_social' => $cliente->nombre]
            : [];

        return $this->postVenta($items, array_merge($datos, ['monto_recibido' => 100000], $extra));
    }

    // ------------------------------------------------------------------
    // Acumular
    // ------------------------------------------------------------------

    public function test_una_venta_pagada_acumula_un_punto_por_cada_diez_bs(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 20], 10);
        $cliente = $this->cliente();

        $r = $this->vender([$this->linea($producto, 3)], $cliente)->assertCreated(); // Bs 60

        $this->assertSame(6, $r->json('venta.puntos_ganados'));
        $this->assertSame(6, $this->saldo($cliente));
        $this->assertDatabaseHas('puntos_movimientos', [
            'cliente_id' => $cliente->id, 'tipo' => 'acumulo', 'puntos' => 6, 'saldo_despues' => 6,
        ]);
    }

    public function test_el_redondeo_es_hacia_abajo(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 19], 10);
        $cliente = $this->cliente();

        $this->vender([$this->linea($producto, 1)], $cliente)->assertCreated(); // Bs 19 => 1 punto

        $this->assertSame(1, $this->saldo($cliente));
    }

    public function test_el_cliente_sin_nombre_no_acumula(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 100], 10);

        $r = $this->vender([$this->linea($producto, 1)])->assertCreated();

        $this->assertSame(0, $r->json('venta.puntos_ganados'));
        $this->assertSame(0, PuntosMovimiento::count());
    }

    public function test_una_venta_a_credito_no_acumula(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 100], 10);
        $cliente = $this->crearClienteConCredito(null, '777');

        $this->vender([$this->linea($producto, 1)], $cliente, ['metodo_pago' => 'credito'])->assertCreated();

        $this->assertSame(0, $this->saldo($cliente));
    }

    public function test_cobrar_un_pedido_online_acumula_y_no_se_duplica(): void
    {
        $cliente = Cliente::create([
            'nombre' => 'Tienda Online', 'email' => 'online@prueba.test', 'activo' => true,
            'password' => bcrypt('secreto123'), // cuenta propia: participa aunque no tenga NIT
        ]);

        $pedido = Pedido::create([
            'cliente_id' => $cliente->id, 'usuario_id' => $this->vendedor->id, 'origen' => 'online',
            'estado' => 'pendiente', 'metodo_pago' => 'qr', 'subtotal' => 95, 'descuento' => 0,
            'total' => 95, 'pagado' => false,
        ]);

        $this->comoUsuario($this->vendedor);
        $this->postJson("/api/pedidos/{$pedido->id}/confirmar-pago", ['metodo_pago' => 'qr'])->assertOk();

        $this->assertSame(9, $this->saldo($cliente));
        $this->assertSame(9, (int) $pedido->fresh()->puntos_ganados);

        // Segundo intento: el pedido ya está pagado y no suma otra vez.
        $this->postJson("/api/pedidos/{$pedido->id}/confirmar-pago", ['metodo_pago' => 'qr'])->assertStatus(422);
        $this->assertSame(9, $this->saldo($cliente));
    }

    // ------------------------------------------------------------------
    // Canjear
    // ------------------------------------------------------------------

    public function test_canjear_puntos_descuenta_y_deja_todo_cuadrado(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 100], 10);
        $cliente = $this->cliente('5551234', 100);

        // Bs 200; tope 20 % = Bs 40 = 80 puntos. Se canjean 50 => Bs 25 de descuento.
        $r = $this->vender([$this->linea($producto, 2)], $cliente, ['puntos_canje' => 50])->assertCreated();

        $this->assertDinero(175, $r->json('venta.total'));
        $this->assertDinero(25, $r->json('venta.descuento_puntos'));
        $this->assertSame(50, $r->json('venta.puntos_canjeados'));
        // Gana por lo pagado (175 => 17): 100 - 50 + 17.
        $this->assertSame(17, $r->json('venta.puntos_ganados'));
        $this->assertSame(67, $this->saldo($cliente));

        // La suma de las líneas coincide con el total, y se cobra el total.
        $venta = Pedido::with(['detalles', 'pagos'])->findOrFail($r->json('venta.id'));
        $this->assertDinero(175, $venta->detalles->sum('subtotal'));
        $this->assertDinero(175, $venta->pagos->sum('monto'));
        $this->assertDinero(25, $venta->descuento);
    }

    public function test_el_canje_se_puede_combinar_con_pago_mixto(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 100], 10);
        $cliente = $this->cliente('5551234', 100);

        $this->vender([$this->linea($producto, 2)], $cliente, [
            'puntos_canje' => 20, // Bs 10 => total 190
            'metodo_pago' => 'mixto',
            'pagos' => [['metodo_pago' => 'efectivo', 'monto' => 90], ['metodo_pago' => 'qr', 'monto' => 100]],
        ])->assertCreated();

        $this->assertSame(100 - 20 + 19, $this->saldo($cliente));
    }

    public function test_no_se_puede_canjear_mas_del_tope_de_la_venta(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 100], 10);
        $cliente = $this->cliente('5551234', 500);

        // Bs 200 => máximo Bs 40 (80 puntos). 90 puntos = Bs 45: se rechaza.
        $this->vender([$this->linea($producto, 2)], $cliente, ['puntos_canje' => 90])
            ->assertStatus(422);

        $this->assertSame(500, $this->saldo($cliente));
        $this->assertSame(0, Pedido::count());
        $this->assertSame(10, $this->stockReal($producto));
    }

    public function test_no_se_puede_canjear_mas_puntos_de_los_que_tiene(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 100], 10);
        $cliente = $this->cliente('5551234', 15);

        $this->vender([$this->linea($producto, 2)], $cliente, ['puntos_canje' => 30])->assertStatus(422);

        $this->assertSame(15, $this->saldo($cliente));
    }

    public function test_el_canje_minimo_es_de_diez_puntos(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 100], 10);
        $cliente = $this->cliente('5551234', 100);

        $this->vender([$this->linea($producto, 2)], $cliente, ['puntos_canje' => 5])->assertStatus(422);
    }

    public function test_el_cliente_sin_nombre_no_puede_canjear(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 100], 10);

        $this->vender([$this->linea($producto, 2)], null, ['puntos_canje' => 20])->assertStatus(422);
    }

    public function test_no_se_canjea_en_una_venta_a_credito(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 100], 10);
        $cliente = $this->crearClienteConCredito(null, '888');
        app(FidelizacionService::class)->ajustar($cliente, 100, 'Saldo inicial', $this->admin->id);

        $this->vender([$this->linea($producto, 2)], $cliente, ['metodo_pago' => 'credito', 'puntos_canje' => 20])
            ->assertStatus(422);
    }

    // ------------------------------------------------------------------
    // Anular y devolver
    // ------------------------------------------------------------------

    public function test_anular_la_venta_devuelve_lo_canjeado_y_quita_lo_ganado(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 100], 10);
        $cliente = $this->cliente('5551234', 100);

        $ventaId = $this->vender([$this->linea($producto, 2)], $cliente, ['puntos_canje' => 50])
            ->assertCreated()->json('venta.id');
        $this->assertSame(67, $this->saldo($cliente));

        $this->comoUsuario($this->admin);
        $this->postJson("/api/ventas/{$ventaId}/anular", ['motivo' => 'Error'])->assertOk();

        $this->assertSame(100, $this->saldo($cliente));
    }

    public function test_una_devolucion_parcial_quita_puntos_en_proporcion(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 100], 10);
        $cliente = $this->cliente();

        $venta = $this->vender([$this->linea($producto, 2)], $cliente)->assertCreated(); // Bs 200 => 20 pts
        $ventaId = $venta->json('venta.id');
        $detalleId = Pedido::findOrFail($ventaId)->detalles()->value('id');
        $this->assertSame(20, $this->saldo($cliente));

        $this->comoUsuario($this->admin);
        $this->postJson("/api/ventas/{$ventaId}/devolucion", [
            'motivo' => 'Botella dañada', 'items' => [['detalle_id' => $detalleId, 'cantidad' => 1]],
        ])->assertCreated();
        $this->assertSame(10, $this->saldo($cliente));

        $this->postJson("/api/ventas/{$ventaId}/devolucion", [
            'motivo' => 'La otra también', 'items' => [['detalle_id' => $detalleId, 'cantidad' => 1]],
        ])->assertCreated();
        $this->assertSame(0, $this->saldo($cliente));
    }

    // ------------------------------------------------------------------
    // Consulta y ajuste
    // ------------------------------------------------------------------

    public function test_el_cajero_ve_el_saldo_y_cuanto_puede_canjear(): void
    {
        $cliente = $this->cliente('5551234', 100);

        $this->comoUsuario($this->vendedor);
        $this->getJson("/api/clientes/{$cliente->id}/puntos?total=200")
            ->assertOk()
            ->assertJsonPath('saldo', 100)
            ->assertJsonPath('maximo_canjeable', 80)
            ->assertJsonPath('descuento_maximo', 40)
            ->assertJsonPath('participa', true);

        // Y al identificar al cliente en caja llega su saldo.
        $this->getJson('/api/ventas/cliente?nit_ci=5551234')->assertJsonPath('cliente.puntos_saldo', 100);
    }

    public function test_el_cliente_de_la_tienda_ve_sus_puntos(): void
    {
        $cliente = Cliente::create([
            'nombre' => 'Ana', 'email' => 'ana@prueba.test', 'activo' => true, 'password' => bcrypt('secreto123'),
        ]);
        app(FidelizacionService::class)->ajustar($cliente, 40, 'Bienvenida', $this->admin->id);

        $this->comoUsuario($cliente);
        $this->getJson('/api/cliente/puntos')->assertOk()->assertJsonPath('saldo', 40);
    }

    public function test_solo_el_administrador_ajusta_puntos(): void
    {
        $cliente = $this->cliente('5551234', 10);

        $this->comoUsuario($this->vendedor);
        $this->postJson("/api/clientes/{$cliente->id}/puntos/ajuste", ['puntos' => 50, 'motivo' => 'Cortesía'])
            ->assertForbidden();

        $this->comoUsuario($this->admin);
        $this->postJson("/api/clientes/{$cliente->id}/puntos/ajuste", ['puntos' => 50, 'motivo' => 'Cortesía'])
            ->assertOk()->assertJsonPath('saldo', 60);

        $this->assertDatabaseHas('puntos_movimientos', ['cliente_id' => $cliente->id, 'tipo' => 'ajuste', 'puntos' => 50]);
    }

    public function test_no_se_ajustan_puntos_al_cliente_sin_nombre(): void
    {
        $generico = Cliente::firstOrCreate(['nit_ci' => '0'], ['nombre' => 'SIN NOMBRE', 'activo' => true]);

        $this->comoUsuario($this->admin);
        $this->postJson("/api/clientes/{$generico->id}/puntos/ajuste", ['puntos' => 50, 'motivo' => 'x'])
            ->assertStatus(422);
    }

    public function test_con_el_programa_desactivado_no_se_acumula_ni_se_canjea(): void
    {
        config(['services.fidelizacion.activo' => false]);

        $producto = $this->crearProducto(['precio_venta' => 100], 10);
        $cliente = $this->cliente('5551234', 100);

        $this->vender([$this->linea($producto, 1)], $cliente)->assertCreated();
        $this->assertSame(100, $this->saldo($cliente));

        $this->vender([$this->linea($producto, 1)], $cliente, ['puntos_canje' => 20])->assertStatus(422);
    }

    // ------------------------------------------------------------------
    // Reparto del descuento
    // ------------------------------------------------------------------

    public function test_el_reparto_del_descuento_suma_exactamente(): void
    {
        $servicio = app(FidelizacionService::class);

        $reparto = $servicio->repartirDescuento([0 => 33.33, 1 => 33.33, 2 => 33.34], 10.00);
        $this->assertDinero(10.00, array_sum($reparto));

        // Una línea ya gratis no recibe descuento y no rompe la suma.
        $reparto = $servicio->repartirDescuento([0 => 0.0, 1 => 50.0], 7.77);
        $this->assertDinero(0, $reparto[0]);
        $this->assertDinero(7.77, $reparto[1]);
    }
}
