<?php

namespace Tests\Feature\Compras;

use App\Models\Almacen;
use App\Models\LoteProducto;
use App\Models\PedidoCompra;
use App\Models\Proveedor;
use Tests\TestCase;

/**
 * Compras por paquete, costo automático, lotes con vencimiento y edición de
 * pedidos de compra pendientes.
 */
class ComprasLotesTest extends TestCase
{
    private Proveedor $proveedor;

    protected function setUp(): void
    {
        parent::setUp();

        $this->proveedor = Proveedor::create(['nombre' => 'Distribuidora Beni', 'activo' => true]);
        $this->comoUsuario($this->crearAdmin());
    }

    public function test_compra_por_paquetes_calcula_unidades_y_costo_unitario(): void
    {
        $producto = $this->crearProducto(['unidades_por_paquete' => 12], 0);

        $respuesta = $this->postJson('/api/pedidos-compra', [
            'proveedor_id' => $this->proveedor->id,
            'items' => [['producto_id' => $producto->id, 'cantidad_paquetes' => 2, 'precio_paquete' => 120]],
        ])->assertCreated();

        $detalle = $respuesta->json('detalles.0');
        $this->assertSame(24, (int) $detalle['cantidad']);
        $this->assertDinero(10, $detalle['precio_unitario']);
        $this->assertDinero(240, $respuesta->json('total'));

        // Un pedido pendiente todavía no mueve el stock.
        $this->assertSame(0, $this->stockReal($producto));
    }

    public function test_paquete_sin_unidades_por_paquete_se_rechaza(): void
    {
        $producto = $this->crearProducto([], 0);

        $this->postJson('/api/pedidos-compra', [
            'proveedor_id' => $this->proveedor->id,
            'items' => [['producto_id' => $producto->id, 'cantidad_paquetes' => 1, 'precio_paquete' => 50]],
        ])->assertStatus(422);
    }

    public function test_recibir_suma_stock_crea_lote_y_actualiza_costo_y_precio_por_margen(): void
    {
        $producto = $this->crearProducto(['precio_compra' => 5, 'precio_venta' => 8, 'margen_porcentaje' => 50], 0);

        $id = $this->postJson('/api/pedidos-compra', [
            'proveedor_id' => $this->proveedor->id,
            'items' => [[
                'producto_id' => $producto->id, 'cantidad' => 10, 'precio_unitario' => 8,
                'numero_lote' => 'L-001', 'fecha_vencimiento' => '2027-03-15',
            ]],
        ])->assertCreated()->json('id');

        $this->postJson("/api/pedidos-compra/{$id}/recibir")->assertOk();

        $producto->refresh();
        $this->assertSame(10, $this->stockReal($producto));
        $this->assertDinero(8, $producto->precio_compra);
        $this->assertDinero(12, $producto->precio_venta); // 8 + 50 %
        $this->assertSame('2027-03-15', substr((string) $producto->fecha_vencimiento, 0, 10));

        $lote = LoteProducto::where('producto_id', $producto->id)->firstOrFail();
        $this->assertSame('L-001', $lote->numero_lote);
        $this->assertSame(10, (int) $lote->cantidad_disponible);
    }

    public function test_recibir_sin_actualizar_costos_deja_el_precio_como_estaba(): void
    {
        $producto = $this->crearProducto(['precio_compra' => 5, 'precio_venta' => 8], 0);

        $id = $this->postJson('/api/pedidos-compra', [
            'proveedor_id' => $this->proveedor->id,
            'items' => [['producto_id' => $producto->id, 'cantidad' => 4, 'precio_unitario' => 9]],
        ])->json('id');

        $this->postJson("/api/pedidos-compra/{$id}/recibir", ['actualizar_costos' => false])->assertOk();

        $this->assertDinero(5, $producto->fresh()->precio_compra);
        $this->assertSame(4, $this->stockReal($producto));
    }

    public function test_las_ventas_descuentan_primero_del_lote_que_vence_antes(): void
    {
        $producto = $this->crearProducto([], 10);
        $almacen = Almacen::principalId();

        $tarde = LoteProducto::create([
            'producto_id' => $producto->id, 'almacen_id' => $almacen, 'fecha_vencimiento' => '2027-12-01',
            'cantidad_inicial' => 5, 'cantidad_disponible' => 5,
        ]);
        $pronto = LoteProducto::create([
            'producto_id' => $producto->id, 'almacen_id' => $almacen, 'fecha_vencimiento' => '2027-01-01',
            'cantidad_inicial' => 5, 'cantidad_disponible' => 5,
        ]);

        $producto->ajustarStock(-7, $almacen);

        $this->assertSame(0, (int) $pronto->fresh()->cantidad_disponible);
        $this->assertSame(3, (int) $tarde->fresh()->cantidad_disponible);
        // Solo queda el lote tardío con unidades: ese es el próximo vencimiento.
        $this->assertSame('2027-12-01', substr((string) $producto->fresh()->fecha_vencimiento, 0, 10));
    }

    public function test_editar_pedido_pendiente_reemplaza_lineas_y_total(): void
    {
        $producto = $this->crearProducto([], 0);

        $id = $this->postJson('/api/pedidos-compra', [
            'proveedor_id' => $this->proveedor->id,
            'items' => [['producto_id' => $producto->id, 'cantidad' => 2, 'precio_unitario' => 10]],
        ])->json('id');

        $this->putJson("/api/pedidos-compra/{$id}", [
            'observaciones' => 'Corregido',
            'items' => [['producto_id' => $producto->id, 'cantidad' => 5, 'precio_unitario' => 10]],
        ])->assertOk();

        $pedido = PedidoCompra::with('detalles')->findOrFail($id);
        $this->assertCount(1, $pedido->detalles);
        $this->assertSame(5, (int) $pedido->detalles[0]->cantidad);
        $this->assertDinero(50, $pedido->total);
        $this->assertSame('Corregido', $pedido->observaciones);
    }

    public function test_un_pedido_recibido_ya_no_se_puede_editar(): void
    {
        $producto = $this->crearProducto([], 0);

        $id = $this->postJson('/api/pedidos-compra', [
            'proveedor_id' => $this->proveedor->id,
            'items' => [['producto_id' => $producto->id, 'cantidad' => 2, 'precio_unitario' => 10]],
        ])->json('id');

        $this->postJson("/api/pedidos-compra/{$id}/recibir")->assertOk();

        $this->putJson("/api/pedidos-compra/{$id}", ['observaciones' => 'Tarde'])->assertStatus(422);
    }

    public function test_reporte_de_compras_agrupa_por_proveedor_y_no_cuenta_cancelados(): void
    {
        $producto = $this->crearProducto([], 0);

        $crear = fn (int $cantidad) => $this->postJson('/api/pedidos-compra', [
            'proveedor_id' => $this->proveedor->id,
            'items' => [['producto_id' => $producto->id, 'cantidad' => $cantidad, 'precio_unitario' => 10]],
        ])->json('id');

        $crear(3);
        $crear(2);
        $cancelado = $crear(9);
        $this->deleteJson("/api/pedidos-compra/{$cancelado}")->assertOk();

        $r = $this->getJson('/api/reportes/compras?agrupar_por=proveedor')->assertOk();

        $this->assertSame(2, $r->json('resumen.pedidos'));
        $this->assertDinero(50, $r->json('resumen.total'));
        $this->assertCount(1, $r->json('grupos'));
        $this->assertSame('Distribuidora Beni', $r->json('grupos.0.etiqueta'));
    }
}
