<?php

namespace Tests\Feature\Caja;

use Tests\TestCase;

/**
 * Reportes de caja del cajero y reporte de caja chica: el vendedor solo ve lo suyo.
 */
class ReportesCajaTest extends TestCase
{
    public function test_el_cajero_ve_solo_sus_ventas_en_su_reporte_de_caja(): void
    {
        $admin = $this->crearAdmin();
        $vendedor = $this->crearVendedor();
        $this->abrirCaja(100, $admin);
        $producto = $this->crearProducto(['precio_venta' => 20], 50);

        $this->comoUsuario($vendedor);
        $this->postVenta([$this->linea($producto, 2)], ['monto_recibido' => 1000])->assertCreated();

        $this->comoUsuario($admin);
        $this->postVenta([$this->linea($producto, 1)], ['monto_recibido' => 1000])->assertCreated();

        $this->comoUsuario($vendedor);
        $r = $this->getJson('/api/caja/mi-reporte')->assertOk();

        $this->assertSame(1, $r->json('resumen.cantidad_ventas'));
        $this->assertDinero(40, $r->json('resumen.total'));
        $this->assertDinero(40, $r->json('resumen.efectivo'));

        // El administrador ve el total de todos, o el de un cajero puntual.
        $this->comoUsuario($admin);
        $this->assertSame(2, $this->getJson('/api/caja/mi-reporte')->json('resumen.cantidad_ventas'));
        $this->assertSame(1, $this->getJson('/api/caja/mi-reporte?usuario_id='.$vendedor->id)->json('resumen.cantidad_ventas'));
    }

    public function test_el_vendedor_no_puede_pedir_el_reporte_de_otro_usuario(): void
    {
        $admin = $this->crearAdmin();
        $vendedor = $this->crearVendedor();
        $this->abrirCaja(100, $admin);
        $producto = $this->crearProducto(['precio_venta' => 20], 10);

        $this->comoUsuario($admin);
        $this->postVenta([$this->linea($producto, 1)], ['monto_recibido' => 1000])->assertCreated();

        $this->comoUsuario($vendedor);
        $r = $this->getJson('/api/caja/mi-reporte?usuario_id='.$admin->id)->assertOk();

        $this->assertSame(0, $r->json('resumen.cantidad_ventas'));
    }

    public function test_reporte_de_caja_chica_suma_ingresos_y_egresos_propios(): void
    {
        $admin = $this->crearAdmin();
        $vendedor = $this->crearVendedor();
        $this->abrirCaja(100, $admin);

        $this->comoUsuario($vendedor);
        $this->postJson('/api/caja-chica', [
            'cuenta' => 'Varios', 'tipo' => 'egreso', 'metodo_pago' => 'efectivo', 'concepto' => 'Hielo', 'monto' => 15,
        ])->assertCreated();

        $this->comoUsuario($admin);
        $this->postJson('/api/caja-chica', [
            'cuenta' => 'Varios', 'tipo' => 'ingreso', 'metodo_pago' => 'efectivo', 'concepto' => 'Cambio', 'monto' => 50,
        ])->assertCreated();

        $this->comoUsuario($vendedor);
        $mio = $this->getJson('/api/caja-chica/reporte')->assertOk();
        $this->assertSame(1, $mio->json('resumen.cantidad'));
        $this->assertDinero(15, $mio->json('resumen.egresos'));
        $this->assertDinero(0, $mio->json('resumen.ingresos'));

        $this->comoUsuario($admin);
        $todo = $this->getJson('/api/caja-chica/reporte')->assertOk();
        $this->assertSame(2, $todo->json('resumen.cantidad'));
        $this->assertDinero(35, $todo->json('resumen.saldo'));
    }
}
