<?php

namespace Tests\Feature\Caja;

use App\Models\Caja;
use App\Models\DetallePedido;
use App\Models\Usuario;
use PHPUnit\Framework\Attributes\DataProvider;
use Tests\TestCase;

/**
 * 3.3 — Abrir, cerrar y arqueo: los totales deben cuadrar con las ventas,
 * la caja chica y el método de pago.
 *
 * Los números de cada escenario están pensados para poder verificarse a mano
 * (se explica la cuenta en el propio test).
 */
class CajaTest extends TestCase
{
    private Usuario $admin;

    private Usuario $vendedor;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = $this->crearAdmin();
        $this->vendedor = $this->crearVendedor();
    }

    private function comoAdmin(): void
    {
        $this->comoUsuario($this->admin);
    }

    private function comoVendedor(): void
    {
        $this->comoUsuario($this->vendedor);
    }

    private function abrirPorApi(float $monto): int
    {
        $this->comoAdmin();

        return $this->postJson('/api/caja/abrir', ['monto_apertura' => $monto])
            ->assertCreated()
            ->json('id');
    }

    // ------------------------------------------------------------------
    // Abrir
    // ------------------------------------------------------------------

    public function test_el_administrador_abre_la_caja_en_el_almacen_principal(): void
    {
        $this->comoAdmin();

        $respuesta = $this->postJson('/api/caja/abrir', [
            'monto_apertura' => 150.50,
            'observaciones' => 'Turno mañana',
        ])->assertCreated();

        $this->assertSame('abierta', $respuesta->json('estado'));
        $this->assertDinero(150.50, $respuesta->json('monto_apertura'));

        $caja = Caja::findOrFail($respuesta->json('id'));
        $this->assertSame('abierta', $caja->estado);
        $this->assertSame($this->admin->id, (int) $caja->usuario_apertura_id);
        $this->assertNotNull($caja->abierta_at);
        $this->assertNull($caja->cerrada_at);
    }

    public function test_el_vendedor_tambien_puede_abrir_su_turno(): void
    {
        $this->comoVendedor();

        $this->postJson('/api/caja/abrir', ['monto_apertura' => 50])->assertCreated();

        $this->assertDatabaseHas('cajas', ['usuario_apertura_id' => $this->vendedor->id, 'estado' => 'abierta']);
    }

    public function test_no_se_puede_abrir_una_segunda_caja_con_otra_abierta(): void
    {
        $this->abrirPorApi(100);

        $segunda = $this->postJson('/api/caja/abrir', ['monto_apertura' => 200]);

        $segunda->assertStatus(422);
        $this->assertStringContainsString('Ya hay una caja abierta', $segunda->json('message'));
        $this->assertSame(1, Caja::where('estado', 'abierta')->count());
    }

    public function test_se_puede_abrir_otra_caja_despues_de_cerrar_la_anterior(): void
    {
        $primera = $this->abrirPorApi(100);
        $this->postJson("/api/caja/{$primera}/cerrar", ['monto_cierre_real' => 100])->assertOk();

        $this->postJson('/api/caja/abrir', ['monto_apertura' => 80])->assertCreated();

        $this->assertSame(1, Caja::where('estado', 'abierta')->count());
        $this->assertSame(1, Caja::where('estado', 'cerrada')->count());
    }

    public function test_abrir_exige_un_monto_de_apertura_valido(): void
    {
        $this->comoAdmin();

        $this->postJson('/api/caja/abrir', [])->assertStatus(422)->assertJsonValidationErrors('monto_apertura');
        $this->postJson('/api/caja/abrir', ['monto_apertura' => -5])->assertStatus(422)->assertJsonValidationErrors('monto_apertura');
        $this->postJson('/api/caja/abrir', ['monto_apertura' => 'mucho'])->assertStatus(422)->assertJsonValidationErrors('monto_apertura');
        $this->postJson('/api/caja/abrir', ['monto_apertura' => 0, 'almacen_id' => 9999])->assertStatus(422)->assertJsonValidationErrors('almacen_id');

        $this->assertDatabaseCount('cajas', 0);
    }

    // ------------------------------------------------------------------
    // Estado actual (y blindaje de caja)
    // ------------------------------------------------------------------

    public function test_sin_caja_abierta_el_estado_actual_lo_dice(): void
    {
        $this->comoVendedor();

        $this->getJson('/api/caja/actual')
            ->assertOk()
            ->assertJsonPath('abierta', false);
    }

    public function test_el_administrador_ve_los_totales_y_el_vendedor_solo_sus_ventas(): void
    {
        $this->abrirPorApi(100);
        $producto = $this->crearProducto(['precio_venta' => 10], 50);

        // El administrador vende 30 y el vendedor 20.
        $this->comoAdmin();
        $this->postVenta([$this->linea($producto, 3)], ['monto_recibido' => 30])->assertCreated();
        $this->comoVendedor();
        $this->postVenta([$this->linea($producto, 2)], ['monto_recibido' => 20])->assertCreated();

        // Vendedor: sabe que hay caja abierta y ve lo SUYO, nunca el acumulado.
        $vendedor = $this->getJson('/api/caja/actual')->assertOk();
        $vendedor->assertJsonPath('abierta', true);
        $vendedor->assertJsonMissingPath('totales');
        $this->assertSame(1, $vendedor->json('mis_ventas.cantidad'));
        $this->assertDinero(20, $vendedor->json('mis_ventas.total'));
        $this->assertDinero(20, $vendedor->json('mis_ventas.efectivo'));

        // Administrador: ve el acumulado de todo el negocio.
        $this->comoAdmin();
        $admin = $this->getJson('/api/caja/actual')->assertOk();
        $admin->assertJsonMissingPath('mis_ventas');
        $this->assertSame(2, $admin->json('totales.cantidad_ventas'));
        $this->assertDinero(50, $admin->json('totales.ventas_total'));
        $this->assertDinero(150, $admin->json('totales.saldo_esperado_ahora')); // 100 + 50
    }

    // ------------------------------------------------------------------
    // Cierre: los totales cuadran
    // ------------------------------------------------------------------

    /**
     * Turno completo con todos los casos que mueven (o NO mueven) el efectivo.
     *
     *   Apertura                                   100
     *   Venta efectivo                              40
     *   Venta QR                                    25
     *   Venta tarjeta                               35
     *   Venta mixta (10 efectivo + 20 QR)           30
     *   Venta efectivo ANULADA                      60   -> no cuenta
     *   Venta a crédito                             70   -> no entra plata
     *   Caja chica: ingreso efectivo                50
     *   Caja chica: egreso efectivo                 20
     *   Caja chica: egreso por cheque               15   -> no es efectivo
     *
     *   Efectivo de ventas = 40 + 10                = 50
     *   QR                 = 25 + 20                = 45
     *   Tarjeta                                     = 35
     *   Total de ventas    = 40 + 25 + 35 + 30      = 130
     *   Esperado en caja   = 100 + 50 + 50 - 20     = 180
     *   Contado 175  ->  diferencia = -5
     */
    public function test_el_cierre_cuadra_con_ventas_caja_chica_y_metodo_de_pago(): void
    {
        $cliente = $this->crearClienteConCredito();
        $p40 = $this->crearProducto(['precio_venta' => 40], 50);
        $p25 = $this->crearProducto(['precio_venta' => 25], 50);
        $p35 = $this->crearProducto(['precio_venta' => 35], 50);
        $p30 = $this->crearProducto(['precio_venta' => 30], 50);
        $p60 = $this->crearProducto(['precio_venta' => 60], 50);
        $p70 = $this->crearProducto(['precio_venta' => 70], 50);

        $cajaId = $this->abrirPorApi(100);

        $this->comoVendedor();
        $ventaEfectivo = $this->postVenta([$this->linea($p40)], ['monto_recibido' => 50])->assertCreated()->json('venta.id');
        $this->postVenta([$this->linea($p25)], ['metodo_pago' => 'qr'])->assertCreated();
        $this->postVenta([$this->linea($p35)], ['metodo_pago' => 'tarjeta'])->assertCreated();
        $this->postVenta([$this->linea($p30)], [
            'metodo_pago' => 'mixto',
            'pagos' => [
                ['metodo_pago' => 'efectivo', 'monto' => 10],
                ['metodo_pago' => 'qr', 'monto' => 20],
            ],
        ])->assertCreated();
        $ventaAnulada = $this->postVenta([$this->linea($p60)], ['monto_recibido' => 60])->assertCreated()->json('venta.id');
        $this->postVenta([$this->linea($p70)], [
            'metodo_pago' => 'credito',
            'nit_ci' => $cliente->nit_ci,
            'razon_social' => $cliente->nombre,
        ])->assertCreated();

        $this->postJson('/api/caja-chica', [
            'cuenta' => 'Cambio', 'tipo' => 'ingreso', 'metodo_pago' => 'efectivo',
            'concepto' => 'Sencillo del banco', 'monto' => 50,
        ])->assertCreated();
        $this->postJson('/api/caja-chica', [
            'cuenta' => 'Hielo', 'tipo' => 'egreso', 'metodo_pago' => 'efectivo',
            'concepto' => 'Bolsas de hielo', 'monto' => 20,
        ])->assertCreated();
        $this->postJson('/api/caja-chica', [
            'cuenta' => 'Servicios', 'tipo' => 'egreso', 'metodo_pago' => 'cheque',
            'concepto' => 'Pago de luz', 'monto' => 15,
        ])->assertCreated();

        $this->comoAdmin();
        $this->postJson("/api/ventas/{$ventaAnulada}/anular", ['motivo' => 'Cliente se arrepintió'])->assertOk();

        // --- Arqueo en vivo, antes de cerrar ---
        $vivo = $this->getJson('/api/caja/actual')->assertOk()->json('totales');
        $this->assertDinero(50, $vivo['ventas_efectivo']);
        $this->assertDinero(45, $vivo['ventas_qr']);
        $this->assertDinero(35, $vivo['ventas_tarjeta']);
        $this->assertDinero(130, $vivo['ventas_total']);
        $this->assertDinero(70, $vivo['ventas_credito']);
        $this->assertDinero(50, $vivo['ingresos_caja_chica']);
        $this->assertDinero(20, $vivo['egresos_caja_chica']);
        $this->assertDinero(180, $vivo['saldo_esperado_ahora']);

        // --- Cierre: se cuentan 175 en el cajón ---
        $cierre = $this->postJson("/api/caja/{$cajaId}/cerrar", [
            'monto_cierre_real' => 175,
            'observaciones' => 'Faltan 5',
        ])->assertOk();

        $this->assertDinero(180, $cierre->json('monto_cierre_esperado'));
        $this->assertDinero(-5, $cierre->json('diferencia'));

        $caja = Caja::findOrFail($cajaId);
        $this->assertSame('cerrada', $caja->estado);
        $this->assertSame($this->admin->id, (int) $caja->usuario_cierre_id);
        $this->assertSame($this->admin->nombre, $caja->cerrada_por_nombre);
        $this->assertNotNull($caja->cerrada_at);

        $this->assertDinero(100, $caja->monto_apertura);
        $this->assertDinero(50, $caja->monto_ventas_efectivo);
        $this->assertDinero(45, $caja->monto_ventas_qr);
        $this->assertDinero(35, $caja->monto_ventas_tarjeta);
        $this->assertDinero(130, $caja->monto_ventas_total);
        $this->assertDinero(70, $caja->monto_ventas_credito);
        $this->assertDinero(50, $caja->monto_ingresos_caja_chica);
        $this->assertDinero(20, $caja->monto_egresos_caja_chica);
        $this->assertDinero(180, $caja->monto_cierre_esperado);
        $this->assertDinero(175, $caja->monto_cierre_real);
        $this->assertDinero(-5, $caja->diferencia);
        $this->assertSame(4, (int) $caja->cantidad_ventas);
        $this->assertSame(1, (int) $caja->cantidad_anuladas);
        $this->assertDinero(60, $caja->monto_anulado);

        // Invariante: lo cobrado por cada método suma el total de ventas.
        $this->assertDinero(
            $caja->monto_ventas_total,
            $caja->monto_ventas_efectivo + $caja->monto_ventas_qr + $caja->monto_ventas_tarjeta
        );

        // Desglose por vendedor (todo lo vendió el mismo).
        $this->assertCount(1, $caja->detalle_vendedores);
        $detalle = $caja->detalle_vendedores[0];
        $this->assertSame($this->vendedor->id, (int) $detalle['usuario_id']);
        $this->assertSame(4, (int) $detalle['cantidad']);
        $this->assertDinero(50, $detalle['efectivo']);
        $this->assertDinero(45, $detalle['qr']);
        $this->assertDinero(35, $detalle['tarjeta']);
        $this->assertDinero(130, $detalle['total']);

        // --- El cierre es una foto: anular una venta DESPUÉS no lo cambia ---
        $this->postJson("/api/ventas/{$ventaEfectivo}/anular", ['motivo' => 'Revisión posterior'])->assertOk();

        $congelada = Caja::findOrFail($cajaId);
        $this->assertDinero(130, $congelada->monto_ventas_total);
        $this->assertDinero(180, $congelada->monto_cierre_esperado);
        $this->assertDinero(-5, $congelada->diferencia);
    }

    #[DataProvider('cierresSinMovimientos')]
    public function test_la_diferencia_es_lo_contado_menos_lo_esperado(float $contado, float $diferencia): void
    {
        // Sin ventas ni caja chica, lo esperado es solo la apertura (100).
        $cajaId = $this->abrirPorApi(100);

        $cierre = $this->postJson("/api/caja/{$cajaId}/cerrar", ['monto_cierre_real' => $contado])->assertOk();

        $this->assertDinero(100, $cierre->json('monto_cierre_esperado'));
        $this->assertDinero($diferencia, $cierre->json('diferencia'));
    }

    public static function cierresSinMovimientos(): array
    {
        return [
            'cuadra exacto' => [100.00, 0.00],
            'faltante' => [90.50, -9.50],
            'sobrante' => [130.00, 30.00],
        ];
    }

    public function test_una_devolucion_en_efectivo_resta_del_efectivo_esperado(): void
    {
        // Venta de 2 x 30 = 60 en efectivo; se devuelve 1 unidad (30).
        $producto = $this->crearProducto(['precio_venta' => 30], 10);
        $cajaId = $this->abrirPorApi(100);

        $this->comoVendedor();
        $ventaId = $this->postVenta([$this->linea($producto, 2)], ['monto_recibido' => 60])->assertCreated()->json('venta.id');
        $detalleId = DetallePedido::where('pedido_id', $ventaId)->value('id');

        $this->comoAdmin();
        $devolucion = $this->postJson("/api/ventas/{$ventaId}/devolucion", [
            'motivo' => 'Botella con fisura',
            'items' => [['detalle_id' => $detalleId, 'cantidad' => 1]],
        ])->assertCreated();

        $this->assertDinero(30, $devolucion->json('devolucion.total'));
        $this->assertDinero(30, $devolucion->json('devolucion.monto_reembolsado'));
        $this->assertSame('efectivo', $devolucion->json('devolucion.metodo_reembolso'));
        $this->assertSame(9, $this->stockReal($producto)); // 10 - 2 + 1

        $vivo = $this->getJson('/api/caja/actual')->assertOk()->json('totales');
        $this->assertDinero(60, $vivo['ventas_efectivo']);
        $this->assertDinero(30, $vivo['devoluciones_efectivo']);
        $this->assertSame(1, $vivo['cantidad_devoluciones']);
        $this->assertDinero(130, $vivo['saldo_esperado_ahora']); // 100 + 60 - 30

        $cierre = $this->postJson("/api/caja/{$cajaId}/cerrar", ['monto_cierre_real' => 130])->assertOk();

        $this->assertDinero(130, $cierre->json('monto_cierre_esperado'));
        $this->assertDinero(0, $cierre->json('diferencia'));
        $this->assertDinero(30, Caja::findOrFail($cajaId)->monto_devoluciones_efectivo);
    }

    public function test_los_abonos_de_fiado_suman_por_metodo_y_la_venta_a_credito_no_cuenta_como_efectivo(): void
    {
        $cliente = $this->crearClienteConCredito();
        $producto = $this->crearProducto(['precio_venta' => 70], 10);
        $cajaId = $this->abrirPorApi(100);

        $this->comoVendedor();
        $this->postVenta([$this->linea($producto)], [
            'metodo_pago' => 'credito',
            'nit_ci' => $cliente->nit_ci,
            'razon_social' => $cliente->nombre,
        ])->assertCreated();

        // El cliente abona 30 en efectivo y 10 por QR.
        $this->postJson('/api/cuentas-por-cobrar/abonos', [
            'cliente_id' => $cliente->id, 'monto' => 30, 'metodo_pago' => 'efectivo',
        ])->assertSuccessful();
        $this->postJson('/api/cuentas-por-cobrar/abonos', [
            'cliente_id' => $cliente->id, 'monto' => 10, 'metodo_pago' => 'qr',
        ])->assertSuccessful();

        $this->comoAdmin();
        $cierre = $this->postJson("/api/caja/{$cajaId}/cerrar", ['monto_cierre_real' => 130])->assertOk();

        $caja = Caja::findOrFail($cajaId);
        $this->assertDinero(0, $caja->monto_ventas_efectivo);   // el fiado no es efectivo
        $this->assertDinero(0, $caja->monto_ventas_total);
        $this->assertDinero(70, $caja->monto_ventas_credito);   // se vendió 70, no entró plata
        $this->assertDinero(30, $caja->monto_abonos_efectivo);
        $this->assertDinero(10, $caja->monto_abonos_qr);
        $this->assertDinero(0, $caja->monto_abonos_tarjeta);

        // Esperado = 100 de apertura + 30 de abono en efectivo (el QR no está en el cajón).
        $this->assertDinero(130, $cierre->json('monto_cierre_esperado'));
        $this->assertDinero(0, $cierre->json('diferencia'));
    }

    // ------------------------------------------------------------------
    // Cierre: reglas
    // ------------------------------------------------------------------

    public function test_una_caja_no_se_puede_cerrar_dos_veces(): void
    {
        $cajaId = $this->abrirPorApi(100);

        $this->postJson("/api/caja/{$cajaId}/cerrar", ['monto_cierre_real' => 100])->assertOk();
        $segunda = $this->postJson("/api/caja/{$cajaId}/cerrar", ['monto_cierre_real' => 999]);

        $segunda->assertStatus(422);
        $this->assertStringContainsString('ya está cerrada', $segunda->json('message'));
        // El segundo intento no pisó el cierre original.
        $this->assertDinero(100, Caja::findOrFail($cajaId)->monto_cierre_real);
    }

    public function test_cerrar_exige_el_monto_contado(): void
    {
        $cajaId = $this->abrirPorApi(100);

        $this->postJson("/api/caja/{$cajaId}/cerrar", [])->assertStatus(422)->assertJsonValidationErrors('monto_cierre_real');
        $this->postJson("/api/caja/{$cajaId}/cerrar", ['monto_cierre_real' => -1])->assertStatus(422)->assertJsonValidationErrors('monto_cierre_real');

        $this->assertSame('abierta', Caja::findOrFail($cajaId)->estado);
    }

    public function test_cuando_cierra_el_vendedor_la_respuesta_no_revela_los_totales_del_negocio(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 10], 10);
        $cajaId = $this->abrirPorApi(100);
        $this->postVenta([$this->linea($producto, 2)], ['monto_recibido' => 20])->assertCreated();

        $this->comoVendedor();
        $respuesta = $this->postJson("/api/caja/{$cajaId}/cerrar", ['monto_cierre_real' => 120])->assertOk();

        foreach ([
            'monto_cierre_esperado', 'diferencia', 'monto_ventas_efectivo', 'monto_ventas_qr',
            'monto_ventas_tarjeta', 'monto_ventas_total', 'monto_ventas_credito', 'cantidad_ventas',
            'monto_anulado', 'monto_ingresos_caja_chica', 'monto_egresos_caja_chica', 'detalle_vendedores',
        ] as $campoOculto) {
            $respuesta->assertJsonMissingPath($campoOculto);
        }

        // Lo oculto en la respuesta sí quedó guardado para el administrador.
        $caja = Caja::findOrFail($cajaId);
        $this->assertDinero(120, $caja->monto_cierre_esperado);
        $this->assertDinero(20, $caja->monto_ventas_total);
        $this->assertSame($this->vendedor->id, (int) $caja->usuario_cierre_id);
    }

    // ------------------------------------------------------------------
    // Caja chica
    // ------------------------------------------------------------------

    public function test_no_se_registra_caja_chica_sin_caja_abierta(): void
    {
        $this->comoVendedor();

        $respuesta = $this->postJson('/api/caja-chica', [
            'cuenta' => 'Hielo', 'tipo' => 'egreso', 'metodo_pago' => 'efectivo',
            'concepto' => 'Bolsas', 'monto' => 10,
        ]);

        $respuesta->assertStatus(422);
        $this->assertStringContainsString('No hay una caja abierta', $respuesta->json('message'));
        $this->assertDatabaseCount('movimientos_caja_chica', 0);
    }

    public function test_el_resumen_de_caja_chica_suma_ingresos_y_egresos_del_turno(): void
    {
        $this->abrirPorApi(100);

        $this->comoVendedor();
        foreach ([['ingreso', 50], ['egreso', 20], ['egreso', 5.50]] as [$tipo, $monto]) {
            $this->postJson('/api/caja-chica', [
                'cuenta' => 'Varios', 'tipo' => $tipo, 'metodo_pago' => 'efectivo',
                'concepto' => 'Movimiento de prueba', 'monto' => $monto,
            ])->assertCreated();
        }

        $resumen = $this->getJson('/api/caja-chica/resumen')->assertOk();

        $this->assertTrue($resumen->json('caja_abierta'));
        $this->assertDinero(50, $resumen->json('ingresos'));
        $this->assertDinero(25.50, $resumen->json('egresos'));
        $this->assertDinero(24.50, $resumen->json('saldo'));
    }
}
