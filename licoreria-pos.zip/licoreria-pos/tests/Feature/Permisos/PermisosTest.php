<?php

namespace Tests\Feature\Permisos;

use App\Models\Abono;
use App\Models\Alerta;
use App\Models\Almacen;
use App\Models\Cliente;
use App\Models\Combo;
use App\Models\Devolucion;
use App\Models\MovimientoCajaChica;
use App\Models\Pedido;
use App\Models\PedidoCompra;
use App\Models\Promocion;
use App\Models\Proveedor;
use App\Models\Repartidor;
use App\Models\Usuario;
use App\Models\ZonaDelivery;
use PHPUnit\Framework\Attributes\DataProvider;
use Tests\TestCase;

/**
 * 3.4 — Vendedor vs administrador en todas las rutas sensibles.
 *
 * Cada ruta se prueba con IDs REALES (no inventados). Es importante: si el
 * binding del modelo corre antes que el middleware de rol, un ID inexistente
 * daría 404 en vez de 403 y el test no probaría el permiso.
 */
class PermisosTest extends TestCase
{
    private Usuario $admin;

    private Usuario $vendedor;

    /**
     * Crea una caja abierta, una venta y un ejemplar de cada entidad que
     * aparece en una URL, y devuelve sus ids por nombre de parámetro.
     * Al terminar queda SIN sesión: cada test elige quién es.
     */
    private function prepararEscenario(): array
    {
        $this->admin = $this->crearAdmin();
        $this->vendedor = $this->crearVendedor();
        $otroUsuario = $this->crearUsuario('vendedor');

        $caja = $this->abrirCaja(100, $this->admin);
        $producto = $this->crearProducto(['precio_venta' => 20], 20);
        $vitrina = $this->crearCombo([[$producto, 1]], 15);

        $this->comoUsuario($this->admin);
        $ventaId = $this->postVenta([$this->linea($producto)], ['monto_recibido' => 50])
            ->assertCreated()->json('venta.id');
        $venta = Pedido::findOrFail($ventaId);

        $proveedor = Proveedor::create(['nombre' => 'Proveedor de prueba']);

        $ids = [
            'usuario' => $otroUsuario->id,
            'categoria' => $producto->categoria_id,
            'producto' => $producto->id,
            'combo' => Combo::where('producto_id', $vitrina->id)->value('id'),
            'promocion' => Promocion::create([
                'nombre' => 'Promo de prueba', 'tipo' => 'volumen', 'alcance' => 'todo',
                'tipo_descuento' => 'porcentaje', 'valor' => 10, 'cantidad_minima' => 3, 'activo' => true,
            ])->id,
            'zona' => ZonaDelivery::create(['nombre' => 'Zona Centro', 'costo_envio' => 5])->id,
            'repartidor' => Repartidor::create(['nombre' => 'Repartidor Uno'])->id,
            'abono' => Abono::create([
                'pedido_id' => $ventaId, 'cliente_id' => $venta->cliente_id, 'usuario_id' => $this->admin->id,
                'caja_id' => $caja->id, 'monto' => 1, 'metodo_pago' => 'efectivo',
            ])->id,
            'almacen' => Almacen::create(['nombre' => 'Almacén secundario'])->id,
            'proveedor' => $proveedor->id,
            'pedidoCompra' => PedidoCompra::create([
                'proveedor_id' => $proveedor->id, 'usuario_id' => $this->admin->id, 'estado' => 'pendiente',
            ])->id,
            'alerta' => Alerta::create([
                'tipo' => 'stock_minimo', 'producto_id' => $producto->id, 'severidad' => 'aviso',
                'titulo' => 'Poco stock', 'mensaje' => 'Quedan pocas unidades',
            ])->id,
            'venta' => $ventaId,
            'pedido' => $ventaId,
            'cliente' => $venta->cliente_id,
            'devolucion' => Devolucion::create([
                'pedido_id' => $ventaId, 'usuario_id' => $this->admin->id, 'caja_id' => $caja->id,
                'total' => 1, 'motivo' => 'Prueba',
            ])->id,
            'caja' => $caja->id,
            'movimiento' => MovimientoCajaChica::create([
                'caja_id' => $caja->id, 'almacen_id' => Almacen::principalId(), 'usuario_id' => $this->admin->id,
                'cuenta' => 'Varios', 'tipo' => 'egreso', 'metodo_pago' => 'efectivo',
                'concepto' => 'Gasto de prueba', 'monto' => 5,
            ])->id,
        ];

        $this->flushHeaders();

        return $ids;
    }

    /** '/api/' + la plantilla con {placeholders} reemplazados por ids reales. */
    private function url(string $plantilla, array $ids): string
    {
        return '/api/'.preg_replace_callback(
            '/\{(\w+)\}/',
            fn (array $m) => (string) $ids[$m[1]],
            $plantilla
        );
    }

    // ------------------------------------------------------------------
    // Rutas solo administrador
    // ------------------------------------------------------------------

    #[DataProvider('rutasSoloAdministrador')]
    public function test_el_vendedor_recibe_403_en_rutas_de_administrador(string $metodo, string $ruta): void
    {
        $ids = $this->prepararEscenario();
        $this->comoUsuario($this->vendedor);

        $this->json($metodo, $this->url($ruta, $ids))->assertForbidden();
    }

    #[DataProvider('rutasDeLecturaDelAdministrador')]
    public function test_el_administrador_pasa_el_control_de_rol(string $metodo, string $ruta): void
    {
        $ids = $this->prepararEscenario();
        $this->comoUsuario($this->admin);

        $estado = $this->json($metodo, $this->url($ruta, $ids))->getStatusCode();

        // Lo que responda la ruta es asunto de otros tests; aquí solo importa
        // que ni la sesión ni el rol lo frenen.
        $this->assertNotContains($estado, [401, 403], "{$metodo} {$ruta} bloqueó al administrador");
    }

    public static function rutasSoloAdministrador(): array
    {
        $rutas = [
            // Usuarios y categorías
            ['GET', 'usuarios'], ['POST', 'usuarios'], ['GET', 'usuarios/{usuario}'],
            ['PUT', 'usuarios/{usuario}'], ['DELETE', 'usuarios/{usuario}'],
            ['POST', 'categorias'], ['PUT', 'categorias/{categoria}'],
            ['PATCH', 'categorias/{categoria}'], ['DELETE', 'categorias/{categoria}'],
            // Productos y precios
            ['POST', 'productos'], ['PUT', 'productos/{producto}'], ['PATCH', 'productos/{producto}'],
            ['DELETE', 'productos/{producto}'], ['GET', 'productos/{producto}/historial-precios'],
            // Combos y promociones
            ['GET', 'combos'], ['POST', 'combos'], ['GET', 'combos/{combo}'],
            ['PUT', 'combos/{combo}'], ['DELETE', 'combos/{combo}'],
            ['GET', 'promociones'], ['POST', 'promociones'], ['GET', 'promociones/{promocion}'],
            ['PUT', 'promociones/{promocion}'], ['DELETE', 'promociones/{promocion}'],
            // Delivery
            ['POST', 'zonas-delivery'], ['PUT', 'zonas-delivery/{zona}'], ['DELETE', 'zonas-delivery/{zona}'],
            ['POST', 'repartidores'], ['PUT', 'repartidores/{repartidor}'], ['DELETE', 'repartidores/{repartidor}'],
            // Fiado
            ['POST', 'cuentas-por-cobrar/abonos/{abono}/anular'], ['GET', 'reportes/cuentas-por-cobrar'],
            // Inventario y almacenes (mermas, altas y bajas)
            ['POST', 'movimientos-inventario'],
            ['POST', 'almacenes'], ['PUT', 'almacenes/{almacen}'], ['DELETE', 'almacenes/{almacen}'],
            // Compras a proveedores
            ['GET', 'proveedores'], ['POST', 'proveedores'], ['GET', 'proveedores/{proveedor}'],
            ['PUT', 'proveedores/{proveedor}'], ['DELETE', 'proveedores/{proveedor}'],
            ['GET', 'pedidos-compra'], ['POST', 'pedidos-compra'], ['GET', 'pedidos-compra/{pedidoCompra}'],
            ['DELETE', 'pedidos-compra/{pedidoCompra}'], ['POST', 'pedidos-compra/{pedidoCompra}/recibir'],
            // Reportes
            ['GET', 'reportes/rentabilidad'], ['GET', 'reportes/ventas'], ['GET', 'reportes/inventario'],
            ['GET', 'reportes/movimientos'], ['GET', 'reportes/clientes'], ['GET', 'reportes/libro-ventas'],
            ['GET', 'reportes/dashboard'],
            // Alertas, reposición, auditoría
            ['GET', 'alertas'], ['POST', 'alertas/revisar'], ['POST', 'alertas/leer-todas'],
            ['POST', 'alertas/{alerta}/leer'],
            ['GET', 'reposicion/sugerencias'], ['POST', 'reposicion/generar-borradores'],
            ['GET', 'auditoria'],
            // Ventas: historial, anular, devolver (mueven dinero y stock)
            ['GET', 'ventas'], ['GET', 'ventas/{venta}'], ['POST', 'ventas/{venta}/anular'],
            ['POST', 'ventas/{venta}/devolucion'], ['GET', 'devoluciones/{devolucion}/nota-pdf'],
            // Caja central: histórico, detalle y arqueo
            ['GET', 'caja'], ['GET', 'caja/{caja}'], ['GET', 'caja/{caja}/arqueo-pdf'],
            // Borrados con efecto contable
            ['DELETE', 'caja-chica/{movimiento}'], ['DELETE', 'pedidos/{pedido}'],
        ];

        return self::comoCasos($rutas);
    }

    public static function rutasDeLecturaDelAdministrador(): array
    {
        return self::comoCasos([
            ['GET', 'usuarios'], ['GET', 'caja'], ['GET', 'caja/{caja}'], ['GET', 'ventas'],
            ['GET', 'ventas/{venta}'], ['GET', 'proveedores'], ['GET', 'combos'],
            ['GET', 'promociones'], ['GET', 'alertas'], ['GET', 'auditoria'],
            ['GET', 'almacenes'], ['GET', 'caja-chica'], ['GET', 'caja/actual'],
        ]);
    }

    // ------------------------------------------------------------------
    // Rutas compartidas (administrador y vendedor)
    // ------------------------------------------------------------------

    #[DataProvider('rutasCompartidas')]
    public function test_el_vendedor_puede_usar_el_modulo_de_venta(string $metodo, string $ruta): void
    {
        $ids = $this->prepararEscenario();
        $this->comoUsuario($this->vendedor);

        $estado = $this->json($metodo, $this->url($ruta, $ids))->getStatusCode();

        // Puede ser 200, 201 o un 422 por body vacío: lo que NO puede ser es 401/403.
        $this->assertNotContains($estado, [401, 403], "{$metodo} {$ruta} le cerró la puerta al vendedor");
    }

    public static function rutasCompartidas(): array
    {
        return self::comoCasos([
            ['GET', 'caja/actual'], ['POST', 'caja/abrir'], ['POST', 'caja/{caja}/cerrar'],
            ['GET', 'ventas/contexto'], ['GET', 'ventas/buscar-producto'], ['GET', 'ventas/cliente'],
            ['POST', 'ventas'], ['POST', 'ventas/promociones'],
            ['GET', 'clientes'], ['POST', 'clientes'], ['GET', 'clientes/{cliente}'], ['PUT', 'clientes/{cliente}'],
            ['GET', 'caja-chica'], ['GET', 'caja-chica/resumen'], ['POST', 'caja-chica'],
            ['GET', 'movimientos-inventario'], ['GET', 'almacenes'], ['GET', 'almacenes/{almacen}'],
            ['GET', 'repartidores'],
            ['GET', 'cuentas-por-cobrar'], ['POST', 'cuentas-por-cobrar/abonos'],
            ['GET', 'pedidos'], ['GET', 'pedidos/nuevos'], ['GET', 'pedidos/{pedido}'],
        ]);
    }

    public function test_el_vendedor_ve_el_estado_de_caja_y_el_contexto_de_venta(): void
    {
        $this->prepararEscenario();
        $this->comoUsuario($this->vendedor);

        $this->getJson('/api/caja/actual')->assertOk()->assertJsonPath('abierta', true);
        $this->getJson('/api/ventas/contexto')->assertOk()->assertJsonPath('caja_abierta', true);
    }

    // ------------------------------------------------------------------
    // Sesión: sin token, token ajeno, token inservible
    // ------------------------------------------------------------------

    #[DataProvider('todasLasRutasDelStaff')]
    public function test_sin_sesion_las_rutas_del_staff_dan_401(string $metodo, string $ruta): void
    {
        $ids = $this->prepararEscenario();

        $this->json($metodo, $this->url($ruta, $ids))->assertUnauthorized();
    }

    #[DataProvider('todasLasRutasDelStaff')]
    public function test_un_token_de_cliente_no_abre_las_rutas_del_staff(string $metodo, string $ruta): void
    {
        $ids = $this->prepararEscenario();
        $cliente = Cliente::create(['nombre' => 'Cliente de la tienda', 'email' => 'cliente@prueba.test', 'activo' => true]);
        $this->comoUsuario($cliente);

        $this->json($metodo, $this->url($ruta, $ids))->assertUnauthorized();
    }

    public static function todasLasRutasDelStaff(): array
    {
        return self::comoCasos(array_merge(
            array_values(self::rutasSoloAdministrador()),
            array_values(self::rutasCompartidas())
        ));
    }

    public function test_un_token_de_staff_no_abre_las_rutas_del_cliente(): void
    {
        $this->prepararEscenario();
        $this->comoUsuario($this->admin);

        $this->getJson('/api/cliente/me')->assertUnauthorized();
        $this->getJson('/api/cliente/mis-pedidos')->assertUnauthorized();
    }

    public function test_el_token_de_un_cliente_si_sirve_en_las_rutas_del_cliente(): void
    {
        $cliente = Cliente::create(['nombre' => 'Cliente de la tienda', 'email' => 'cliente@prueba.test', 'activo' => true]);
        $this->comoUsuario($cliente);

        $this->getJson('/api/cliente/me')->assertOk()->assertJsonPath('id', $cliente->id);
    }

    public function test_un_token_inventado_o_vencido_o_de_usuario_inactivo_se_rechaza(): void
    {
        $usuario = $this->crearVendedor();

        // Inventado.
        $this->withToken('1|esto-no-es-un-token-real')->getJson('/api/caja/actual')->assertUnauthorized();

        // Vencido.
        $vencido = $usuario->createToken('vencido', ['*'], now()->subMinute())->plainTextToken;
        $this->withToken($vencido)->getJson('/api/caja/actual')->assertUnauthorized();

        // Válido... hasta que desactivan al usuario.
        $this->comoUsuario($usuario);
        $this->getJson('/api/caja/actual')->assertOk();

        $usuario->update(['activo' => false]);
        $this->getJson('/api/caja/actual')->assertUnauthorized();
    }

    public function test_el_login_rechaza_clave_incorrecta_y_usuario_inactivo(): void
    {
        $vendedor = $this->crearVendedor();
        $inactivo = $this->crearUsuario('vendedor', ['activo' => false]);

        $this->postJson('/api/auth/login', ['email' => $vendedor->email, 'password' => 'incorrecta'])
            ->assertUnauthorized();

        $this->postJson('/api/auth/login', ['email' => $inactivo->email, 'password' => 'secreto123'])
            ->assertForbidden();

        $ok = $this->postJson('/api/auth/login', ['email' => $vendedor->email, 'password' => 'secreto123'])
            ->assertOk();

        // El token que devuelve el login realmente abre la sesión.
        $this->flushHeaders();
        $this->withToken($ok->json('token'))->getJson('/api/auth/me')
            ->assertOk()->assertJsonPath('email', $vendedor->email);
    }

    // ------------------------------------------------------------------
    // Escalada de privilegios y datos ajenos
    // ------------------------------------------------------------------

    public function test_el_vendedor_no_puede_darse_rol_de_administrador_desde_su_perfil(): void
    {
        $this->prepararEscenario();
        $this->comoUsuario($this->vendedor);
        $emailOriginal = $this->vendedor->email;

        $this->putJson('/api/auth/perfil', [
            'nombre' => 'Nuevo Nombre',
            'rol' => 'administrador',
            'activo' => false,
            'email' => 'otro@correo.test',
        ])->assertOk();

        $actual = Usuario::findOrFail($this->vendedor->id);
        $this->assertSame('Nuevo Nombre', $actual->nombre);   // lo permitido, sí cambia
        $this->assertSame('vendedor', $actual->rol);          // lo prohibido, no
        $this->assertTrue((bool) $actual->activo);
        $this->assertSame($emailOriginal, $actual->email);

        // Y sigue sin poder entrar a lo de administrador.
        $this->getJson('/api/usuarios')->assertForbidden();
    }

    public function test_el_vendedor_no_puede_habilitar_credito_ni_fijar_limite_a_un_cliente(): void
    {
        $this->prepararEscenario();
        $this->comoUsuario($this->vendedor);

        // Alta: los campos de crédito se descartan.
        $creado = $this->postJson('/api/clientes', [
            'nombre' => 'Cliente Nuevo', 'nit_ci' => '5550001',
            'credito_habilitado' => true, 'limite_credito' => 5000,
        ])->assertCreated();

        $clienteId = $creado->json('id');
        $cliente = Cliente::findOrFail($clienteId);
        $this->assertFalse((bool) $cliente->credito_habilitado);
        $this->assertNull($cliente->limite_credito);

        // Edición: lo mismo.
        $this->putJson("/api/clientes/{$clienteId}", [
            'nombre' => 'Cliente Nuevo', 'credito_habilitado' => true, 'limite_credito' => 5000,
        ])->assertOk();

        $cliente = Cliente::findOrFail($clienteId);
        $this->assertFalse((bool) $cliente->credito_habilitado);
        $this->assertNull($cliente->limite_credito);

        // El administrador sí puede.
        $this->comoUsuario($this->admin);
        $this->putJson("/api/clientes/{$clienteId}", [
            'nombre' => 'Cliente Nuevo', 'credito_habilitado' => true, 'limite_credito' => 500,
        ])->assertOk();

        $cliente = Cliente::findOrFail($clienteId);
        $this->assertTrue((bool) $cliente->credito_habilitado);
        $this->assertDinero(500, $cliente->limite_credito);
    }

    public function test_el_vendedor_solo_ve_y_toca_su_propia_caja_chica(): void
    {
        $ids = $this->prepararEscenario();     // el movimiento del escenario es del administrador
        $this->comoUsuario($this->vendedor);

        $ajeno = $ids['movimiento'];
        $this->getJson("/api/caja-chica/{$ajeno}")->assertForbidden();
        $this->getJson("/api/caja-chica/{$ajeno}/recibo-pdf")->assertForbidden();
        $this->putJson("/api/caja-chica/{$ajeno}", ['monto' => 1])->assertForbidden();
        $this->assertDinero(5, MovimientoCajaChica::findOrFail($ajeno)->monto);

        // Crea uno propio: ese sí lo ve, y el listado solo trae el suyo.
        $propio = $this->postJson('/api/caja-chica', [
            'cuenta' => 'Hielo', 'tipo' => 'egreso', 'metodo_pago' => 'efectivo',
            'concepto' => 'Bolsas de hielo', 'monto' => 12,
        ])->assertCreated()->json('id');

        $this->getJson("/api/caja-chica/{$propio}")->assertOk();

        $lista = $this->getJson('/api/caja-chica')->assertOk();
        $lista->assertJsonCount(1);
        $this->assertSame($propio, $lista->json('0.id'));

        // El administrador, en cambio, ve los dos.
        $this->comoUsuario($this->admin);
        $this->getJson('/api/caja-chica')->assertOk()->assertJsonCount(2);
    }

    public function test_el_catalogo_es_publico_pero_escribir_exige_ser_administrador(): void
    {
        $ids = $this->prepararEscenario();

        // Sin sesión: se puede mirar...
        $this->getJson('/api/categorias')->assertOk();

        // ...pero no escribir.
        $this->postJson('/api/productos', [])->assertUnauthorized();
        $this->putJson("/api/productos/{$ids['producto']}", ['precio_venta' => 1])->assertUnauthorized();

        // Un vendedor tampoco puede cambiar un precio.
        $this->comoUsuario($this->vendedor);
        $this->putJson("/api/productos/{$ids['producto']}", ['precio_venta' => 1])->assertForbidden();
    }

    // ------------------------------------------------------------------

    /** Convierte [[método, ruta], ...] en casos con nombre legible para el data provider. */
    private static function comoCasos(array $rutas): array
    {
        $casos = [];
        foreach ($rutas as [$metodo, $ruta]) {
            $casos["{$metodo} /{$ruta}"] = [$metodo, $ruta];
        }

        return $casos;
    }
}
