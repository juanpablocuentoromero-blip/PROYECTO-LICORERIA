<?php

namespace Tests\Feature\Pedidos;

use App\Models\Cliente;
use Tests\TestCase;

/**
 * El teléfono es obligatorio al registrar un pedido (pantalla Pedidos).
 */
class TelefonoObligatorioTest extends TestCase
{
    private function pedido(Cliente $cliente, array $extra = []): array
    {
        $producto = $this->crearProducto(['precio_venta' => 20], 10);

        return array_merge([
            'cliente_id' => $cliente->id,
            'metodo_pago' => 'efectivo',
            'items' => [['producto_id' => $producto->id, 'cantidad' => 1]],
        ], $extra);
    }

    public function test_sin_telefono_ni_en_el_pedido_ni_en_el_cliente_se_rechaza(): void
    {
        $cliente = Cliente::create(['nombre' => 'Sin teléfono', 'nit_ci' => '9876543', 'activo' => true]);
        $this->comoUsuario($this->crearVendedor());

        $this->postJson('/api/pedidos', $this->pedido($cliente))->assertStatus(422);
    }

    public function test_con_telefono_en_el_pedido_se_guarda_y_se_completa_la_ficha_del_cliente(): void
    {
        $cliente = Cliente::create(['nombre' => 'Ana', 'nit_ci' => '9876543', 'activo' => true]);
        $this->comoUsuario($this->crearVendedor());

        $r = $this->postJson('/api/pedidos', $this->pedido($cliente, ['telefono' => '75612345']))->assertCreated();

        $this->assertSame('75612345', $r->json('telefono_contacto'));
        $this->assertSame('75612345', $cliente->fresh()->telefono);
    }

    public function test_usa_el_telefono_que_ya_tiene_el_cliente(): void
    {
        $cliente = Cliente::create(['nombre' => 'Luis', 'nit_ci' => '1112223', 'telefono' => '70011223', 'activo' => true]);
        $this->comoUsuario($this->crearVendedor());

        $r = $this->postJson('/api/pedidos', $this->pedido($cliente))->assertCreated();

        $this->assertSame('70011223', $r->json('telefono_contacto'));
    }

    public function test_el_cliente_generico_no_se_ensucia_con_telefonos_ajenos(): void
    {
        $generico = Cliente::create(['nombre' => 'SIN NOMBRE', 'nit_ci' => '0', 'activo' => true]);
        $this->comoUsuario($this->crearVendedor());

        $this->postJson('/api/pedidos', $this->pedido($generico, ['telefono' => '71234567']))->assertCreated();

        $this->assertNull($generico->fresh()->telefono);
    }

    public function test_telefono_con_letras_se_rechaza(): void
    {
        $cliente = Cliente::create(['nombre' => 'Eva', 'nit_ci' => '5556667', 'activo' => true]);
        $this->comoUsuario($this->crearVendedor());

        $this->postJson('/api/pedidos', $this->pedido($cliente, ['telefono' => 'abc']))->assertStatus(422);
    }
}
