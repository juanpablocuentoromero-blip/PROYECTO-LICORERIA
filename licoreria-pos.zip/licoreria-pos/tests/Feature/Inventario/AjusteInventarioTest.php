<?php

namespace Tests\Feature\Inventario;

use App\Models\MovimientoInventario;
use Tests\TestCase;

/**
 * Ajustes de inventario por conteo físico: el admin dice cuánto HAY y el
 * sistema calcula la diferencia y la deja en el kardex.
 */
class AjusteInventarioTest extends TestCase
{
    public function test_el_ajuste_calcula_la_diferencia_y_deja_movimiento_marcado(): void
    {
        $producto = $this->crearProducto(['precio_compra' => 10], 10);
        $this->comoUsuario($this->crearAdmin());

        $r = $this->postJson('/api/inventario/ajustes', [
            'motivo' => 'Conteo físico',
            'items' => [['producto_id' => $producto->id, 'stock_real' => 7]],
        ])->assertCreated();

        $this->assertSame(-3, $r->json('ajustes.0.diferencia'));
        $this->assertDinero(-30, $r->json('valor_total_diferencia'));
        $this->assertSame(7, $this->stockReal($producto));
        $this->assertSame(7, $this->stockCache($producto));

        $mov = MovimientoInventario::where('producto_id', $producto->id)->firstOrFail();
        $this->assertTrue($mov->es_ajuste);
        $this->assertSame('salida', $mov->tipo);
        $this->assertSame(3, (int) $mov->cantidad);
        $this->assertStringContainsString('Conteo físico', $mov->motivo);
    }

    public function test_un_conteo_igual_al_del_sistema_no_genera_movimientos(): void
    {
        $producto = $this->crearProducto([], 5);
        $this->comoUsuario($this->crearAdmin());

        $r = $this->postJson('/api/inventario/ajustes', [
            'motivo' => 'Conteo',
            'items' => [['producto_id' => $producto->id, 'stock_real' => 5]],
        ])->assertCreated();

        $this->assertSame(1, $r->json('sin_cambios'));
        $this->assertSame(0, MovimientoInventario::count());
    }

    public function test_un_ajuste_hacia_arriba_puede_registrar_lote_con_vencimiento(): void
    {
        $producto = $this->crearProducto([], 2);
        $this->comoUsuario($this->crearAdmin());

        $this->postJson('/api/inventario/ajustes', [
            'motivo' => 'Mercadería sin registrar',
            'items' => [['producto_id' => $producto->id, 'stock_real' => 6, 'fecha_vencimiento' => '2027-06-30']],
        ])->assertCreated();

        $this->assertSame(6, $this->stockReal($producto));
        $this->assertSame('2027-06-30', substr((string) $producto->fresh()->fecha_vencimiento, 0, 10));
    }

    public function test_el_vendedor_no_puede_ajustar_inventario(): void
    {
        $producto = $this->crearProducto([], 5);
        $this->comoUsuario($this->crearVendedor());

        $this->postJson('/api/inventario/ajustes', [
            'motivo' => 'Intento',
            'items' => [['producto_id' => $producto->id, 'stock_real' => 0]],
        ])->assertForbidden();

        $this->assertSame(5, $this->stockReal($producto));
    }
}
