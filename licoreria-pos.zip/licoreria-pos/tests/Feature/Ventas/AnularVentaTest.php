<?php

namespace Tests\Feature\Ventas;

use App\Models\DetallePedido;
use App\Models\MovimientoInventario;
use App\Models\Pedido;
use App\Models\Producto;
use App\Models\Usuario;
use Illuminate\Testing\TestResponse;
use Tests\TestCase;

/**
 * 3.2 — POST /api/ventas/{venta}/anular
 *
 * Anular debe devolver el stock (también de los componentes de un combo),
 * dejar rastro en el kardex y no poder repetirse nunca.
 */
class AnularVentaTest extends TestCase
{
    private Usuario $admin;

    private Usuario $vendedor;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = $this->crearAdmin();
        $this->vendedor = $this->crearVendedor();
        $this->abrirCaja(100, $this->admin);
    }

    /** El vendedor registra una venta en efectivo y se devuelve su id. */
    private function vender(Producto $producto, int $cantidad, array $extra = []): int
    {
        $this->comoUsuario($this->vendedor);

        return $this->postVenta(
            [$this->linea($producto, $cantidad)],
            array_merge(['monto_recibido' => 10000], $extra)
        )->assertCreated()->json('venta.id');
    }

    private function anular(int $ventaId, array $body = ['motivo' => 'Error de digitación']): TestResponse
    {
        $this->comoUsuario($this->admin);

        return $this->postJson("/api/ventas/{$ventaId}/anular", $body);
    }

    // ------------------------------------------------------------------
    // Efecto de anular
    // ------------------------------------------------------------------

    public function test_anular_devuelve_el_stock_y_deja_el_kardex_cuadrado(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 20], 10);
        $ventaId = $this->vender($producto, 4);
        $this->assertSame(6, $this->stockReal($producto));

        $respuesta = $this->anular($ventaId)->assertOk();

        $this->assertTrue($respuesta->json('venta.anulada'));
        $this->assertSame('anulada', $respuesta->json('venta.estado'));

        // Stock de vuelta (almacén y caché).
        $this->assertSame(10, $this->stockReal($producto));
        $this->assertSame(10, $this->stockCache($producto));

        // La venta no se borra: queda marcada con motivo, quién y cuándo.
        $this->assertDatabaseHas('pedidos', [
            'id' => $ventaId,
            'anulada' => true,
            'estado' => 'cancelado',
            'motivo_anulacion' => 'Error de digitación',
            'usuario_anulacion_id' => $this->admin->id,
        ]);
        $this->assertNotNull(Pedido::findOrFail($ventaId)->anulada_at);

        // Kardex: la salida de la venta y la entrada de la anulación, en ese orden.
        $movimientos = MovimientoInventario::where('producto_id', $producto->id)->orderBy('id')->get();
        $this->assertCount(2, $movimientos);

        $this->assertSame('salida', $movimientos[0]->tipo);
        $this->assertSame(4, (int) $movimientos[0]->cantidad);
        $this->assertSame(6, (int) $movimientos[0]->stock_resultante);

        $this->assertSame('entrada', $movimientos[1]->tipo);
        $this->assertSame(4, (int) $movimientos[1]->cantidad);
        $this->assertSame(10, (int) $movimientos[1]->stock_resultante);
        $this->assertSame($this->admin->id, (int) $movimientos[1]->usuario_id);
        $this->assertSame("Anulación de venta #{$ventaId}", $movimientos[1]->motivo);
    }

    public function test_anular_reintegra_todas_las_lineas_de_la_venta(): void
    {
        $a = $this->crearProducto(['precio_venta' => 10], 10);
        $b = $this->crearProducto(['precio_venta' => 25], 10);

        $this->comoUsuario($this->vendedor);
        $ventaId = $this->postVenta(
            [$this->linea($a, 3), $this->linea($b, 2)],
            ['monto_recibido' => 1000]
        )->assertCreated()->json('venta.id');

        $this->anular($ventaId)->assertOk();

        $this->assertSame(10, $this->stockReal($a));
        $this->assertSame(10, $this->stockReal($b));
        $this->assertSame(2, MovimientoInventario::where('tipo', 'entrada')->count());
    }

    public function test_anular_una_venta_con_combo_devuelve_los_componentes(): void
    {
        $ron = $this->crearProducto([], 10);
        $hielo = $this->crearProducto([], 10);
        $vitrina = $this->crearCombo([[$ron, 2], [$hielo, 1]], 80);

        $ventaId = $this->vender($vitrina, 3);
        $this->assertSame(4, $this->stockReal($ron));
        $this->assertSame(7, $this->stockReal($hielo));

        $this->anular($ventaId)->assertOk();

        $this->assertSame(10, $this->stockReal($ron));
        $this->assertSame(10, $this->stockReal($hielo));
        $this->assertSame(10, $this->stockCache($ron));
        $this->assertSame(10, $this->stockCache($hielo));

        // Una entrada por componente, con el motivo de la anulación...
        $entradaRon = MovimientoInventario::where('producto_id', $ron->id)->where('tipo', 'entrada')->firstOrFail();
        $this->assertSame(6, (int) $entradaRon->cantidad);
        $this->assertSame(10, (int) $entradaRon->stock_resultante);
        $this->assertStringContainsString("Anulación de venta #{$ventaId}", $entradaRon->motivo);

        $entradaHielo = MovimientoInventario::where('producto_id', $hielo->id)->where('tipo', 'entrada')->firstOrFail();
        $this->assertSame(3, (int) $entradaHielo->cantidad);

        // ...y nada en la vitrina, que no lleva stock propio.
        $this->assertDatabaseMissing('movimientos_inventario', ['producto_id' => $vitrina->id]);
        $this->assertSame(0, $this->stockReal($vitrina));
    }

    // ------------------------------------------------------------------
    // No se puede anular dos veces
    // ------------------------------------------------------------------

    public function test_una_venta_no_se_puede_anular_dos_veces(): void
    {
        $producto = $this->crearProducto([], 10);
        $ventaId = $this->vender($producto, 4);

        $this->anular($ventaId)->assertOk();

        $segunda = $this->anular($ventaId, ['motivo' => 'Otra vez']);
        $segunda->assertStatus(422);
        $this->assertStringContainsString('ya fue anulada', $segunda->json('message'));

        // El stock se repuso UNA sola vez: 10, no 14.
        $this->assertSame(10, $this->stockReal($producto));
        $this->assertSame(10, $this->stockCache($producto));
        $this->assertSame(1, MovimientoInventario::where('producto_id', $producto->id)->where('tipo', 'entrada')->count());

        // Y el motivo original no se pisó.
        $this->assertDatabaseHas('pedidos', ['id' => $ventaId, 'motivo_anulacion' => 'Error de digitación']);
    }

    public function test_anular_una_venta_con_combo_dos_veces_no_repone_dos_veces(): void
    {
        $ron = $this->crearProducto([], 10);
        $vitrina = $this->crearCombo([[$ron, 2]], 50);
        $ventaId = $this->vender($vitrina, 2);

        $this->anular($ventaId)->assertOk();
        $this->anular($ventaId)->assertStatus(422);

        $this->assertSame(10, $this->stockReal($ron));
        $this->assertSame(1, MovimientoInventario::where('producto_id', $ron->id)->where('tipo', 'entrada')->count());
    }

    // ------------------------------------------------------------------
    // Validaciones y bloqueos
    // ------------------------------------------------------------------

    public function test_el_motivo_es_obligatorio(): void
    {
        $producto = $this->crearProducto([], 10);
        $ventaId = $this->vender($producto, 4);

        $this->anular($ventaId, [])->assertStatus(422)->assertJsonValidationErrors('motivo');

        $this->assertDatabaseHas('pedidos', ['id' => $ventaId, 'anulada' => false]);
        $this->assertSame(6, $this->stockReal($producto));
    }

    public function test_anular_una_venta_que_no_existe_da_404(): void
    {
        $this->anular(987654)->assertNotFound();
    }

    public function test_el_vendedor_no_puede_anular_y_no_se_toca_nada(): void
    {
        $producto = $this->crearProducto([], 10);
        $ventaId = $this->vender($producto, 4);

        // Sigue con la sesión del vendedor (vender() lo dejó autenticado).
        $this->postJson("/api/ventas/{$ventaId}/anular", ['motivo' => 'Quiero anularla'])
            ->assertForbidden();

        $this->assertDatabaseHas('pedidos', ['id' => $ventaId, 'anulada' => false, 'estado' => 'entregado']);
        $this->assertSame(6, $this->stockReal($producto));
        $this->assertSame(0, MovimientoInventario::where('tipo', 'entrada')->count());
    }

    public function test_no_se_puede_anular_una_venta_que_ya_tiene_devoluciones(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 20], 10);
        $ventaId = $this->vender($producto, 4);
        $detalleId = DetallePedido::where('pedido_id', $ventaId)->value('id');

        // Devuelve 1 de las 4 unidades: el stock sube a 7.
        $this->comoUsuario($this->admin);
        $this->postJson("/api/ventas/{$ventaId}/devolucion", [
            'motivo' => 'Botella dañada',
            'items' => [['detalle_id' => $detalleId, 'cantidad' => 1]],
        ])->assertCreated();
        $this->assertSame(7, $this->stockReal($producto));

        // Anular ahora repondría las 4 y duplicaría la unidad ya devuelta.
        $this->anular($ventaId)->assertStatus(422);

        $this->assertSame(7, $this->stockReal($producto));
        $this->assertDatabaseHas('pedidos', ['id' => $ventaId, 'anulada' => false]);
    }

    public function test_no_se_puede_anular_una_venta_a_credito_con_abonos_vigentes(): void
    {
        $cliente = $this->crearClienteConCredito();
        $producto = $this->crearProducto(['precio_venta' => 40], 10);

        $this->comoUsuario($this->vendedor);
        $ventaId = $this->postVenta([$this->linea($producto)], [
            'metodo_pago' => 'credito',
            'nit_ci' => $cliente->nit_ci,
            'razon_social' => $cliente->nombre,
        ])->assertCreated()->json('venta.id');

        $this->postJson('/api/cuentas-por-cobrar/abonos', [
            'cliente_id' => $cliente->id,
            'monto' => 10,
            'metodo_pago' => 'efectivo',
        ])->assertSuccessful();

        $respuesta = $this->anular($ventaId);

        $respuesta->assertStatus(422);
        $this->assertStringContainsString('abonos', $respuesta->json('message'));
        $this->assertDatabaseHas('pedidos', ['id' => $ventaId, 'anulada' => false]);
        $this->assertSame(9, $this->stockReal($producto));
    }

    public function test_anular_funciona_aunque_el_producto_ya_se_haya_eliminado_del_catalogo(): void
    {
        $producto = $this->crearProducto([], 10);
        $ventaId = $this->vender($producto, 4);

        $producto->delete();

        $this->anular($ventaId)->assertOk();

        $this->assertDatabaseHas('pedidos', ['id' => $ventaId, 'anulada' => true]);
        // No hay producto al que reponer: no se inventa un movimiento.
        $this->assertSame(0, MovimientoInventario::where('tipo', 'entrada')->count());
    }

    // ------------------------------------------------------------------
    // Efecto en los totales
    // ------------------------------------------------------------------

    public function test_una_venta_anulada_deja_de_contar_en_los_totales_del_historial(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 10], 20);
        $queSeQueda = $this->vender($producto, 4);   // Bs 40
        $queSeAnula = $this->vender($producto, 6);   // Bs 60

        $this->anular($queSeAnula)->assertOk();

        $this->comoUsuario($this->admin);

        // Sin filtro aparecen las dos, pero el total solo suma la válida.
        $todas = $this->getJson('/api/ventas')->assertOk();
        $this->assertSame(2, $todas->json('resumen.cantidad'));
        $this->assertDinero(40, $todas->json('resumen.total'));

        $validas = $this->getJson('/api/ventas?estado=validas')->assertOk();
        $this->assertSame(1, $validas->json('resumen.cantidad'));
        $this->assertSame($queSeQueda, $validas->json('ventas.0.id'));

        $anuladas = $this->getJson('/api/ventas?estado=anuladas')->assertOk();
        $this->assertSame(1, $anuladas->json('resumen.cantidad'));
        $this->assertSame($queSeAnula, $anuladas->json('ventas.0.id'));
    }
}
