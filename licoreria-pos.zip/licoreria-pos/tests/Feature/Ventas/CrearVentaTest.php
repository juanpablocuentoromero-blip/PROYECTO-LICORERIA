<?php

namespace Tests\Feature\Ventas;

use App\Models\DetallePedido;
use App\Models\MovimientoInventario;
use App\Models\PagoVenta;
use App\Models\Pedido;
use App\Models\Usuario;
use Tests\TestCase;

/**
 * 3.1 — POST /api/ventas: lo que, si falla, cuesta dinero.
 */
class CrearVentaTest extends TestCase
{
    private Usuario $vendedor;

    protected function setUp(): void
    {
        parent::setUp();

        $this->vendedor = $this->crearVendedor();
        $this->comoUsuario($this->vendedor);
    }

    // ------------------------------------------------------------------
    // Acceso y caja
    // ------------------------------------------------------------------

    public function test_vender_exige_estar_autenticado(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto([], 5);

        $this->flushHeaders();

        $this->postVenta([$this->linea($producto)])->assertUnauthorized();

        $this->assertDatabaseCount('pedidos', 0);
    }

    public function test_no_se_puede_vender_sin_caja_abierta(): void
    {
        $producto = $this->crearProducto(['precio_venta' => 20], 10);

        $respuesta = $this->postVenta([$this->linea($producto, 2)]);

        $respuesta->assertStatus(422);
        $this->assertStringContainsString('caja está cerrada', $respuesta->json('message'));

        // No quedó nada a medias: ni venta, ni pago, ni movimiento, ni stock descontado.
        $this->assertDatabaseCount('pedidos', 0);
        $this->assertDatabaseCount('detalle_pedidos', 0);
        $this->assertDatabaseCount('pagos_venta', 0);
        $this->assertDatabaseCount('movimientos_inventario', 0);
        $this->assertSame(10, $this->stockReal($producto));
        $this->assertSame(10, $this->stockCache($producto));
    }

    public function test_una_caja_ya_cerrada_no_permite_vender(): void
    {
        $caja = $this->abrirCaja();
        $caja->update(['estado' => 'cerrada', 'cerrada_at' => now()]);

        $producto = $this->crearProducto([], 10);

        $this->postVenta([$this->linea($producto)])->assertStatus(422);

        $this->assertDatabaseCount('pedidos', 0);
        $this->assertSame(10, $this->stockReal($producto));
    }

    // ------------------------------------------------------------------
    // Venta normal
    // ------------------------------------------------------------------

    public function test_una_venta_en_efectivo_registra_cobro_stock_y_kardex(): void
    {
        $caja = $this->abrirCaja();
        $producto = $this->crearProducto(['precio_venta' => 20, 'precio_compra' => 12], 10);

        $respuesta = $this->postVenta([$this->linea($producto, 3)], ['monto_recibido' => 100]);

        $respuesta->assertCreated();
        $this->assertDinero(60, $respuesta->json('venta.total'));
        $this->assertDinero(40, $respuesta->json('cambio'));

        $ventaId = $respuesta->json('venta.id');

        // Cabecera: nace pagada y entregada, atada a la caja y al vendedor.
        $this->assertDatabaseHas('pedidos', [
            'id' => $ventaId,
            'usuario_id' => $this->vendedor->id,
            'caja_id' => $caja->id,
            'estado' => 'entregado',
            'metodo_pago' => 'efectivo',
            'pagado' => true,
            'anulada' => false,
        ]);
        $this->assertDinero(60, Pedido::findOrFail($ventaId)->total);
        $this->assertDinero(0, Pedido::findOrFail($ventaId)->saldo_pendiente);

        // Línea: precio y costo congelados al momento de vender.
        $detalle = DetallePedido::where('pedido_id', $ventaId)->firstOrFail();
        $this->assertSame($producto->id, (int) $detalle->producto_id);
        $this->assertSame(3, (int) $detalle->cantidad);
        $this->assertDinero(20, $detalle->precio_unitario);
        $this->assertDinero(20, $detalle->precio_venta);
        $this->assertDinero(12, $detalle->precio_compra);
        $this->assertDinero(60, $detalle->subtotal);

        // Una fila de pago por el total, en la caja del turno (de ahí sale el arqueo).
        $pago = PagoVenta::where('pedido_id', $ventaId)->firstOrFail();
        $this->assertSame('efectivo', $pago->metodo_pago);
        $this->assertSame($caja->id, (int) $pago->caja_id);
        $this->assertDinero(60, $pago->monto);

        // Stock: almacén y caché coinciden.
        $this->assertSame(7, $this->stockReal($producto));
        $this->assertSame(7, $this->stockCache($producto));

        // Kardex: un movimiento de salida que explica el descuento.
        $movimientos = MovimientoInventario::where('producto_id', $producto->id)->get();
        $this->assertCount(1, $movimientos);
        $this->assertSame('salida', $movimientos[0]->tipo);
        $this->assertSame(3, (int) $movimientos[0]->cantidad);
        $this->assertSame(7, (int) $movimientos[0]->stock_resultante);
        $this->assertSame($this->vendedor->id, (int) $movimientos[0]->usuario_id);
        $this->assertSame("Venta mostrador #{$ventaId}", $movimientos[0]->motivo);
    }

    public function test_sin_datos_de_cliente_la_venta_va_a_sin_nombre(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto([], 5);

        $respuesta = $this->postVenta([$this->linea($producto)])->assertCreated();

        $this->assertSame('SIN NOMBRE', $respuesta->json('venta.cliente'));
    }

    // ------------------------------------------------------------------
    // Precios: siempre de la base, nunca del body
    // ------------------------------------------------------------------

    public function test_los_precios_y_totales_se_toman_de_la_base_y_no_del_body(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto(['precio_venta' => 50, 'precio_compra' => 30], 10);

        // Un cliente malicioso (o un front con bug) manda precios y totales falsos.
        $respuesta = $this->postVenta(
            [$this->linea($producto, 2, [
                'precio_venta' => 1,
                'precio_unitario' => 1,
                'precio' => 1,
                'precio_compra' => 1,
                'subtotal' => 1,
            ])],
            ['total' => 1, 'subtotal' => 1, 'descuento' => 99, 'monto_recibido' => 500]
        );

        $respuesta->assertCreated();
        $this->assertDinero(100, $respuesta->json('venta.total'));
        $this->assertDinero(100, $respuesta->json('venta.subtotal'));
        $this->assertDinero(0, $respuesta->json('venta.descuento'));

        $detalle = DetallePedido::where('pedido_id', $respuesta->json('venta.id'))->firstOrFail();
        $this->assertDinero(50, $detalle->precio_unitario);
        $this->assertDinero(50, $detalle->precio_venta);
        $this->assertDinero(30, $detalle->precio_compra);
        $this->assertDinero(100, $detalle->subtotal);
    }

    public function test_si_cambia_el_precio_en_la_base_la_siguiente_venta_usa_el_nuevo(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto(['precio_venta' => 50], 10);

        $primera = $this->postVenta([$this->linea($producto)], ['monto_recibido' => 100])->assertCreated();
        $producto->update(['precio_venta' => 70]);
        $segunda = $this->postVenta([$this->linea($producto)], ['monto_recibido' => 100])->assertCreated();

        $this->assertDinero(50, $primera->json('venta.total'));
        $this->assertDinero(70, $segunda->json('venta.total'));

        // La venta anterior conserva el precio con el que se hizo.
        $this->assertDinero(50, DetallePedido::where('pedido_id', $primera->json('venta.id'))->value('precio_unitario'));
    }

    public function test_el_descuento_manual_reduce_el_total_pero_no_puede_superar_la_linea(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto(['precio_venta' => 50], 10);

        $conDescuento = $this->postVenta(
            [$this->linea($producto, 2, ['descuento' => 10])],
            ['monto_recibido' => 100]
        )->assertCreated();

        $this->assertDinero(90, $conDescuento->json('venta.total'));
        $this->assertDinero(10, $conDescuento->json('venta.descuento'));

        $demasiado = $this->postVenta([$this->linea($producto, 1, ['descuento' => 51])]);

        $demasiado->assertStatus(422);
        $this->assertDatabaseCount('pedidos', 1);
        $this->assertSame(8, $this->stockReal($producto));
    }

    // ------------------------------------------------------------------
    // Stock
    // ------------------------------------------------------------------

    public function test_stock_insuficiente_rechaza_la_venta_sin_tocar_nada(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto(['precio_venta' => 20], 2);

        $respuesta = $this->postVenta([$this->linea($producto, 3)]);

        $respuesta->assertStatus(422);
        $this->assertStringContainsString('Stock insuficiente', $respuesta->json('message'));

        $this->assertDatabaseCount('pedidos', 0);
        $this->assertDatabaseCount('movimientos_inventario', 0);
        $this->assertSame(2, $this->stockReal($producto));
        $this->assertSame(2, $this->stockCache($producto));
    }

    public function test_se_puede_vender_exactamente_todo_el_stock_pero_no_una_unidad_mas(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto(['precio_venta' => 10], 5);

        $this->postVenta([$this->linea($producto, 5)], ['monto_recibido' => 50])->assertCreated();
        $this->assertSame(0, $this->stockReal($producto));

        $this->postVenta([$this->linea($producto, 1)])->assertStatus(422);

        $this->assertSame(0, $this->stockReal($producto));
        $this->assertDatabaseCount('pedidos', 1);
    }

    public function test_si_una_linea_no_alcanza_no_se_descuenta_ninguna_de_las_otras(): void
    {
        $this->abrirCaja();
        $hay = $this->crearProducto(['precio_venta' => 10], 10);
        $noHay = $this->crearProducto(['precio_venta' => 10], 1);

        $this->postVenta([$this->linea($hay, 4), $this->linea($noHay, 2)])->assertStatus(422);

        $this->assertDatabaseCount('pedidos', 0);
        $this->assertDatabaseCount('movimientos_inventario', 0);
        $this->assertSame(10, $this->stockReal($hay));
        $this->assertSame(1, $this->stockReal($noHay));
    }

    public function test_el_mismo_producto_en_dos_lineas_se_suma_antes_de_validar_el_stock(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto(['precio_venta' => 10], 5);

        // 3 + 3 = 6 y solo hay 5: cada línea por separado "cabría", juntas no.
        $this->postVenta([$this->linea($producto, 3), $this->linea($producto, 3)])
            ->assertStatus(422);

        $this->assertDatabaseCount('pedidos', 0);
        $this->assertSame(5, $this->stockReal($producto));
    }

    public function test_el_mismo_producto_en_dos_lineas_queda_fusionado_en_una(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto(['precio_venta' => 10], 10);

        $respuesta = $this->postVenta(
            [$this->linea($producto, 2), $this->linea($producto, 3)],
            ['monto_recibido' => 100]
        )->assertCreated();

        $detalles = DetallePedido::where('pedido_id', $respuesta->json('venta.id'))->get();
        $this->assertCount(1, $detalles);
        $this->assertSame(5, (int) $detalles[0]->cantidad);
        $this->assertDinero(50, $respuesta->json('venta.total'));
        $this->assertSame(5, $this->stockReal($producto));
    }

    public function test_un_producto_inactivo_no_se_puede_vender(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto(['activo' => false], 10);

        $this->postVenta([$this->linea($producto)])->assertStatus(422);

        $this->assertDatabaseCount('pedidos', 0);
        $this->assertSame(10, $this->stockReal($producto));
    }

    public function test_un_producto_eliminado_del_catalogo_no_se_puede_vender(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto([], 10);
        $producto->delete();

        $this->postVenta([$this->linea($producto)])
            ->assertStatus(422)
            ->assertJsonValidationErrors('items.0.producto_id');

        $this->assertDatabaseCount('pedidos', 0);
    }

    // ------------------------------------------------------------------
    // Combos
    // ------------------------------------------------------------------

    public function test_vender_un_combo_descuenta_sus_componentes_y_no_la_vitrina(): void
    {
        $this->abrirCaja();
        $ron = $this->crearProducto(['precio_compra' => 10], 10);
        $hielo = $this->crearProducto(['precio_compra' => 15], 10);
        // Cada combo = 2 ron + 1 hielo, a Bs 80.
        $vitrina = $this->crearCombo([[$ron, 2], [$hielo, 1]], 80);

        $respuesta = $this->postVenta([$this->linea($vitrina, 3)], ['monto_recibido' => 300]);

        $respuesta->assertCreated();
        $this->assertDinero(240, $respuesta->json('venta.total'));
        $ventaId = $respuesta->json('venta.id');

        // Componentes: 3 combos x 2 = 6 de ron; 3 combos x 1 = 3 de hielo.
        $this->assertSame(4, $this->stockReal($ron));
        $this->assertSame(7, $this->stockReal($hielo));
        $this->assertSame(4, $this->stockCache($ron));
        $this->assertSame(7, $this->stockCache($hielo));

        // La vitrina no lleva stock propio: ni se movió ni quedó en negativo.
        $this->assertSame(0, $this->stockReal($vitrina));
        $this->assertDatabaseMissing('movimientos_inventario', ['producto_id' => $vitrina->id]);

        // Kardex por componente.
        $movRon = MovimientoInventario::where('producto_id', $ron->id)->firstOrFail();
        $this->assertSame('salida', $movRon->tipo);
        $this->assertSame(6, (int) $movRon->cantidad);
        $this->assertSame(4, (int) $movRon->stock_resultante);
        $this->assertStringContainsString("Venta mostrador #{$ventaId}", $movRon->motivo);
        $this->assertStringContainsString('combo', $movRon->motivo);

        $movHielo = MovimientoInventario::where('producto_id', $hielo->id)->firstOrFail();
        $this->assertSame(3, (int) $movHielo->cantidad);
        $this->assertSame(7, (int) $movHielo->stock_resultante);

        // La línea cobra el precio del combo; el costo es el de los componentes (2x10 + 1x15 = 35).
        $detalle = DetallePedido::where('pedido_id', $ventaId)->firstOrFail();
        $this->assertSame($vitrina->id, (int) $detalle->producto_id);
        $this->assertDinero(80, $detalle->precio_unitario);
        $this->assertDinero(35, $detalle->precio_compra);
        $this->assertDinero(240, $detalle->subtotal);
    }

    public function test_el_combo_se_limita_por_el_componente_que_rinde_menos(): void
    {
        $this->abrirCaja();
        $ron = $this->crearProducto([], 5);      // 5 / 2 = 2 combos posibles
        $hielo = $this->crearProducto([], 100);
        $vitrina = $this->crearCombo([[$ron, 2], [$hielo, 1]], 80);

        // 3 combos necesitarían 6 de ron y solo hay 5.
        $rechazada = $this->postVenta([$this->linea($vitrina, 3)]);
        $rechazada->assertStatus(422);
        $this->assertStringContainsString('Stock insuficiente', $rechazada->json('message'));

        $this->assertDatabaseCount('pedidos', 0);
        $this->assertSame(5, $this->stockReal($ron));
        $this->assertSame(100, $this->stockReal($hielo));

        // 2 combos sí alcanzan.
        $this->postVenta([$this->linea($vitrina, 2)], ['monto_recibido' => 200])->assertCreated();

        $this->assertSame(1, $this->stockReal($ron));
        $this->assertSame(98, $this->stockReal($hielo));
    }

    // ------------------------------------------------------------------
    // Cobro: efectivo, pagos mixtos
    // ------------------------------------------------------------------

    public function test_el_monto_recibido_no_puede_ser_menor_al_efectivo_a_cobrar(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto(['precio_venta' => 40], 5);

        $this->postVenta([$this->linea($producto)], ['monto_recibido' => 30])->assertStatus(422);

        $this->assertDatabaseCount('pedidos', 0);
        $this->assertSame(5, $this->stockReal($producto));
    }

    public function test_un_pago_mixto_reparte_el_total_entre_los_metodos(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto(['precio_venta' => 30], 5);

        $respuesta = $this->postVenta([$this->linea($producto)], [
            'metodo_pago' => 'mixto',
            'pagos' => [
                ['metodo_pago' => 'efectivo', 'monto' => 10],
                ['metodo_pago' => 'qr', 'monto' => 20],
            ],
        ])->assertCreated();

        $ventaId = $respuesta->json('venta.id');
        $this->assertSame('mixto', Pedido::findOrFail($ventaId)->metodo_pago);

        $pagos = PagoVenta::where('pedido_id', $ventaId)->pluck('monto', 'metodo_pago');
        $this->assertCount(2, $pagos);
        $this->assertDinero(10, $pagos['efectivo']);
        $this->assertDinero(20, $pagos['qr']);
    }

    public function test_un_pago_mixto_que_no_suma_el_total_se_rechaza(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto(['precio_venta' => 30], 5);

        $this->postVenta([$this->linea($producto)], [
            'metodo_pago' => 'mixto',
            'pagos' => [
                ['metodo_pago' => 'efectivo', 'monto' => 10],
                ['metodo_pago' => 'qr', 'monto' => 15], // suma 25, el total es 30
            ],
        ])->assertStatus(422);

        $this->assertDatabaseCount('pedidos', 0);
        $this->assertDatabaseCount('pagos_venta', 0);
        $this->assertSame(5, $this->stockReal($producto));
    }

    public function test_metodo_mixto_sin_detalle_de_pagos_se_rechaza(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto([], 5);

        $this->postVenta([$this->linea($producto)], ['metodo_pago' => 'mixto'])->assertStatus(422);

        $this->assertDatabaseCount('pedidos', 0);
    }

    // ------------------------------------------------------------------
    // Crédito (fiado)
    // ------------------------------------------------------------------

    public function test_una_venta_a_credito_queda_sin_cobrar_y_con_saldo_pendiente(): void
    {
        $this->abrirCaja();
        $cliente = $this->crearClienteConCredito();
        $producto = $this->crearProducto(['precio_venta' => 70], 5);

        $respuesta = $this->postVenta([$this->linea($producto)], [
            'metodo_pago' => 'credito',
            'nit_ci' => $cliente->nit_ci,
            'razon_social' => $cliente->nombre,
        ])->assertCreated();

        $venta = Pedido::findOrFail($respuesta->json('venta.id'));
        $this->assertSame('credito', $venta->metodo_pago);
        $this->assertFalse($venta->pagado);
        $this->assertNull($venta->pagado_at);
        $this->assertSame($cliente->id, (int) $venta->cliente_id);
        $this->assertDinero(70, $venta->saldo_pendiente);
        $this->assertNotNull($venta->fecha_vencimiento_credito);

        // Es una deuda: no entra plata, así que no hay filas de pago.
        $this->assertDatabaseCount('pagos_venta', 0);
        // Pero la mercadería sí salió.
        $this->assertSame(4, $this->stockReal($producto));
    }

    public function test_no_se_vende_a_credito_a_un_cliente_sin_identificar(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto([], 5);

        $this->postVenta([$this->linea($producto)], ['metodo_pago' => 'credito'])->assertStatus(422);

        $this->assertDatabaseCount('pedidos', 0);
        $this->assertSame(5, $this->stockReal($producto));
    }

    public function test_no_se_vende_a_credito_si_el_cliente_no_tiene_credito_habilitado(): void
    {
        $this->abrirCaja();
        $cliente = $this->crearClienteConCredito();
        $cliente->update(['credito_habilitado' => false]);
        $producto = $this->crearProducto([], 5);

        $this->postVenta([$this->linea($producto)], [
            'metodo_pago' => 'credito',
            'nit_ci' => $cliente->nit_ci,
            'razon_social' => $cliente->nombre,
        ])->assertStatus(422);

        $this->assertDatabaseCount('pedidos', 0);
        $this->assertSame(5, $this->stockReal($producto));
    }

    public function test_el_credito_respeta_el_limite_del_cliente_incluyendo_su_deuda_previa(): void
    {
        $this->abrirCaja();
        $cliente = $this->crearClienteConCredito(limite: 100);
        $producto = $this->crearProducto(['precio_venta' => 60], 10);

        $datos = [
            'metodo_pago' => 'credito',
            'nit_ci' => $cliente->nit_ci,
            'razon_social' => $cliente->nombre,
        ];

        // 60 <= 100: pasa.
        $this->postVenta([$this->linea($producto)], $datos)->assertCreated();

        // Debe 60 y pide 60 más = 120 > 100: se rechaza.
        $this->postVenta([$this->linea($producto)], $datos)->assertStatus(422);

        $this->assertDatabaseCount('pedidos', 1);
        $this->assertSame(9, $this->stockReal($producto));
    }

    // ------------------------------------------------------------------
    // Validación del body
    // ------------------------------------------------------------------

    public function test_el_body_incompleto_o_invalido_se_rechaza(): void
    {
        $this->abrirCaja();
        $producto = $this->crearProducto([], 5);

        $this->postVenta([])->assertStatus(422)->assertJsonValidationErrors('items');
        $this->postVenta([$this->linea($producto, 0)])->assertStatus(422)->assertJsonValidationErrors('items.0.cantidad');
        $this->postVenta([$this->linea($producto, -2)])->assertStatus(422)->assertJsonValidationErrors('items.0.cantidad');
        $this->postVenta([['producto_id' => 999999, 'cantidad' => 1]])->assertStatus(422)->assertJsonValidationErrors('items.0.producto_id');
        $this->postVenta([$this->linea($producto)], ['metodo_pago' => 'bitcoin'])->assertStatus(422)->assertJsonValidationErrors('metodo_pago');

        $this->assertDatabaseCount('pedidos', 0);
        $this->assertSame(5, $this->stockReal($producto));
    }
}
