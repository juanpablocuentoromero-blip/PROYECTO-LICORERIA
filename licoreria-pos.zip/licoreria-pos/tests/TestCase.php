<?php

namespace Tests;

use App\Models\Almacen;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\TestCase as BaseTestCase;
use RuntimeException;
use Tests\Concerns\ArmaNegocio;

abstract class TestCase extends BaseTestCase
{
    use ArmaNegocio;
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        // Almacen::principalId() guarda el id en una propiedad estática que
        // sobrevive entre tests. Se limpia para que cada test parta de cero.
        \Closure::bind(
            static function () {
                static::$principalIdCache = null;
            },
            null,
            Almacen::class
        )();
    }

    /**
     * Última barrera de seguridad: RefreshDatabase borra todas las tablas.
     * Si por cualquier motivo la conexión no fuera SQLite en memoria (por
     * ejemplo, si alguien quita el force="true" de phpunit.xml y el .env
     * apunta a MySQL), el test se detiene ANTES de tocar la base real.
     */
    protected function beforeRefreshingDatabase(): void
    {
        $conexion = config('database.default');
        $base = config("database.connections.{$conexion}.database");

        if ($conexion !== 'sqlite' || $base !== ':memory:') {
            throw new RuntimeException(
                "Los tests solo pueden correr sobre SQLite en memoria (conexión actual: {$conexion}, base: {$base}). "
                .'Revisa phpunit.xml.'
            );
        }
    }
}
