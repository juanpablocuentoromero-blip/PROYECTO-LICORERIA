<?php

namespace Tests\Concerns;

use App\Models\Almacen;
use App\Models\Caja;
use App\Models\Categoria;
use App\Models\Cliente;
use App\Models\Combo;
use App\Models\ComboItem;
use App\Models\Producto;
use App\Models\StockPorAlmacen;
use App\Models\Usuario;
use Illuminate\Support\Facades\Hash;
use Illuminate\Testing\TestResponse;

/**
 * Helpers para armar el "negocio" de cada test: usuarios con token, productos
 * con stock real en el almacén principal, combos, caja abierta y ventas.
 *
 * Nada de esto usa factories a propósito: los modelos son simples y así cada
 * test deja a la vista exactamente qué datos necesita.
 */
trait ArmaNegocio
{
    private int $secuencia = 0;

    // ------------------------------------------------------------------
    // Usuarios y sesión
    // ------------------------------------------------------------------

    protected function crearUsuario(string $rol = 'vendedor', array $atributos = []): Usuario
    {
        $n = ++$this->secuencia;

        return Usuario::create(array_merge([
            'nombre' => ucfirst($rol)." {$n}",
            'email' => "{$rol}{$n}@prueba.test",
            'password' => Hash::make('secreto123'),
            'rol' => $rol,
            'activo' => true,
        ], $atributos));
    }

    protected function crearAdmin(): Usuario
    {
        return $this->crearUsuario('administrador');
    }

    protected function crearVendedor(): Usuario
    {
        return $this->crearUsuario('vendedor');
    }

    /**
     * Las siguientes peticiones del test van con el token de este usuario.
     * Llamarlo de nuevo con otro usuario cambia de sesión.
     */
    protected function comoUsuario(Usuario|Cliente $cuenta): static
    {
        $token = $cuenta->createToken('pruebas', ['*'], now()->addHour())->plainTextToken;

        return $this->withToken($token);
    }

    // ------------------------------------------------------------------
    // Catálogo y stock
    // ------------------------------------------------------------------

    /**
     * Crea un producto con $stock unidades en el almacén principal. Deja
     * sincronizados stock_por_almacen (lo que valida la venta) y la caché
     * productos.stock (lo que leen los listados).
     */
    protected function crearProducto(array $atributos = [], int $stock = 0): Producto
    {
        $n = ++$this->secuencia;
        $categoria = Categoria::firstOrCreate(['nombre' => 'General']);

        $producto = Producto::create(array_merge([
            'categoria_id' => $categoria->id,
            'codigo' => sprintf('PRU-%04d', $n),
            'nombre' => "Producto de prueba {$n}",
            'precio_compra' => 10,
            'precio_venta' => 20,
            'stock_minimo' => 0,
            'activo' => true,
        ], $atributos, ['stock' => $stock]));

        StockPorAlmacen::create([
            'producto_id' => $producto->id,
            'almacen_id' => Almacen::principalId(),
            'cantidad' => $stock,
        ]);

        return $producto;
    }

    /**
     * Crea un combo y devuelve su producto "vitrina" (el que se escanea en
     * caja). $componentes = [[$productoA, 2], [$productoB, 1]] (producto, cantidad).
     */
    protected function crearCombo(array $componentes, float $precio, string $nombre = 'Combo de prueba'): Producto
    {
        $vitrina = $this->crearProducto([
            'nombre' => $nombre,
            'precio_venta' => $precio,
            'precio_compra' => 0,
        ], 0);

        $combo = Combo::create([
            'producto_id' => $vitrina->id,
            'nombre' => $nombre,
            'precio' => $precio,
            'activo' => true,
        ]);

        foreach ($componentes as [$producto, $cantidad]) {
            ComboItem::create([
                'combo_id' => $combo->id,
                'producto_id' => $producto->id,
                'cantidad' => $cantidad,
            ]);
        }

        return $vitrina;
    }

    /** Unidades reales en el almacén principal (lo que valida la venta). */
    protected function stockReal(Producto $producto): int
    {
        return (int) StockPorAlmacen::where('producto_id', $producto->id)
            ->where('almacen_id', Almacen::principalId())
            ->value('cantidad');
    }

    /** La caché productos.stock: debe coincidir siempre con stockReal(). */
    protected function stockCache(Producto $producto): int
    {
        return (int) Producto::findOrFail($producto->id)->stock;
    }

    // ------------------------------------------------------------------
    // Caja y clientes
    // ------------------------------------------------------------------

    /** Abre una caja directamente en la base (sin pasar por la API). */
    protected function abrirCaja(float $monto = 100, ?Usuario $por = null): Caja
    {
        $por ??= $this->crearAdmin();

        return Caja::create([
            'almacen_id' => Almacen::principalId(),
            'usuario_apertura_id' => $por->id,
            'monto_apertura' => $monto,
            'estado' => 'abierta',
            // Un minuto atrás: las ventas del test caen holgadamente dentro del turno.
            'abierta_at' => now()->subMinute(),
        ]);
    }

    /** Cliente identificado con NIT, listo para comprar a crédito (fiado). */
    protected function crearClienteConCredito(?float $limite = null, string $nit = '1234567'): Cliente
    {
        return Cliente::create([
            'nombre' => 'Cliente Fiado',
            'nit_ci' => $nit,
            'activo' => true,
            'credito_habilitado' => true,
            'limite_credito' => $limite,
        ]);
    }

    // ------------------------------------------------------------------
    // Ventas
    // ------------------------------------------------------------------

    protected function linea(Producto $producto, int $cantidad = 1, array $extra = []): array
    {
        return array_merge(['producto_id' => $producto->id, 'cantidad' => $cantidad], $extra);
    }

    /** POST /api/ventas con la sesión actual. Por defecto, pago en efectivo. */
    protected function postVenta(array $items, array $extra = []): TestResponse
    {
        return $this->postJson('/api/ventas', array_merge([
            'metodo_pago' => 'efectivo',
            'items' => $items,
        ], $extra));
    }

    /** Dinero: compara con tolerancia de medio centavo (SQLite devuelve floats). */
    protected function assertDinero(float|int|string $esperado, mixed $real, string $mensaje = ''): void
    {
        $this->assertEqualsWithDelta((float) $esperado, (float) $real, 0.005, $mensaje);
    }
}
