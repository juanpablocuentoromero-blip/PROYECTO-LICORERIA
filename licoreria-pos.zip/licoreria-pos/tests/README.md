# Tests automáticos

Corren sobre **SQLite en memoria**: no tocan tu base MySQL.

```bash
php artisan test                      # todo
php artisan test --testsuite=Feature  # solo feature tests
php artisan test --filter=CajaTest    # una clase
php artisan test tests/Feature/Ventas # una carpeta
```

Requisito: la extensión `pdo_sqlite` de PHP (`php -m | grep sqlite`).

| Archivo | Cubre |
|---|---|
| `Feature/Ventas/CrearVentaTest.php` | 3.1 — caja cerrada, stock, combos, precios de la base, pagos, crédito |
| `Feature/Ventas/AnularVentaTest.php` | 3.2 — devuelve stock (incl. combos), kardex, no se anula dos veces |
| `Feature/Caja/CajaTest.php` | 3.3 — abrir, cerrar, arqueo por método de pago, caja chica, devoluciones, fiado |
| `Feature/Permisos/PermisosTest.php` | 3.4 — vendedor vs administrador en cada ruta sensible |
| `Feature/Compras/ComprasLotesTest.php` | compras por paquete, costo/precio automático, lotes (FEFO), edición y reporte de compras |
| `Feature/Inventario/AjusteInventarioTest.php` | ajustes de inventario por conteo físico |
| `Feature/Pedidos/TelefonoObligatorioTest.php` | teléfono obligatorio al registrar un pedido |
| `Feature/Caja/ReportesCajaTest.php` | reporte de caja del cajero y de caja chica (vendedor solo ve lo suyo) |
| `Concerns/ArmaNegocio.php` | helpers: usuarios con token, productos con stock, combos, caja |

## Seguridad de la base

`phpunit.xml` fuerza `DB_CONNECTION=sqlite` y `DB_DATABASE=:memory:` con
`force="true"` (gana sobre el `.env`), y `tests/TestCase.php` aborta si la
conexión no es SQLite en memoria. No quites ninguna de las dos protecciones:
`RefreshDatabase` borra todas las tablas.
