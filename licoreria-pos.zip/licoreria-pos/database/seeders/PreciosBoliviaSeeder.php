<?php

namespace Database\Seeders;

use App\Models\Producto;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

/**
 * Ajusta precios de referencia a la realidad de una licorería en Bolivia y
 * carga las presentaciones de venta (paquete y caja) de cada producto.
 *
 * Se puede correr sobre una base ya cargada, sin borrar nada:
 *     php artisan db:seed --class=PreciosBoliviaSeeder
 *
 * IMPORTANTE: son precios REFERENCIALES de venta al público en tienda. Los
 * precios en Bolivia cambian seguido (inflación, tipo de cambio de lo
 * importado, ciudad: en Beni suelen ser algo más altos que en La Paz o Santa
 * Cruz). Antes de usarlos, contrástalos con tus facturas de proveedor y
 * corrígelos desde Productos. Si un producto tiene "margen %", al comprar a
 * otro costo el sistema recalcula solo el precio de venta.
 */
class PreciosBoliviaSeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        // codigo => [precio_compra, precio_venta]  (Bs, por UNIDAD)
        $precios = [
            // Cervezas
            'CERV-0001' => [12.50, 16.00],  // Paceña 620cc retornable
            'CERV-0002' => [5.80, 8.00],    // Paceñita 330
            'CERV-0003' => [6.90, 8.50],    // Paceña lata 354
            'CERV-0004' => [9.00, 11.00],   // Paceña lata 473
            'CERV-0005' => [8.50, 11.00],   // Paceña Black / sin alcohol
            'CERV-0006' => [11.80, 15.00],  // Huari 620 retornable
            'CERV-0007' => [7.30, 9.00],    // Huari lata
            'CERV-0008' => [9.50, 12.00],   // Huari sabores
            'CERV-0009' => [11.00, 14.00],  // Taquiña 620
            'CERV-0010' => [6.30, 8.00],    // Taquiña lata
            'CERV-0011' => [11.00, 14.00],  // Ducal 620
            'CERV-0012' => [6.30, 8.00],    // Ducal lata
            'CERV-0013' => [8.80, 11.00],   // Potosina lata 473
            'CERV-0014' => [4.70, 6.00],    // Skol lata
            'CERV-0015' => [12.50, 16.00],  // Corona porrón
            // Gaseosas (3 L, 2 L, 500 ml, lata)
            'SODA-0012' => [13.80, 17.00],  // Coca-Cola 3 L
            'SODA-0013' => [11.50, 14.50],  // Coca-Cola 2.5 L
            'SODA-0014' => [9.20, 12.00],   // Coca-Cola 2 L
            'SODA-0016' => [3.90, 5.00],    // Coca-Cola 500 ml
            'SODA-0017' => [4.70, 6.00],    // Coca-Cola lata
            'SODA-0018' => [11.50, 15.00],  // Fanta 3 L
            'SODA-0022' => [11.50, 15.00],  // Sprite 3 L
            'SODA-0026' => [9.70, 12.50],   // Pepsi 3 L
            // Aguas
            'AGUA-0001' => [6.30, 8.50],    // Vital 2.5 L
            'AGUA-0003' => [2.70, 3.50],    // Vital 600 ml
            'AGUA-0004' => [9.00, 12.00],   // Vital bidón 5 L
            'AGUA-0007' => [8.00, 11.00],   // Villa Santa bidón 5 L
            // Whiskies / destilados importados (el tipo de cambio los mueve mucho)
            'WHIS-0001' => [105.00, 140.00], // Johnnie Walker Red 750
            'WHIS-0011' => [205.00, 265.00], // Chivas 12
            // Cigarrillos
            'CIGA-0001' => [14.00, 18.00],  // Marlboro x20
            'CIGA-0004' => [10.00, 13.00],  // Astors x20
            // Energizantes
            'ENER-0001' => [11.00, 15.00],  // Monster
            'ENER-0002' => [10.50, 14.00],  // Red Bull 250
        ];

        foreach ($precios as $codigo => [$compra, $venta]) {
            Producto::where('codigo', $codigo)->update([
                'precio_compra' => $compra,
                'precio_venta' => $venta,
            ]);
        }

        // Presentaciones: [patrón en el nombre => [unidades por paquete, unidades por caja]].
        // La primera regla que coincide gana, así que las más específicas van arriba.
        // null = ese producto no se vende en esa presentación.
        $reglas = [
            // Cerveza en lata: el paquete trae 12 (la caja = 2 paquetes de 12, ajústala si tu proveedor entrega otra).
            '/(Cerveza|Paceña|Huari|Taquiña|Ducal|Potosina|Skol|Corona).*Lata/i' => [12, 24],
            '/Paceñita/i'                     => [6, 24],  // botellín 330 ml: la caja trae 24
            '/Lata/i'                         => [6, 24],  // otras latas (gaseosas, energizantes): pack de 6, caja de 24
            '/Retornable|Corona Porrón/i'     => [6, 12],  // cerveza en botella
            '/Botella 3 ?L/i'                 => [null, 4],
            '/Botella 2\.5 ?L/i'              => [null, 6],
            '/Botella 2 ?L/i'                 => [null, 8],
            '/Botella 1\.5 ?L/i'              => [null, 8],
            '/Botella (500|600) ?ml/i'        => [6, 12],
            '/Bidón/i'                        => [null, 4],
            '/Cajetilla/i'                    => [10, 50], // cartón de 10, caja de 50 cajetillas
            '/Takis|Doritos|Lay|Nachos|Cheetos|Chizitos/i' => [null, 24],
            '/Sidra|Champagne|Federico/i'     => [null, 6],
            '/Vino/i'                         => [null, 12],
            '/Whisky|Jack Daniel|Johnnie|Chivas|Ballantine|Grant|Ron |Flor de Caña|Havana|Vodka|Gin |Tequila|Fernet|Singani|Casa Real|Parrales|Rujero|San Pedro|Tierra Alta|Amarula|Jagermeister|Cinzano|Tres Plumas/i' => [null, 12],
        ];

        $actualizados = 0;

        foreach (Producto::all() as $producto) {
            foreach ($reglas as $patron => [$paquete, $caja]) {
                if (preg_match($patron, $producto->nombre)) {
                    $producto->forceFill([
                        'unidades_por_paquete' => $paquete,
                        'unidades_por_caja' => $caja,
                    ])->saveQuietly();
                    $actualizados++;
                    break;
                }
            }
        }

        $this->command?->info(count($precios).' precios ajustados y '.$actualizados.' productos con presentaciones de paquete/caja.');
    }
}
