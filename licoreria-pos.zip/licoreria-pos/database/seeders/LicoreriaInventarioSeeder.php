<?php

namespace Database\Seeders;

use App\Models\Almacen;
use App\Models\Categoria;
use App\Models\Producto;
use App\Models\StockPorAlmacen;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class LicoreriaInventarioSeeder extends Seeder
{
    use WithoutModelEvents;

    // Catálogo generado a partir de la lista de inventario con precios reales
    // de la licorería (20 categorías, 194 productos). El precio de venta es el
    // punto medio del rango dado; el precio de compra es una estimación (margen
    // ~25-30%) porque el documento original no traía costo de compra. Ambos se
    // pueden corregir después desde la pantalla de productos.
    public function run(): void
    {
        $categorias = [];

        $categorias['Singanis'] = Categoria::firstOrCreate(['nombre' => 'Singanis'], ['descripcion' => 'Singanis nacionales de distintas casas y presentaciones', 'activo' => true])->id;
        $categorias['Cervezas'] = Categoria::firstOrCreate(['nombre' => 'Cervezas'], ['descripcion' => 'Cervezas nacionales, retornables, botella y lata', 'activo' => true])->id;
        $categorias['Sodas y Gaseosas Locales'] = Categoria::firstOrCreate(['nombre' => 'Sodas y Gaseosas Locales'], ['descripcion' => 'Gaseosas y sodas de marcas locales', 'activo' => true])->id;
        $categorias['Sodas Internacionales'] = Categoria::firstOrCreate(['nombre' => 'Sodas Internacionales'], ['descripcion' => 'Gaseosas de marcas internacionales', 'activo' => true])->id;
        $categorias['Aguas Embotelladas'] = Categoria::firstOrCreate(['nombre' => 'Aguas Embotelladas'], ['descripcion' => 'Agua con y sin gas, distintas presentaciones', 'activo' => true])->id;
        $categorias['Whiskies'] = Categoria::firstOrCreate(['nombre' => 'Whiskies'], ['descripcion' => 'Whiskies importados', 'activo' => true])->id;
        $categorias['Rones'] = Categoria::firstOrCreate(['nombre' => 'Rones'], ['descripcion' => 'Rones nacionales e importados', 'activo' => true])->id;
        $categorias['Tragos Económicos'] = Categoria::firstOrCreate(['nombre' => 'Tragos Económicos'], ['descripcion' => 'Tragos y aperitivos de bajo costo', 'activo' => true])->id;
        $categorias['Licores'] = Categoria::firstOrCreate(['nombre' => 'Licores'], ['descripcion' => 'Fernet, amaros y licores de sobremesa', 'activo' => true])->id;
        $categorias['Vodkas'] = Categoria::firstOrCreate(['nombre' => 'Vodkas'], ['descripcion' => 'Vodkas nacionales e importados', 'activo' => true])->id;
        $categorias['Gins'] = Categoria::firstOrCreate(['nombre' => 'Gins'], ['descripcion' => 'Gins nacionales e importados', 'activo' => true])->id;
        $categorias['Tequilas'] = Categoria::firstOrCreate(['nombre' => 'Tequilas'], ['descripcion' => 'Tequilas mexicanos y similares', 'activo' => true])->id;
        $categorias['Dulces y Chicles'] = Categoria::firstOrCreate(['nombre' => 'Dulces y Chicles'], ['descripcion' => 'Chicles, pastillas y chocolates', 'activo' => true])->id;
        $categorias['Energizantes y Rehidratantes'] = Categoria::firstOrCreate(['nombre' => 'Energizantes y Rehidratantes'], ['descripcion' => 'Bebidas energizantes e hidratantes', 'activo' => true])->id;
        $categorias['Cigarrillos'] = Categoria::firstOrCreate(['nombre' => 'Cigarrillos'], ['descripcion' => 'Cigarrillos de distintas marcas', 'activo' => true])->id;
        $categorias['Snacks'] = Categoria::firstOrCreate(['nombre' => 'Snacks'], ['descripcion' => 'Snacks y frituras para acompañar', 'activo' => true])->id;
        $categorias['Espumantes y Sidras'] = Categoria::firstOrCreate(['nombre' => 'Espumantes y Sidras'], ['descripcion' => 'Espumantes y sidras para celebraciones', 'activo' => true])->id;
        $categorias['Chichas, Macerados y Tragos Tradicionales'] = Categoria::firstOrCreate(['nombre' => 'Chichas, Macerados y Tragos Tradicionales'], ['descripcion' => 'Bebidas artesanales y tradicionales', 'activo' => true])->id;
        $categorias['Complementos e Insumos de Barra'] = Categoria::firstOrCreate(['nombre' => 'Complementos e Insumos de Barra'], ['descripcion' => 'Hielo, limones, vasos y otros insumos de barra', 'activo' => true])->id;
        $categorias['Vinos'] = Categoria::firstOrCreate(['nombre' => 'Vinos'], ['descripcion' => 'Vinos tintos, blancos y en caja', 'activo' => true])->id;

        $productos = [
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0001', 'nombre' => 'Casa Real Etiqueta Azul 750ml', 'descripcion' => 'Casa Real Etiqueta Azul 750ml', 'precio_compra' => 27.78, 'precio_venta' => 39.0, 'stock' => 29, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0002', 'nombre' => 'Casa Real Etiqueta Roja 750ml', 'descripcion' => 'Casa Real Etiqueta Roja 750ml', 'precio_compra' => 44.97, 'precio_venta' => 62.5, 'stock' => 16, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0003', 'nombre' => 'Casa Real Etiqueta Negra 750ml', 'descripcion' => 'Casa Real Etiqueta Negra 750ml', 'precio_compra' => 65.29, 'precio_venta' => 95.0, 'stock' => 78, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0004', 'nombre' => 'Casa Real Petaca Roja 375ml', 'descripcion' => 'Casa Real Petaca Roja 375ml', 'precio_compra' => 25.16, 'precio_venta' => 36.5, 'stock' => 84, 'stock_minimo' => 13],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0005', 'nombre' => 'Casa Real Gran Singani Don Lucho 750ml', 'descripcion' => 'Casa Real Gran Singani Don Lucho 750ml', 'precio_compra' => 234.89, 'precio_venta' => 342.5, 'stock' => 74, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0006', 'nombre' => 'Los Parrales Clásico 750ml', 'descripcion' => 'Los Parrales Clásico 750ml', 'precio_compra' => 31.57, 'precio_venta' => 45.0, 'stock' => 21, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0007', 'nombre' => 'Los Parrales Selección 750ml', 'descripcion' => 'Los Parrales Selección 750ml', 'precio_compra' => 47.02, 'precio_venta' => 65.0, 'stock' => 18, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0008', 'nombre' => 'Los Parrales Reserva Aniversario 750ml', 'descripcion' => 'Los Parrales Reserva Aniversario 750ml', 'precio_compra' => 77.45, 'precio_venta' => 110.0, 'stock' => 80, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0009', 'nombre' => 'Los Parrales Petaca 375ml', 'descripcion' => 'Los Parrales Petaca 375ml', 'precio_compra' => 18.06, 'precio_venta' => 25.0, 'stock' => 82, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0010', 'nombre' => 'Rujero Tradicional 750ml', 'descripcion' => 'Rujero Tradicional 750ml', 'precio_compra' => 32.89, 'precio_venta' => 47.5, 'stock' => 38, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0011', 'nombre' => 'Rujero Colección Privada 750ml', 'descripcion' => 'Rujero Colección Privada 750ml', 'precio_compra' => 63.16, 'precio_venta' => 85.0, 'stock' => 84, 'stock_minimo' => 13],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0012', 'nombre' => 'Rujero Botella 1 Litro', 'descripcion' => 'Rujero Botella 1 Litro', 'precio_compra' => 46.49, 'precio_venta' => 60.0, 'stock' => 83, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0013', 'nombre' => 'San Pedro Clásico/Plata 750ml', 'descripcion' => 'San Pedro Clásico/Plata 750ml', 'precio_compra' => 31.39, 'precio_venta' => 42.5, 'stock' => 16, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0014', 'nombre' => 'San Pedro Oro 750ml', 'descripcion' => 'San Pedro Oro 750ml', 'precio_compra' => 42.77, 'precio_venta' => 55.0, 'stock' => 15, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0015', 'nombre' => 'San Pedro Galón 1.95 Litros', 'descripcion' => 'San Pedro Galón 1.95 Litros', 'precio_compra' => 66.21, 'precio_venta' => 90.0, 'stock' => 27, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Singanis'], 'codigo' => 'SING-0016', 'nombre' => 'Tierra Alta Botella 750ml', 'descripcion' => 'Tierra Alta Botella 750ml', 'precio_compra' => 26.59, 'precio_venta' => 37.5, 'stock' => 28, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0001', 'nombre' => 'Paceña Botella Retornable 620cc', 'descripcion' => 'Paceña Botella Retornable 620cc', 'precio_compra' => 11.75, 'precio_venta' => 16.0, 'stock' => 83, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0002', 'nombre' => 'Paceña Paceñita 330ml', 'descripcion' => 'Paceña Paceñita 330ml', 'precio_compra' => 6.4, 'precio_venta' => 9.0, 'stock' => 33, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0003', 'nombre' => 'Paceña Lata 354ml', 'descripcion' => 'Paceña Lata 354ml', 'precio_compra' => 6.56, 'precio_venta' => 9.5, 'stock' => 83, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0004', 'nombre' => 'Paceña Lata 473ml', 'descripcion' => 'Paceña Lata 473ml', 'precio_compra' => 9.67, 'precio_venta' => 13.0, 'stock' => 57, 'stock_minimo' => 9],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0005', 'nombre' => 'Paceña Black/Sin Alcohol', 'descripcion' => 'Paceña Black/Sin Alcohol', 'precio_compra' => 8.28, 'precio_venta' => 12.0, 'stock' => 18, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0006', 'nombre' => 'Huari Botella Retornable 620cc', 'descripcion' => 'Huari Botella Retornable 620cc', 'precio_compra' => 13.26, 'precio_venta' => 18.0, 'stock' => 89, 'stock_minimo' => 13],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0007', 'nombre' => 'Huari Lata 354ml', 'descripcion' => 'Huari Lata 354ml', 'precio_compra' => 7.71, 'precio_venta' => 11.0, 'stock' => 78, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0008', 'nombre' => 'Huari Sabores (Miel/Chocolate/Quinua)', 'descripcion' => 'Huari Sabores (Miel/Chocolate/Quinua)', 'precio_compra' => 9.4, 'precio_venta' => 13.0, 'stock' => 50, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0009', 'nombre' => 'Taquiña Botella Retornable 620cc', 'descripcion' => 'Taquiña Botella Retornable 620cc', 'precio_compra' => 10.9, 'precio_venta' => 15.0, 'stock' => 68, 'stock_minimo' => 10],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0010', 'nombre' => 'Taquiña Lata 354ml', 'descripcion' => 'Taquiña Lata 354ml', 'precio_compra' => 6.45, 'precio_venta' => 9.0, 'stock' => 41, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0011', 'nombre' => 'Ducal Botella Retornable 620cc', 'descripcion' => 'Ducal Botella Retornable 620cc', 'precio_compra' => 11.39, 'precio_venta' => 15.0, 'stock' => 41, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0012', 'nombre' => 'Ducal Lata 354ml', 'descripcion' => 'Ducal Lata 354ml', 'precio_compra' => 6.19, 'precio_venta' => 9.0, 'stock' => 48, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0013', 'nombre' => 'Potosina Lata 473ml', 'descripcion' => 'Potosina Lata 473ml', 'precio_compra' => 9.52, 'precio_venta' => 13.0, 'stock' => 53, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0014', 'nombre' => 'Cerveza Skol Lata 354ml', 'descripcion' => 'Cerveza Skol Lata 354ml', 'precio_compra' => 4.89, 'precio_venta' => 6.5, 'stock' => 46, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0015', 'nombre' => 'Corona Porrón 355ml', 'descripcion' => 'Corona Porrón 355ml', 'precio_compra' => 11.11, 'precio_venta' => 15.0, 'stock' => 19, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0016', 'nombre' => 'Corona Coronita 210ml', 'descripcion' => 'Corona Coronita 210ml', 'precio_compra' => 6.23, 'precio_venta' => 9.0, 'stock' => 63, 'stock_minimo' => 9],
            ['categoria_id' => $categorias['Cervezas'], 'codigo' => 'CERV-0017', 'nombre' => 'Corona Lata 354ml', 'descripcion' => 'Corona Lata 354ml', 'precio_compra' => 8.36, 'precio_venta' => 12.0, 'stock' => 53, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Sodas y Gaseosas Locales'], 'codigo' => 'SODA-0001', 'nombre' => 'Coka Quina Botella 3 Litros', 'descripcion' => 'Coka Quina Botella 3 Litros', 'precio_compra' => 9.39, 'precio_venta' => 13.5, 'stock' => 72, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Sodas y Gaseosas Locales'], 'codigo' => 'SODA-0002', 'nombre' => 'Coka Quina Botella 2 Litros', 'descripcion' => 'Coka Quina Botella 2 Litros', 'precio_compra' => 7.22, 'precio_venta' => 10.0, 'stock' => 19, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Sodas y Gaseosas Locales'], 'codigo' => 'SODA-0003', 'nombre' => 'Coka Quina Botella 750ml', 'descripcion' => 'Coka Quina Botella 750ml', 'precio_compra' => 3.78, 'precio_venta' => 5.0, 'stock' => 83, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Sodas y Gaseosas Locales'], 'codigo' => 'SODA-0004', 'nombre' => 'Coka Quina Botella 330ml', 'descripcion' => 'Coka Quina Botella 330ml', 'precio_compra' => 2.28, 'precio_venta' => 3.0, 'stock' => 50, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Sodas y Gaseosas Locales'], 'codigo' => 'SODA-0005', 'nombre' => 'La Cascada Botella 3 Litros', 'descripcion' => 'La Cascada Botella 3 Litros', 'precio_compra' => 8.21, 'precio_venta' => 11.5, 'stock' => 54, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Sodas y Gaseosas Locales'], 'codigo' => 'SODA-0006', 'nombre' => 'La Cascada Botella 2 Litros', 'descripcion' => 'La Cascada Botella 2 Litros', 'precio_compra' => 5.92, 'precio_venta' => 8.0, 'stock' => 84, 'stock_minimo' => 13],
            ['categoria_id' => $categorias['Sodas y Gaseosas Locales'], 'codigo' => 'SODA-0007', 'nombre' => 'La Cascada Botella 500ml', 'descripcion' => 'La Cascada Botella 500ml', 'precio_compra' => 2.66, 'precio_venta' => 3.5, 'stock' => 18, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Sodas y Gaseosas Locales'], 'codigo' => 'SODA-0008', 'nombre' => 'La Cascada Vidrio Retornable 190ml', 'descripcion' => 'La Cascada Vidrio Retornable 190ml', 'precio_compra' => 1.34, 'precio_venta' => 1.75, 'stock' => 44, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Sodas y Gaseosas Locales'], 'codigo' => 'SODA-0009', 'nombre' => 'Triny Botella 3 Litros', 'descripcion' => 'Triny Botella 3 Litros', 'precio_compra' => 7.64, 'precio_venta' => 10.5, 'stock' => 18, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Sodas y Gaseosas Locales'], 'codigo' => 'SODA-0010', 'nombre' => 'Triny Botella 2 Litros', 'descripcion' => 'Triny Botella 2 Litros', 'precio_compra' => 5.15, 'precio_venta' => 7.5, 'stock' => 49, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Sodas y Gaseosas Locales'], 'codigo' => 'SODA-0011', 'nombre' => 'Triny Botella 500ml', 'descripcion' => 'Triny Botella 500ml', 'precio_compra' => 2.23, 'precio_venta' => 3.0, 'stock' => 67, 'stock_minimo' => 10],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0012', 'nombre' => 'Coca-Cola Botella 3L', 'descripcion' => 'Coca-Cola Botella 3L', 'precio_compra' => 11.69, 'precio_venta' => 16.5, 'stock' => 59, 'stock_minimo' => 9],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0013', 'nombre' => 'Coca-Cola Botella 2.5L', 'descripcion' => 'Coca-Cola Botella 2.5L', 'precio_compra' => 10.76, 'precio_venta' => 14.0, 'stock' => 54, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0014', 'nombre' => 'Coca-Cola Botella 2L', 'descripcion' => 'Coca-Cola Botella 2L', 'precio_compra' => 8.19, 'precio_venta' => 12.0, 'stock' => 69, 'stock_minimo' => 10],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0015', 'nombre' => 'Coca-Cola Botella 1.5L', 'descripcion' => 'Coca-Cola Botella 1.5L', 'precio_compra' => 7.16, 'precio_venta' => 10.0, 'stock' => 88, 'stock_minimo' => 13],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0016', 'nombre' => 'Coca-Cola Botella 500ml', 'descripcion' => 'Coca-Cola Botella 500ml', 'precio_compra' => 3.46, 'precio_venta' => 5.0, 'stock' => 17, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0017', 'nombre' => 'Coca-Cola Lata 354ml', 'descripcion' => 'Coca-Cola Lata 354ml', 'precio_compra' => 4.21, 'precio_venta' => 6.0, 'stock' => 46, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0018', 'nombre' => 'Fanta Botella 3L', 'descripcion' => 'Fanta Botella 3L', 'precio_compra' => 10.05, 'precio_venta' => 14.5, 'stock' => 41, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0019', 'nombre' => 'Fanta Botella 2L', 'descripcion' => 'Fanta Botella 2L', 'precio_compra' => 7.92, 'precio_venta' => 11.0, 'stock' => 73, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0020', 'nombre' => 'Fanta Botella 500ml', 'descripcion' => 'Fanta Botella 500ml', 'precio_compra' => 3.44, 'precio_venta' => 5.0, 'stock' => 67, 'stock_minimo' => 10],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0021', 'nombre' => 'Fanta Lata 354ml', 'descripcion' => 'Fanta Lata 354ml', 'precio_compra' => 3.96, 'precio_venta' => 5.5, 'stock' => 45, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0022', 'nombre' => 'Sprite Botella 3L', 'descripcion' => 'Sprite Botella 3L', 'precio_compra' => 11.14, 'precio_venta' => 14.5, 'stock' => 65, 'stock_minimo' => 10],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0023', 'nombre' => 'Sprite Botella 2L', 'descripcion' => 'Sprite Botella 2L', 'precio_compra' => 8.43, 'precio_venta' => 11.0, 'stock' => 45, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0024', 'nombre' => 'Sprite Botella 500ml', 'descripcion' => 'Sprite Botella 500ml', 'precio_compra' => 3.75, 'precio_venta' => 5.0, 'stock' => 55, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0025', 'nombre' => 'Sprite Lata 354ml', 'descripcion' => 'Sprite Lata 354ml', 'precio_compra' => 4.12, 'precio_venta' => 5.5, 'stock' => 58, 'stock_minimo' => 9],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0026', 'nombre' => 'Pepsi Botella 3 Litros', 'descripcion' => 'Pepsi Botella 3 Litros', 'precio_compra' => 9.7, 'precio_venta' => 12.5, 'stock' => 29, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0027', 'nombre' => 'Pepsi Botella 2 Litros', 'descripcion' => 'Pepsi Botella 2 Litros', 'precio_compra' => 6.54, 'precio_venta' => 9.5, 'stock' => 29, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0028', 'nombre' => 'Pepsi Botella 500ml', 'descripcion' => 'Pepsi Botella 500ml', 'precio_compra' => 3.16, 'precio_venta' => 4.5, 'stock' => 39, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0029', 'nombre' => 'Pepsi Lata 354ml', 'descripcion' => 'Pepsi Lata 354ml', 'precio_compra' => 3.41, 'precio_venta' => 5.0, 'stock' => 85, 'stock_minimo' => 13],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0030', 'nombre' => 'Guaraná Antarctica Botella 3 Litros', 'descripcion' => 'Guaraná Antarctica Botella 3 Litros', 'precio_compra' => 9.08, 'precio_venta' => 13.0, 'stock' => 46, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0031', 'nombre' => 'Guaraná Antarctica Botella 2 Litros', 'descripcion' => 'Guaraná Antarctica Botella 2 Litros', 'precio_compra' => 6.8, 'precio_venta' => 10.0, 'stock' => 63, 'stock_minimo' => 9],
            ['categoria_id' => $categorias['Sodas Internacionales'], 'codigo' => 'SODA-0032', 'nombre' => 'Guaraná Antarctica Lata 350ml', 'descripcion' => 'Guaraná Antarctica Lata 350ml', 'precio_compra' => 4.4, 'precio_venta' => 6.0, 'stock' => 88, 'stock_minimo' => 13],
            ['categoria_id' => $categorias['Aguas Embotelladas'], 'codigo' => 'AGUA-0001', 'nombre' => 'Vital Botella 2.5L', 'descripcion' => 'Vital Botella 2.5L', 'precio_compra' => 6.26, 'precio_venta' => 8.5, 'stock' => 26, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Aguas Embotelladas'], 'codigo' => 'AGUA-0002', 'nombre' => 'Vital Botella 1.5L', 'descripcion' => 'Vital Botella 1.5L', 'precio_compra' => 4.49, 'precio_venta' => 6.0, 'stock' => 75, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Aguas Embotelladas'], 'codigo' => 'AGUA-0003', 'nombre' => 'Vital Botella 600ml', 'descripcion' => 'Vital Botella 600ml', 'precio_compra' => 2.71, 'precio_venta' => 3.5, 'stock' => 16, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Aguas Embotelladas'], 'codigo' => 'AGUA-0004', 'nombre' => 'Vital Bidón 5 Litros', 'descripcion' => 'Vital Bidón 5 Litros', 'precio_compra' => 10.88, 'precio_venta' => 15.0, 'stock' => 81, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Aguas Embotelladas'], 'codigo' => 'AGUA-0005', 'nombre' => 'Villa Santa Botella 2L', 'descripcion' => 'Villa Santa Botella 2L', 'precio_compra' => 5.03, 'precio_venta' => 7.0, 'stock' => 61, 'stock_minimo' => 9],
            ['categoria_id' => $categorias['Aguas Embotelladas'], 'codigo' => 'AGUA-0006', 'nombre' => 'Villa Santa Botella 600ml', 'descripcion' => 'Villa Santa Botella 600ml', 'precio_compra' => 2.16, 'precio_venta' => 3.0, 'stock' => 71, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Aguas Embotelladas'], 'codigo' => 'AGUA-0007', 'nombre' => 'Villa Santa Bidón 5 Litros', 'descripcion' => 'Villa Santa Bidón 5 Litros', 'precio_compra' => 9.66, 'precio_venta' => 13.0, 'stock' => 17, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Aguas Embotelladas'], 'codigo' => 'AGUA-0008', 'nombre' => 'Villa Santa Botellón 20 Litros (Recarga)', 'descripcion' => 'Villa Santa Botellón 20 Litros (Recarga)', 'precio_compra' => 11.53, 'precio_venta' => 16.5, 'stock' => 36, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0001', 'nombre' => 'Johnnie Walker Red Label 750ml', 'descripcion' => 'Johnnie Walker Red Label 750ml', 'precio_compra' => 86.89, 'precio_venta' => 120.0, 'stock' => 24, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0002', 'nombre' => 'Johnnie Walker Black Label 1L', 'descripcion' => 'Johnnie Walker Black Label 1L', 'precio_compra' => 285.6, 'precio_venta' => 400.0, 'stock' => 16, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0003', 'nombre' => 'Johnnie Walker Double Black 750ml', 'descripcion' => 'Johnnie Walker Double Black 750ml', 'precio_compra' => 248.49, 'precio_venta' => 360.0, 'stock' => 82, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0004', 'nombre' => 'Johnnie Walker Gold Label 750ml', 'descripcion' => 'Johnnie Walker Gold Label 750ml', 'precio_compra' => 382.32, 'precio_venta' => 550.0, 'stock' => 22, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0005', 'nombre' => 'Johnnie Walker Blue Label 750ml', 'descripcion' => 'Johnnie Walker Blue Label 750ml', 'precio_compra' => 1511.05, 'precio_venta' => 1950.0, 'stock' => 88, 'stock_minimo' => 13],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0006', 'nombre' => 'Johnnie Walker Petaca Red Label 200ml', 'descripcion' => 'Johnnie Walker Petaca Red Label 200ml', 'precio_compra' => 27.3, 'precio_venta' => 40.0, 'stock' => 36, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0007', 'nombre' => 'Jack Daniel\'s Old No. 7 750ml', 'descripcion' => 'Jack Daniel\'s Old No. 7 750ml', 'precio_compra' => 174.23, 'precio_venta' => 235.0, 'stock' => 29, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0008', 'nombre' => 'Jack Daniel\'s Honey 750ml', 'descripcion' => 'Jack Daniel\'s Honey 750ml', 'precio_compra' => 174.71, 'precio_venta' => 235.0, 'stock' => 54, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0009', 'nombre' => 'Jack Daniel\'s Apple 750ml', 'descripcion' => 'Jack Daniel\'s Apple 750ml', 'precio_compra' => 173.95, 'precio_venta' => 235.0, 'stock' => 70, 'stock_minimo' => 10],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0010', 'nombre' => 'Jack Daniel\'s Botella 1 Litro', 'descripcion' => 'Jack Daniel\'s Botella 1 Litro', 'precio_compra' => 211.15, 'precio_venta' => 305.0, 'stock' => 72, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0011', 'nombre' => 'Chivas Regal 12 Años 750ml', 'descripcion' => 'Chivas Regal 12 Años 750ml', 'precio_compra' => 198.72, 'precio_venta' => 255.0, 'stock' => 69, 'stock_minimo' => 10],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0012', 'nombre' => 'Chivas Regal 18 Años 750ml', 'descripcion' => 'Chivas Regal 18 Años 750ml', 'precio_compra' => 498.71, 'precio_venta' => 685.0, 'stock' => 49, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0013', 'nombre' => 'Ballantine\'s Botella 750ml', 'descripcion' => 'Ballantine\'s Botella 750ml', 'precio_compra' => 82.63, 'precio_venta' => 120.0, 'stock' => 23, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0014', 'nombre' => 'Ballantine\'s Botella 1 Litro', 'descripcion' => 'Ballantine\'s Botella 1 Litro', 'precio_compra' => 120.79, 'precio_venta' => 160.0, 'stock' => 43, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0015', 'nombre' => 'Grant\'s Botella 750ml', 'descripcion' => 'Grant\'s Botella 750ml', 'precio_compra' => 87.34, 'precio_venta' => 120.0, 'stock' => 30, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0016', 'nombre' => 'Grant\'s Botella 1 Litro', 'descripcion' => 'Grant\'s Botella 1 Litro', 'precio_compra' => 117.06, 'precio_venta' => 160.0, 'stock' => 36, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Whiskies'], 'codigo' => 'WHIS-0017', 'nombre' => 'Killa Botella 750ml (Artesanal boliviano)', 'descripcion' => 'Killa Botella 750ml (Artesanal boliviano)', 'precio_compra' => 131.77, 'precio_venta' => 170.0, 'stock' => 77, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Rones'], 'codigo' => 'RONE-0001', 'nombre' => 'Flor de Caña 4 Años 750ml', 'descripcion' => 'Flor de Caña 4 Años 750ml', 'precio_compra' => 60.87, 'precio_venta' => 85.0, 'stock' => 79, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Rones'], 'codigo' => 'RONE-0002', 'nombre' => 'Flor de Caña 5 Años 750ml', 'descripcion' => 'Flor de Caña 5 Años 750ml', 'precio_compra' => 77.14, 'precio_venta' => 100.0, 'stock' => 77, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Rones'], 'codigo' => 'RONE-0003', 'nombre' => 'Flor de Caña 7 Años 750ml', 'descripcion' => 'Flor de Caña 7 Años 750ml', 'precio_compra' => 92.28, 'precio_venta' => 130.0, 'stock' => 21, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Rones'], 'codigo' => 'RONE-0004', 'nombre' => 'Flor de Caña 12 Años 750ml', 'descripcion' => 'Flor de Caña 12 Años 750ml', 'precio_compra' => 179.91, 'precio_venta' => 240.0, 'stock' => 43, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Rones'], 'codigo' => 'RONE-0005', 'nombre' => 'Havana Club 3 Años 750ml', 'descripcion' => 'Havana Club 3 Años 750ml', 'precio_compra' => 62.21, 'precio_venta' => 85.0, 'stock' => 31, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Rones'], 'codigo' => 'RONE-0006', 'nombre' => 'Havana Club Especial 750ml', 'descripcion' => 'Havana Club Especial 750ml', 'precio_compra' => 67.98, 'precio_venta' => 95.0, 'stock' => 38, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Rones'], 'codigo' => 'RONE-0007', 'nombre' => 'Havana Club 7 Años 750ml', 'descripcion' => 'Havana Club 7 Años 750ml', 'precio_compra' => 117.32, 'precio_venta' => 160.0, 'stock' => 74, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Rones'], 'codigo' => 'RONE-0008', 'nombre' => 'Ron Abuelo Añejo 750ml', 'descripcion' => 'Ron Abuelo Añejo 750ml', 'precio_compra' => 53.47, 'precio_venta' => 75.0, 'stock' => 38, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Rones'], 'codigo' => 'RONE-0009', 'nombre' => 'Ron Abuelo 7 Años 750ml', 'descripcion' => 'Ron Abuelo 7 Años 750ml', 'precio_compra' => 100.08, 'precio_venta' => 135.0, 'stock' => 34, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Tragos Económicos'], 'codigo' => 'TRAG-0001', 'nombre' => 'Tres Plumas Jerez 750ml', 'descripcion' => 'Tres Plumas Jerez 750ml', 'precio_compra' => 20.16, 'precio_venta' => 26.5, 'stock' => 61, 'stock_minimo' => 9],
            ['categoria_id' => $categorias['Tragos Económicos'], 'codigo' => 'TRAG-0002', 'nombre' => 'Tres Plumas Coñac 750ml', 'descripcion' => 'Tres Plumas Coñac 750ml', 'precio_compra' => 19.98, 'precio_venta' => 26.5, 'stock' => 39, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Tragos Económicos'], 'codigo' => 'TRAG-0003', 'nombre' => 'Tres Plumas Menta 750ml', 'descripcion' => 'Tres Plumas Menta 750ml', 'precio_compra' => 18.55, 'precio_venta' => 26.5, 'stock' => 73, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Tragos Económicos'], 'codigo' => 'TRAG-0004', 'nombre' => 'Tres Plumas Café 750ml', 'descripcion' => 'Tres Plumas Café 750ml', 'precio_compra' => 18.96, 'precio_venta' => 26.5, 'stock' => 13, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Tragos Económicos'], 'codigo' => 'TRAG-0005', 'nombre' => 'Tres Plumas Frutilla 750ml', 'descripcion' => 'Tres Plumas Frutilla 750ml', 'precio_compra' => 20.64, 'precio_venta' => 26.5, 'stock' => 45, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Tragos Económicos'], 'codigo' => 'TRAG-0006', 'nombre' => 'Corote Sachet 400ml', 'descripcion' => 'Corote Sachet 400ml', 'precio_compra' => 6.55, 'precio_venta' => 9.0, 'stock' => 34, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Tragos Económicos'], 'codigo' => 'TRAG-0007', 'nombre' => 'Corote Botella Plástica 900ml', 'descripcion' => 'Corote Botella Plástica 900ml', 'precio_compra' => 12.74, 'precio_venta' => 17.0, 'stock' => 54, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Tragos Económicos'], 'codigo' => 'TRAG-0008', 'nombre' => 'Bombita Sachet/Bolsa 350ml', 'descripcion' => 'Bombita Sachet/Bolsa 350ml', 'precio_compra' => 5.07, 'precio_venta' => 7.0, 'stock' => 54, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Licores'], 'codigo' => 'LICO-0001', 'nombre' => 'Fernet Branca Botella 750ml', 'descripcion' => 'Fernet Branca Botella 750ml', 'precio_compra' => 80.65, 'precio_venta' => 104.0, 'stock' => 56, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Licores'], 'codigo' => 'LICO-0002', 'nombre' => 'Fernet Branca Botella 1 Litro', 'descripcion' => 'Fernet Branca Botella 1 Litro', 'precio_compra' => 97.36, 'precio_venta' => 141.5, 'stock' => 23, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Licores'], 'codigo' => 'LICO-0003', 'nombre' => 'Fernet Branca Menta 750ml', 'descripcion' => 'Fernet Branca Menta 750ml', 'precio_compra' => 79.75, 'precio_venta' => 113.5, 'stock' => 35, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Licores'], 'codigo' => 'LICO-0004', 'nombre' => 'Fernet Branca Mini 50ml', 'descripcion' => 'Fernet Branca Mini 50ml', 'precio_compra' => 10.71, 'precio_venta' => 15.0, 'stock' => 71, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Licores'], 'codigo' => 'LICO-0005', 'nombre' => 'Fernet Buhero Negro Botella 750ml', 'descripcion' => 'Fernet Buhero Negro Botella 750ml', 'precio_compra' => 51.97, 'precio_venta' => 70.0, 'stock' => 88, 'stock_minimo' => 13],
            ['categoria_id' => $categorias['Licores'], 'codigo' => 'LICO-0006', 'nombre' => 'Cinzano Botella 750ml', 'descripcion' => 'Cinzano Botella 750ml', 'precio_compra' => 53.48, 'precio_venta' => 70.0, 'stock' => 71, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Licores'], 'codigo' => 'LICO-0007', 'nombre' => 'Amarula Botella 750ml', 'descripcion' => 'Amarula Botella 750ml', 'precio_compra' => 107.93, 'precio_venta' => 140.0, 'stock' => 54, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Licores'], 'codigo' => 'LICO-0008', 'nombre' => 'Jagermeister Botella 700ml', 'descripcion' => 'Jagermeister Botella 700ml', 'precio_compra' => 113.99, 'precio_venta' => 150.0, 'stock' => 20, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Licores'], 'codigo' => 'LICO-0009', 'nombre' => 'Jagermeister Botella 1 Litro', 'descripcion' => 'Jagermeister Botella 1 Litro', 'precio_compra' => 160.33, 'precio_venta' => 210.0, 'stock' => 25, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Licores'], 'codigo' => 'LICO-0010', 'nombre' => 'Jagermeister Mini 20ml', 'descripcion' => 'Jagermeister Mini 20ml', 'precio_compra' => 13.88, 'precio_venta' => 18.0, 'stock' => 35, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Vodkas'], 'codigo' => 'VODK-0001', 'nombre' => 'Vodka Smirnoff Botella 750ml', 'descripcion' => 'Vodka Smirnoff Botella 750ml', 'precio_compra' => 50.95, 'precio_venta' => 70.0, 'stock' => 32, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Vodkas'], 'codigo' => 'VODK-0002', 'nombre' => 'Vodka Smirnoff Sabores 750ml', 'descripcion' => 'Vodka Smirnoff Sabores 750ml', 'precio_compra' => 57.87, 'precio_venta' => 80.0, 'stock' => 52, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Vodkas'], 'codigo' => 'VODK-0003', 'nombre' => 'Vodka Skyy Botella 750ml', 'descripcion' => 'Vodka Skyy Botella 750ml', 'precio_compra' => 48.21, 'precio_venta' => 70.0, 'stock' => 60, 'stock_minimo' => 9],
            ['categoria_id' => $categorias['Vodkas'], 'codigo' => 'VODK-0004', 'nombre' => 'Vodka Skyy Sabores 750ml', 'descripcion' => 'Vodka Skyy Sabores 750ml', 'precio_compra' => 58.11, 'precio_venta' => 80.0, 'stock' => 20, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Vodkas'], 'codigo' => 'VODK-0005', 'nombre' => 'Vodka Absolut Original 750ml', 'descripcion' => 'Vodka Absolut Original 750ml', 'precio_compra' => 90.3, 'precio_venta' => 120.0, 'stock' => 31, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Vodkas'], 'codigo' => 'VODK-0006', 'nombre' => 'Vodka Absolut Sabores 750ml', 'descripcion' => 'Vodka Absolut Sabores 750ml', 'precio_compra' => 111.05, 'precio_venta' => 142.5, 'stock' => 13, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Vodkas'], 'codigo' => 'VODK-0007', 'nombre' => 'Vodka 1825 Botella 750ml (Boliviano)', 'descripcion' => 'Vodka 1825 Botella 750ml (Boliviano)', 'precio_compra' => 66.04, 'precio_venta' => 95.0, 'stock' => 69, 'stock_minimo' => 10],
            ['categoria_id' => $categorias['Gins'], 'codigo' => 'GINS-0001', 'nombre' => 'Gin Tanqueray Botella 750ml', 'descripcion' => 'Gin Tanqueray Botella 750ml', 'precio_compra' => 117.9, 'precio_venta' => 155.0, 'stock' => 28, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Gins'], 'codigo' => 'GINS-0002', 'nombre' => 'Gin Beefeater Botella 750ml', 'descripcion' => 'Gin Beefeater Botella 750ml', 'precio_compra' => 114.88, 'precio_venta' => 155.0, 'stock' => 86, 'stock_minimo' => 13],
            ['categoria_id' => $categorias['Gins'], 'codigo' => 'GINS-0003', 'nombre' => 'Gin La República Andino 750ml', 'descripcion' => 'Gin La República Andino 750ml', 'precio_compra' => 93.36, 'precio_venta' => 120.0, 'stock' => 54, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Gins'], 'codigo' => 'GINS-0004', 'nombre' => 'Gin La República Amazónico 750ml', 'descripcion' => 'Gin La República Amazónico 750ml', 'precio_compra' => 83.47, 'precio_venta' => 120.0, 'stock' => 80, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Tequilas'], 'codigo' => 'TEQU-0001', 'nombre' => 'Tequila José Cuervo Especial Reposado 750ml', 'descripcion' => 'Tequila José Cuervo Especial Reposado 750ml', 'precio_compra' => 103.96, 'precio_venta' => 150.0, 'stock' => 11, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Tequilas'], 'codigo' => 'TEQU-0002', 'nombre' => 'Tequila José Cuervo Blanco 750ml', 'descripcion' => 'Tequila José Cuervo Blanco 750ml', 'precio_compra' => 113.99, 'precio_venta' => 150.0, 'stock' => 23, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Tequilas'], 'codigo' => 'TEQU-0003', 'nombre' => 'Sombrero Negro Botella 750ml', 'descripcion' => 'Sombrero Negro Botella 750ml', 'precio_compra' => 67.77, 'precio_venta' => 92.5, 'stock' => 27, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Tequilas'], 'codigo' => 'TEQU-0004', 'nombre' => 'Camino Real Botella 750ml', 'descripcion' => 'Camino Real Botella 750ml', 'precio_compra' => 66.91, 'precio_venta' => 92.5, 'stock' => 34, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Dulces y Chicles'], 'codigo' => 'DULC-0001', 'nombre' => 'Chicles Clorets Cajita', 'descripcion' => 'Chicles Clorets Cajita', 'precio_compra' => 2.67, 'precio_venta' => 3.5, 'stock' => 37, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Dulces y Chicles'], 'codigo' => 'DULC-0002', 'nombre' => 'Chicles Beldent Cajita', 'descripcion' => 'Chicles Beldent Cajita', 'precio_compra' => 2.39, 'precio_venta' => 3.5, 'stock' => 37, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Dulces y Chicles'], 'codigo' => 'DULC-0003', 'nombre' => 'Chicles Trident Cajita', 'descripcion' => 'Chicles Trident Cajita', 'precio_compra' => 2.48, 'precio_venta' => 3.5, 'stock' => 40, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Dulces y Chicles'], 'codigo' => 'DULC-0004', 'nombre' => 'Chicles Mogul Unidad', 'descripcion' => 'Chicles Mogul Unidad', 'precio_compra' => 0.38, 'precio_venta' => 0.5, 'stock' => 51, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Dulces y Chicles'], 'codigo' => 'DULC-0005', 'nombre' => 'Chicles Groot Unidad', 'descripcion' => 'Chicles Groot Unidad', 'precio_compra' => 0.35, 'precio_venta' => 0.5, 'stock' => 63, 'stock_minimo' => 9],
            ['categoria_id' => $categorias['Dulces y Chicles'], 'codigo' => 'DULC-0006', 'nombre' => 'Pastillas Halls Paquete', 'descripcion' => 'Pastillas Halls Paquete', 'precio_compra' => 1.53, 'precio_venta' => 2.0, 'stock' => 17, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Dulces y Chicles'], 'codigo' => 'DULC-0007', 'nombre' => 'Chocolate El Ceibo Barra Pequeña', 'descripcion' => 'Chocolate El Ceibo Barra Pequeña', 'precio_compra' => 3.86, 'precio_venta' => 5.0, 'stock' => 55, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Dulces y Chicles'], 'codigo' => 'DULC-0008', 'nombre' => 'Chocolate El Ceibo Barra Grande', 'descripcion' => 'Chocolate El Ceibo Barra Grande', 'precio_compra' => 14.24, 'precio_venta' => 18.5, 'stock' => 84, 'stock_minimo' => 13],
            ['categoria_id' => $categorias['Dulces y Chicles'], 'codigo' => 'DULC-0009', 'nombre' => 'Chocolate Breick Barra Pequeña', 'descripcion' => 'Chocolate Breick Barra Pequeña', 'precio_compra' => 3.81, 'precio_venta' => 5.0, 'stock' => 76, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Dulces y Chicles'], 'codigo' => 'DULC-0010', 'nombre' => 'Chocolate Breick Barra Grande', 'descripcion' => 'Chocolate Breick Barra Grande', 'precio_compra' => 13.36, 'precio_venta' => 18.5, 'stock' => 74, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Energizantes y Rehidratantes'], 'codigo' => 'ENER-0001', 'nombre' => 'Monster Energy Lata 473ml', 'descripcion' => 'Monster Energy Lata 473ml', 'precio_compra' => 10.4, 'precio_venta' => 15.0, 'stock' => 29, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Energizantes y Rehidratantes'], 'codigo' => 'ENER-0002', 'nombre' => 'Red Bull Lata 250ml', 'descripcion' => 'Red Bull Lata 250ml', 'precio_compra' => 9.89, 'precio_venta' => 13.5, 'stock' => 12, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Energizantes y Rehidratantes'], 'codigo' => 'ENER-0003', 'nombre' => 'Red Bull Lata 355ml', 'descripcion' => 'Red Bull Lata 355ml', 'precio_compra' => 13.81, 'precio_venta' => 18.0, 'stock' => 33, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Energizantes y Rehidratantes'], 'codigo' => 'ENER-0004', 'nombre' => 'Reactor Lata', 'descripcion' => 'Reactor Lata', 'precio_compra' => 5.56, 'precio_venta' => 7.5, 'stock' => 29, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Energizantes y Rehidratantes'], 'codigo' => 'ENER-0005', 'nombre' => 'Rockstar Lata', 'descripcion' => 'Rockstar Lata', 'precio_compra' => 5.23, 'precio_venta' => 7.5, 'stock' => 70, 'stock_minimo' => 10],
            ['categoria_id' => $categorias['Energizantes y Rehidratantes'], 'codigo' => 'ENER-0006', 'nombre' => 'Volt Botella 400ml/473ml', 'descripcion' => 'Volt Botella 400ml/473ml', 'precio_compra' => 4.08, 'precio_venta' => 5.5, 'stock' => 25, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Energizantes y Rehidratantes'], 'codigo' => 'ENER-0007', 'nombre' => 'Gatorade Botella 500-600ml', 'descripcion' => 'Gatorade Botella 500-600ml', 'precio_compra' => 4.78, 'precio_venta' => 6.5, 'stock' => 51, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Energizantes y Rehidratantes'], 'codigo' => 'ENER-0008', 'nombre' => 'Powerade Botella 500-600ml', 'descripcion' => 'Powerade Botella 500-600ml', 'precio_compra' => 4.86, 'precio_venta' => 6.5, 'stock' => 77, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Energizantes y Rehidratantes'], 'codigo' => 'ENER-0009', 'nombre' => 'Sporade Botella 500-600ml', 'descripcion' => 'Sporade Botella 500-600ml', 'precio_compra' => 4.78, 'precio_venta' => 6.5, 'stock' => 23, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Cigarrillos'], 'codigo' => 'CIGA-0001', 'nombre' => 'Marlboro Cajetilla x20', 'descripcion' => 'Marlboro Cajetilla x20', 'precio_compra' => 13.06, 'precio_venta' => 17.0, 'stock' => 17, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Cigarrillos'], 'codigo' => 'CIGA-0002', 'nombre' => 'Marlboro Cajetilla x10', 'descripcion' => 'Marlboro Cajetilla x10', 'precio_compra' => 6.7, 'precio_venta' => 9.5, 'stock' => 45, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Cigarrillos'], 'codigo' => 'CIGA-0003', 'nombre' => 'L&M Cajetilla x20', 'descripcion' => 'L&M Cajetilla x20', 'precio_compra' => 8.89, 'precio_venta' => 13.0, 'stock' => 22, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Cigarrillos'], 'codigo' => 'CIGA-0004', 'nombre' => 'Astors Cajetilla x20', 'descripcion' => 'Astors Cajetilla x20', 'precio_compra' => 9.5, 'precio_venta' => 13.0, 'stock' => 81, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Cigarrillos'], 'codigo' => 'CIGA-0005', 'nombre' => 'Camel Cajetilla x20', 'descripcion' => 'Camel Cajetilla x20', 'precio_compra' => 8.88, 'precio_venta' => 13.0, 'stock' => 18, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Cigarrillos'], 'codigo' => 'CIGA-0006', 'nombre' => 'Hills Cajetilla x20', 'descripcion' => 'Hills Cajetilla x20', 'precio_compra' => 9.42, 'precio_venta' => 13.0, 'stock' => 88, 'stock_minimo' => 13],
            ['categoria_id' => $categorias['Cigarrillos'], 'codigo' => 'CIGA-0007', 'nombre' => 'Casino Cajetilla x20', 'descripcion' => 'Casino Cajetilla x20', 'precio_compra' => 7.0, 'precio_venta' => 9.0, 'stock' => 87, 'stock_minimo' => 13],
            ['categoria_id' => $categorias['Cigarrillos'], 'codigo' => 'CIGA-0008', 'nombre' => 'Carnival Cajetilla x20', 'descripcion' => 'Carnival Cajetilla x20', 'precio_compra' => 6.58, 'precio_venta' => 9.0, 'stock' => 45, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Cigarrillos'], 'codigo' => 'CIGA-0009', 'nombre' => 'Pine Cajetilla x20', 'descripcion' => 'Pine Cajetilla x20', 'precio_compra' => 6.53, 'precio_venta' => 9.0, 'stock' => 78, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Snacks'], 'codigo' => 'SNAC-0001', 'nombre' => 'Takis Bolsa Mediana 90g', 'descripcion' => 'Takis Bolsa Mediana 90g', 'precio_compra' => 8.37, 'precio_venta' => 11.0, 'stock' => 74, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Snacks'], 'codigo' => 'SNAC-0002', 'nombre' => 'Takis Bolsa Familiar 200g+', 'descripcion' => 'Takis Bolsa Familiar 200g+', 'precio_compra' => 18.58, 'precio_venta' => 24.0, 'stock' => 76, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Snacks'], 'codigo' => 'SNAC-0003', 'nombre' => 'Doritos Individual 40g', 'descripcion' => 'Doritos Individual 40g', 'precio_compra' => 3.45, 'precio_venta' => 4.5, 'stock' => 43, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Snacks'], 'codigo' => 'SNAC-0004', 'nombre' => 'Doritos Mediana 90g', 'descripcion' => 'Doritos Mediana 90g', 'precio_compra' => 8.5, 'precio_venta' => 11.0, 'stock' => 35, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Snacks'], 'codigo' => 'SNAC-0005', 'nombre' => 'Doritos Fiesta/Familiar', 'descripcion' => 'Doritos Fiesta/Familiar', 'precio_compra' => 17.95, 'precio_venta' => 23.5, 'stock' => 27, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Snacks'], 'codigo' => 'SNAC-0006', 'nombre' => 'Nachos Picantes Bolsa Mediana', 'descripcion' => 'Nachos Picantes Bolsa Mediana', 'precio_compra' => 9.02, 'precio_venta' => 12.5, 'stock' => 60, 'stock_minimo' => 9],
            ['categoria_id' => $categorias['Snacks'], 'codigo' => 'SNAC-0007', 'nombre' => 'Nachos Picantes Bolsa Grande', 'descripcion' => 'Nachos Picantes Bolsa Grande', 'precio_compra' => 12.67, 'precio_venta' => 17.5, 'stock' => 19, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Snacks'], 'codigo' => 'SNAC-0008', 'nombre' => 'Lay\'s Papas Fritas Pequeña', 'descripcion' => 'Lay\'s Papas Fritas Pequeña', 'precio_compra' => 2.99, 'precio_venta' => 4.0, 'stock' => 64, 'stock_minimo' => 10],
            ['categoria_id' => $categorias['Snacks'], 'codigo' => 'SNAC-0009', 'nombre' => 'Lay\'s Papas Fritas Familiar', 'descripcion' => 'Lay\'s Papas Fritas Familiar', 'precio_compra' => 11.34, 'precio_venta' => 16.5, 'stock' => 48, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Snacks'], 'codigo' => 'SNAC-0010', 'nombre' => 'Pringles Tubo Grande', 'descripcion' => 'Pringles Tubo Grande', 'precio_compra' => 15.17, 'precio_venta' => 20.0, 'stock' => 29, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Snacks'], 'codigo' => 'SNAC-0011', 'nombre' => 'Cheetos/Chizitos Pequeña', 'descripcion' => 'Cheetos/Chizitos Pequeña', 'precio_compra' => 1.93, 'precio_venta' => 2.5, 'stock' => 56, 'stock_minimo' => 8],
            ['categoria_id' => $categorias['Snacks'], 'codigo' => 'SNAC-0012', 'nombre' => 'Cheetos/Chizitos Grande', 'descripcion' => 'Cheetos/Chizitos Grande', 'precio_compra' => 7.64, 'precio_venta' => 11.0, 'stock' => 27, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Snacks'], 'codigo' => 'SNAC-0013', 'nombre' => 'Frutos Secos/Maní Bolsita Individual', 'descripcion' => 'Frutos Secos/Maní Bolsita Individual', 'precio_compra' => 2.72, 'precio_venta' => 3.5, 'stock' => 38, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Espumantes y Sidras'], 'codigo' => 'ESPU-0001', 'nombre' => 'Sidra Del Valle 710ml/910ml', 'descripcion' => 'Sidra Del Valle 710ml/910ml', 'precio_compra' => 22.64, 'precio_venta' => 30.0, 'stock' => 22, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Espumantes y Sidras'], 'codigo' => 'ESPU-0002', 'nombre' => 'Sidra Real 710ml/910ml', 'descripcion' => 'Sidra Real 710ml/910ml', 'precio_compra' => 21.59, 'precio_venta' => 30.0, 'stock' => 72, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Espumantes y Sidras'], 'codigo' => 'ESPU-0003', 'nombre' => 'Sidra Farruco 710ml/910ml', 'descripcion' => 'Sidra Farruco 710ml/910ml', 'precio_compra' => 20.89, 'precio_venta' => 30.0, 'stock' => 38, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Espumantes y Sidras'], 'codigo' => 'ESPU-0004', 'nombre' => 'Champagne Chandon Botella 750ml', 'descripcion' => 'Champagne Chandon Botella 750ml', 'precio_compra' => 97.46, 'precio_venta' => 140.0, 'stock' => 65, 'stock_minimo' => 10],
            ['categoria_id' => $categorias['Espumantes y Sidras'], 'codigo' => 'ESPU-0005', 'nombre' => 'Federico de Alvear Botella 750ml', 'descripcion' => 'Federico de Alvear Botella 750ml', 'precio_compra' => 38.97, 'precio_venta' => 50.0, 'stock' => 61, 'stock_minimo' => 9],
            ['categoria_id' => $categorias['Chichas, Macerados y Tragos Tradicionales'], 'codigo' => 'CHIC-0001', 'nombre' => 'Chapunato Botella 750ml/Litro', 'descripcion' => 'Chapunato Botella 750ml/Litro', 'precio_compra' => 17.85, 'precio_venta' => 25.0, 'stock' => 35, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Chichas, Macerados y Tragos Tradicionales'], 'codigo' => 'CHIC-0002', 'nombre' => 'Coco Macerado Botella 750ml/Litro', 'descripcion' => 'Coco Macerado Botella 750ml/Litro', 'precio_compra' => 17.89, 'precio_venta' => 25.0, 'stock' => 21, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Chichas, Macerados y Tragos Tradicionales'], 'codigo' => 'CHIC-0003', 'nombre' => 'Sucumbé Botella 1 Litro', 'descripcion' => 'Sucumbé Botella 1 Litro', 'precio_compra' => 22.57, 'precio_venta' => 30.0, 'stock' => 12, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Chichas, Macerados y Tragos Tradicionales'], 'codigo' => 'CHIC-0004', 'nombre' => 'Té con Té Botella 1 Litro', 'descripcion' => 'Té con Té Botella 1 Litro', 'precio_compra' => 21.41, 'precio_venta' => 30.0, 'stock' => 68, 'stock_minimo' => 10],
            ['categoria_id' => $categorias['Complementos e Insumos de Barra'], 'codigo' => 'COMP-0001', 'nombre' => 'Hielo en Rolito Bolsa 2 kg', 'descripcion' => 'Hielo en Rolito Bolsa 2 kg', 'precio_compra' => 5.79, 'precio_venta' => 8.0, 'stock' => 12, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Complementos e Insumos de Barra'], 'codigo' => 'COMP-0002', 'nombre' => 'Hielo en Rolito Bolsa 5 kg', 'descripcion' => 'Hielo en Rolito Bolsa 5 kg', 'precio_compra' => 11.14, 'precio_venta' => 15.5, 'stock' => 76, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Complementos e Insumos de Barra'], 'codigo' => 'COMP-0003', 'nombre' => 'Limones Unidad', 'descripcion' => 'Limones Unidad', 'precio_compra' => 0.56, 'precio_venta' => 0.75, 'stock' => 75, 'stock_minimo' => 11],
            ['categoria_id' => $categorias['Complementos e Insumos de Barra'], 'codigo' => 'COMP-0004', 'nombre' => 'Vasos Plásticos Paquete 50u (Grandes)', 'descripcion' => 'Vasos Plásticos Paquete 50u (Grandes)', 'precio_compra' => 10.48, 'precio_venta' => 13.5, 'stock' => 24, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Vinos'], 'codigo' => 'VINO-0001', 'nombre' => 'Campos de Solana Clásico/Varietal 750ml', 'descripcion' => 'Campos de Solana Clásico/Varietal 750ml', 'precio_compra' => 31.14, 'precio_venta' => 40.0, 'stock' => 39, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Vinos'], 'codigo' => 'VINO-0002', 'nombre' => 'Campos de Solana Reserva', 'descripcion' => 'Campos de Solana Reserva', 'precio_compra' => 62.17, 'precio_venta' => 80.0, 'stock' => 23, 'stock_minimo' => 3],
            ['categoria_id' => $categorias['Vinos'], 'codigo' => 'VINO-0003', 'nombre' => 'Kohlberg Clásico/Varietal 750ml', 'descripcion' => 'Kohlberg Clásico/Varietal 750ml', 'precio_compra' => 27.54, 'precio_venta' => 40.0, 'stock' => 44, 'stock_minimo' => 7],
            ['categoria_id' => $categorias['Vinos'], 'codigo' => 'VINO-0004', 'nombre' => 'Kohlberg Reserva', 'descripcion' => 'Kohlberg Reserva', 'precio_compra' => 54.72, 'precio_venta' => 80.0, 'stock' => 33, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Vinos'], 'codigo' => 'VINO-0005', 'nombre' => 'Aranjuez Clásico/Varietal 750ml', 'descripcion' => 'Aranjuez Clásico/Varietal 750ml', 'precio_compra' => 28.28, 'precio_venta' => 40.0, 'stock' => 26, 'stock_minimo' => 4],
            ['categoria_id' => $categorias['Vinos'], 'codigo' => 'VINO-0006', 'nombre' => 'Aranjuez Reserva', 'descripcion' => 'Aranjuez Reserva', 'precio_compra' => 60.96, 'precio_venta' => 80.0, 'stock' => 43, 'stock_minimo' => 6],
            ['categoria_id' => $categorias['Vinos'], 'codigo' => 'VINO-0007', 'nombre' => 'Vino Tetra Pack Toro 1 Litro', 'descripcion' => 'Vino Tetra Pack Toro 1 Litro', 'precio_compra' => 14.41, 'precio_venta' => 20.0, 'stock' => 78, 'stock_minimo' => 12],
            ['categoria_id' => $categorias['Vinos'], 'codigo' => 'VINO-0008', 'nombre' => 'Vino Tetra Pack Termidor 1 Litro', 'descripcion' => 'Vino Tetra Pack Termidor 1 Litro', 'precio_compra' => 15.44, 'precio_venta' => 20.0, 'stock' => 83, 'stock_minimo' => 12],

            // Productos nuevos que no tenían equivalente en el catálogo (vienen
            // del inventario de ejemplo con código de barras que se cargó el
            // 24/09/2026).
            ['categoria_id' => $categorias['Sodas y Gaseosas Locales'], 'codigo' => 'SODA-0033', 'codigo_barras' => '7402223334446', 'unidades_por_paquete' => 6, 'nombre' => 'Gaseosa Mendocina Pomelo 2 Litros', 'descripcion' => 'Gaseosa Mendocina Pomelo 2 Litros', 'precio_compra' => 6.75, 'precio_venta' => 9.0, 'stock' => 36, 'stock_minimo' => 5],
            ['categoria_id' => $categorias['Cigarrillos'], 'codigo' => 'CIGA-0010', 'codigo_barras' => '7404445556668', 'unidades_por_paquete' => 10, 'nombre' => 'Lucky Strike Click Cajetilla x20', 'descripcion' => 'Lucky Strike Click Cajetilla x20', 'precio_compra' => 11.5, 'precio_venta' => 15.0, 'stock' => 40, 'stock_minimo' => 6],
        ];

        // El almacén Principal ya existe: lo crea la migración de almacenes
        // (2026_09_20_000100_create_almacenes_table). productos.stock es una
        // caché del total en todos los almacenes (ver Producto::ajustarStock),
        // así que cada producto sembrado necesita también su fila en
        // stock_por_almacen o la caché quedaría desincronizada del detalle.
        $almacenPrincipalId = Almacen::principalId();

        foreach ($productos as $p) {
            // updateOrCreate por 'codigo': si el producto ya existía (por una
            // corrida anterior del seeder), no lo duplica ni pisa su precio o
            // stock actuales — solo asegura que esté cargado con sus datos
            // base. El bloque de $actualizaciones más abajo es el que corrige
            // stock/barcode de productos existentes a propósito.
            $producto = Producto::firstOrCreate(
                ['codigo' => $p['codigo']],
                $p + ['activo' => true]
            );

            StockPorAlmacen::firstOrCreate(
                ['producto_id' => $producto->id, 'almacen_id' => $almacenPrincipalId],
                ['cantidad' => $p['stock']]
            );
        }

        // Productos que ya existían en el catálogo con otro código y que el
        // inventario de ejemplo (24/09/2026) trae con barcode y stock propios.
        // Se les agrega el código de barras / unidades por paquete y se pisa
        // el stock con el valor nuevo, sin tocar el precio (el inventario de
        // ejemplo no traía precios).
        $actualizaciones = [
            // codigo existente => [codigo_barras, unidades_por_paquete, stock nuevo]
            'SING-0014' => ['7401234567891', 6, 24],  // San Pedro Oro 750ml
            'SING-0003' => ['7401234567892', 6, 18],  // Casa Real Etiqueta Negra 750ml
            'CERV-0001' => ['7401112223334', 12, 120], // Paceña Botella Retornable 620cc (~ Centenario)
            'CERV-0006' => ['7401112223335', 12, 84],  // Huari Botella Retornable 620cc
            'SODA-0012' => ['7402223334445', 6, 60],   // Coca-Cola Botella 3L
            'WHIS-0001' => ['5010103917890', 12, 12],  // Johnnie Walker Red Label (etiqueta trae 1L, catálogo tiene 750ml)
            'WHIS-0011' => ['5010103917891', 12, 8],   // Chivas Regal 12 Años 750ml
            'ENER-0007' => ['7403334445556', 6, 48],   // Gatorade Botella 500-600ml
            'ENER-0001' => ['7403334445557', 12, 72],  // Monster Energy Lata 473ml
            'CIGA-0005' => ['7404445556667', 10, 50],  // Camel Cajetilla x20
            'SNAC-0002' => ['7575232311223', 10, 30],  // Takis Bolsa Familiar (~ Fuego Grandes)
            'SNAC-0004' => ['7575232311224', 12, 25],  // Doritos Mediana 90g (~ Nachos Queso Mediano)
        ];

        foreach ($actualizaciones as $codigo => [$codigoBarras, $unidadesPorPaquete, $stockNuevo]) {
            $producto = Producto::where('codigo', $codigo)->first();

            if (! $producto) {
                continue;
            }

            $producto->update([
                'codigo_barras' => $codigoBarras,
                'unidades_por_paquete' => $unidadesPorPaquete,
            ]);

            $stockActual = StockPorAlmacen::where('producto_id', $producto->id)
                ->where('almacen_id', $almacenPrincipalId)
                ->value('cantidad') ?? 0;

            $delta = $stockNuevo - $stockActual;

            if ($delta !== 0) {
                $producto->ajustarStock($delta, $almacenPrincipalId);
            }
        }

        $this->command?->info(count($productos).' productos cargados, '.count($actualizaciones).' actualizados con código de barras, en '.count($categorias).' categorías.');
    }
}
