<?php

namespace Database\Seeders;

use App\Models\Producto;
use Illuminate\Database\Seeder;

/**
 * OPCIONAL. Guarda en productos.imagen la foto que ya sugiere
 * config/imagenes_productos.php (el sistema la muestra igual sin ejecutar esto).
 * Sirve si quieres que la ruta quede escrita en la base.
 *
 * No pisa una imagen que hayas puesto a mano con otra ruta o URL.
 *
 *     php artisan db:seed --class=ImagenesProductosSeeder
 */
class ImagenesProductosSeeder extends Seeder
{
    public function run(): void
    {
        $actualizados = 0;
        $conservados = 0;
        $sinFoto = 0;

        foreach (Producto::query()->get() as $producto) {
            $ruta = Producto::imagenPorDefecto($producto->codigo, $producto->nombre);

            if (! $ruta) {
                $sinFoto++;
                continue;
            }

            $guardada = $producto->getRawOriginal('imagen');

            // Imagen puesta a mano (otra ruta o URL): se respeta.
            if ($guardada && ! str_starts_with($guardada, '/productos/')) {
                $conservados++;
                continue;
            }

            $producto->update(['imagen' => $ruta]);
            $actualizados++;
        }

        $this->command?->info("Imágenes guardadas: {$actualizados}. Conservadas (puestas a mano): {$conservados}. Sin foto disponible: {$sinFoto}.");
    }
}
