<?php

namespace Database\Seeders;

use App\Models\Cliente;
use App\Models\Usuario;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        // Usuarios del sistema (para login y para asignar como vendedor en los pedidos)
        Usuario::create([
            'nombre' => 'Administrador',
            'email' => 'admin@licoreria.com',
            'password' => Hash::make('admin123'),
            'rol' => 'administrador',
            'activo' => true,
        ]);

        $vendedor = Usuario::create([
            'nombre' => 'Juan Pablo Cueto',
            'email' => 'vendedor@licoreria.com',
            'password' => Hash::make('vendedor123'),
            'rol' => 'vendedor',
            'activo' => true,
        ]);

        // Categorías y productos: catálogo completo de la licorería
        $this->call(LicoreriaInventarioSeeder::class);
        $this->call(ImagenesProductosSeeder::class);
        $this->call(PreciosBoliviaSeeder::class);

        // Clientes
        Cliente::create(['nombre' => 'Mercedes Rojas', 'telefono' => '75612345', 'email' => 'mercedes@example.com', 'direccion' => 'Av. Progreso 123', 'activo' => true]);
        Cliente::create(['nombre' => 'Restaurante El Puente', 'telefono' => '75698765', 'email' => 'contacto@elpuente.com', 'direccion' => 'Calle Cochabamba 45', 'activo' => true]);
        Cliente::create(['nombre' => 'Hostal Amazonas', 'telefono' => '75611223', 'email' => null, 'direccion' => 'Av. Costanera 200', 'activo' => true]);

        $this->command?->info('Datos de demo creados. Login admin: admin@licoreria.com / admin123');
    }
}
