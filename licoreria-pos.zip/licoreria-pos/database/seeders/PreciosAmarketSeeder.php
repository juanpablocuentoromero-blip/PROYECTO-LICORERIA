<?php

namespace Database\Seeders;

use App\Models\Producto;
use Illuminate\Console\Command;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

/**
 * Precios tomados de https://amarket.com.bo (sucursal Urubó, Santa Cruz) en
 * octubre de 2026, solo de productos que coinciden con los tuyos en marca,
 * línea y tamaño. Para el resto del catálogo usa el comando:
 *
 *     php artisan productos:importar-amarket
 *
 * Es un precio de supermercado en Santa Cruz: en Beni suele ser algo más alto.
 * El costo se calcula como 80 % del precio de venta (margen de 25 %) y queda
 * guardado el margen, así que al comprar a otro costo el sistema recalcula
 * solo el precio de venta. Ajusta el costo con tus facturas desde Productos.
 *
 *     php artisan db:seed --class=PreciosAmarketSeeder
 */
class PreciosAmarketSeeder extends Seeder
{
    use WithoutModelEvents;

    private const FACTOR_COSTO = 0.80;
    private const MARGEN = 25.0;

    public function run(): void
    {
        // codigo => precio de venta en Amarket (Bs, por unidad)
        $precios = [
            'CERV-0013' => 12.50, // Potosina Pilsener Premium lata 473 ml
            'CERV-0015' => 14.00, // Corona botella 330 ml (aprox.: tu porrón es de 355 ml)
            'SODA-0012' => 20.00, // Coca-Cola Original 3 L
            'SODA-0013' => 15.50, // Coca-Cola Original 2.5 L
            'SODA-0022' => 20.00, // Sprite Original 3 L
            'SODA-0023' => 14.00, // Sprite Original 2 L
            'SODA-0026' => 15.00, // Pepsi Original 3 L
            'SODA-0031' => 14.00, // Guaraná Antárctica 2 L
            'COMP-0001' => 8.00,  // Hielo Nevada 2 kg
            'VINO-0003' => 33.30, // Kohlberg Clásico 700 ml (aprox.: tu vino es de 750 ml)
            'SNAC-0010' => 33.40, // Pringles Original 124 g
        ];

        $cambiados = 0;

        foreach ($precios as $codigo => $venta) {
            $producto = Producto::where('codigo', $codigo)->first();

            if (! $producto) {
                continue;
            }

            $producto->forceFill([
                'precio_venta' => $venta,
                'precio_compra' => round($venta * self::FACTOR_COSTO, 2),
                'margen_porcentaje' => self::MARGEN,
            ])->saveQuietly();

            $cambiados++;
        }

        $this->command?->info("Precios de Amarket aplicados a {$cambiados} productos.");
    }
}
