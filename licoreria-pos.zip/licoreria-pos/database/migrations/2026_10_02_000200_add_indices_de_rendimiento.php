<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// 2.3 — Índices para que los listados y reportes no se vuelvan lentos
// cuando crezcan pedidos y movimientos de inventario.
//
// OJO: pedidos.usuario_id, detalle_pedidos.pedido_id y
// detalle_pedidos.producto_id ya tienen índice en MySQL porque nacieron
// como foreignId()->constrained() (InnoDB lo crea solo para cada llave
// foránea). Duplicarlos solo haría más lentas las escrituras, por eso no
// se vuelven a crear aquí.
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            $table->index('created_at', 'pedidos_created_at_idx');
            $table->index('estado', 'pedidos_estado_idx');
            $table->index('origen', 'pedidos_origen_idx');
        });

        Schema::table('movimientos_inventario', function (Blueprint $table) {
            $table->index(['producto_id', 'created_at'], 'mov_inv_producto_created_idx');
        });
    }

    public function down(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            $table->dropIndex('pedidos_created_at_idx');
            $table->dropIndex('pedidos_estado_idx');
            $table->dropIndex('pedidos_origen_idx');
        });

        Schema::table('movimientos_inventario', function (Blueprint $table) {
            $table->dropIndex('mov_inv_producto_created_idx');
        });
    }
};
