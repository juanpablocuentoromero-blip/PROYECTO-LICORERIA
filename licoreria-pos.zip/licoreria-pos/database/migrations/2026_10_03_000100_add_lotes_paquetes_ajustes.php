<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Lotes: cada entrada de mercadería (compra o ajuste) puede traer su
        // propia fecha de vencimiento. El stock total sigue viviendo en
        // stock_por_almacen; el lote solo dice "de lo que hay, esto vence tal día".
        Schema::create('lotes_producto', function (Blueprint $table) {
            $table->id();
            $table->foreignId('producto_id')->constrained('productos')->onDelete('cascade');
            $table->foreignId('almacen_id')->constrained('almacenes')->onDelete('restrict');
            $table->foreignId('pedido_compra_id')->nullable()->constrained('pedidos_compra')->nullOnDelete();
            $table->string('numero_lote')->nullable();
            $table->date('fecha_vencimiento')->nullable();
            $table->unsignedInteger('cantidad_inicial');
            $table->unsignedInteger('cantidad_disponible');
            $table->decimal('costo_unitario', 10, 2)->default(0);
            $table->timestamps();

            $table->index(['producto_id', 'fecha_vencimiento']);
        });

        // Compras por paquete/caja: se guarda cómo se compró (paquetes y
        // unidades por paquete) además de las unidades resultantes (cantidad).
        Schema::table('detalle_pedidos_compra', function (Blueprint $table) {
            $table->unsignedInteger('cantidad_paquetes')->nullable()->after('cantidad');
            $table->unsignedInteger('unidades_por_paquete')->nullable()->after('cantidad_paquetes');
            $table->decimal('precio_paquete', 10, 2)->nullable()->after('unidades_por_paquete');
            $table->string('numero_lote')->nullable()->after('subtotal');
            $table->date('fecha_vencimiento')->nullable()->after('numero_lote');
        });

        // Margen de ganancia (%) para calcular el precio de venta automáticamente.
        Schema::table('productos', function (Blueprint $table) {
            $table->decimal('margen_porcentaje', 6, 2)->nullable()->after('precio_venta');
        });

        // Teléfono de contacto del pedido (obligatorio al registrar un pedido).
        // Vive en el pedido y no solo en el cliente: el cliente genérico
        // "SIN NOMBRE" lo comparten todas las ventas rápidas.
        Schema::table('pedidos', function (Blueprint $table) {
            $table->string('telefono_contacto', 20)->nullable()->after('direccion_entrega');
        });

        // Marca los movimientos que vienen de un ajuste por conteo físico.
        Schema::table('movimientos_inventario', function (Blueprint $table) {
            $table->boolean('es_ajuste')->default(false)->after('motivo');
        });
    }

    public function down(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            $table->dropColumn('telefono_contacto');
        });

        Schema::table('movimientos_inventario', function (Blueprint $table) {
            $table->dropColumn('es_ajuste');
        });

        Schema::table('productos', function (Blueprint $table) {
            $table->dropColumn('margen_porcentaje');
        });

        Schema::table('detalle_pedidos_compra', function (Blueprint $table) {
            $table->dropColumn(['cantidad_paquetes', 'unidades_por_paquete', 'precio_paquete', 'numero_lote', 'fecha_vencimiento']);
        });

        Schema::dropIfExists('lotes_producto');
    }
};
