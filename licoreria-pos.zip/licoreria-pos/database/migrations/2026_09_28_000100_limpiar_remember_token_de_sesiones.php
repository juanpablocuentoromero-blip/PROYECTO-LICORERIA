<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

// Las sesiones ahora viven en personal_access_tokens (hasheadas). Los
// remember_token viejos ya no sirven para entrar, pero seguían guardados en
// texto plano: se borran para no dejar credenciales muertas en la base.
return new class extends Migration
{
    public function up(): void
    {
        DB::table('usuarios')->update(['remember_token' => null]);
        DB::table('clientes')->update(['remember_token' => null]);
    }

    public function down(): void
    {
        // Irreversible a propósito: no hay nada que restaurar.
    }
};
