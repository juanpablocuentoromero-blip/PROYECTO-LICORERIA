<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Un combo/promoción (ej. "botella + hielo + gaseosa") se vende como
        // un producto más: producto_id apunta al producto "vitrina" que lo
        // representa en el catálogo/POS (tiene su propio código de barras y
        // precio_venta = precio del combo). El stock real de ese producto
        // vitrina NO se lleva por columna propia: se calcula/descuenta a
        // partir del stock de sus componentes (ver combo_items), así que un
        // combo nunca puede venderse por encima de lo que sus partes permiten.
        Schema::create('combos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('producto_id')->constrained('productos')->onDelete('cascade');
            $table->string('nombre');
            $table->text('descripcion')->nullable();
            $table->decimal('precio', 10, 2);
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        Schema::create('combo_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('combo_id')->constrained('combos')->onDelete('cascade');
            // restrict: no se puede borrar un producto mientras siga siendo
            // componente de un combo activo (rompería el cálculo de stock).
            $table->foreignId('producto_id')->constrained('productos')->onDelete('restrict');
            $table->integer('cantidad');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('combo_items');
        Schema::dropIfExists('combos');
    }
};
