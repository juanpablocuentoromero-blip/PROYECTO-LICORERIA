<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            // Suma de los descuentos de todas las líneas. Se cumple siempre:
            // total = subtotal - descuento.
            $table->decimal('descuento', 10, 2)->default(0)->after('subtotal');

            // Desde qué almacén y en qué turno de caja se hizo la venta. Son
            // nullable porque los pedidos anteriores (y los de la tienda
            // online) no tienen ninguno de los dos.
            $table->foreignId('almacen_id')->nullable()->after('usuario_id')
                ->constrained('almacenes')->nullOnDelete();
            $table->foreignId('caja_id')->nullable()->after('almacen_id')
                ->constrained('cajas')->nullOnDelete();
        });

        Schema::table('detalle_pedidos', function (Blueprint $table) {
            // Descuento en Bs de la línea. detalle_pedidos.subtotal guarda el
            // importe ya descontado: precio_unitario * cantidad - descuento.
            $table->decimal('descuento', 10, 2)->default(0)->after('precio_unitario');
        });
    }

    public function down(): void
    {
        Schema::table('detalle_pedidos', function (Blueprint $table) {
            $table->dropColumn('descuento');
        });

        Schema::table('pedidos', function (Blueprint $table) {
            $table->dropConstrainedForeignId('caja_id');
            $table->dropConstrainedForeignId('almacen_id');
            $table->dropColumn('descuento');
        });
    }
};
