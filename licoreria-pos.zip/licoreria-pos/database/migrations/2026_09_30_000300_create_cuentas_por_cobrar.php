<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('clientes', function (Blueprint $table) {
            // El fiado es una decisión por cliente: nace deshabilitado y solo
            // el administrador lo habilita. `limite_credito` null = sin tope.
            $table->boolean('credito_habilitado')->default(false)->after('activo');
            $table->decimal('limite_credito', 10, 2)->nullable()->after('credito_habilitado');
        });

        Schema::table('pedidos', function (Blueprint $table) {
            // Lo que el cliente todavía debe de esta venta. 0 en todo lo que
            // no sea crédito. Se mantiene en la misma transacción que crea
            // cada abono, así los reportes no tienen que recalcularlo.
            $table->decimal('saldo_pendiente', 10, 2)->default(0)->after('total');
            $table->date('fecha_vencimiento_credito')->nullable()->after('saldo_pendiente');
        });

        Schema::create('abonos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('pedido_id')->constrained('pedidos')->onDelete('restrict');
            // Se guarda también el cliente para consultar "todo lo que abonó
            // Juan" sin pasar por pedidos.
            $table->foreignId('cliente_id')->constrained('clientes')->onDelete('restrict');
            $table->foreignId('usuario_id')->constrained('usuarios')->onDelete('restrict');
            // Caja abierta cuando se cobró: el abono en efectivo entra al
            // arqueo de ese turno.
            $table->foreignId('caja_id')->nullable()->constrained('cajas')->nullOnDelete();
            $table->decimal('monto', 10, 2);
            $table->string('metodo_pago', 20); // efectivo | qr | tarjeta
            $table->string('observaciones', 255)->nullable();
            // Un abono nunca se borra: se anula (queda el rastro de quién y por qué).
            $table->boolean('anulado')->default(false);
            $table->timestamp('anulado_at')->nullable();
            $table->string('motivo_anulacion', 255)->nullable();
            $table->foreignId('usuario_anulacion_id')->nullable()->constrained('usuarios')->nullOnDelete();
            $table->timestamps();

            $table->index(['cliente_id', 'anulado']);
        });

        Schema::table('cajas', function (Blueprint $table) {
            // Foto del turno (se congela al cerrar, igual que el resto).
            $table->decimal('monto_abonos_efectivo', 10, 2)->nullable()->after('monto_ventas_total');
            $table->decimal('monto_abonos_qr', 10, 2)->nullable()->after('monto_abonos_efectivo');
            $table->decimal('monto_abonos_tarjeta', 10, 2)->nullable()->after('monto_abonos_qr');
            $table->decimal('monto_ventas_credito', 10, 2)->nullable()->after('monto_abonos_tarjeta');
        });
    }

    public function down(): void
    {
        Schema::table('cajas', function (Blueprint $table) {
            $table->dropColumn([
                'monto_abonos_efectivo', 'monto_abonos_qr', 'monto_abonos_tarjeta', 'monto_ventas_credito',
            ]);
        });

        Schema::dropIfExists('abonos');

        Schema::table('pedidos', function (Blueprint $table) {
            $table->dropColumn(['saldo_pendiente', 'fecha_vencimiento_credito']);
        });

        Schema::table('clientes', function (Blueprint $table) {
            $table->dropColumn(['credito_habilitado', 'limite_credito']);
        });
    }
};
