<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// 6.4 — Fidelización: puntos para clientes identificados.
//
// El saldo vive en clientes.puntos_saldo (lectura rápida en caja), pero la
// verdad contable es el libro puntos_movimientos: cada fila es un
// movimiento firmado (+ganado / -canjeado) con el saldo resultante, así el
// saldo siempre se puede reconstruir y auditar.
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('clientes', function (Blueprint $table) {
            // Puede quedar negativo si se devuelve mercadería cuyos puntos
            // ya se gastaron; en ese caso no se puede canjear hasta volver
            // a ser positivo.
            $table->integer('puntos_saldo')->default(0);
        });

        Schema::table('pedidos', function (Blueprint $table) {
            $table->unsignedInteger('puntos_ganados')->default(0);
            $table->unsignedInteger('puntos_canjeados')->default(0);
            // Dinero descontado por canjear puntos. YA está incluido en
            // pedidos.descuento y repartido en el descuento de cada línea.
            $table->decimal('descuento_puntos', 10, 2)->default(0);
        });

        Schema::create('puntos_movimientos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cliente_id')->constrained('clientes')->cascadeOnDelete();
            $table->foreignId('pedido_id')->nullable()->constrained('pedidos')->nullOnDelete();
            $table->foreignId('usuario_id')->nullable()->constrained('usuarios')->nullOnDelete();
            // acumulo | canje | reverso_acumulo | reverso_canje | reverso_devolucion | ajuste
            $table->string('tipo', 30);
            $table->integer('puntos'); // firmado
            $table->integer('saldo_despues');
            $table->string('descripcion')->nullable();
            $table->timestamps();

            $table->index(['cliente_id', 'id']);
            $table->index(['pedido_id', 'tipo']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('puntos_movimientos');

        Schema::table('pedidos', function (Blueprint $table) {
            $table->dropColumn(['puntos_ganados', 'puntos_canjeados', 'descuento_puntos']);
        });

        Schema::table('clientes', function (Blueprint $table) {
            $table->dropColumn('puntos_saldo');
        });
    }
};
