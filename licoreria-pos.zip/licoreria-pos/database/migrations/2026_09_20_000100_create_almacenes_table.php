<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('almacenes', function (Blueprint $table) {
            $table->id();
            $table->string('nombre')->unique();
            $table->string('direccion')->nullable();
            // Exactamente un almacén debe ser el "principal": es el que se usa
            // por defecto en ventas, compras y ajustes mientras el resto del
            // sistema (POS, caja) todavía no deja elegir almacén explícitamente.
            $table->boolean('es_principal')->default(false);
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        // Semilla: un almacén "Principal" para que todo el stock existente
        // tenga dónde vivir. Si ya había productos con stock, esa cantidad
        // se migra a este almacén en la siguiente migración.
        DB::table('almacenes')->insert([
            'nombre' => 'Principal',
            'direccion' => null,
            'es_principal' => true,
            'activo' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('almacenes');
    }
};
