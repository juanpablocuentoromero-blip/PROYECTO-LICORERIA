<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('movimientos_inventario', function (Blueprint $table) {
            $table->foreignId('almacen_id')->nullable()->after('producto_id')
                ->constrained('almacenes')->onDelete('restrict');
        });

        // Los movimientos que ya existían no tenían almacén: se atribuyen
        // al Principal para no dejar huecos en el historial/reportes.
        $almacenPrincipalId = DB::table('almacenes')->where('es_principal', true)->value('id');
        DB::table('movimientos_inventario')->whereNull('almacen_id')->update(['almacen_id' => $almacenPrincipalId]);
    }

    public function down(): void
    {
        Schema::table('movimientos_inventario', function (Blueprint $table) {
            $table->dropConstrainedForeignId('almacen_id');
        });
    }
};
