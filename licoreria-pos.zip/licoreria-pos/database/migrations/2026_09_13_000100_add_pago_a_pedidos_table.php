<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            // El pedido puede crearse sin estar pagado todavía (ej. el cliente
            // eligió QR y aún no escaneó). "pagado" se marca aparte, cuando el
            // empleado confirma que el dinero llegó (efectivo/QR/datáfono).
            $table->boolean('pagado')->default(false)->after('metodo_pago');
            $table->timestamp('pagado_at')->nullable()->after('pagado');
            // Referencia que se muestra dentro del QR (para conciliar el pago
            // manualmente contra el estado de cuenta del banco).
            $table->string('referencia_pago')->nullable()->after('pagado_at');
        });
    }

    public function down(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            $table->dropColumn(['pagado', 'pagado_at', 'referencia_pago']);
        });
    }
};
