<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('clientes', function (Blueprint $table) {
            // NIT o CI del cliente. Es nullable porque los clientes que ya
            // existen (y los de la tienda online) no lo tienen; y es único
            // porque el mostrador busca al cliente por este dato.
            $table->string('nit_ci', 20)->nullable()->unique()->after('nombre');
        });

        // Cliente por defecto de las ventas rápidas: NIT/CI "0" y razón
        // social "SIN NOMBRE". Se crea acá para que exista desde el primer
        // día; VentaController lo vuelve a crear si alguien lo borra.
        if (! DB::table('clientes')->where('nit_ci', '0')->exists()) {
            DB::table('clientes')->insert([
                'nombre' => 'SIN NOMBRE',
                'nit_ci' => '0',
                'activo' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }

    public function down(): void
    {
        Schema::table('clientes', function (Blueprint $table) {
            $table->dropUnique(['nit_ci']);
            $table->dropColumn('nit_ci');
        });
    }
};
