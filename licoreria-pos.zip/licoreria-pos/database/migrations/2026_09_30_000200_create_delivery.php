<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Zonas de reparto con su costo de envío fijo.
        Schema::create('zonas_delivery', function (Blueprint $table) {
            $table->id();
            $table->string('nombre', 100);
            $table->decimal('costo_envio', 10, 2)->default(0);
            $table->string('descripcion', 255)->nullable();
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        // Repartidores: no necesitan usuario del sistema, basta con poder
        // asignarlos a un pedido y saber a qué número llamar.
        Schema::create('repartidores', function (Blueprint $table) {
            $table->id();
            $table->string('nombre', 100);
            $table->string('telefono', 20)->nullable();
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        Schema::table('pedidos', function (Blueprint $table) {
            // 'recojo' = el cliente pasa por la tienda; 'delivery' = se lleva.
            $table->string('tipo_entrega', 20)->default('recojo')->after('direccion_entrega');
            $table->foreignId('zona_delivery_id')->nullable()->after('tipo_entrega')
                ->constrained('zonas_delivery')->nullOnDelete();
            // Costo de envío congelado al crear el pedido (si después cambian
            // la tarifa de la zona, los pedidos viejos no se alteran). Ya está
            // incluido dentro de `total`.
            $table->decimal('costo_envio', 10, 2)->default(0)->after('zona_delivery_id');
            $table->foreignId('repartidor_id')->nullable()->after('costo_envio')
                ->constrained('repartidores')->nullOnDelete();
            $table->timestamp('en_camino_at')->nullable()->after('repartidor_id');
        });
    }

    public function down(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            $table->dropConstrainedForeignId('repartidor_id');
            $table->dropConstrainedForeignId('zona_delivery_id');
            $table->dropColumn(['tipo_entrega', 'costo_envio', 'en_camino_at']);
        });

        Schema::dropIfExists('repartidores');
        Schema::dropIfExists('zonas_delivery');
    }
};
