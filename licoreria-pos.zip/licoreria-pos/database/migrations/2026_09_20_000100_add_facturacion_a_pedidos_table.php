<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            // Tipo de venta: 'factura' emite documento fiscal y consume un
            // número correlativo; 'sin_factura' es la nota de venta simple
            // (la mayoría del mostrador). El filtro de la pantalla de
            // Ventas Registradas segmenta por esta columna.
            $table->string('tipo_venta', 20)->default('sin_factura')->after('metodo_pago');

            // Número fiscal con formato SUCURSAL-CORRELATIVO (0026-000002).
            // Solo lo llevan las ventas con factura; queda nullable para no
            // inventar números en las notas de venta. Único para que la base
            // rechace un correlativo repetido aunque dos cajas facturen a la
            // vez y la aplicación falle en el control.
            $table->string('nro_factura', 20)->nullable()->unique()->after('tipo_venta');

            // Anulación: una venta emitida NUNCA se borra, se anula. Así el
            // correlativo fiscal no queda con huecos y la auditoría puede ver
            // qué se anuló, cuándo, por qué y quién lo autorizó.
            $table->boolean('anulada')->default(false)->after('nro_factura');
            $table->timestamp('anulada_at')->nullable()->after('anulada');
            $table->string('motivo_anulacion')->nullable()->after('anulada_at');
            $table->foreignId('usuario_anulacion_id')->nullable()->after('motivo_anulacion')
                ->constrained('usuarios')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            $table->dropConstrainedForeignId('usuario_anulacion_id');
            $table->dropColumn([
                'tipo_venta', 'nro_factura', 'anulada', 'anulada_at', 'motivo_anulacion',
            ]);
        });
    }
};
