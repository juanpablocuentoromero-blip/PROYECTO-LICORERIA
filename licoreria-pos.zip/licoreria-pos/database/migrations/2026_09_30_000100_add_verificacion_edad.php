<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('clientes', function (Blueprint $table) {
            // Momento en que el cliente marcó "soy mayor de 18 años" al crear
            // su cuenta. Queda como constancia (cumplimiento: venta de alcohol
            // solo a mayores de edad). Null en cuentas anteriores a esta
            // función: se les pide confirmar en su próximo pedido.
            $table->timestamp('mayor_edad_confirmada_at')->nullable()->after('activo');
        });

        Schema::table('pedidos', function (Blueprint $table) {
            // Casilla marcada al hacer el pedido en línea. Las ventas de
            // mostrador la verifica el cajero en persona, por eso el valor
            // por defecto es false y solo el checkout online lo pone en true.
            $table->boolean('mayor_edad_confirmada')->default(false)->after('observaciones');
        });
    }

    public function down(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            $table->dropColumn('mayor_edad_confirmada');
        });

        Schema::table('clientes', function (Blueprint $table) {
            $table->dropColumn('mayor_edad_confirmada_at');
        });
    }
};
