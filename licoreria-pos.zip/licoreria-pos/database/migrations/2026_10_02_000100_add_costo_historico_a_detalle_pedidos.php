<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

// 2.1 — Costo y precio históricos en cada línea de venta.
//
// Hasta ahora la ganancia se calculaba con productos.precio_compra ACTUAL,
// así que cada vez que cambiaba el costo de un producto se "reescribía" la
// ganancia de todas las ventas pasadas. Desde aquí cada línea guarda el
// costo y el precio con los que se vendió.
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('detalle_pedidos', function (Blueprint $table) {
            $table->decimal('precio_compra', 10, 2)->nullable()->after('precio_unitario');
            $table->decimal('precio_venta', 10, 2)->nullable()->after('precio_compra');
        });

        // Relleno de las ventas ya existentes:
        //  - precio_venta: es exacto, ya estaba guardado como precio_unitario.
        //  - precio_compra: no hay forma de saber el costo de entonces; se
        //    congela el costo actual del producto (mejor aproximación posible)
        //    para que desde hoy deje de moverse.
        DB::statement('UPDATE detalle_pedidos SET precio_venta = precio_unitario');
        DB::statement(
            'UPDATE detalle_pedidos SET precio_compra = '
            .'(SELECT productos.precio_compra FROM productos WHERE productos.id = detalle_pedidos.producto_id)'
        );
    }

    public function down(): void
    {
        Schema::table('detalle_pedidos', function (Blueprint $table) {
            $table->dropColumn(['precio_compra', 'precio_venta']);
        });
    }
};
