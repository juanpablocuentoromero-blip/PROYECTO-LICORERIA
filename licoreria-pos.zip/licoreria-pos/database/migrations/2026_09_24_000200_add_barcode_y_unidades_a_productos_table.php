<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('productos', function (Blueprint $table) {
            // Código de barras físico del producto (distinto de 'codigo', que es
            // el código interno del catálogo). Nullable porque no todos los
            // productos lo traen cargado todavía; unique solo entre los que sí
            // lo tienen.
            $table->string('codigo_barras')->nullable()->unique()->after('codigo');

            // Cuántas unidades trae el paquete/caja en que se compra este
            // producto al proveedor (ej. una caja de cerveza trae 12). Se usa
            // como referencia informativa; el stock sigue contándose en
            // unidades individuales.
            $table->unsignedInteger('unidades_por_paquete')->nullable()->after('codigo_barras');
        });
    }

    public function down(): void
    {
        Schema::table('productos', function (Blueprint $table) {
            $table->dropColumn(['codigo_barras', 'unidades_por_paquete']);
        });
    }
};
