<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('stock_por_almacen', function (Blueprint $table) {
            $table->id();
            $table->foreignId('producto_id')->constrained('productos')->onDelete('cascade');
            $table->foreignId('almacen_id')->constrained('almacenes')->onDelete('restrict');
            $table->integer('cantidad')->default(0);
            $table->timestamps();
            $table->unique(['producto_id', 'almacen_id']);
        });

        // Migración de datos: todo el stock que ya tenían los productos
        // (columna productos.stock) pasa a vivir en el almacén Principal.
        // productos.stock se conserva como caché del total (se mantiene en
        // sincronía desde Producto::ajustarStock()), así que el resto del
        // sistema que ya lee $producto->stock sigue funcionando sin cambios.
        $almacenPrincipalId = DB::table('almacenes')->where('es_principal', true)->value('id');

        $ahora = now();
        $filas = DB::table('productos')->select('id', 'stock')->get()->map(function ($producto) use ($almacenPrincipalId, $ahora) {
            return [
                'producto_id' => $producto->id,
                'almacen_id' => $almacenPrincipalId,
                'cantidad' => $producto->stock,
                'created_at' => $ahora,
                'updated_at' => $ahora,
            ];
        })->all();

        if (! empty($filas)) {
            DB::table('stock_por_almacen')->insert($filas);
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('stock_por_almacen');
    }
};
