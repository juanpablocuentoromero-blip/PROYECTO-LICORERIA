<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Agrega lo necesario para que un cliente pueda crear su propia cuenta
    // y autenticarse en la tienda pública, sin tocar los clientes que ya
    // existan (creados a mano por el personal, que seguirán sin password:
    // simplemente no podrán iniciar sesión hasta que se registren).
    public function up(): void
    {
        Schema::table('clientes', function (Blueprint $table) {
            $table->string('password')->nullable()->after('email');
            $table->rememberToken()->after('password');
        });
    }

    public function down(): void
    {
        Schema::table('clientes', function (Blueprint $table) {
            $table->dropColumn(['password', 'remember_token']);
        });
    }
};
