<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('movimientos_caja_chica', function (Blueprint $table) {
            $table->id();
            // Todo movimiento de caja chica pertenece a un turno de caja
            // abierto: así el cierre puede sumar exactamente lo que pasó
            // en ESE turno, sin mezclar movimientos de otros días.
            $table->foreignId('caja_id')->constrained('cajas')->onDelete('restrict');
            $table->foreignId('almacen_id')->constrained('almacenes')->onDelete('restrict');
            $table->foreignId('usuario_id')->constrained('usuarios')->onDelete('restrict');

            $table->string('cuenta'); // ej: Servicios, Limpieza, Transporte, Otros
            $table->string('tipo'); // ingreso | egreso
            $table->string('metodo_pago')->default('efectivo'); // efectivo | cheque
            $table->string('nro_documento')->nullable();
            $table->string('concepto');
            $table->decimal('monto', 10, 2);

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('movimientos_caja_chica');
    }
};
