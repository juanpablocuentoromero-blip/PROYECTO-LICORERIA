<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Presentaciones de venta: unidad (siempre), paquete y caja. El stock
        // sigue contándose en UNIDADES; "unidades_por_paquete" ya existía y
        // ahora también es la presentación "paquete" en la venta. La caja
        // (p. ej. 12 botellas de cerveza, 6 de Coca-Cola de 3 L) es nueva.
        Schema::table('productos', function (Blueprint $table) {
            $table->unsignedInteger('unidades_por_caja')->nullable()->after('unidades_por_paquete');
        });

        // En qué presentación se vendió la línea y cuántas (p. ej. "2 cajas").
        // `cantidad` sigue siendo siempre en unidades, así que stock, costos y
        // reportes no cambian.
        Schema::table('detalle_pedidos', function (Blueprint $table) {
            $table->string('presentacion', 10)->default('unidad')->after('cantidad');
            $table->unsignedInteger('cantidad_presentacion')->nullable()->after('presentacion');
        });
    }

    public function down(): void
    {
        Schema::table('detalle_pedidos', function (Blueprint $table) {
            $table->dropColumn(['presentacion', 'cantidad_presentacion']);
        });

        Schema::table('productos', function (Blueprint $table) {
            $table->dropColumn('unidades_por_caja');
        });
    }
};
