<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 * Paso 4 — funcionalidades nuevas:
 *  4.2 alertas        -> tabla `alertas`
 *  4.4 auditoría      -> tabla `auditorias`
 *  4.5 devoluciones   -> `devoluciones`, `detalle_devoluciones`, columnas en pedidos/cajas
 *  4.6 pagos mixtos   -> `pagos_venta`
 */
return new class extends Migration
{
    public function up(): void
    {
        // 4.4 — Quién cambió qué y cuándo (valor anterior y nuevo).
        Schema::create('auditorias', function (Blueprint $table) {
            $table->id();
            $table->foreignId('usuario_id')->nullable()->constrained('usuarios')->nullOnDelete();
            // Se guarda el nombre aparte: si el usuario se borra, el rastro queda legible.
            $table->string('usuario_nombre')->nullable();
            $table->string('accion', 20);            // crear | actualizar | eliminar | ajuste
            $table->string('entidad', 30);           // producto | usuario | inventario
            $table->unsignedBigInteger('entidad_id')->nullable();
            $table->string('descripcion', 255);      // "Producto: Cerveza Paceña"
            $table->string('campo', 60)->nullable(); // precio_venta, stock, rol...
            $table->text('valor_anterior')->nullable();
            $table->text('valor_nuevo')->nullable();
            $table->timestamp('created_at')->useCurrent();

            $table->index(['entidad', 'entidad_id']);
            $table->index(['entidad', 'campo']);
            $table->index('created_at');
        });

        // 4.2 — Alertas de stock mínimo y vencimiento (una por producto y tipo).
        Schema::create('alertas', function (Blueprint $table) {
            $table->id();
            $table->string('tipo', 20);              // stock_minimo | vencimiento
            $table->foreignId('producto_id')->constrained('productos')->cascadeOnDelete();
            $table->string('severidad', 10)->default('aviso'); // aviso | critica
            $table->string('titulo');
            $table->string('mensaje');
            $table->boolean('activa')->default(true);  // false = ya se resolvió
            $table->boolean('leida')->default(false);
            $table->timestamp('leida_at')->nullable();
            $table->timestamps();

            $table->unique(['tipo', 'producto_id']);
            $table->index(['activa', 'leida']);
        });

        // 4.6 — Cada venta cobrada deja una fila por método usado.
        Schema::create('pagos_venta', function (Blueprint $table) {
            $table->id();
            $table->foreignId('pedido_id')->constrained('pedidos')->cascadeOnDelete();
            $table->foreignId('caja_id')->nullable()->constrained('cajas')->nullOnDelete();
            $table->string('metodo_pago', 20);       // efectivo | qr | tarjeta
            $table->decimal('monto', 10, 2);
            $table->timestamps();

            $table->index('pedido_id');
        });

        // 4.5 — Devoluciones parciales (nota de crédito).
        Schema::create('devoluciones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('pedido_id')->constrained('pedidos')->onDelete('restrict');
            $table->foreignId('usuario_id')->constrained('usuarios')->onDelete('restrict');
            // Caja abierta cuando se devolvió: la devolución en efectivo sale del arqueo de ese turno.
            $table->foreignId('caja_id')->nullable()->constrained('cajas')->nullOnDelete();
            $table->decimal('total', 10, 2);
            // Parte del total que se descontó de la deuda (venta a crédito) y no salió plata.
            $table->decimal('aplicado_a_saldo', 10, 2)->default(0);
            // Plata que realmente se le devolvió al cliente y por qué medio.
            $table->decimal('monto_reembolsado', 10, 2)->default(0);
            $table->string('metodo_reembolso', 20)->nullable(); // efectivo | qr | tarjeta
            $table->string('motivo', 255);
            $table->timestamps();

            $table->index('pedido_id');
            $table->index('caja_id');
        });

        Schema::create('detalle_devoluciones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('devolucion_id')->constrained('devoluciones')->cascadeOnDelete();
            $table->foreignId('detalle_pedido_id')->constrained('detalle_pedidos')->onDelete('restrict');
            $table->foreignId('producto_id')->constrained('productos')->onDelete('restrict');
            $table->unsignedInteger('cantidad');
            $table->decimal('monto', 10, 2);
            $table->timestamps();
        });

        Schema::table('pedidos', function (Blueprint $table) {
            $table->decimal('monto_devuelto', 10, 2)->default(0)->after('total');
        });

        Schema::table('cajas', function (Blueprint $table) {
            // Foto del turno (se congela al cerrar, igual que el resto).
            $table->decimal('monto_devoluciones_efectivo', 10, 2)->nullable();
            $table->decimal('monto_devoluciones_total', 10, 2)->nullable();
            $table->unsignedInteger('cantidad_devoluciones')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('cajas', function (Blueprint $table) {
            $table->dropColumn(['monto_devoluciones_efectivo', 'monto_devoluciones_total', 'cantidad_devoluciones']);
        });

        Schema::table('pedidos', function (Blueprint $table) {
            $table->dropColumn('monto_devuelto');
        });

        Schema::dropIfExists('detalle_devoluciones');
        Schema::dropIfExists('devoluciones');
        Schema::dropIfExists('pagos_venta');
        Schema::dropIfExists('alertas');
        Schema::dropIfExists('auditorias');
    }
};
