<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('cajas', function (Blueprint $table) {
            // Foto del turno, congelada al cerrar.
            $table->decimal('monto_ventas_qr', 10, 2)->nullable()->after('monto_ventas_efectivo');
            $table->decimal('monto_ventas_tarjeta', 10, 2)->nullable()->after('monto_ventas_qr');
            $table->decimal('monto_ventas_total', 10, 2)->nullable()->after('monto_ventas_tarjeta');
            $table->unsignedInteger('cantidad_ventas')->nullable()->after('monto_ventas_total');
            $table->unsignedInteger('cantidad_anuladas')->nullable()->after('cantidad_ventas');
            $table->decimal('monto_anulado', 10, 2)->nullable()->after('cantidad_anuladas');
            $table->json('detalle_vendedores')->nullable()->after('monto_anulado');

            // La observación de cierre ya no pisa la de apertura.
            $table->string('observaciones_cierre', 255)->nullable()->after('observaciones');

            // Nombre de quien cerró, congelado: la auditoría no cambia
            // aunque después renombren al usuario.
            $table->string('cerrada_por_nombre')->nullable()->after('usuario_cierre_id');
        });
    }

    public function down(): void
    {
        Schema::table('cajas', function (Blueprint $table) {
            $table->dropColumn([
                'monto_ventas_qr', 'monto_ventas_tarjeta', 'monto_ventas_total',
                'cantidad_ventas', 'cantidad_anuladas', 'monto_anulado',
                'detalle_vendedores', 'observaciones_cierre', 'cerrada_por_nombre',
            ]);
        });
    }
};
