<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('promociones', function (Blueprint $table) {
            $table->id();
            $table->string('nombre', 120);
            // volumen = "llevando N o más"; horario = happy hour por franja
            // y días; cupon = se aplica solo si el cliente/cajero escribe el código.
            $table->string('tipo', 20);
            // A qué productos alcanza: todo | categoria | producto.
            $table->string('alcance', 20)->default('todo');
            $table->foreignId('categoria_id')->nullable()->constrained('categorias')->nullOnDelete();
            $table->foreignId('producto_id')->nullable()->constrained('productos')->nullOnDelete();
            // porcentaje = % del importe elegible; monto = Bs fijos, una vez,
            // repartidos entre las líneas elegibles.
            $table->string('tipo_descuento', 20);
            $table->decimal('valor', 10, 2);

            // Reglas (cada tipo usa las suyas; el resto queda null).
            $table->unsignedInteger('cantidad_minima')->nullable();   // volumen
            $table->time('hora_inicio')->nullable();                  // horario
            $table->time('hora_fin')->nullable();                     // horario
            $table->string('dias_semana', 20)->nullable();            // "1,2,3,4,5" (0=domingo)
            $table->string('codigo', 40)->nullable()->unique();       // cupón
            $table->unsignedInteger('usos_maximos')->nullable();      // cupón: tope total
            $table->unsignedInteger('usos_actuales')->default(0);

            // Vigencia general (opcional) y estado.
            $table->date('fecha_inicio')->nullable();
            $table->date('fecha_fin')->nullable();
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        Schema::table('detalle_pedidos', function (Blueprint $table) {
            // Cuánto del descuento de la línea vino de promociones (el resto
            // es el descuento manual del cajero) y cuáles fueron.
            $table->decimal('descuento_promocion', 10, 2)->default(0)->after('descuento');
            $table->string('promocion_aplicada', 255)->nullable()->after('descuento_promocion');
        });

        Schema::table('pedidos', function (Blueprint $table) {
            $table->string('cupon_codigo', 40)->nullable()->after('descuento');
        });
    }

    public function down(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            $table->dropColumn('cupon_codigo');
        });

        Schema::table('detalle_pedidos', function (Blueprint $table) {
            $table->dropColumn(['descuento_promocion', 'promocion_aplicada']);
        });

        Schema::dropIfExists('promociones');
    }
};
