<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Tabla propia (en vez de reutilizar la `password_reset_tokens` que trae
    // Laravel por defecto) porque acá conviven DOS audiencias con la misma
    // dirección de correo posible: el staff (tabla `usuarios`) y los
    // clientes de la tienda (tabla `clientes`). La columna `tipo` evita que
    // un token pensado para restablecer la contraseña de un cliente sirva
    // para tocar la cuenta de un usuario interno con el mismo email.
    public function up(): void
    {
        Schema::create('tokens_recuperacion_password', function (Blueprint $table) {
            $table->id();
            $table->string('email');
            $table->string('tipo'); // usuario | cliente
            $table->string('token'); // se guarda hasheado (Hash::make), nunca en texto plano
            $table->timestamp('created_at')->nullable();

            $table->index(['email', 'tipo']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tokens_recuperacion_password');
    }
};
