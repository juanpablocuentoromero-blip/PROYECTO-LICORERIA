<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pedidos_compra', function (Blueprint $table) {
            $table->id();
            $table->foreignId('proveedor_id')->constrained('proveedores')->onDelete('restrict');
            $table->foreignId('usuario_id')->constrained('usuarios')->onDelete('restrict');
            // pendiente: se hizo el pedido al proveedor pero todavía no llegó (NO suma stock).
            // recibido: la mercadería llegó; al pasar a este estado se suma el stock
            //           automáticamente y se registra el movimiento de inventario.
            // cancelado: el pedido no se concretó (solo se puede cancelar si sigue pendiente).
            $table->string('estado')->default('pendiente');
            $table->decimal('subtotal', 10, 2)->default(0);
            $table->decimal('total', 10, 2)->default(0);
            $table->text('observaciones')->nullable();
            $table->timestamp('recibido_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pedidos_compra');
    }
};
