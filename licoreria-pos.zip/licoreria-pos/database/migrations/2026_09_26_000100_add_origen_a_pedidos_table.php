<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            // 'mostrador': lo registró un empleado desde Venta/Pedidos.
            // 'online': lo hizo el propio cliente desde la tienda
            // (PedidoController::crearComoCliente). Antes no había forma de
            // distinguirlos, así que el filtro "el vendedor solo ve sus
            // pedidos" (PedidoController::index) dejaba fuera TODOS los
            // pedidos hechos por clientes (quedaban a nombre del usuario
            // "de sistema", nunca de un vendedor real): el vendedor nunca
            // se enteraba de que habían llegado.
            $table->string('origen', 20)->default('mostrador')->after('usuario_id');
        });
    }

    public function down(): void
    {
        Schema::table('pedidos', function (Blueprint $table) {
            $table->dropColumn('origen');
        });
    }
};
