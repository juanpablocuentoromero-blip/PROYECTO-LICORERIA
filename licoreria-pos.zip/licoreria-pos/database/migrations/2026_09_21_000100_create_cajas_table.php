<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cajas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('almacen_id')->constrained('almacenes')->onDelete('restrict');
            $table->foreignId('usuario_apertura_id')->constrained('usuarios')->onDelete('restrict');
            $table->foreignId('usuario_cierre_id')->nullable()->constrained('usuarios')->onDelete('restrict');

            $table->decimal('monto_apertura', 10, 2);

            // Estos tres se calculan y se congelan recién al cerrar (ver
            // CajaController::cerrar): son la "foto" de lo que pasó durante
            // el turno, para que el arqueo no cambie si después se anula
            // una venta vieja o se edita un movimiento de otra caja.
            $table->decimal('monto_ventas_efectivo', 10, 2)->nullable();
            $table->decimal('monto_ingresos_caja_chica', 10, 2)->nullable();
            $table->decimal('monto_egresos_caja_chica', 10, 2)->nullable();

            $table->decimal('monto_cierre_esperado', 10, 2)->nullable();
            $table->decimal('monto_cierre_real', 10, 2)->nullable();
            $table->decimal('diferencia', 10, 2)->nullable();

            $table->string('estado')->default('abierta'); // abierta | cerrada
            $table->text('observaciones')->nullable();

            $table->timestamp('abierta_at');
            $table->timestamp('cerrada_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cajas');
    }
};
